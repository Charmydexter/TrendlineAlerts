package com.trendlinealerts.core

import com.trendlinealerts.core.model.BacktestTrade
import com.trendlinealerts.core.ml.DailyRecord
import com.trendlinealerts.core.ml.LongTermHistory
import com.trendlinealerts.core.ml.ProvenGate
import com.trendlinealerts.core.indicators.RegressionChannel
import com.trendlinealerts.core.model.TradeTiming
import com.trendlinealerts.core.model.TradeCloseReason
import com.trendlinealerts.core.model.ClosedTrade
import com.trendlinealerts.core.trade.TradeTracker
import org.junit.Assert.assertNull
import com.trendlinealerts.core.analytics.TradeRiskCalculator
import com.trendlinealerts.core.analytics.HeikinAshiConverter
import com.trendlinealerts.core.dispatcher.AlertDispatcher
import com.trendlinealerts.core.indicators.ScalpingIndicators
import com.trendlinealerts.core.ml.LogisticMlEngine
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.IndicatorId
import com.trendlinealerts.core.model.IndicatorPriorityTier
import com.trendlinealerts.core.model.SignalAction
import com.trendlinealerts.core.model.SignalCandidate
import com.trendlinealerts.core.model.SignalStateCodec
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.Timeframe
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreUnitTests {

    private val t0 = 1_700_000_000_000L

    private fun syntheticCandles(count: Int, tfMs: Long = 60_000L): List<Candle> {
        val out = ArrayList<Candle>(count)
        var price = 100.0
        for (i in 0 until count) {
            val wave = sin(i / 14.0) * 0.45 + sin(i / 41.0) * 0.65
            val drift = if ((i / 120) % 2 == 0) 0.03 else -0.025
            val open = price
            val close = (price + wave * 0.15 + drift).coerceAtLeast(10.0)
            val high = maxOf(open, close) + 0.18
            val low = minOf(open, close) - 0.16
            val vol = 100.0 + (i % 17) * 18.0
            out.add(Candle(t0 + i * tfMs, open, high, low, close, vol, true))
            price = close
        }
        return out
    }

    @Test
    fun timeframesExcludeGreaterThan90DaysAndDefaultTo1m() {
        val defaults = AlertSettings()
        assertEquals(Timeframe.M1, defaults.timeframe)
        assertEquals(1.0, defaults.minProfitMultiplier, 1e-6)
        assertEquals(listOf("1m", "3m", "5m", "15m", "30m"), Timeframe.entries.map { it.label })
        assertTrue(Timeframe.entries.all { it.historyDays <= 90 })
        assertEquals(28, Timeframe.M1.historyDays)
        assertEquals(7, Timeframe.M1.initialTrainDays)
        assertEquals(21, Timeframe.M1.evalDays)
        assertEquals(listOf("4H", "1H", "30m", "15m"), Timeframe.M1.chartRanges.map { it.key })
    }

    private fun rampWithLastClose(count: Int, lastMultiplier: Double): List<Candle> = List(count) { i ->
        val base = 100.0 + 0.1 * i
        val close = if (i == count - 1) base * lastMultiplier else base
        Candle(i * 60_000L, base, maxOf(base, close) + 0.05, minOf(base, close) - 0.05, close, 100.0)
    }

    @Test
    fun channelPositionIsNearZeroOnAStraightTrendAndLargeOnAnOutlier() {
        val n = ScalpingIndicators.FEATURE_COUNT
        val flatLine = ScalpingIndicators.computeMatrix(rampWithLastClose(80, 1.0), Timeframe.M1)
        assertEquals(0.0, flatLine.channelZSeries.last(), 0.05)

        val up = ScalpingIndicators.computeMatrix(rampWithLastClose(80, 1.03), Timeframe.M1)
        assertTrue("up ${up.channelZSeries.last()}", up.channelZSeries.last() > ScalpingIndicators.CHANNEL_ENTRY_Z)
        val featureUp = up.features[79 * n + IndicatorId.LINREG_CHANNEL_POSITION.ordinal]
        assertTrue("feature $featureUp", featureUp in 1.6f..3.0f)

        val down = ScalpingIndicators.computeMatrix(rampWithLastClose(80, 0.97), Timeframe.M1)
        assertTrue("down ${down.channelZSeries.last()}", down.channelZSeries.last() < -ScalpingIndicators.CHANNEL_ENTRY_Z)

        val channel = RegressionChannel.compute(rampWithLastClose(80, 1.0), ScalpingIndicators.channelWindow(Timeframe.M1))!!
        assertEquals(20, channel.startIdx)
        assertEquals(79, channel.endIdx)
        assertTrue(channel.upperEnd > channel.midEnd && channel.lowerEnd < channel.midEnd)
        assertNull(RegressionChannel.compute(rampWithLastClose(30, 1.0), 60))
    }

    @Test
    fun entriesOnlyHappenAtTheChannelExtremes() {
        fun decide(pL: Double, pS: Double, channelZ: Double?) = LogisticMlEngine.resolveSignalDecision(
            pLong = pL,
            pShort = pS,
            mode = AssetMode.GENERAL,
            lastSignalDirection = null,
            threshold = 0.58,
            ofiValue = 0.0,
            rsi7SlopeValue = 0.0,
            channelZ = channelZ
        ).action
        assertEquals(SignalAction.LONG, decide(0.75, 0.20, -2.0))
        assertEquals(SignalAction.WAIT, decide(0.75, 0.20, 0.0))   // model likes it, price is mid-channel
        assertEquals(SignalAction.WAIT, decide(0.75, 0.20, 2.0))   // wrong end of the channel for a long
        assertEquals(SignalAction.SHORT, decide(0.20, 0.75, 2.0))
        assertEquals(SignalAction.WAIT, decide(0.20, 0.75, -1.0))
        assertEquals(SignalAction.LONG, decide(0.75, 0.20, null))  // no channel rule given
    }

    @Test
    fun timeOfDayCluesFollowUtcClockAndWeekend() {
        val n = ScalpingIndicators.FEATURE_COUNT
        // 2024-01-06 00:00 UTC is a Saturday; 2024-01-08 06:00 UTC is a Monday.
        val saturday = 1_704_499_200_000L
        val monday = 1_704_693_600_000L
        fun bars(start: Long) = List(60) { i ->
            val px = 100.0 + (i % 3) * 0.01
            Candle(start + i * 60_000L, px, px + 0.05, px - 0.05, px, 10.0)
        }
        val sat = ScalpingIndicators.computeMatrix(bars(saturday), Timeframe.M1)
        assertEquals(1f, sat.features[IndicatorId.WEEKEND.ordinal], 0f)
        assertEquals(0f, sat.features[IndicatorId.TIME_OF_DAY_SIN.ordinal], 1e-6f)
        assertEquals(1f, sat.features[IndicatorId.TIME_OF_DAY_COS.ordinal], 1e-6f)
        val mon = ScalpingIndicators.computeMatrix(bars(monday), Timeframe.M1)
        assertEquals(0f, mon.features[IndicatorId.WEEKEND.ordinal], 0f)
        // 06:00 UTC is a quarter of the day: sine 1, cosine 0 (first bar of the series).
        assertEquals(1f, mon.features[IndicatorId.TIME_OF_DAY_SIN.ordinal], 1e-6f)
        assertEquals(0f, mon.features[IndicatorId.TIME_OF_DAY_COS.ordinal], 1e-5f)
        assertEquals(n * 60, mon.features.size)
    }

    @Test
    fun provenGateNeedsEnoughProfitableTrades() {
        val now = t0 + 30L * 86_400_000L
        fun trade(daysAgo: Int, net: Double) = BacktestTrade(
            entryTimeMs = now - daysAgo * 86_400_000L, exitTimeMs = now - daysAgo * 86_400_000L + 60_000L,
            direction = EntryDirection.LONG, entryPrice = 1.0, exitPrice = 1.0,
            netReturnPct = net, probability = 0.7, won = net > 0.0
        )
        val good = (1..9).map { trade(it, 0.3) } + trade(2, -0.2)
        assertTrue(ProvenGate.check(good, now).proven)
        assertFalse(ProvenGate.check(good.take(5), now).proven)                 // too few trades
        assertFalse(ProvenGate.check((1..10).map { trade(it, -0.1) }, now).proven) // losing
        assertFalse(ProvenGate.check((25..40).map { trade(it, 0.5) }, now).proven) // too old
    }

    @Test
    fun longTermHistoryAccumulatesWithoutDoubleCounting() {
        val day = 86_400_000L
        val now = t0 + 400L * day
        fun rec(daysAgo: Int, trades: Int, wins: Int, net: Double, clues: List<IndicatorId> = emptyList()) = DailyRecord(
            epochDay = Math.floorDiv(now, day) - daysAgo, symbol = "SOLUSDT", timeframe = Timeframe.M1,
            trades = trades, wins = wins, netReturnPct = net,
            grossWonPct = if (net > 0) net else 0.0, grossLostPct = if (net < 0) -net else 0.0, clues = clues
        )
        val first = listOf(rec(40, 10, 6, 1.0), rec(0, 4, 2, -0.4, listOf(IndicatorId.VOLUME_SURGE)))
        // Re-saving the same day replaces it; an empty clue list keeps the clues saved earlier.
        val merged = LongTermHistory.upsert(first, listOf(rec(0, 5, 3, 0.5)), now)
        assertEquals(2, merged.size)
        assertEquals(5, merged.last().trades)
        assertEquals(listOf(IndicatorId.VOLUME_SURGE), merged.last().clues)

        val periods = LongTermHistory.periods(merged, "SOLUSDT", Timeframe.M1, now)
        assertEquals(5, periods[0].trades)          // last month: only today
        assertEquals(15, periods[1].trades)         // last 3 months: both days
        assertEquals(60.0, periods[1].winRatePct, 1e-9)      // 9 wins out of 15
        assertEquals(0, LongTermHistory.periods(merged, "OTHER", Timeframe.M1, now)[3].trades)

        // Anything older than a year is dropped.
        val old = listOf(rec(400, 3, 1, 0.1))
        assertTrue(LongTermHistory.upsert(old, emptyList(), now).isEmpty())
    }

    private fun tradeSettings() = AlertSettings(capitalUsd = 100.0, maxLossUsd = 0.5, minProfitMultiplier = 2.0)

    @Test
    fun tradeTrackerAssumesEntryAfterThreeMinutesAndSeesTargetAndStop() {
        val trade = TradeTracker.open(EntryDirection.LONG, 100.0, tradeSettings(), alertAtMs = t0, horizonMs = 12 * 60_000L)!!
        assertEquals(99.5, trade.slPrice, 1e-9)
        assertEquals(101.0, trade.tpPrice, 1e-9)
        assertEquals(TradeTracker.Phase.WAITING_ENTRY, TradeTracker.phase(trade, t0 + 60_000L))
        assertEquals(TradeTracker.Phase.OPEN, TradeTracker.phase(trade, t0 + TradeTiming.AUTO_ENTRY_DELAY_MS))

        val entryAt = trade.entryAtMs
        // A spike before the assumed entry time is ignored.
        val early = Candle(entryAt - 60_000L, 100.0, 102.0, 100.0, 101.0, 10.0, true)
        val quiet = Candle(entryAt, 100.0, 100.4, 99.8, 100.2, 10.0, true)
        assertNull(TradeTracker.checkPriceExit(trade, listOf(early, quiet)))

        val hitTarget = Candle(entryAt + 60_000L, 100.2, 101.2, 100.1, 101.0, 10.0, true)
        val c1 = TradeTracker.checkPriceExit(trade, listOf(early, quiet, hitTarget))!!
        assertEquals(TradeCloseReason.TARGET_HIT, c1.reason)
        assertEquals(1.0, c1.pnlUsd, 1e-9)

        // One candle touching both stop and target counts as the stop (cautious).
        val both = Candle(entryAt + 60_000L, 100.0, 101.5, 99.0, 100.0, 10.0, true)
        val c2 = TradeTracker.checkPriceExit(trade, listOf(quiet, both))!!
        assertEquals(TradeCloseReason.STOP_HIT, c2.reason)
        assertEquals(-0.5, c2.pnlUsd, 1e-9)
    }

    @Test
    fun tradeTrackerHandlesShortsProfitAndHistoryCap() {
        val trade = TradeTracker.open(EntryDirection.SHORT, 100.0, tradeSettings(), t0, 60_000L)!!
        assertEquals(100.5, trade.slPrice, 1e-9)
        assertEquals(99.0, trade.tpPrice, 1e-9)
        assertEquals(0.4, TradeTracker.pnlAt(trade, 99.6), 1e-9)
        assertEquals(-0.3, TradeTracker.pnlAt(trade, 100.3), 1e-9)

        val closure = TradeTracker.closeAt(trade, TradeCloseReason.EXPIRED, 100.0)
        var history = emptyList<ClosedTrade>()
        for (i in 1..120) history = TradeTracker.appendClosed(history, TradeTracker.toClosed(trade, closure, t0 + i))
        assertEquals(TradeTiming.MAX_CLOSED_PER_ASSET, history.size)
    }

    @Test
    fun exitAlertsReachGeneralAssetsAndSilentOnesOnlyGoToTheLog() {
        val now = t0 + 10_000L
        val exit = SignalCandidate("AAAUSDT", EventType.EXIT_LONG, SignalAction.EXIT, 1.0, 0.3, 0.6, 0.0, "x", now)
        val silent = exit.copy(symbol = "BBBUSDT", silent = true)
        val plan = AlertDispatcher.plan(listOf(exit, silent), positionedSymbols = emptySet(), generalMonitoringOn = true)
        assertEquals(listOf("AAAUSDT"), plan.individual.map { it.symbol })
        assertEquals(listOf("BBBUSDT"), plan.logOnly.map { it.symbol })
    }

    @Test
    fun stateWithActiveTradeSurvivesCodec() {
        val trade = TradeTracker.open(EntryDirection.LONG, 100.0, tradeSettings(), t0, 60_000L)
        val closed = ClosedTrade(EntryDirection.LONG, 100.0, 101.0, TradeCloseReason.TARGET_HIT, 1.0, true, t0, t0 + 1)
        val st = SymbolSignalState(symbol = "SOLUSDT", activeTrade = trade, closedTrades = listOf(closed))
        assertEquals(st, SignalStateCodec.decode(SignalStateCodec.encode(st), "SOLUSDT"))
    }

    @Test
    fun tradeLevelsFollowTradeAmountAndMaxLoss() {
        val s = AlertSettings(capitalUsd = 100.0, maxLossUsd = 0.5, minProfitMultiplier = 2.0)
        assertEquals(0.5, s.stopLossPct, 1e-9)
        assertEquals(1.0, s.takeProfitPct, 1e-9)
        assertEquals(0.5, s.slUsd, 1e-9)
        assertEquals(1.0, s.tpUsd, 1e-9)

        val long = TradeRiskCalculator.compute(100.0, EntryDirection.LONG, s)!!
        assertEquals(99.5, long.slPrice, 1e-9)
        assertEquals(101.0, long.tpPrice, 1e-9)
        val short = TradeRiskCalculator.compute(100.0, EntryDirection.SHORT, s)!!
        assertEquals(100.5, short.slPrice, 1e-9)
        assertEquals(99.0, short.tpPrice, 1e-9)

        // The stop is never tighter than 0.10% of price, and the dollars follow the real stop.
        val tight = AlertSettings(capitalUsd = 1000.0, maxLossUsd = 0.5)
        assertEquals(0.10, tight.stopLossPct, 1e-9)
        assertEquals(1.0, tight.slUsd, 1e-9)
        assertNull(TradeRiskCalculator.compute(0.0, EntryDirection.LONG, s))
    }

    @Test
    fun profitMultiplierIsDecimalWithMinimumOfOne() {
        assertEquals(1.0, AlertSettings(minProfitMultiplier = 0.3).effectiveMinProfitMultiplier, 1e-9)
        assertEquals(1.0, AlertSettings(minProfitMultiplier = 1.0).effectiveMinProfitMultiplier, 1e-9)
        assertEquals(1.5, AlertSettings(minProfitMultiplier = 1.5).effectiveMinProfitMultiplier, 1e-9)
        assertEquals(10.0, AlertSettings(minProfitMultiplier = 25.0).effectiveMinProfitMultiplier, 1e-9)
    }

    private fun trendCandles(count: Int, startPrice: Double, step: Double): List<Candle> =
        List(count) { i ->
            val close = startPrice + i * step
            Candle(
                openTimeMs = i * 60_000L,
                open = close - step,
                high = maxOf(close, close - step) + 0.2,
                low = minOf(close, close - step) - 0.2,
                close = close,
                volume = 100.0
            )
        }

    @Test
    fun linRegSlopeAndDonchianPositionFollowTheTrend() {
        val n = ScalpingIndicators.FEATURE_COUNT
        val linIdx = IndicatorId.NORM_LINREG_SLOPE.ordinal
        val donIdx = IndicatorId.DONCHIAN_POSITION.ordinal

        val up = ScalpingIndicators.computeMatrix(trendCandles(80, 100.0, 0.5), Timeframe.M1)
        val upLast = 79 * n
        assertTrue("up slope ${up.features[upLast + linIdx]}", up.features[upLast + linIdx] > 0.5f)
        assertTrue("up donchian ${up.features[upLast + donIdx]}", up.features[upLast + donIdx] > 1.5f)

        val down = ScalpingIndicators.computeMatrix(trendCandles(80, 200.0, -0.5), Timeframe.M1)
        val downLast = 79 * n
        assertTrue("down slope ${down.features[downLast + linIdx]}", down.features[downLast + linIdx] < -0.5f)
        assertTrue("down donchian ${down.features[downLast + donIdx]}", down.features[downLast + donIdx] < -1.5f)

        val flat = ScalpingIndicators.computeMatrix(trendCandles(80, 100.0, 0.0), Timeframe.M1)
        val flatLast = 79 * n
        assertEquals(0f, flat.features[flatLast + linIdx], 0.05f)

        // Both features stay inside their documented bounds on every bar.
        for (i in 0 until 80) {
            assertTrue(up.features[i * n + donIdx] in -2f..2f)
            assertTrue(up.features[i * n + linIdx] in -4f..4f)
        }
    }

    @Test
    fun scalpingIndicatorsIncludeZScoreAndShiftPriorityByTimeframe() {
        assertEquals(26, ScalpingIndicators.FEATURE_COUNT)
        assertTrue(IndicatorId.LINREG_CHANNEL_POSITION in ScalpingIndicators.ALL_INDICATORS)
        assertTrue(IndicatorId.PRICE_ZSCORE in ScalpingIndicators.ALL_INDICATORS)
        assertTrue(IndicatorId.NORM_LINREG_SLOPE in ScalpingIndicators.ALL_INDICATORS)
        assertTrue(IndicatorId.DONCHIAN_POSITION in ScalpingIndicators.ALL_INDICATORS)
        // Every indicator needs a priority for every timeframe or getPriority would throw.
        for (tf in Timeframe.entries) for (id in ScalpingIndicators.ALL_INDICATORS) {
            assertNotNull(ScalpingIndicators.getPriority(tf, id))
        }

        val m1Ofi = ScalpingIndicators.getPriority(Timeframe.M1, IndicatorId.ORDER_FLOW_IMBALANCE)
        val m30Ofi = ScalpingIndicators.getPriority(Timeframe.M30, IndicatorId.ORDER_FLOW_IMBALANCE)
        val m1Z = ScalpingIndicators.getPriority(Timeframe.M1, IndicatorId.PRICE_ZSCORE)
        val m30Dmi = ScalpingIndicators.getPriority(Timeframe.M30, IndicatorId.DI_DIRECTIONAL)

        assertEquals(IndicatorPriorityTier.LEAD, m1Ofi.tier)
        assertEquals(IndicatorPriorityTier.LEAD, m1Z.tier)
        assertEquals(IndicatorPriorityTier.SECONDARY, m30Ofi.tier)
        assertEquals(IndicatorPriorityTier.LEAD, m30Dmi.tier)
        assertTrue(m1Ofi.weight > m30Ofi.weight)

        val bars = syntheticCandles(120)
        val computed = ScalpingIndicators.computeMatrix(bars, Timeframe.M1)
        assertEquals(bars.size * ScalpingIndicators.FEATURE_COUNT, computed.features.size)
        assertEquals(bars.size, computed.zScoreSeries.size)
        assertTrue(computed.zScoreSeries.all { !it.isNaN() && !it.isInfinite() })
    }

    @Test
    fun logisticMlEngineTrainsWalkForwardAndProducesDriftBenchmarks() {
        // 8 days of 5m candles (~2304 bars) for fast unit test verification
        val bars = syntheticCandles(2400, tfMs = 5 * 60_000L)
        val settings = AlertSettings(timeframe = Timeframe.M5, minProfitMultiplier = 1.4, signalThreshold = 0.56)

        val eval1 = LogisticMlEngine.trainAndEvaluateAsset(
            symbol = "SUIUSDT",
            candles = bars,
            timeframe = Timeframe.M5,
            settings = settings,
            mode = AssetMode.GENERAL,
            lastSignalDirection = null,
            previousActiveIndicators = emptyList(),
            masterModel = null,
            nowMs = t0 + bars.size * 5 * 60_000L
        )
        assertEquals("SUIUSDT", eval1.snapshot.symbol)
        assertEquals(ScalpingIndicators.FEATURE_COUNT, eval1.snapshot.indicatorStats.size)
        assertTrue(eval1.snapshot.pLong in 0.0..1.0)
        assertTrue(eval1.snapshot.pShort in 0.0..1.0)
        assertNotNull(eval1.snapshot.drift.benchmarks.d21)

        val master = LogisticMlEngine.trainMasterModel(
            timeframe = Timeframe.M5,
            assetSamples = mapOf("SUIUSDT" to eval1.sampledFeatures)
        )
        assertNotNull(master)
        assertTrue(master!!.topIndicators.isNotEmpty())
    }

    @Test
    fun positionedModeEmitsExitWhenLastDirectionIsExhausted() {
        val longExit = LogisticMlEngine.resolveSignalDecision(
            pLong = 0.38,
            pShort = 0.55,
            mode = AssetMode.POSITIONED,
            lastSignalDirection = EntryDirection.LONG,
            threshold = 0.58,
            ofiValue = -0.6,
            rsi7SlopeValue = -0.7,
            zScore = 2.4
        )
        assertEquals(SignalAction.EXIT, longExit.action)
        assertTrue(longExit.exhaustionScore > 0.3)

        val shortHold = LogisticMlEngine.resolveSignalDecision(
            pLong = 0.28,
            pShort = 0.69,
            mode = AssetMode.POSITIONED,
            lastSignalDirection = EntryDirection.SHORT,
            threshold = 0.58,
            ofiValue = -0.4,
            rsi7SlopeValue = -0.3,
            zScore = -0.8
        )
        assertEquals(SignalAction.WAIT, shortHold.action)
    }

    @Test
    fun alertDispatcherClustersGeneralAndSeparatesPositionedExits() {
        val now = t0 + 10_000L
        val events = listOf(
            SignalCandidate("AAAUSDT", EventType.LONG_SIGNAL, SignalAction.LONG, 1.23, 0.68, 0.22, 1.1, "OFI", now),
            SignalCandidate("BBBUSDT", EventType.SHORT_SIGNAL, SignalAction.SHORT, 4.56, 0.21, 0.70, -1.4, "Z-Score", now),
            SignalCandidate("POSUSDT", EventType.EXIT_LONG, SignalAction.EXIT, 2.34, 0.35, 0.58, 2.3, "RSI7 d", now)
        )
        val plan = AlertDispatcher.plan(events, positionedSymbols = setOf("POSUSDT"), generalMonitoringOn = true)
        assertEquals(listOf("AAAUSDT", "BBBUSDT"), plan.cluster.map { it.symbol })
        assertEquals(listOf("POSUSDT"), plan.individual.map { it.symbol })
    }

    @Test
    fun stateSurvivesCodecRoundTripAndHeikinAshiWorks() {
        val st = SymbolSignalState(
            symbol = "SOLUSDT",
            mode = AssetMode.POSITIONED,
            lastProcessedOpenMs = t0,
            lastTrainedAtMs = t0 + 60_000L,
            lastAction = SignalAction.LONG,
            lastSignalDirection = EntryDirection.LONG,
            previousActiveIndicators = listOf(IndicatorId.ORDER_FLOW_IMBALANCE, IndicatorId.PRICE_ZSCORE)
        )
        val encoded = SignalStateCodec.encode(st)
        val decoded = SignalStateCodec.decode(encoded, "SOLUSDT")
        assertEquals(st, decoded)

        val raw = listOf(
            Candle(t0, 10.0, 12.0, 9.0, 11.0, 100.0, true),
            Candle(t0 + 60_000L, 11.0, 15.0, 10.5, 14.0, 120.0, true)
        )
        val ha = HeikinAshiConverter.convert(raw)
        assertEquals(2, ha.size)
        assertEquals(10.5, ha[0].open, 1e-6)
        assertEquals(12.625, ha[1].close, 1e-6)
    }

    @Test
    fun masterAssetDefaultsToBtcAndComputesAltCorrelation() {
        val defaults = AlertSettings()
        assertEquals("BTCUSDT", defaults.masterAsset)
        assertEquals("ETHUSDT", AlertSettings.normalizeMasterAsset("eth/usdt"))

        val btc = syntheticCandles(80)
        val invertedAlt = btc.mapIndexed { idx, c ->
            val invClose = 200.0 - c.close
            val invOpen = if (idx == 0) invClose else 200.0 - btc[idx - 1].close
            Candle(c.openTimeMs, invOpen, maxOf(invOpen, invClose) + 0.1, minOf(invOpen, invClose) - 0.1, invClose, c.volume, true)
        }
        val coMovingComputed = ScalpingIndicators.computeMatrix(btc, Timeframe.M1, masterCandles = btc)
        val invertedComputed = ScalpingIndicators.computeMatrix(invertedAlt, Timeframe.M1, masterCandles = btc)

        assertTrue(coMovingComputed.latestBtcCorrelation > 0.9)
        assertTrue(invertedComputed.latestBtcCorrelation < -0.9)
    }
}
