package com.trendlinealerts.core

import com.trendlinealerts.core.analytics.HeikinAshiConverter
import com.trendlinealerts.core.dispatcher.AlertDispatcher
import com.trendlinealerts.core.indicators.ScalpingIndicators
import com.trendlinealerts.core.ml.LogisticMlEngine
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.IndicatorId
import com.trendlinealerts.core.model.IndicatorPriorityTier
import com.trendlinealerts.core.model.SignalAction
import com.trendlinealerts.core.model.SignalCandidate
import com.trendlinealerts.core.model.SignalStateCodec
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.Timeframe
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreUnitTests {

    private val t0 = 1_700_000_000_000L

    private fun syntheticCandles(count: Int, tfMs: Long = 60_000L): List<Candle> {
        val out = ArrayList<Candle>(count)
        var price = 100.0
        for (i in 0 until count) {
            val wave = sin(i / 14.0) * 0.45 + sin(i / 41.0) * 0.65
            val drift = if ((i / 120) % 2 == 0) 0.03 else -0.025
            val open = price
            val close = (price + wave * 0.15 + drift).coerceAtLeast(10.0)
            val high = maxOf(open, close) + 0.18
            val low = minOf(open, close) - 0.16
            val vol = 100.0 + (i % 17) * 18.0
            out.add(Candle(t0 + i * tfMs, open, high, low, close, vol, true))
            price = close
        }
        return out
    }

    @Test
    fun timeframesExcludeGreaterThan90DaysAndDefaultTo1m() {
        val defaults = AlertSettings()
        assertEquals(Timeframe.M1, defaults.timeframe)
        assertEquals(1.0, defaults.minProfitMultiplier, 1e-6)
        assertEquals(listOf("1m", "3m", "5m", "15m", "30m"), Timeframe.entries.map { it.label })
        assertTrue(Timeframe.entries.all { it.historyDays <= 90 })
        assertEquals(28, Timeframe.M1.historyDays)
        assertEquals(7, Timeframe.M1.initialTrainDays)
        assertEquals(21, Timeframe.M1.evalDays)
        assertEquals(listOf("4H", "1H", "30m", "15m"), Timeframe.M1.chartRanges.map { it.key })
    }

    @Test
    fun profitMultiplierIsDecimalWithMinimumOfOne() {
        assertEquals(1.0, AlertSettings(minProfitMultiplier = 0.3).effectiveMinProfitMultiplier, 1e-9)
        assertEquals(1.0, AlertSettings(minProfitMultiplier = 1.0).effectiveMinProfitMultiplier, 1e-9)
        assertEquals(1.5, AlertSettings(minProfitMultiplier = 1.5).effectiveMinProfitMultiplier, 1e-9)
        assertEquals(10.0, AlertSettings(minProfitMultiplier = 25.0).effectiveMinProfitMultiplier, 1e-9)
    }

    private fun trendCandles(count: Int, startPrice: Double, step: Double): List<Candle> =
        List(count) { i ->
            val close = startPrice + i * step
            Candle(
                openTimeMs = i * 60_000L,
                open = close - step,
                high = maxOf(close, close - step) + 0.2,
                low = minOf(close, close - step) - 0.2,
                close = close,
                volume = 100.0
            )
        }

    @Test
    fun linRegSlopeAndDonchianPositionFollowTheTrend() {
        val n = ScalpingIndicators.FEATURE_COUNT
        val linIdx = IndicatorId.NORM_LINREG_SLOPE.ordinal
        val donIdx = IndicatorId.DONCHIAN_POSITION.ordinal

        val up = ScalpingIndicators.computeMatrix(trendCandles(80, 100.0, 0.5), Timeframe.M1)
        val upLast = 79 * n
        assertTrue("up slope ${up.features[upLast + linIdx]}", up.features[upLast + linIdx] > 0.5f)
        assertTrue("up donchian ${up.features[upLast + donIdx]}", up.features[upLast + donIdx] > 1.5f)

        val down = ScalpingIndicators.computeMatrix(trendCandles(80, 200.0, -0.5), Timeframe.M1)
        val downLast = 79 * n
        assertTrue("down slope ${down.features[downLast + linIdx]}", down.features[downLast + linIdx] < -0.5f)
        assertTrue("down donchian ${down.features[downLast + donIdx]}", down.features[downLast + donIdx] < -1.5f)

        val flat = ScalpingIndicators.computeMatrix(trendCandles(80, 100.0, 0.0), Timeframe.M1)
        val flatLast = 79 * n
        assertEquals(0f, flat.features[flatLast + linIdx], 0.05f)

        // Both features stay inside their documented bounds on every bar.
        for (i in 0 until 80) {
            assertTrue(up.features[i * n + donIdx] in -2f..2f)
            assertTrue(up.features[i * n + linIdx] in -4f..4f)
        }
    }

    @Test
    fun scalpingIndicatorsIncludeZScoreAndShiftPriorityByTimeframe() {
        assertEquals(20, ScalpingIndicators.FEATURE_COUNT)
        assertTrue(IndicatorId.PRICE_ZSCORE in ScalpingIndicators.ALL_INDICATORS)
        assertTrue(IndicatorId.NORM_LINREG_SLOPE in ScalpingIndicators.ALL_INDICATORS)
        assertTrue(IndicatorId.DONCHIAN_POSITION in ScalpingIndicators.ALL_INDICATORS)
        // Every indicator needs a priority for every timeframe or getPriority would throw.
        for (tf in Timeframe.entries) for (id in ScalpingIndicators.ALL_INDICATORS) {
            assertNotNull(ScalpingIndicators.getPriority(tf, id))
        }

        val m1Ofi = ScalpingIndicators.getPriority(Timeframe.M1, IndicatorId.ORDER_FLOW_IMBALANCE)
        val m30Ofi = ScalpingIndicators.getPriority(Timeframe.M30, IndicatorId.ORDER_FLOW_IMBALANCE)
        val m1Z = ScalpingIndicators.getPriority(Timeframe.M1, IndicatorId.PRICE_ZSCORE)
        val m30Dmi = ScalpingIndicators.getPriority(Timeframe.M30, IndicatorId.DI_DIRECTIONAL)

        assertEquals(IndicatorPriorityTier.LEAD, m1Ofi.tier)
        assertEquals(IndicatorPriorityTier.LEAD, m1Z.tier)
        assertEquals(IndicatorPriorityTier.SECONDARY, m30Ofi.tier)
        assertEquals(IndicatorPriorityTier.LEAD, m30Dmi.tier)
        assertTrue(m1Ofi.weight > m30Ofi.weight)

        val bars = syntheticCandles(120)
        val computed = ScalpingIndicators.computeMatrix(bars, Timeframe.M1)
        assertEquals(bars.size * ScalpingIndicators.FEATURE_COUNT, computed.features.size)
        assertEquals(bars.size, computed.zScoreSeries.size)
        assertTrue(computed.zScoreSeries.all { !it.isNaN() && !it.isInfinite() })
    }

    @Test
    fun logisticMlEngineTrainsWalkForwardAndProducesDriftBenchmarks() {
        // 8 days of 5m candles (~2304 bars) for fast unit test verification
        val bars = syntheticCandles(2400, tfMs = 5 * 60_000L)
        val settings = AlertSettings(timeframe = Timeframe.M5, minProfitMultiplier = 1.4, signalThreshold = 0.56)

        val eval1 = LogisticMlEngine.trainAndEvaluateAsset(
            symbol = "SUIUSDT",
            candles = bars,
            timeframe = Timeframe.M5,
            settings = settings,
            mode = AssetMode.GENERAL,
            lastSignalDirection = null,
            previousActiveIndicators = emptyList(),
            masterModel = null,
            nowMs = t0 + bars.size * 5 * 60_000L
        )
        assertEquals("SUIUSDT", eval1.snapshot.symbol)
        assertEquals(ScalpingIndicators.FEATURE_COUNT, eval1.snapshot.indicatorStats.size)
        assertTrue(eval1.snapshot.pLong in 0.0..1.0)
        assertTrue(eval1.snapshot.pShort in 0.0..1.0)
        assertNotNull(eval1.snapshot.drift.benchmarks.d21)

        val master = LogisticMlEngine.trainMasterModel(
            timeframe = Timeframe.M5,
            assetSamples = mapOf("SUIUSDT" to eval1.sampledFeatures)
        )
        assertNotNull(master)
        assertTrue(master!!.topIndicators.isNotEmpty())
    }

    @Test
    fun positionedModeEmitsExitWhenLastDirectionIsExhausted() {
        val longExit = LogisticMlEngine.resolveSignalDecision(
            pLong = 0.38,
            pShort = 0.55,
            mode = AssetMode.POSITIONED,
            lastSignalDirection = EntryDirection.LONG,
            threshold = 0.58,
            ofiValue = -0.6,
            rsi7SlopeValue = -0.7,
            zScore = 2.4
        )
        assertEquals(SignalAction.EXIT, longExit.action)
        assertTrue(longExit.exhaustionScore > 0.3)

        val shortHold = LogisticMlEngine.resolveSignalDecision(
            pLong = 0.28,
            pShort = 0.69,
            mode = AssetMode.POSITIONED,
            lastSignalDirection = EntryDirection.SHORT,
            threshold = 0.58,
            ofiValue = -0.4,
            rsi7SlopeValue = -0.3,
            zScore = -0.8
        )
        assertEquals(SignalAction.WAIT, shortHold.action)
    }

    @Test
    fun alertDispatcherClustersGeneralAndSeparatesPositionedExits() {
        val now = t0 + 10_000L
        val events = listOf(
            SignalCandidate("AAAUSDT", EventType.LONG_SIGNAL, SignalAction.LONG, 1.23, 0.68, 0.22, 1.1, "OFI", now),
            SignalCandidate("BBBUSDT", EventType.SHORT_SIGNAL, SignalAction.SHORT, 4.56, 0.21, 0.70, -1.4, "Z-Score", now),
            SignalCandidate("POSUSDT", EventType.EXIT_LONG, SignalAction.EXIT, 2.34, 0.35, 0.58, 2.3, "RSI7 d", now)
        )
        val plan = AlertDispatcher.plan(events, positionedSymbols = setOf("POSUSDT"), generalMonitoringOn = true)
        assertEquals(listOf("AAAUSDT", "BBBUSDT"), plan.cluster.map { it.symbol })
        assertEquals(listOf("POSUSDT"), plan.individual.map { it.symbol })
    }

    @Test
    fun stateSurvivesCodecRoundTripAndHeikinAshiWorks() {
        val st = SymbolSignalState(
            symbol = "SOLUSDT",
            mode = AssetMode.POSITIONED,
            lastProcessedOpenMs = t0,
            lastTrainedAtMs = t0 + 60_000L,
            lastAction = SignalAction.LONG,
            lastSignalDirection = EntryDirection.LONG,
            previousActiveIndicators = listOf(IndicatorId.ORDER_FLOW_IMBALANCE, IndicatorId.PRICE_ZSCORE)
        )
        val encoded = SignalStateCodec.encode(st)
        val decoded = SignalStateCodec.decode(encoded, "SOLUSDT")
        assertEquals(st, decoded)

        val raw = listOf(
            Candle(t0, 10.0, 12.0, 9.0, 11.0, 100.0, true),
            Candle(t0 + 60_000L, 11.0, 15.0, 10.5, 14.0, 120.0, true)
        )
        val ha = HeikinAshiConverter.convert(raw)
        assertEquals(2, ha.size)
        assertEquals(10.5, ha[0].open, 1e-6)
        assertEquals(12.625, ha[1].close, 1e-6)
    }

    @Test
    fun masterAssetDefaultsToBtcAndComputesAltCorrelation() {
        val defaults = AlertSettings()
        assertEquals("BTCUSDT", defaults.masterAsset)
        assertEquals("ETHUSDT", AlertSettings.normalizeMasterAsset("eth/usdt"))

        val btc = syntheticCandles(80)
        val invertedAlt = btc.mapIndexed { idx, c ->
            val invClose = 200.0 - c.close
            val invOpen = if (idx == 0) invClose else 200.0 - btc[idx - 1].close
            Candle(c.openTimeMs, invOpen, maxOf(invOpen, invClose) + 0.1, minOf(invOpen, invClose) - 0.1, invClose, c.volume, true)
        }
        val coMovingComputed = ScalpingIndicators.computeMatrix(btc, Timeframe.M1, masterCandles = btc)
        val invertedComputed = ScalpingIndicators.computeMatrix(invertedAlt, Timeframe.M1, masterCandles = btc)

        assertTrue(coMovingComputed.latestBtcCorrelation > 0.9)
        assertTrue(invertedComputed.latestBtcCorrelation < -0.9)
    }
}
