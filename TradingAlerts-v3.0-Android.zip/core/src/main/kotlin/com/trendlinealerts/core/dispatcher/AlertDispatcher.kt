package com.trendlinealerts.core.dispatcher

import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.SignalCandidate

data class DispatchPlan(
    val cluster: List<SignalCandidate>,
    val individual: List<SignalCandidate>,
    val missed: Map<String, List<SignalCandidate>>,
    val logOnly: List<SignalCandidate>
) {
    val isEmpty: Boolean
        get() = cluster.isEmpty() && individual.isEmpty() && missed.isEmpty() && logOnly.isEmpty()
}

object AlertDispatcher {
    fun plan(
        events: List<SignalCandidate>,
        positionedSymbols: Set<String>,
        generalMonitoringOn: Boolean
    ): DispatchPlan {
        val clusterMap = LinkedHashMap<String, SignalCandidate>()
        val individual = mutableListOf<SignalCandidate>()
        val missed = LinkedHashMap<String, MutableList<SignalCandidate>>()
        val logOnly = mutableListOf<SignalCandidate>()

        val sorted = events.sortedBy { it.eventTimeMs }

        for (e in sorted) {
            val positioned = e.symbol in positionedSymbols
            when {
                e.missed && positioned -> {
                    missed.getOrPut(e.symbol) { mutableListOf() }.add(e)
                }
                e.missed -> {
                    logOnly.add(e)
                }
                positioned -> {
                    if (e.eventType == EventType.EXIT_LONG || e.eventType == EventType.EXIT_SHORT) {
                        individual.add(e)
                    } else {
                        logOnly.add(e)
                    }
                }
                !generalMonitoringOn -> continue
                e.eventType == EventType.LONG_SIGNAL || e.eventType == EventType.SHORT_SIGNAL -> {
                    clusterMap[e.symbol] = e
                }
                e.eventType == EventType.INDICATOR_PROMOTED -> {
                    logOnly.add(e)
                }
            }
        }

        return DispatchPlan(
            cluster = clusterMap.values.toList(),
            individual = individual,
            missed = missed,
            logOnly = logOnly
        )
    }
}
