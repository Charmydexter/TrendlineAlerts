package com.trendlinealerts.core.ml

import com.trendlinealerts.core.indicators.ComputedIndicators
import com.trendlinealerts.core.indicators.ScalpingIndicators
import com.trendlinealerts.core.indicators.ScalpingIndicators.ALL_INDICATORS
import com.trendlinealerts.core.indicators.ScalpingIndicators.FEATURE_COUNT
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.AssetModelSnapshot
import com.trendlinealerts.core.model.BacktestTrade
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.ChartSignalMarker
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.IndicatorEffectiveness
import com.trendlinealerts.core.model.IndicatorId
import com.trendlinealerts.core.model.LogisticWeights
import com.trendlinealerts.core.model.MasterModelSnapshot
import com.trendlinealerts.core.model.MasterTopIndicator
import com.trendlinealerts.core.model.RollingDriftBenchmarks
import com.trendlinealerts.core.model.RollingDriftComparison
import com.trendlinealerts.core.model.RollingWindowBenchmark
import com.trendlinealerts.core.model.SignalAction
import com.trendlinealerts.core.model.Timeframe
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

class ScalpLabelSet(
    val yLong: ByteArray,
    val yShort: ByteArray,
    val retLongPct: FloatArray,
    val retShortPct: FloatArray
)

data class SampledFeatureRow(
    val x: FloatArray,
    val yLong: Int,
    val yShort: Int
)

data class SignalDecisionResult(
    val action: SignalAction,
    val exhaustionScore: Double
)

data class EvaluatedAssetModel(
    val snapshot: AssetModelSnapshot,
    val longWeights: LogisticWeights,
    val shortWeights: LogisticWeights,
    val computed: ComputedIndicators,
    val sampledFeatures: List<SampledFeatureRow>
)

object LogisticMlEngine {
    private const val DAY_MS = 86_400_000L
    private const val FEE_ROUNDTRIP_PCT = 0.06

    private fun sigmoid(z: Double): Double {
        if (z > 18.0) return 0.99999998
        if (z < -18.0) return 0.00000002
        return 1.0 / (1.0 + exp(-z))
    }

    fun computeScalpLabels(
        candles: List<Candle>,
        atr14: DoubleArray,
        minProfitMultiplier: Double,
        lookaheadBars: Int
    ): ScalpLabelSet {
        val n = candles.size
        val yLong = ByteArray(n)
        val yShort = ByteArray(n)
        val retLongPct = FloatArray(n)
        val retShortPct = FloatArray(n)

        val mult = max(0.2, minProfitMultiplier)

        for (i in 0 until max(0, n - 1)) {
            val entry = candles[i].close
            if (entry <= 0.0) continue

            val atrPct = (atr14[i] / entry) * 100.0
            val stopPct = max(atrPct * 0.9, 0.14)
            val targetPct = stopPct * mult

            val longTp = entry * (1.0 + targetPct / 100.0)
            val longSl = entry * (1.0 - stopPct / 100.0)
            val shortTp = entry * (1.0 - targetPct / 100.0)
            val shortSl = entry * (1.0 + stopPct / 100.0)

            val endIdx = min(i + lookaheadBars, n - 1)
            var longDone = false
            var shortDone = false
            var lOutcome: Byte = 0
            var sOutcome: Byte = 0
            var lRet = ((candles[endIdx].close - entry) / entry) * 100.0
            var sRet = ((entry - candles[endIdx].close) / entry) * 100.0

            for (k in (i + 1)..endIdx) {
                val bar = candles[k]
                if (!longDone) {
                    if (bar.low <= longSl) {
                        lOutcome = 0
                        lRet = -stopPct
                        longDone = true
                    } else if (bar.high >= longTp) {
                        lOutcome = 1
                        lRet = targetPct
                        longDone = true
                    }
                }
                if (!shortDone) {
                    if (bar.high >= shortSl) {
                        sOutcome = 0
                        sRet = -stopPct
                        shortDone = true
                    } else if (bar.low <= shortTp) {
                        sOutcome = 1
                        sRet = targetPct
                        shortDone = true
                    }
                }
                if (longDone && shortDone) break
            }

            if (!longDone && lRet >= targetPct * 0.65) lOutcome = 1
            if (!shortDone && sRet >= targetPct * 0.65) sOutcome = 1

            yLong[i] = lOutcome
            yShort[i] = sOutcome
            retLongPct[i] = (lRet - FEE_ROUNDTRIP_PCT).toFloat()
            retShortPct[i] = (sRet - FEE_ROUNDTRIP_PCT).toFloat()
        }

        return ScalpLabelSet(yLong, yShort, retLongPct, retShortPct)
    }

    fun trainLogisticRegression(
        features: FloatArray,
        labels: ByteArray,
        startIdx: Int,
        endIdx: Int,
        stride: Int,
        activeMask: BooleanArray,
        timeframe: Timeframe,
        priorWeights: LogisticWeights? = null,
        priorStrength: Double = 0.08,
        iterations: Int = 55,
        nowMs: Long = System.currentTimeMillis()
    ): LogisticWeights {
        val means = DoubleArray(FEATURE_COUNT)
        val stds = DoubleArray(FEATURE_COUNT) { 1.0 }
        val weights = DoubleArray(FEATURE_COUNT)

        val step = max(1, stride)
        val indices = ArrayList<Int>()
        var posCount = 0
        var idx = max(0, startIdx)
        while (idx < endIdx) {
            indices.add(idx)
            if (labels[idx].toInt() == 1) posCount++
            idx += step
        }

        val m = indices.size
        if (m < 25) {
            return LogisticWeights(
                weights = weights.toList(),
                bias = -0.35,
                means = means.toList(),
                stds = stds.toList(),
                trainedAtMs = nowMs,
                sampleCount = m
            )
        }

        for (j in 0 until FEATURE_COUNT) {
            if (!activeMask[j]) continue
            var sum = 0.0
            for (k in 0 until m) {
                sum += features[indices[k] * FEATURE_COUNT + j].toDouble()
            }
            val mean = sum / m.toDouble()
            var sq = 0.0
            for (k in 0 until m) {
                val d = features[indices[k] * FEATURE_COUNT + j].toDouble() - mean
                sq += d * d
            }
            means[j] = mean
            stds[j] = max(sqrt(sq / m.toDouble()), 1e-4)
        }

        val negCount = m - posCount
        val wPos = if (posCount > 0) min(2.2, (0.5 * m) / posCount.toDouble()) else 1.0
        val wNeg = if (negCount > 0) min(2.2, (0.5 * m) / negCount.toDouble()) else 1.0

        val l2PerFeature = DoubleArray(FEATURE_COUNT)
        for (j in 0 until FEATURE_COUNT) {
            val prio = ScalpingIndicators.getPriority(timeframe, ALL_INDICATORS[j]).weight
            l2PerFeature[j] = 0.015 / max(prio, 0.25)
            if (priorWeights != null && activeMask[j]) {
                weights[j] = (priorWeights.weights.getOrNull(j) ?: 0.0) * 0.35
            }
        }

        var bias = ln(max(posCount, 1).toDouble() / max(negCount, 1).toDouble()) * 0.4

        val mW = DoubleArray(FEATURE_COUNT)
        val vW = DoubleArray(FEATURE_COUNT)
        var mB = 0.0
        var vB = 0.0
        val lr = 0.08
        val b1 = 0.9
        val b2 = 0.999
        val eps = 1e-8

        val gradW = DoubleArray(FEATURE_COUNT)

        for (iter in 1..iterations) {
            gradW.fill(0.0)
            var gradB = 0.0

            for (k in 0 until m) {
                val rowIdx = indices[k]
                val base = rowIdx * FEATURE_COUNT
                var z = bias
                for (j in 0 until FEATURE_COUNT) {
                    if (!activeMask[j]) continue
                    val xj = (features[base + j].toDouble() - means[j]) / stds[j]
                    z += weights[j] * xj
                }
                val p = sigmoid(z)
                val y = labels[rowIdx].toInt()
                val sw = if (y == 1) wPos else wNeg
                val err = (p - y) * sw
                gradB += err
                for (j in 0 until FEATURE_COUNT) {
                    if (!activeMask[j]) continue
                    val xj = (features[base + j].toDouble() - means[j]) / stds[j]
                    gradW[j] += err * xj
                }
            }

            val invM = 1.0 / m.toDouble()
            val b1Corr = 1.0 - b1.pow(iter)
            val b2Corr = 1.0 - b2.pow(iter)

            val gB = gradB * invM
            mB = b1 * mB + (1.0 - b1) * gB
            vB = b2 * vB + (1.0 - b2) * gB * gB
            bias -= (lr * (mB / b1Corr)) / (sqrt(vB / b2Corr) + eps)

            for (j in 0 until FEATURE_COUNT) {
                if (!activeMask[j]) {
                    weights[j] = 0.0
                    continue
                }
                var g = gradW[j] * invM + l2PerFeature[j] * weights[j]
                if (priorWeights != null) {
                    g += priorStrength * (weights[j] - (priorWeights.weights.getOrNull(j) ?: 0.0))
                }
                mW[j] = b1 * mW[j] + (1.0 - b1) * g
                vW[j] = b2 * vW[j] + (1.0 - b2) * g * g
                weights[j] -= (lr * (mW[j] / b1Corr)) / (sqrt(vW[j] / b2Corr) + eps)
            }
        }

        return LogisticWeights(
            weights = weights.toList(),
            bias = bias,
            means = means.toList(),
            stds = stds.toList(),
            trainedAtMs = nowMs,
            sampleCount = m
        )
    }

    fun predictLogistic(features: FloatArray, rowIndex: Int, model: LogisticWeights): Double {
        val base = rowIndex * FEATURE_COUNT
        var z = model.bias
        for (j in 0 until FEATURE_COUNT) {
            val w = model.weights.getOrNull(j) ?: 0.0
            if (w == 0.0) continue
            val mean = model.means.getOrNull(j) ?: 0.0
            val std = model.stds.getOrNull(j) ?: 1.0
            val xj = (features[base + j].toDouble() - mean) / std
            z += w * xj
        }
        return sigmoid(z)
    }

    fun resolveSignalDecision(
        pLong: Double,
        pShort: Double,
        mode: AssetMode,
        lastSignalDirection: EntryDirection?,
        threshold: Double,
        ofiValue: Double,
        rsi7SlopeValue: Double,
        zScore: Double = 0.0
    ): SignalDecisionResult {
        if (mode == AssetMode.POSITIONED) {
            val side = lastSignalDirection ?: if (pLong >= pShort) EntryDirection.LONG else EntryDirection.SHORT
            return if (side == EntryDirection.LONG) {
                val oppPressure = max(0.0, pShort - pLong)
                val decay = max(0.0, 0.52 - pLong) * 1.8
                val zStretch = if (zScore >= 2.1 && rsi7SlopeValue < 0.0) 0.2 else 0.0
                val microExhaustion =
                    (if (ofiValue < -0.55) 0.2 else 0.0) + (if (rsi7SlopeValue < -0.6) 0.2 else 0.0) + zStretch
                val exhaustion = min(1.0, max(0.0, decay + oppPressure * 1.4 + microExhaustion))
                val shouldExit = pLong < 0.41 ||
                    pShort >= 0.52 ||
                    (pShort > pLong + 0.07 && (ofiValue < -0.35 || rsi7SlopeValue < -0.45)) ||
                    (zScore >= 2.3 && rsi7SlopeValue < -0.35 && pLong < 0.50)
                SignalDecisionResult(if (shouldExit) SignalAction.EXIT else SignalAction.WAIT, exhaustion)
            } else {
                val oppPressure = max(0.0, pLong - pShort)
                val decay = max(0.0, 0.52 - pShort) * 1.8
                val zStretch = if (zScore <= -2.1 && rsi7SlopeValue > 0.0) 0.2 else 0.0
                val microExhaustion =
                    (if (ofiValue > 0.55) 0.2 else 0.0) + (if (rsi7SlopeValue > 0.6) 0.2 else 0.0) + zStretch
                val exhaustion = min(1.0, max(0.0, decay + oppPressure * 1.4 + microExhaustion))
                val shouldExit = pShort < 0.41 ||
                    pLong >= 0.52 ||
                    (pLong > pShort + 0.07 && (ofiValue > 0.35 || rsi7SlopeValue > 0.45)) ||
                    (zScore <= -2.3 && rsi7SlopeValue > 0.35 && pShort < 0.50)
                SignalDecisionResult(if (shouldExit) SignalAction.EXIT else SignalAction.WAIT, exhaustion)
            }
        }

        val margin = 0.07
        if (pLong >= threshold && pLong - pShort >= margin) {
            return SignalDecisionResult(SignalAction.LONG, 0.0)
        }
        if (pShort >= threshold && pShort - pLong >= margin) {
            return SignalDecisionResult(SignalAction.SHORT, 0.0)
        }
        return SignalDecisionResult(SignalAction.WAIT, 0.0)
    }

    private fun computeFeatureDirectionalScore(
        features: FloatArray,
        labels: ScalpLabelSet,
        startIdx: Int,
        endIdx: Int,
        featureIdx: Int
    ): Double {
        val step = max(1, (endIdx - startIdx) / 800)
        var sumXY = 0.0
        var sumX = 0.0
        var sumY = 0.0
        var sumX2 = 0.0
        var sumY2 = 0.0
        var count = 0

        var i = max(30, startIdx)
        while (i < endIdx) {
            val x = features[i * FEATURE_COUNT + featureIdx].toDouble()
            val y = (labels.yLong[i].toInt() - labels.yShort[i].toInt()).toDouble()
            sumX += x
            sumY += y
            sumXY += x * y
            sumX2 += x * x
            sumY2 += y * y
            count++
            i += step
        }

        if (count < 15) return 0.0
        val num = count * sumXY - sumX * sumY
        val den = sqrt(max(0.0, (count * sumX2 - sumX * sumX) * (count * sumY2 - sumY * sumY)))
        if (den <= 1e-9) return 0.0
        return abs(num / den)
    }

    private fun computeWindowDrift(
        features: FloatArray,
        recentStart: Int,
        recentEnd: Int,
        olderStart: Int,
        olderEnd: Int
    ): Double {
        if (recentEnd - recentStart < 10 || olderEnd - olderStart < 10) return 0.0
        var totalShift = 0.0
        val rStep = max(1, (recentEnd - recentStart) / 300)
        val oStep = max(1, (olderEnd - olderStart) / 300)
        for (j in 0 until FEATURE_COUNT) {
            var rSum = 0.0
            var rCount = 0
            var ri = recentStart
            while (ri < recentEnd) {
                rSum += features[ri * FEATURE_COUNT + j].toDouble()
                rCount++
                ri += rStep
            }
            var oSum = 0.0
            var oCount = 0
            var oi = olderStart
            while (oi < olderEnd) {
                oSum += features[oi * FEATURE_COUNT + j].toDouble()
                oCount++
                oi += oStep
            }
            val rMean = if (rCount > 0) rSum / rCount.toDouble() else 0.0
            val oMean = if (oCount > 0) oSum / oCount.toDouble() else 0.0
            totalShift += abs(rMean - oMean)
        }
        return totalShift / FEATURE_COUNT.toDouble()
    }

    private fun findIndexAtOrAfter(candles: List<Candle>, targetTimeMs: Long): Int {
        var lo = 0
        var hi = candles.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (candles[mid].openTimeMs < targetTimeMs) lo = mid + 1 else hi = mid
        }
        return lo
    }

    private fun summarizeTrades(
        label: String,
        days: Int,
        trades: List<BacktestTrade>,
        startTimeMs: Long,
        endTimeMs: Long,
        correctPreds: Int,
        totalPreds: Int
    ): RollingWindowBenchmark {
        var wins = 0
        var count = 0
        var grossWin = 0.0
        var grossLoss = 0.0
        var net = 0.0
        for (t in trades) {
            if (t.entryTimeMs in startTimeMs..endTimeMs) {
                count++
                net += t.netReturnPct
                if (t.won) {
                    wins++
                    grossWin += max(0.0, t.netReturnPct)
                } else {
                    grossLoss += abs(min(0.0, t.netReturnPct))
                }
            }
        }
        val winRatePct = if (count > 0) (wins.toDouble() / count.toDouble()) * 100.0 else 0.0
        val profitFactor = when {
            grossLoss > 0.0 -> grossWin / grossLoss
            grossWin > 0.0 -> 3.0
            else -> 1.0
        }
        val accuracyPct = if (totalPreds > 0) (correctPreds.toDouble() / totalPreds.toDouble()) * 100.0 else winRatePct
        return RollingWindowBenchmark(
            label = label,
            days = days,
            tradeCount = count,
            winRatePct = winRatePct,
            netReturnPct = net,
            profitFactor = min(profitFactor, 9.99),
            accuracyPct = accuracyPct
        )
    }

    fun trainAndEvaluateAsset(
        symbol: String,
        candles: List<Candle>,
        timeframe: Timeframe,
        settings: AlertSettings,
        mode: AssetMode,
        lastSignalDirection: EntryDirection?,
        previousActiveIndicators: List<IndicatorId>,
        masterModel: MasterModelSnapshot?,
        nowMs: Long = System.currentTimeMillis(),
        masterCandles: List<Candle> = emptyList()
    ): EvaluatedAssetModel {
        val computed = ScalpingIndicators.computeMatrix(
            candles = candles,
            timeframe = timeframe,
            masterCandles = if (settings.observeWithMaster) masterCandles else emptyList()
        )
        val labels = computeScalpLabels(
            candles = candles,
            atr14 = computed.atr14,
            minProfitMultiplier = settings.effectiveMinProfitMultiplier,
            lookaheadBars = timeframe.lookaheadBars
        )

        val n = candles.size
        val lastTimeMs = if (n > 0) candles[n - 1].openTimeMs else nowMs
        val evalStartMs = lastTimeMs - timeframe.evalDays * DAY_MS
        val rawSplitIdx = findIndexAtOrAfter(candles, evalStartMs)
        val splitIdx = max(min(rawSplitIdx, (n * 6) / 10), min(350, (n * 3) / 10))

        val activeSet = LinkedHashSet(
            if (previousActiveIndicators.isNotEmpty()) {
                previousActiveIndicators
            } else {
                ScalpingIndicators.getDefaultActiveIndicators(timeframe, 8)
            }
        )

        fun buildMask(set: Set<IndicatorId>): BooleanArray =
            BooleanArray(FEATURE_COUNT) { idx -> ALL_INDICATORS[idx] in set }

        val masterLong = if (settings.observeWithMaster && masterModel?.timeframe == timeframe) masterModel.longWeights else null
        val masterShort = if (settings.observeWithMaster && masterModel?.timeframe == timeframe) masterModel.shortWeights else null

        val stride = max(1, n / 4500)
        var curLong = trainLogisticRegression(
            features = computed.features,
            labels = labels.yLong,
            startIdx = min(30, n),
            endIdx = max(60, splitIdx - timeframe.lookaheadBars),
            stride = stride,
            activeMask = buildMask(activeSet),
            timeframe = timeframe,
            priorWeights = masterLong,
            iterations = 45,
            nowMs = nowMs
        )
        var curShort = trainLogisticRegression(
            features = computed.features,
            labels = labels.yShort,
            startIdx = min(30, n),
            endIdx = max(60, splitIdx - timeframe.lookaheadBars),
            stride = stride,
            activeMask = buildMask(activeSet),
            timeframe = timeframe,
            priorWeights = masterShort,
            iterations = 45,
            nowMs = nowMs
        )

        val trades21d = ArrayList<BacktestTrade>()
        val chartMarkers = ArrayList<ChartSignalMarker>()

        val dayCursorMs = candles.getOrNull(splitIdx)?.openTimeMs ?: evalStartMs
        var nextRetrainMs = dayCursorMs + DAY_MS
        var lastTradeExitBar = -1
        var simDir: EntryDirection? = null
        var simEntryBar = 0
        var lastEvalDir: EntryDirection? = null

        val d3StartMs = lastTimeMs - 3L * DAY_MS
        val d7StartMs = lastTimeMs - 7L * DAY_MS
        val d14StartMs = lastTimeMs - 14L * DAY_MS
        val d21StartMs = lastTimeMs - 21L * DAY_MS
        val d1StartMs = lastTimeMs - DAY_MS

        var d1Hit = 0; var d1Tot = 0
        var d13Hit = 0; var d13Tot = 0
        var d3Hit = 0; var d3Tot = 0
        var d37Hit = 0; var d37Tot = 0
        var d7Hit = 0; var d7Tot = 0
        var d14Hit = 0; var d14Tot = 0
        var d21Hit = 0; var d21Tot = 0

        val recentChartStartMs = lastTimeMs - ((timeframe.chartRanges.firstOrNull()?.ms ?: (4 * 3_600_000L)) * 1.5).toLong()

        for (i in splitIdx until n) {
            val bar = candles[i]
            if (bar.openTimeMs >= nextRetrainMs && i > splitIdx + 30) {
                val trainWinStart = max(30, i - ((14L * DAY_MS) / timeframe.ms).toInt())
                val trainEnd = max(trainWinStart + 40, i - timeframe.lookaheadBars)
                val localStride = max(1, (trainEnd - trainWinStart) / 3000)
                curLong = trainLogisticRegression(
                    features = computed.features,
                    labels = labels.yLong,
                    startIdx = trainWinStart,
                    endIdx = trainEnd,
                    stride = localStride,
                    activeMask = buildMask(activeSet),
                    timeframe = timeframe,
                    priorWeights = masterLong,
                    iterations = 36,
                    nowMs = nowMs
                )
                curShort = trainLogisticRegression(
                    features = computed.features,
                    labels = labels.yShort,
                    startIdx = trainWinStart,
                    endIdx = trainEnd,
                    stride = localStride,
                    activeMask = buildMask(activeSet),
                    timeframe = timeframe,
                    priorWeights = masterShort,
                    iterations = 36,
                    nowMs = nowMs
                )
                nextRetrainMs += DAY_MS
            }

            val pL = predictLogistic(computed.features, i, curLong)
            val pS = predictLogistic(computed.features, i, curShort)

            if (i < n - timeframe.lookaheadBars) {
                val predLong = pL >= 0.52 && pL > pS
                val predShort = pS >= 0.52 && pS > pL
                if (predLong || predShort) {
                    val hit = if (predLong) labels.yLong[i].toInt() == 1 else labels.yShort[i].toInt() == 1
                    if (bar.openTimeMs >= d1StartMs) {
                        d1Tot++; if (hit) d1Hit++
                    } else if (bar.openTimeMs >= d3StartMs) {
                        d13Tot++; if (hit) d13Hit++
                    }
                    if (bar.openTimeMs >= d3StartMs) {
                        d3Tot++; if (hit) d3Hit++
                    } else if (bar.openTimeMs >= d7StartMs) {
                        d37Tot++; if (hit) d37Hit++
                    }
                    if (bar.openTimeMs >= d7StartMs) { d7Tot++; if (hit) d7Hit++ }
                    if (bar.openTimeMs >= d14StartMs) { d14Tot++; if (hit) d14Hit++ }
                    if (bar.openTimeMs >= d21StartMs) { d21Tot++; if (hit) d21Hit++ }
                }
            }

            val base = i * FEATURE_COUNT
            val ofiVal = computed.features[base + 0].toDouble()
            val rsiSlopeVal = computed.features[base + 2].toDouble()
            val zVal = computed.zScoreSeries[i]

            if (simDir != null) {
                val exitDec = resolveSignalDecision(
                    pLong = pL,
                    pShort = pS,
                    mode = AssetMode.POSITIONED,
                    lastSignalDirection = simDir,
                    threshold = settings.effectiveSignalThreshold,
                    ofiValue = ofiVal,
                    rsi7SlopeValue = rsiSlopeVal,
                    zScore = zVal
                )
                val heldBars = i - simEntryBar
                if (exitDec.action == SignalAction.EXIT || heldBars >= timeframe.lookaheadBars) {
                    if (bar.openTimeMs >= recentChartStartMs && exitDec.action == SignalAction.EXIT) {
                        chartMarkers.add(ChartSignalMarker(bar.openTimeMs, bar.close, SignalAction.EXIT, exitDec.exhaustionScore))
                    }
                    simDir = null
                }
            }

            if (simDir == null && i > lastTradeExitBar && i < n - timeframe.lookaheadBars) {
                val entryDec = resolveSignalDecision(
                    pLong = pL,
                    pShort = pS,
                    mode = AssetMode.GENERAL,
                    lastSignalDirection = lastEvalDir,
                    threshold = settings.effectiveSignalThreshold,
                    ofiValue = ofiVal,
                    rsi7SlopeValue = rsiSlopeVal,
                    zScore = zVal
                )
                if (entryDec.action == SignalAction.LONG || entryDec.action == SignalAction.SHORT) {
                    val dir = if (entryDec.action == SignalAction.LONG) EntryDirection.LONG else EntryDirection.SHORT
                    lastEvalDir = dir
                    val netRet = (if (dir == EntryDirection.LONG) labels.retLongPct[i] else labels.retShortPct[i]).toDouble()
                    val exitIdx = min(i + timeframe.lookaheadBars, n - 1)
                    val prob = if (dir == EntryDirection.LONG) pL else pS
                    trades21d.add(
                        BacktestTrade(
                            entryTimeMs = bar.openTimeMs,
                            exitTimeMs = candles[exitIdx].openTimeMs,
                            direction = dir,
                            entryPrice = bar.close,
                            exitPrice = candles[exitIdx].close,
                            netReturnPct = netRet,
                            probability = prob,
                            won = netRet > 0.0
                        )
                    )
                    lastTradeExitBar = i + max(2, timeframe.lookaheadBars / 2)
                    simDir = dir
                    simEntryBar = i

                    if (bar.openTimeMs >= recentChartStartMs) {
                        chartMarkers.add(ChartSignalMarker(bar.openTimeMs, bar.close, entryDec.action, prob))
                    }
                }
            }
        }

        val idx1d = findIndexAtOrAfter(candles, d1StartMs)
        val idx3d = findIndexAtOrAfter(candles, d3StartMs)
        val idx7d = findIndexAtOrAfter(candles, d7StartMs)
        val idx14d = findIndexAtOrAfter(candles, d14StartMs)
        val idx21d = findIndexAtOrAfter(candles, d21StartMs)
        val labelEnd = max(35, n - timeframe.lookaheadBars)

        val baselineDefaults = ScalpingIndicators.getDefaultActiveIndicators(timeframe, 8).toSet()
        val prevSet = if (previousActiveIndicators.isNotEmpty()) previousActiveIndicators.toSet() else baselineDefaults

        val rawStats = ALL_INDICATORS.mapIndexed { j, meta ->
            val prio = ScalpingIndicators.getPriority(timeframe, meta)
            val s1 = computeFeatureDirectionalScore(computed.features, labels, idx1d, labelEnd, j)
            val s3 = computeFeatureDirectionalScore(computed.features, labels, idx3d, labelEnd, j)
            val s7 = computeFeatureDirectionalScore(computed.features, labels, idx7d, labelEnd, j)
            val s14 = computeFeatureDirectionalScore(computed.features, labels, idx14d, labelEnd, j)
            val s21 = computeFeatureDirectionalScore(computed.features, labels, idx21d, labelEnd, j)

            val recentScore = s1 * 0.45 + s3 * 0.35 + s7 * 0.20
            val olderScore = (s14 + s21) * 0.50
            val wasActive = meta in prevSet
            val emerging = !wasActive && recentScore >= 0.065 && recentScore > olderScore * 1.25

            IndicatorEffectiveness(
                id = meta,
                label = meta.label,
                tier = prio.tier,
                priorityWeight = prio.weight,
                isActive = wasActive || emerging,
                isNewlyEffective = emerging,
                score1d = s1,
                score3d = s3,
                score7d = s7,
                score14d = s14,
                score21d = s21,
                longWeight = curLong.weights.getOrElse(j) { 0.0 },
                shortWeight = curShort.weights.getOrElse(j) { 0.0 },
                currentValue = if (n > 0) computed.features[(n - 1) * FEATURE_COUNT + j].toDouble() else 0.0
            )
        }

        val nextActiveIds = rawStats
            .sortedByDescending {
                (it.score1d * 0.4 + it.score3d * 0.3 + it.score7d * 0.3) * it.priorityWeight +
                    if (it.isNewlyEffective) 0.15 else 0.0
            }
            .take(9)
            .map { it.id }
        val nextActiveSet = nextActiveIds.toSet()
        val promotedIndicators = rawStats.filter { it.isNewlyEffective }.map { it.id }

        val finalTrainStart = max(30, n - ((14L * DAY_MS) / timeframe.ms).toInt())
        val finalStride = max(1, (labelEnd - finalTrainStart) / 3500)
        val finalLong = trainLogisticRegression(
            features = computed.features,
            labels = labels.yLong,
            startIdx = finalTrainStart,
            endIdx = labelEnd,
            stride = finalStride,
            activeMask = buildMask(nextActiveSet),
            timeframe = timeframe,
            priorWeights = masterLong,
            iterations = 60,
            nowMs = nowMs
        )
        val finalShort = trainLogisticRegression(
            features = computed.features,
            labels = labels.yShort,
            startIdx = finalTrainStart,
            endIdx = labelEnd,
            stride = finalStride,
            activeMask = buildMask(nextActiveSet),
            timeframe = timeframe,
            priorWeights = masterShort,
            iterations = 60,
            nowMs = nowMs
        )

        val finalStats = rawStats.mapIndexed { j, stat ->
            stat.copy(
                isActive = stat.id in nextActiveSet,
                longWeight = finalLong.weights.getOrElse(j) { 0.0 },
                shortWeight = finalShort.weights.getOrElse(j) { 0.0 }
            )
        }.sortedByDescending { abs(it.longWeight) + abs(it.shortWeight) }

        val lastIdx = max(0, n - 1)
        val assetPLong = if (n > 30) predictLogistic(computed.features, lastIdx, finalLong) else 0.5
        val assetPShort = if (n > 30) predictLogistic(computed.features, lastIdx, finalShort) else 0.5

        val masterPLong = if (masterLong != null && n > 30) predictLogistic(computed.features, lastIdx, masterLong) else assetPLong
        val masterPShort = if (masterShort != null && n > 30) predictLogistic(computed.features, lastIdx, masterShort) else assetPShort

        val blendAlpha = if (settings.observeWithMaster && masterLong != null) 0.28 else 0.0
        val pLong = assetPLong * (1.0 - blendAlpha) + masterPLong * blendAlpha
        val pShort = assetPShort * (1.0 - blendAlpha) + masterPShort * blendAlpha

        val masterAgreement =
            (assetPLong >= assetPShort && masterPLong >= masterPShort) ||
                (assetPShort > assetPLong && masterPShort > masterPLong)

        val effectiveLastDir = lastSignalDirection ?: lastEvalDir
        val liveDecision = resolveSignalDecision(
            pLong = pLong,
            pShort = pShort,
            mode = mode,
            lastSignalDirection = effectiveLastDir,
            threshold = settings.effectiveSignalThreshold,
            ofiValue = if (n > 0) computed.features[lastIdx * FEATURE_COUNT + 0].toDouble() else 0.0,
            rsi7SlopeValue = if (n > 0) computed.features[lastIdx * FEATURE_COUNT + 2].toDouble() else 0.0,
            zScore = if (n > 0) computed.zScoreSeries[lastIdx] else 0.0
        )

        val day1VsDay3Drift = computeWindowDrift(computed.features, idx1d, n, idx3d, idx1d)
        val day3VsDay7Drift = computeWindowDrift(computed.features, idx3d, n, idx7d, idx3d)

        fun accPct(hit: Int, tot: Int) = if (tot > 0) (hit.toDouble() / tot.toDouble()) * 100.0 else 50.0
        val day1VsDay3AccuracyDelta = accPct(d1Hit, d1Tot) - accPct(d13Hit, d13Tot)
        val day3VsDay7AccuracyDelta = accPct(d3Hit, d3Tot) - accPct(d37Hit, d37Tot)

        val w1 = summarizeTrades("7d Block 1", 7, trades21d, d7StartMs, lastTimeMs, d7Hit, d7Tot)
        val w2 = summarizeTrades("7d Block 2", 7, trades21d, d14StartMs, d7StartMs - 1L, 0, 0)
        val w3 = summarizeTrades("7d Block 3", 7, trades21d, d21StartMs, d14StartMs - 1L, 0, 0)

        val drift = RollingDriftComparison(
            day1VsDay3Drift = day1VsDay3Drift,
            day1VsDay3AccuracyDelta = day1VsDay3AccuracyDelta,
            day3VsDay7Drift = day3VsDay7Drift,
            day3VsDay7AccuracyDelta = day3VsDay7AccuracyDelta,
            week1NetPct = w1.netReturnPct,
            week2NetPct = w2.netReturnPct,
            week3NetPct = w3.netReturnPct,
            week1WinRate = w1.winRatePct,
            week2WinRate = w2.winRatePct,
            week3WinRate = w3.winRatePct,
            benchmarks = RollingDriftBenchmarks(
                d3 = summarizeTrades("3d", 3, trades21d, d3StartMs, lastTimeMs, d3Hit, d3Tot),
                d7 = summarizeTrades("1w (7d)", 7, trades21d, d7StartMs, lastTimeMs, d7Hit, d7Tot),
                d14 = summarizeTrades("2w (14d)", 14, trades21d, d14StartMs, lastTimeMs, d14Hit, d14Tot),
                d21 = summarizeTrades("3w (21d)", 21, trades21d, d21StartMs, lastTimeMs, d21Hit, d21Tot)
            )
        )

        val sampledFeatures = ArrayList<SampledFeatureRow>()
        val sampleStep = max(1, (labelEnd - finalTrainStart) / 220)
        var si = finalTrainStart
        while (si < labelEnd) {
            val base = si * FEATURE_COUNT
            val x = FloatArray(FEATURE_COUNT) { j -> computed.features[base + j] }
            sampledFeatures.add(SampledFeatureRow(x, labels.yLong[si].toInt(), labels.yShort[si].toInt()))
            si += sampleStep
        }

        val snapshot = AssetModelSnapshot(
            symbol = symbol,
            timeframe = timeframe,
            updatedAtMs = nowMs,
            lastTrainedAtMs = nowMs,
            lastPrice = if (n > 0) candles[lastIdx].close else 0.0,
            zScore = if (n > 0) computed.zScoreSeries[lastIdx] else 0.0,
            masterAsset = settings.effectiveMasterAsset,
            masterZScore = computed.latestMasterZScore,
            btcCorrelation = computed.latestBtcCorrelation,
            btcBeta = computed.latestBtcBeta,
            relStrengthVsMaster = computed.latestRelStrength,
            barCount = n,
            currentAction = liveDecision.action,
            pLong = pLong,
            pShort = pShort,
            exhaustionScore = liveDecision.exhaustionScore,
            masterAgreement = masterAgreement,
            masterPLong = masterPLong,
            masterPShort = masterPShort,
            activeIndicators = nextActiveIds,
            promotedIndicators = promotedIndicators,
            indicatorStats = finalStats,
            drift = drift,
            trades21d = trades21d,
            chartMarkers = chartMarkers,
            lastSignalDirection = effectiveLastDir
        )

        return EvaluatedAssetModel(
            snapshot = snapshot,
            longWeights = finalLong,
            shortWeights = finalShort,
            computed = computed,
            sampledFeatures = sampledFeatures
        )
    }

    fun trainMasterModel(
        timeframe: Timeframe,
        assetSamples: Map<String, List<SampledFeatureRow>>,
        nowMs: Long = System.currentTimeMillis(),
        masterAsset: String = "BTCUSDT"
    ): MasterModelSnapshot? {
        val allRows = assetSamples.values.flatten()
        if (allRows.size < 60) return null

        val total = allRows.size
        val flatFeatures = FloatArray(total * FEATURE_COUNT)
        val yL = ByteArray(total)
        val yS = ByteArray(total)

        for (i in 0 until total) {
            val r = allRows[i]
            val base = i * FEATURE_COUNT
            for (j in 0 until FEATURE_COUNT) {
                flatFeatures[base + j] = r.x[j]
            }
            yL[i] = r.yLong.toByte()
            yS[i] = r.yShort.toByte()
        }

        val allActive = BooleanArray(FEATURE_COUNT) { true }
        val longWeights = trainLogisticRegression(
            features = flatFeatures,
            labels = yL,
            startIdx = 0,
            endIdx = total,
            stride = 1,
            activeMask = allActive,
            timeframe = timeframe,
            iterations = 65,
            nowMs = nowMs
        )
        val shortWeights = trainLogisticRegression(
            features = flatFeatures,
            labels = yS,
            startIdx = 0,
            endIdx = total,
            stride = 1,
            activeMask = allActive,
            timeframe = timeframe,
            iterations = 65,
            nowMs = nowMs
        )

        val topIndicators = ALL_INDICATORS.mapIndexed { j, meta ->
            val score = (abs(longWeights.weights.getOrElse(j) { 0.0 }) +
                abs(shortWeights.weights.getOrElse(j) { 0.0 })) *
                ScalpingIndicators.getPriority(timeframe, meta).weight
            MasterTopIndicator(meta, meta.label, score)
        }.sortedByDescending { it.score }

        return MasterModelSnapshot(
            timeframe = timeframe,
            masterAsset = AlertSettings.normalizeMasterAsset(masterAsset),
            trainedAtMs = nowMs,
            assetCount = assetSamples.size,
            sampleCount = total,
            longWeights = longWeights,
            shortWeights = shortWeights,
            topIndicators = topIndicators
        )
    }
}
