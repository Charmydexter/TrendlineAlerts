package com.trendlinealerts.core.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class Candle(
    val openTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0,
    val isClosed: Boolean = true
)

@Serializable
data class ChartRangeSpec(
    val key: String,
    val label: String,
    val ms: Long,
    val bars: Int
)

/**
 * Supported scalping timeframes (1m default; 1h and 4h excluded as they exceed the 90-day history cap).
 */
@Serializable
enum class Timeframe(
    val label: String,
    val minutes: Int,
    val binanceInterval: String,
    val bybitInterval: String,
    val okxBar: String,
    val historyDays: Int,
    val initialTrainDays: Int,
    val evalDays: Int,
    val lookaheadBars: Int,
    val defaultChartRangeKey: String,
    val chartRanges: List<ChartRangeSpec>
) {
    M1(
        label = "1m",
        minutes = 1,
        binanceInterval = "1m",
        bybitInterval = "1",
        okxBar = "1m",
        historyDays = 28,
        initialTrainDays = 7,
        evalDays = 21,
        lookaheadBars = 12,
        defaultChartRangeKey = "4H",
        chartRanges = listOf(
            ChartRangeSpec("4H", "4H", 4 * 3_600_000L, 240),
            ChartRangeSpec("1H", "1H", 3_600_000L, 60),
            ChartRangeSpec("30m", "30m", 30 * 60_000L, 30),
            ChartRangeSpec("15m", "15m", 15 * 60_000L, 15)
        )
    ),
    M3(
        label = "3m",
        minutes = 3,
        binanceInterval = "3m",
        bybitInterval = "3",
        okxBar = "3m",
        historyDays = 42,
        initialTrainDays = 21,
        evalDays = 21,
        lookaheadBars = 10,
        defaultChartRangeKey = "12H",
        chartRanges = listOf(
            ChartRangeSpec("12H", "12H", 12 * 3_600_000L, 240),
            ChartRangeSpec("4H", "4H", 4 * 3_600_000L, 80),
            ChartRangeSpec("1H", "1H", 3_600_000L, 20),
            ChartRangeSpec("30m", "30m", 30 * 60_000L, 10)
        )
    ),
    M5(
        label = "5m",
        minutes = 5,
        binanceInterval = "5m",
        bybitInterval = "5",
        okxBar = "5m",
        historyDays = 56,
        initialTrainDays = 35,
        evalDays = 21,
        lookaheadBars = 8,
        defaultChartRangeKey = "24H",
        chartRanges = listOf(
            ChartRangeSpec("24H", "24H", 24 * 3_600_000L, 288),
            ChartRangeSpec("12H", "12H", 12 * 3_600_000L, 144),
            ChartRangeSpec("4H", "4H", 4 * 3_600_000L, 48),
            ChartRangeSpec("1H", "1H", 3_600_000L, 12)
        )
    ),
    M15(
        label = "15m",
        minutes = 15,
        binanceInterval = "15m",
        bybitInterval = "15",
        okxBar = "15m",
        historyDays = 84,
        initialTrainDays = 63,
        evalDays = 21,
        lookaheadBars = 6,
        defaultChartRangeKey = "3D",
        chartRanges = listOf(
            ChartRangeSpec("3D", "3D", 3 * 86_400_000L, 288),
            ChartRangeSpec("24H", "24H", 86_400_000L, 96),
            ChartRangeSpec("12H", "12H", 12 * 3_600_000L, 48),
            ChartRangeSpec("4H", "4H", 4 * 3_600_000L, 16)
        )
    ),
    M30(
        label = "30m",
        minutes = 30,
        binanceInterval = "30m",
        bybitInterval = "30",
        okxBar = "30m",
        historyDays = 90,
        initialTrainDays = 69,
        evalDays = 21,
        lookaheadBars = 6,
        defaultChartRangeKey = "7D",
        chartRanges = listOf(
            ChartRangeSpec("7D", "7D", 7 * 86_400_000L, 336),
            ChartRangeSpec("3D", "3D", 3 * 86_400_000L, 144),
            ChartRangeSpec("24H", "24H", 86_400_000L, 48),
            ChartRangeSpec("12H", "12H", 12 * 3_600_000L, 24)
        )
    );

    val ms: Long get() = minutes * 60_000L
    val targetBars: Int get() = ((historyDays * 24L * 60L) / minutes).toInt()
}

@Serializable
enum class SignalAction {
    LONG,
    SHORT,
    WAIT,
    EXIT
}

@Serializable
enum class EntryDirection {
    LONG,
    SHORT
}

/** GENERAL = Long/Short entry alerts. POSITIONED = Exit alerts using last signal direction. */
@Serializable
enum class AssetMode {
    GENERAL,
    POSITIONED
}

@Serializable
enum class ChartCandleStyle {
    HEIKIN_ASHI,
    CANDLES
}

@Serializable
enum class OverviewWindow(val key: String, val label: String, val days: Int) {
    D21("3wks", "3wks", 21),
    D14("2wks", "2wks", 14),
    D7("1wk", "1wk", 7),
    D3("3d", "3d", 3),
    D1("1d", "1d", 1)
}

@Serializable
enum class EventType {
    LONG_SIGNAL,
    SHORT_SIGNAL,
    EXIT_LONG,
    EXIT_SHORT,
    INDICATOR_PROMOTED
}

@Serializable
enum class IndicatorId(val label: String, val shortLabel: String, val description: String) {
    ORDER_FLOW_IMBALANCE(
        "Order-Flow Wick Imbalance",
        "OFI",
        "Smoothed candle buying/selling pressure for pre-move absorption"
    ),
    VOLUME_SURGE(
        "Signed Volume Surge",
        "VolSurge",
        "Log volume ratio weighted by directional impulse"
    ),
    RSI7_SLOPE(
        "RSI(7) Slope",
        "RSI7 d",
        "2-bar rate of change on fast RSI(7) for early turnarounds"
    ),
    EMA_SLOPE_FAST(
        "EMA(5) Velocity",
        "EMA5 d",
        "ATR-normalized micro-trend acceleration before crossover"
    ),
    BB_SQUEEZE_TILT(
        "BB Squeeze Tilt",
        "BB Sqz",
        "Bollinger %B directional tilt amplified during volatility squeeze"
    ),
    STOCH_RSI_DIFF(
        "StochRSI(8,3) Turn",
        "StRSI",
        "Fast K-D oscillator spread for scalping inflections"
    ),
    VWAP_DEVIATION(
        "Rolling VWAP Z-Score",
        "VWAP-Z",
        "ATR-normalized distance from rolling session VWAP"
    ),
    MACD_HIST_SLOPE(
        "MACD(6,13,5) Hist Slope",
        "MACD d",
        "Fast scalping MACD histogram acceleration"
    ),
    EMA_RIBBON_SPREAD(
        "EMA(5/13/34) Ribbon",
        "Ribbon",
        "Multi-EMA separation scaled by local volatility"
    ),
    RSI7_LEVEL(
        "RSI(7) Level",
        "RSI7",
        "Centered fast RSI momentum zone"
    ),
    CCI14_NORM(
        "CCI(14) Excursion",
        "CCI14",
        "Bounded Commodity Channel Index cyclical stretch"
    ),
    DI_DIRECTIONAL(
        "DMI(10) Spread",
        "DMI",
        "+DI minus -DI directional trend strength"
    ),
    PRICE_ZSCORE(
        "Rolling Price Z-Score",
        "Z-Score",
        "20-bar (Close - Mean) / StdDev statistical stretch"
    ),
    MASTER_MOMENTUM(
        "Master (BTC) Impulse",
        "BTC Mom",
        "Timestamp-aligned Master asset EMA5 velocity + order-flow impulse"
    ),
    MASTER_ZSCORE(
        "Master (BTC) Z-Score",
        "BTC Z",
        "Master asset 20-bar statistical stretch signaling market-wide extremes"
    ),
    ALT_BTC_REL_STRENGTH(
        "Alt vs Master Residual RS",
        "Alt/BTC RS",
        "5-bar beta-adjusted altcoin lead/lag residual return vs Master"
    ),
    ALT_BTC_CORRELATION(
        "Alt-Master 30b Correlation",
        "BTC Corr",
        "Rolling 30-bar Pearson return coupling between altcoin and Master"
    ),
    ALT_BTC_BETA(
        "Alt-Master Dynamic Beta",
        "BTC Beta",
        "Rolling 30-bar sensitivity of altcoin returns to Master shocks"
    ),
    NORM_LINREG_SLOPE(
        "Normalized Linear Regression Slope",
        "LinReg",
        "Least-squares slope of the last 20 closes in ATR units, weighted by trend cleanliness (R-squared)"
    ),
    DONCHIAN_POSITION(
        "Donchian Channel Position",
        "Donch",
        "Where the close sits inside the 20-bar high/low channel (bottom = -2, top = +2)"
    ),
    LINREG_CHANNEL_POSITION(
        "Regression Channel Position",
        "Chan",
        "How far price is from the middle of its regression channel, in standard deviations (bottom = long zone, top = short zone)"
    ),
    TIME_OF_DAY_SIN(
        "Time of Day (sine)",
        "Time-S",
        "Position in the 24-hour UTC cycle (lets the model learn good and bad hours)"
    ),
    TIME_OF_DAY_COS(
        "Time of Day (cosine)",
        "Time-C",
        "Position in the 24-hour UTC cycle, second half of the pair"
    ),
    TIME_OF_DAY_2X_SIN(
        "Twice-Daily Pattern (sine)",
        "Time2-S",
        "Position in a 12-hour cycle (lets the model learn two busy or quiet periods a day)"
    ),
    TIME_OF_DAY_2X_COS(
        "Twice-Daily Pattern (cosine)",
        "Time2-C",
        "Position in a 12-hour cycle, second half of the pair"
    ),
    WEEKEND(
        "Weekend",
        "Wkend",
        "1 on Saturday and Sunday (UTC), 0 on weekdays"
    )
}

@Serializable
enum class IndicatorPriorityTier {
    LEAD,
    CORE,
    SUPPORT,
    SECONDARY
}

@Serializable
data class AlertSettings(
    val timeframe: Timeframe = Timeframe.M1,
    /** Float multiplier, default 1.0 */
    val minProfitMultiplier: Double = 1.0,
    /** Minimum Logistic Regression probability to fire LONG/SHORT (0.52..0.75) */
    val signalThreshold: Double = 0.58,
    /** Whether each asset observes & learns from the Master Asset + pooled Master Model */
    val observeWithMaster: Boolean = true,
    /** Master market-leader symbol (default BTCUSDT) whose behavior & alt coupling is learned */
    val masterAsset: String = "BTCUSDT",
    /** Only alert on assets whose last 3 weeks of practice trades ended in profit (see ProvenGate). */
    val onlyProvenAssets: Boolean = true,
    /** Trade amount in USD (the position size the stop and target are worked out for). */
    val capitalUsd: Double = 100.0,
    /** Most money you accept to lose on one trade; sets the stop-loss distance. */
    val maxLossUsd: Double = 0.30
) {
    val effectiveMinProfitMultiplier: Double
        get() = minProfitMultiplier.coerceIn(MIN_PROFIT_MULTIPLIER, MAX_PROFIT_MULTIPLIER)

    val effectiveSignalThreshold: Double get() = signalThreshold.coerceIn(0.50, 0.85)

    val effectiveCapitalUsd: Double get() = capitalUsd.coerceAtLeast(1.0)
    val effectiveMaxLossUsd: Double get() = maxLossUsd.coerceIn(0.01, effectiveCapitalUsd)

    /** Stop-loss distance as % of the entry price: max loss / trade amount (never tighter than 0.10%). */
    val stopLossPct: Double get() = (effectiveMaxLossUsd / effectiveCapitalUsd * 100.0).coerceAtLeast(MIN_STOP_PCT)

    /** Take-profit distance as % of the entry price: stop distance x profit multiplier. */
    val takeProfitPct: Double get() = stopLossPct * effectiveMinProfitMultiplier

    /** What you lose if the stop is hit / win if the target is hit, in USD. */
    val slUsd: Double get() = effectiveCapitalUsd * stopLossPct / 100.0
    val tpUsd: Double get() = slUsd * effectiveMinProfitMultiplier
    val effectiveMasterAsset: String get() = normalizeMasterAsset(masterAsset)

    companion object {
        /** The profit multiplier is a decimal, but never below 1 (reward at least equal to risk). */
        const val MIN_PROFIT_MULTIPLIER = 1.0
        const val MAX_PROFIT_MULTIPLIER = 10.0
        const val MIN_STOP_PCT = 0.10

        fun normalizeMasterAsset(raw: String?): String {
            val cleaned = (raw ?: "").trim().uppercase().replace("/", "").replace("-", "")
            if (cleaned.isBlank()) return "BTCUSDT"
            return if (cleaned.endsWith("USDT")) cleaned else "${cleaned}USDT"
        }
    }
}

@Serializable
data class LogisticWeights(
    val weights: List<Double>,
    val bias: Double,
    val means: List<Double>,
    val stds: List<Double>,
    val trainedAtMs: Long,
    val sampleCount: Int
)

@Serializable
data class RollingWindowBenchmark(
    val label: String,
    val days: Int,
    val tradeCount: Int,
    val winRatePct: Double,
    val netReturnPct: Double,
    val profitFactor: Double,
    val accuracyPct: Double
)

@Serializable
data class RollingDriftBenchmarks(
    val d3: RollingWindowBenchmark,
    val d7: RollingWindowBenchmark,
    val d14: RollingWindowBenchmark,
    val d21: RollingWindowBenchmark
)

@Serializable
data class RollingDriftComparison(
    val day1VsDay3Drift: Double,
    val day1VsDay3AccuracyDelta: Double,
    val day3VsDay7Drift: Double,
    val day3VsDay7AccuracyDelta: Double,
    val week1NetPct: Double,
    val week2NetPct: Double,
    val week3NetPct: Double,
    val week1WinRate: Double,
    val week2WinRate: Double,
    val week3WinRate: Double,
    val benchmarks: RollingDriftBenchmarks
)

@Serializable
data class IndicatorEffectiveness(
    val id: IndicatorId,
    val label: String,
    val tier: IndicatorPriorityTier,
    val priorityWeight: Double,
    val isActive: Boolean,
    val isNewlyEffective: Boolean,
    val score1d: Double,
    val score3d: Double,
    val score7d: Double,
    val score14d: Double,
    val score21d: Double,
    val longWeight: Double,
    val shortWeight: Double,
    val currentValue: Double
)

@Serializable
data class BacktestTrade(
    val entryTimeMs: Long,
    val exitTimeMs: Long,
    val direction: EntryDirection,
    val entryPrice: Double,
    val exitPrice: Double,
    val netReturnPct: Double,
    val probability: Double,
    val won: Boolean
)

@Serializable
data class ChartSignalMarker(
    val openTimeMs: Long,
    val price: Double,
    val action: SignalAction,
    val probability: Double
)

@Serializable
data class AssetModelSnapshot(
    val symbol: String,
    val timeframe: Timeframe,
    val updatedAtMs: Long,
    val lastTrainedAtMs: Long,
    val lastPrice: Double,
    val zScore: Double,
    val masterAsset: String = "BTCUSDT",
    val masterZScore: Double = 0.0,
    val btcCorrelation: Double = 0.0,
    val btcBeta: Double = 1.0,
    val relStrengthVsMaster: Double = 0.0,
    val barCount: Int,
    val currentAction: SignalAction,
    val pLong: Double,
    val pShort: Double,
    val exhaustionScore: Double,
    val masterAgreement: Boolean,
    val masterPLong: Double,
    val masterPShort: Double,
    val activeIndicators: List<IndicatorId>,
    val promotedIndicators: List<IndicatorId>,
    val indicatorStats: List<IndicatorEffectiveness>,
    val drift: RollingDriftComparison,
    val trades21d: List<BacktestTrade>,
    val chartMarkers: List<ChartSignalMarker>,
    val lastSignalDirection: EntryDirection?,
    /** Distance from the regression channel middle in standard deviations; +/-1.6 is an entry zone. */
    val channelZ: Double = 0.0
)

@Serializable
data class MasterTopIndicator(
    val id: IndicatorId,
    val label: String,
    val score: Double
)

@Serializable
data class MasterModelSnapshot(
    val timeframe: Timeframe,
    val masterAsset: String = "BTCUSDT",
    val trainedAtMs: Long,
    val assetCount: Int,
    val sampleCount: Int,
    val longWeights: LogisticWeights,
    val shortWeights: LogisticWeights,
    val topIndicators: List<MasterTopIndicator>
)

@Serializable
data class SignalCandidate(
    val symbol: String,
    val eventType: EventType,
    val action: SignalAction,
    val price: Double,
    val pLong: Double,
    val pShort: Double,
    val zScore: Double = 0.0,
    val topIndicator: String,
    val timestampMs: Long,
    val eventTimeMs: Long = timestampMs,
    val missed: Boolean = false,
    val note: String? = null,
    /** Suggested stop and target for LONG/SHORT signals, from the user's trade amount and max loss. */
    val slPrice: Double? = null,
    val tpPrice: Double? = null,
    /** True = write to the Alert Log only, no notification (e.g. a stop hit on a trade you never entered). */
    val silent: Boolean = false
)

@Serializable
data class SymbolSignalState(
    val symbol: String,
    val mode: AssetMode = AssetMode.GENERAL,
    val lastProcessedOpenMs: Long = 0L,
    val lastTrainedAtMs: Long = 0L,
    val lastAction: SignalAction = SignalAction.WAIT,
    /** Remembers last LONG or SHORT signal so switching Positioned ON knows the side */
    val lastSignalDirection: EntryDirection? = null,
    val lastSignalAtMs: Long? = null,
    val lastExitAlertAtMs: Long? = null,
    val previousActiveIndicators: List<IndicatorId> = emptyList(),
    /** The trade started by the last alert, followed until it closes. */
    val activeTrade: ActiveTrade? = null,
    val closedTrades: List<ClosedTrade> = emptyList()
)

object SignalStateCodec {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun encode(state: SymbolSignalState): String =
        json.encodeToString(SymbolSignalState.serializer(), state)

    fun decode(raw: String?, symbol: String): SymbolSignalState {
        if (raw.isNullOrBlank()) return SymbolSignalState(symbol = symbol)
        return runCatching {
            json.decodeFromString(SymbolSignalState.serializer(), raw)
        }.getOrElse {
            SymbolSignalState(symbol = symbol)
        }
    }
}
