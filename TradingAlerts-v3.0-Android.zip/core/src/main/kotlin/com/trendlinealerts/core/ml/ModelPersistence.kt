package com.trendlinealerts.core.ml

import com.trendlinealerts.core.model.AssetModelSnapshot
import com.trendlinealerts.core.model.IndicatorId
import com.trendlinealerts.core.model.LogisticWeights
import com.trendlinealerts.core.model.MasterModelSnapshot
import com.trendlinealerts.core.model.Timeframe
import kotlinx.serialization.Serializable

object ModelPersistenceFormat {
    /** Bump when the saved layout changes; older files are then ignored and retrained. */
    const val VERSION = 1
}

/** One asset's trained model, saved so a restart does not have to retrain everything. */
@Serializable
data class PersistedAssetModel(
    val formatVersion: Int,
    val featureCount: Int,
    /** Settings the model was trained under; a different key means the file is not reused. */
    val configKey: String,
    val savedAtMs: Long,
    val snapshot: AssetModelSnapshot,
    val longWeights: LogisticWeights,
    val shortWeights: LogisticWeights
)

@Serializable
data class PersistedMaster(
    val formatVersion: Int,
    val featureCount: Int,
    val configKey: String,
    val savedAtMs: Long,
    val master: MasterModelSnapshot
)

/** What one asset did on one UTC day. Kept for a year, long after the raw candles are gone. */
@Serializable
data class DailyRecord(
    val epochDay: Long,
    val symbol: String,
    val timeframe: Timeframe,
    val trades: Int,
    val wins: Int,
    val netReturnPct: Double,
    val grossWonPct: Double,
    val grossLostPct: Double,
    /** The clues the model relied on that day (recorded once per day). */
    val clues: List<IndicatorId> = emptyList()
)

data class LongTermPeriod(
    val label: String,
    val days: Int,
    val trades: Int,
    val winRatePct: Double,
    val netReturnPct: Double,
    val profitFactor: Double,
    val daysRecorded: Int,
    val topClues: List<IndicatorId>
)

object LongTermHistory {
    const val KEEP_DAYS = 366
    private const val DAY_MS = 86_400_000L

    /** Day-by-day results from the snapshot's practice trades, plus today's clues. */
    fun recordsFromSnapshot(snapshot: AssetModelSnapshot, nowMs: Long): List<DailyRecord> {
        val today = Math.floorDiv(nowMs, DAY_MS)
        val byDay = snapshot.trades21d.groupBy { Math.floorDiv(it.entryTimeMs, DAY_MS) }
        val days = (byDay.keys + today).toSortedSet()
        return days.map { day ->
            val trades = byDay[day].orEmpty()
            DailyRecord(
                epochDay = day,
                symbol = snapshot.symbol,
                timeframe = snapshot.timeframe,
                trades = trades.size,
                wins = trades.count { it.won },
                netReturnPct = trades.sumOf { it.netReturnPct },
                grossWonPct = trades.filter { it.netReturnPct > 0.0 }.sumOf { it.netReturnPct },
                grossLostPct = kotlin.math.abs(trades.filter { it.netReturnPct < 0.0 }.sumOf { it.netReturnPct }),
                clues = if (day == today) snapshot.activeIndicators.take(3) else emptyList()
            )
        }
    }

    /** Replaces matching days (so re-saving never double counts) and drops anything older than a year. */
    fun upsert(existing: List<DailyRecord>, fresh: List<DailyRecord>, nowMs: Long): List<DailyRecord> {
        data class Key(val day: Long, val symbol: String, val tf: Timeframe)
        val map = LinkedHashMap<Key, DailyRecord>()
        existing.forEach { map[Key(it.epochDay, it.symbol, it.timeframe)] = it }
        fresh.forEach { f ->
            val key = Key(f.epochDay, f.symbol, f.timeframe)
            val old = map[key]
            map[key] = if (f.clues.isEmpty() && old != null) f.copy(clues = old.clues) else f
        }
        val minDay = Math.floorDiv(nowMs, DAY_MS) - KEEP_DAYS
        return map.values.filter { it.epochDay >= minDay }.sortedBy { it.epochDay }
    }

    /** 1, 3, 6 and 12 month totals. [symbol] null = all assets together. */
    fun periods(records: List<DailyRecord>, symbol: String?, timeframe: Timeframe, nowMs: Long): List<LongTermPeriod> {
        val today = Math.floorDiv(nowMs, DAY_MS)
        val scoped = records.filter { it.timeframe == timeframe && (symbol == null || it.symbol == symbol) }
        return listOf("1 month" to 30, "3 months" to 90, "6 months" to 180, "12 months" to 365).map { (label, days) ->
            val inRange = scoped.filter { it.epochDay > today - days }
            val trades = inRange.sumOf { it.trades }
            val wins = inRange.sumOf { it.wins }
            val won = inRange.sumOf { it.grossWonPct }
            val lost = inRange.sumOf { it.grossLostPct }
            val clues = inRange.flatMap { it.clues }
                .groupingBy { it }.eachCount()
                .entries.sortedByDescending { it.value }
                .take(3).map { it.key }
            LongTermPeriod(
                label = label,
                days = days,
                trades = trades,
                winRatePct = if (trades > 0) wins * 100.0 / trades else 0.0,
                netReturnPct = inRange.sumOf { it.netReturnPct },
                profitFactor = when {
                    lost > 0.0 -> minOf(won / lost, 9.99)
                    won > 0.0 -> 9.99
                    else -> 1.0
                },
                daysRecorded = inRange.map { it.epochDay }.distinct().size,
                topClues = clues
            )
        }
    }
}
