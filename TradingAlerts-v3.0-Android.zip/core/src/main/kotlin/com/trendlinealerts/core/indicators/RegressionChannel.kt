package com.trendlinealerts.core.indicators

import com.trendlinealerts.core.model.Candle
import kotlin.math.max
import kotlin.math.sqrt

/**
 * The regression channel as drawn on the chart: a straight least-squares line through the last
 * [window] closes, with bands [bandSigmas] standard deviations above and below it.
 * The bands are the entry zones: price at the lower band = possible long, upper band = possible short.
 * Indices are positions in the candle list that was passed in.
 */
data class ChannelLine(
    val startIdx: Int,
    val endIdx: Int,
    val midStart: Double,
    val midEnd: Double,
    val bandStart: Double,
    val bandEnd: Double
) {
    val upperStart: Double get() = midStart + bandStart
    val upperEnd: Double get() = midEnd + bandEnd
    val lowerStart: Double get() = midStart - bandStart
    val lowerEnd: Double get() = midEnd - bandEnd
}

object RegressionChannel {
    fun compute(
        candles: List<Candle>,
        window: Int,
        bandSigmas: Double = ScalpingIndicators.CHANNEL_ENTRY_Z
    ): ChannelLine? {
        val n = candles.size
        if (window < 10 || n < window) return null
        val start = n - window
        var sy = 0.0
        var sxy = 0.0
        var syy = 0.0
        for (j in 0 until window) {
            val y = candles[start + j].close
            sy += y
            sxy += j * y
            syy += y * y
        }
        val m = window.toDouble()
        val sx = m * (m - 1.0) / 2.0
        val sxx = (m - 1.0) * m * (2.0 * m - 1.0) / 6.0
        val denX = m * sxx - sx * sx
        if (denX <= 1e-12) return null
        val slope = (m * sxy - sx * sy) / denX
        val intercept = (sy - slope * sx) / m
        val meanY = sy / m
        val syyC = syy - m * meanY * meanY
        val sxxC = sxx - sx * sx / m
        val sse = max(0.0, syyC - slope * slope * sxxC)
        val sigma = max(sqrt(sse / m), candles[n - 1].close * 0.0003)
        return ChannelLine(
            startIdx = start,
            endIdx = n - 1,
            midStart = intercept,
            midEnd = intercept + slope * (m - 1.0),
            bandStart = bandSigmas * sigma,
            bandEnd = bandSigmas * sigma
        )
    }
}
