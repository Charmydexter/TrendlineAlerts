package com.trendlinealerts.core.trade

import com.trendlinealerts.core.analytics.TradeRiskCalculator
import com.trendlinealerts.core.model.ActiveTrade
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.ClosedTrade
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.TradeCloseReason
import com.trendlinealerts.core.model.TradeTiming

/**
 * Follows a trade from the moment its alert fires:
 * waiting (first 3 minutes) -> open (entry assumed at the alert price) -> closed by target, stop,
 * the model turning against it, or the trade window running out.
 * Pure logic with no Android code, so it can be unit tested.
 */
object TradeTracker {

    enum class Phase { WAITING_ENTRY, OPEN }

    data class Closure(val reason: TradeCloseReason, val exitPrice: Double, val pnlUsd: Double)

    fun open(
        direction: EntryDirection,
        price: Double,
        settings: AlertSettings,
        alertAtMs: Long,
        horizonMs: Long
    ): ActiveTrade? {
        val levels = TradeRiskCalculator.compute(price, direction, settings) ?: return null
        return ActiveTrade(
            direction = direction,
            alertAtMs = alertAtMs,
            entryPrice = price,
            slPrice = levels.slPrice,
            tpPrice = levels.tpPrice,
            sizeUsd = settings.effectiveCapitalUsd,
            slUsd = levels.slUsd,
            tpUsd = levels.tpUsd,
            expiresAtMs = alertAtMs + TradeTiming.AUTO_ENTRY_DELAY_MS + horizonMs
        )
    }

    fun phase(trade: ActiveTrade, nowMs: Long): Phase =
        if (nowMs < trade.entryAtMs) Phase.WAITING_ENTRY else Phase.OPEN

    fun pnlAt(trade: ActiveTrade, price: Double): Double {
        if (trade.entryPrice <= 0.0) return 0.0
        val move = if (trade.direction == EntryDirection.LONG) {
            (price - trade.entryPrice) / trade.entryPrice
        } else {
            (trade.entryPrice - price) / trade.entryPrice
        }
        return trade.sizeUsd * move
    }

    fun closeAt(trade: ActiveTrade, reason: TradeCloseReason, price: Double): Closure =
        Closure(reason, price, pnlAt(trade, price))

    /**
     * Target or stop touched by a candle that opened after the assumed entry time. When one candle
     * touches both, the stop counts (the cautious choice). Earlier candles are ignored.
     */
    fun checkPriceExit(trade: ActiveTrade, candles: List<Candle>): Closure? {
        var start = candles.size
        var i = candles.lastIndex
        while (i >= 0 && candles[i].openTimeMs >= trade.entryAtMs) {
            start = i
            i--
        }
        for (k in start until candles.size) {
            val c = candles[k]
            val long = trade.direction == EntryDirection.LONG
            val stopHit = if (long) c.low <= trade.slPrice else c.high >= trade.slPrice
            val targetHit = if (long) c.high >= trade.tpPrice else c.low <= trade.tpPrice
            if (stopHit) return Closure(TradeCloseReason.STOP_HIT, trade.slPrice, -trade.slUsd)
            if (targetHit) return Closure(TradeCloseReason.TARGET_HIT, trade.tpPrice, trade.tpUsd)
        }
        return null
    }

    fun toClosed(trade: ActiveTrade, closure: Closure, nowMs: Long): ClosedTrade = ClosedTrade(
        direction = trade.direction,
        entryPrice = trade.entryPrice,
        exitPrice = closure.exitPrice,
        reason = closure.reason,
        pnlUsd = closure.pnlUsd,
        enteredByUser = trade.enteredByUser,
        alertAtMs = trade.alertAtMs,
        closedAtMs = nowMs
    )

    fun appendClosed(history: List<ClosedTrade>, closed: ClosedTrade): List<ClosedTrade> =
        (history + closed).takeLast(TradeTiming.MAX_CLOSED_PER_ASSET)
}
