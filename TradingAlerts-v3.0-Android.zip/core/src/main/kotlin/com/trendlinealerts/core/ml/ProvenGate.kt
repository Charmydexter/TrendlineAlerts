package com.trendlinealerts.core.ml

import com.trendlinealerts.core.model.BacktestTrade

/**
 * "Proven first": an asset only sends alerts once its last 3 weeks of practice trades
 * (the same trades the Overview shows) ended in profit, with enough trades to mean something.
 */
object ProvenGate {
    const val MIN_TRADES = 8
    private const val DAY_MS = 86_400_000L

    data class Status(
        val proven: Boolean,
        val tradeCount: Int,
        val netReturnPct: Double,
        val winRatePct: Double
    )

    fun check(trades: List<BacktestTrade>, nowMs: Long, windowDays: Int = 21): Status {
        val since = nowMs - windowDays * DAY_MS
        val recent = trades.filter { it.entryTimeMs >= since }
        val net = recent.sumOf { it.netReturnPct }
        val winRate = if (recent.isEmpty()) 0.0 else recent.count { it.won } * 100.0 / recent.size
        return Status(
            proven = recent.size >= MIN_TRADES && net > 0.0,
            tradeCount = recent.size,
            netReturnPct = net,
            winRatePct = winRate
        )
    }
}
