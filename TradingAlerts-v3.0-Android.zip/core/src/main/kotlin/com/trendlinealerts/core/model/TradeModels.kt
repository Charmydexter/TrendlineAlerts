package com.trendlinealerts.core.model

import kotlinx.serialization.Serializable

object TradeTiming {
    /** After an alert the app assumes you are in the trade this long later (you place orders by hand). */
    const val AUTO_ENTRY_DELAY_MS = 3L * 60_000L
    const val MAX_CLOSED_PER_ASSET = 100
}

/** A trade started by an alert. Stop and target are fixed at the alert price. */
@Serializable
data class ActiveTrade(
    val direction: EntryDirection,
    val alertAtMs: Long,
    val entryPrice: Double,
    val slPrice: Double,
    val tpPrice: Double,
    val sizeUsd: Double,
    val slUsd: Double,
    val tpUsd: Double,
    val expiresAtMs: Long,
    /** True once the Positioned switch was on at any time before the trade ended. */
    val enteredByUser: Boolean = false
) {
    val entryAtMs: Long get() = alertAtMs + TradeTiming.AUTO_ENTRY_DELAY_MS
}

@Serializable
enum class TradeCloseReason {
    TARGET_HIT,
    STOP_HIT,
    ML_EXIT,
    CANCELLED,
    EXPIRED
}

@Serializable
data class ClosedTrade(
    val direction: EntryDirection,
    val entryPrice: Double,
    val exitPrice: Double,
    val reason: TradeCloseReason,
    val pnlUsd: Double,
    /** Only trades you entered (Positioned on) count in your own results. */
    val enteredByUser: Boolean,
    val alertAtMs: Long,
    val closedAtMs: Long
)
