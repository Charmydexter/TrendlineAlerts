package com.trendlinealerts.core.model

/**
 * Everyday wording for the model's indicators, so no screen has to show codes like "OFI" or "Z".
 * Written as a short noun phrase that fits "the model uses ___".
 */
fun IndicatorId.plainName(): String = when (this) {
    IndicatorId.ORDER_FLOW_IMBALANCE -> "buying vs selling pressure"
    IndicatorId.VOLUME_SURGE -> "sudden jumps in trading volume"
    IndicatorId.RSI7_SLOPE -> "how fast short-term momentum is changing"
    IndicatorId.RSI7_LEVEL -> "short-term overbought or oversold"
    IndicatorId.EMA_SLOPE_FAST -> "speed of the short-term trend"
    IndicatorId.BB_SQUEEZE_TILT -> "price squeezing before a move"
    IndicatorId.PRICE_ZSCORE -> "how stretched price is from normal"
    IndicatorId.MASTER_MOMENTUM -> "the market leader's momentum"
    IndicatorId.ALT_BTC_REL_STRENGTH -> "strength compared with the market leader"
    IndicatorId.STOCH_RSI_DIFF -> "momentum turning points"
    IndicatorId.VWAP_DEVIATION -> "distance from the average traded price"
    IndicatorId.MACD_HIST_SLOPE -> "trend strength building or fading"
    IndicatorId.MASTER_ZSCORE -> "how stretched the market leader is"
    IndicatorId.ALT_BTC_CORRELATION -> "how closely it follows the market leader"
    IndicatorId.EMA_RIBBON_SPREAD -> "whether short and long trends line up"
    IndicatorId.CCI14_NORM -> "price compared with its recent average"
    IndicatorId.DI_DIRECTIONAL -> "whether buyers or sellers are winning"
    IndicatorId.ALT_BTC_BETA -> "how strongly it reacts to the market leader"
    IndicatorId.NORM_LINREG_SLOPE -> "steady direction of the last 20 candles"
    IndicatorId.DONCHIAN_POSITION -> "where price sits in its recent high-low range"
    IndicatorId.LINREG_CHANNEL_POSITION -> "where price sits inside its price channel"
    IndicatorId.TIME_OF_DAY_SIN, IndicatorId.TIME_OF_DAY_COS -> "the time of day"
    IndicatorId.TIME_OF_DAY_2X_SIN, IndicatorId.TIME_OF_DAY_2X_COS -> "busy and quiet times of the day"
    IndicatorId.WEEKEND -> "whether it is the weekend"
}

/** How helpful a clue has been over the last 3 weeks, in words. */
fun IndicatorEffectiveness.helpfulness(): String = when {
    score21d >= 0.05 -> "Helpful"
    score21d >= 0.015 -> "A little helpful"
    else -> "Not helpful"
}

/** Whether a clue is getting better or fading, comparing the last few days with the weeks before. */
fun IndicatorEffectiveness.trendWord(): String {
    val recent = score1d * 0.45 + score3d * 0.35 + score7d * 0.20
    val older = (score14d + score21d) * 0.5
    return when {
        recent > older + 0.03 -> "Getting better"
        recent < older - 0.03 -> "Fading"
        else -> "Steady"
    }
}
