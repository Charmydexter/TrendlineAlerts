package com.trendlinealerts.core.analytics

import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection
import java.util.Locale

object HeikinAshiConverter {
    fun convert(candles: List<Candle>): List<Candle> {
        if (candles.isEmpty()) return emptyList()
        val out = ArrayList<Candle>(candles.size)
        var prevHaOpen = (candles[0].open + candles[0].close) / 2.0
        var prevHaClose = (candles[0].open + candles[0].high + candles[0].low + candles[0].close) / 4.0
        for (i in candles.indices) {
            val c = candles[i]
            val haClose = (c.open + c.high + c.low + c.close) / 4.0
            val haOpen = if (i == 0) {
                (c.open + c.close) / 2.0
            } else {
                (prevHaOpen + prevHaClose) / 2.0
            }
            val haHigh = maxOf(c.high, haOpen, haClose)
            val haLow = minOf(c.low, haOpen, haClose)
            out.add(
                Candle(
                    openTimeMs = c.openTimeMs,
                    open = haOpen,
                    high = haHigh,
                    low = haLow,
                    close = haClose,
                    volume = c.volume,
                    isClosed = c.isClosed
                )
            )
            prevHaOpen = haOpen
            prevHaClose = haClose
        }
        return out
    }
}

/** Entry, stop-loss and take-profit for one trade, with the dollar amounts at risk and at stake. */
data class TradeLevels(
    val entryPrice: Double,
    val tpPrice: Double,
    val slPrice: Double,
    val tpPct: Double,
    val slPct: Double,
    val tpUsd: Double,
    val slUsd: Double
)

object TradeRiskCalculator {
    /**
     * Stop and target for entering at [price]. The stop distance is max loss / trade amount; the
     * target is that distance times the profit multiplier. These are the same distances the model
     * is trained on, so what you see here is what the model's win rates are about.
     */
    fun compute(price: Double, direction: EntryDirection, settings: AlertSettings): TradeLevels? {
        if (price <= 0.0 || price.isNaN() || price.isInfinite()) return null
        val slFrac = settings.stopLossPct / 100.0
        val tpFrac = settings.takeProfitPct / 100.0
        val sl = if (direction == EntryDirection.LONG) price * (1.0 - slFrac) else price * (1.0 + slFrac)
        val tp = if (direction == EntryDirection.LONG) price * (1.0 + tpFrac) else price * (1.0 - tpFrac)
        return TradeLevels(
            entryPrice = price,
            tpPrice = tp,
            slPrice = sl,
            tpPct = settings.takeProfitPct,
            slPct = settings.stopLossPct,
            tpUsd = settings.tpUsd,
            slUsd = settings.slUsd
        )
    }
}

object PriceFormat {
    fun format(v: Double): String = when {
        v >= 1_000.0 -> String.format(Locale.US, "%.2f", v)
        v >= 1.0 -> String.format(Locale.US, "%.4f", v)
        v >= 0.01 -> String.format(Locale.US, "%.5f", v)
        else -> String.format(Locale.US, "%.7f", v)
    }
}
