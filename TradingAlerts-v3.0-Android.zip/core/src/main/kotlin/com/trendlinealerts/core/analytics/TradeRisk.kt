package com.trendlinealerts.core.analytics

import com.trendlinealerts.core.model.Candle

object HeikinAshiConverter {
    fun convert(candles: List<Candle>): List<Candle> {
        if (candles.isEmpty()) return emptyList()
        val out = ArrayList<Candle>(candles.size)
        var prevHaOpen = (candles[0].open + candles[0].close) / 2.0
        var prevHaClose = (candles[0].open + candles[0].high + candles[0].low + candles[0].close) / 4.0
        for (i in candles.indices) {
            val c = candles[i]
            val haClose = (c.open + c.high + c.low + c.close) / 4.0
            val haOpen = if (i == 0) {
                (c.open + c.close) / 2.0
            } else {
                (prevHaOpen + prevHaClose) / 2.0
            }
            val haHigh = maxOf(c.high, haOpen, haClose)
            val haLow = minOf(c.low, haOpen, haClose)
            out.add(
                Candle(
                    openTimeMs = c.openTimeMs,
                    open = haOpen,
                    high = haHigh,
                    low = haLow,
                    close = haClose,
                    volume = c.volume,
                    isClosed = c.isClosed
                )
            )
            prevHaOpen = haOpen
            prevHaClose = haClose
        }
        return out
    }
}
