package com.trendlinealerts.core.indicators

import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.IndicatorId
import com.trendlinealerts.core.model.IndicatorPriorityTier
import com.trendlinealerts.core.model.Timeframe
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.tanh

data class IndicatorPrioritySpec(
    val tier: IndicatorPriorityTier,
    val weight: Double
)

class ComputedIndicators(
    val features: FloatArray,
    val atr14: DoubleArray,
    val ema5: DoubleArray,
    val ema13: DoubleArray,
    val ema34: DoubleArray,
    val vwap: DoubleArray,
    val bbUpper: DoubleArray,
    val bbLower: DoubleArray,
    val zScoreSeries: DoubleArray,
    /** Per candle: distance of the close from the regression-channel middle, in standard deviations. */
    val channelZSeries: DoubleArray = DoubleArray(0),
    val latestMasterZScore: Double = 0.0,
    val latestBtcCorrelation: Double = 0.0,
    val latestBtcBeta: Double = 1.0,
    val latestRelStrength: Double = 0.0
)

private class MasterCausalSeries(
    val times: LongArray,
    val momentum: DoubleArray,
    val zScore: DoubleArray,
    val ret1: DoubleArray,
    val ret5: DoubleArray
)

object ScalpingIndicators {
    val ALL_INDICATORS: List<IndicatorId> = IndicatorId.entries
    val FEATURE_COUNT: Int = ALL_INDICATORS.size

    /** Entries only happen when price is this many standard deviations from the channel middle. */
    const val CHANNEL_ENTRY_Z = 1.6

    /** Candles the regression channel is fitted over; shorter timeframes need more candles. */
    fun channelWindow(timeframe: Timeframe): Int = when (timeframe) {
        Timeframe.M1 -> 60
        Timeframe.M3 -> 40
        Timeframe.M5 -> 36
        Timeframe.M15 -> 30
        Timeframe.M30 -> 24
    }

    private val PRIORITY_MATRIX: Map<Timeframe, Map<IndicatorId, IndicatorPrioritySpec>> = mapOf(
        Timeframe.M1 to mapOf(
            IndicatorId.TIME_OF_DAY_SIN to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_COS to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_2X_SIN to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_2X_COS to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.WEEKEND to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.LINREG_CHANNEL_POSITION to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.98),
            IndicatorId.NORM_LINREG_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.80),
            IndicatorId.DONCHIAN_POSITION to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.76),
            IndicatorId.ORDER_FLOW_IMBALANCE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.VOLUME_SURGE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.RSI7_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.EMA_SLOPE_FAST to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.BB_SQUEEZE_TILT to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.PRICE_ZSCORE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.96),
            IndicatorId.MASTER_MOMENTUM to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.95),
            IndicatorId.ALT_BTC_REL_STRENGTH to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.85),
            IndicatorId.STOCH_RSI_DIFF to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.78),
            IndicatorId.VWAP_DEVIATION to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.78),
            IndicatorId.MACD_HIST_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.75),
            IndicatorId.MASTER_ZSCORE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.74),
            IndicatorId.ALT_BTC_CORRELATION to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.62),
            IndicatorId.ALT_BTC_BETA to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.58),
            IndicatorId.EMA_RIBBON_SPREAD to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.52),
            IndicatorId.RSI7_LEVEL to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.50),
            IndicatorId.CCI14_NORM to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.32),
            IndicatorId.DI_DIRECTIONAL to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.30)
        ),
        Timeframe.M3 to mapOf(
            IndicatorId.TIME_OF_DAY_SIN to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_COS to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_2X_SIN to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_2X_COS to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.WEEKEND to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.LINREG_CHANNEL_POSITION to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.98),
            IndicatorId.NORM_LINREG_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.82),
            IndicatorId.DONCHIAN_POSITION to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.78),
            IndicatorId.EMA_SLOPE_FAST to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.VOLUME_SURGE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.MACD_HIST_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.BB_SQUEEZE_TILT to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.RSI7_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.96),
            IndicatorId.PRICE_ZSCORE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.94),
            IndicatorId.MASTER_MOMENTUM to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.92),
            IndicatorId.ALT_BTC_REL_STRENGTH to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.84),
            IndicatorId.ORDER_FLOW_IMBALANCE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.80),
            IndicatorId.VWAP_DEVIATION to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.78),
            IndicatorId.STOCH_RSI_DIFF to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.75),
            IndicatorId.MASTER_ZSCORE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.75),
            IndicatorId.ALT_BTC_CORRELATION to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.64),
            IndicatorId.ALT_BTC_BETA to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.60),
            IndicatorId.EMA_RIBBON_SPREAD to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.58),
            IndicatorId.RSI7_LEVEL to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.55),
            IndicatorId.CCI14_NORM to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.38),
            IndicatorId.DI_DIRECTIONAL to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35)
        ),
        Timeframe.M5 to mapOf(
            IndicatorId.TIME_OF_DAY_SIN to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_COS to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_2X_SIN to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_2X_COS to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.WEEKEND to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.LINREG_CHANNEL_POSITION to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.98),
            IndicatorId.NORM_LINREG_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.86),
            IndicatorId.DONCHIAN_POSITION to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.80),
            IndicatorId.MACD_HIST_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.EMA_RIBBON_SPREAD to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.VWAP_DEVIATION to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.BB_SQUEEZE_TILT to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.98),
            IndicatorId.VOLUME_SURGE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.95),
            IndicatorId.MASTER_MOMENTUM to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.88),
            IndicatorId.ALT_BTC_REL_STRENGTH to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.85),
            IndicatorId.PRICE_ZSCORE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.82),
            IndicatorId.EMA_SLOPE_FAST to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.80),
            IndicatorId.MASTER_ZSCORE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.78),
            IndicatorId.RSI7_LEVEL to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.76),
            IndicatorId.STOCH_RSI_DIFF to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.74),
            IndicatorId.CCI14_NORM to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.70),
            IndicatorId.ALT_BTC_CORRELATION to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.65),
            IndicatorId.ALT_BTC_BETA to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.60),
            IndicatorId.ORDER_FLOW_IMBALANCE to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.52),
            IndicatorId.RSI7_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.52),
            IndicatorId.DI_DIRECTIONAL to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.45)
        ),
        Timeframe.M15 to mapOf(
            IndicatorId.TIME_OF_DAY_SIN to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_COS to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_2X_SIN to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_2X_COS to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.WEEKEND to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.LINREG_CHANNEL_POSITION to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.98),
            IndicatorId.NORM_LINREG_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.95),
            IndicatorId.DONCHIAN_POSITION to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.88),
            IndicatorId.EMA_RIBBON_SPREAD to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.MACD_HIST_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.DI_DIRECTIONAL to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.CCI14_NORM to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.96),
            IndicatorId.VWAP_DEVIATION to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.94),
            IndicatorId.ALT_BTC_REL_STRENGTH to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.86),
            IndicatorId.MASTER_MOMENTUM to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.84),
            IndicatorId.MASTER_ZSCORE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.82),
            IndicatorId.RSI7_LEVEL to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.80),
            IndicatorId.PRICE_ZSCORE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.78),
            IndicatorId.BB_SQUEEZE_TILT to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.76),
            IndicatorId.VOLUME_SURGE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.74),
            IndicatorId.ALT_BTC_CORRELATION to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.70),
            IndicatorId.ALT_BTC_BETA to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.62),
            IndicatorId.EMA_SLOPE_FAST to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.55),
            IndicatorId.STOCH_RSI_DIFF to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.52),
            IndicatorId.ORDER_FLOW_IMBALANCE to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.RSI7_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35)
        ),
        Timeframe.M30 to mapOf(
            IndicatorId.TIME_OF_DAY_SIN to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_COS to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_2X_SIN to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.TIME_OF_DAY_2X_COS to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.WEEKEND to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.35),
            IndicatorId.LINREG_CHANNEL_POSITION to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.98),
            IndicatorId.NORM_LINREG_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.97),
            IndicatorId.DONCHIAN_POSITION to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.95),
            IndicatorId.DI_DIRECTIONAL to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.EMA_RIBBON_SPREAD to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.CCI14_NORM to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 1.00),
            IndicatorId.MACD_HIST_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.96),
            IndicatorId.RSI7_LEVEL to IndicatorPrioritySpec(IndicatorPriorityTier.LEAD, 0.94),
            IndicatorId.ALT_BTC_REL_STRENGTH to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.88),
            IndicatorId.MASTER_ZSCORE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.84),
            IndicatorId.MASTER_MOMENTUM to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.82),
            IndicatorId.VWAP_DEVIATION to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.80),
            IndicatorId.BB_SQUEEZE_TILT to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.76),
            IndicatorId.ALT_BTC_CORRELATION to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.74),
            IndicatorId.VOLUME_SURGE to IndicatorPrioritySpec(IndicatorPriorityTier.CORE, 0.72),
            IndicatorId.ALT_BTC_BETA to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.65),
            IndicatorId.PRICE_ZSCORE to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.60),
            IndicatorId.STOCH_RSI_DIFF to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.52),
            IndicatorId.EMA_SLOPE_FAST to IndicatorPrioritySpec(IndicatorPriorityTier.SUPPORT, 0.50),
            IndicatorId.ORDER_FLOW_IMBALANCE to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.32),
            IndicatorId.RSI7_SLOPE to IndicatorPrioritySpec(IndicatorPriorityTier.SECONDARY, 0.32)
        )
    )

    fun getPriority(timeframe: Timeframe, id: IndicatorId): IndicatorPrioritySpec {
        return PRIORITY_MATRIX.getValue(timeframe).getValue(id)
    }

    fun getDefaultActiveIndicators(timeframe: Timeframe, count: Int = 8): List<IndicatorId> {
        val map = PRIORITY_MATRIX.getValue(timeframe)
        return ALL_INDICATORS
            .sortedByDescending { map.getValue(it).weight }
            .take(count)
    }

    private fun clamp(v: Double, lo: Double, hi: Double): Float {
        val c = if (v < lo) lo else if (v > hi) hi else v
        return c.toFloat()
    }

    private fun clampDouble(v: Double, lo: Double, hi: Double): Double {
        return if (v < lo) lo else if (v > hi) hi else v
    }

    private fun buildMasterCausalSeries(masterCandles: List<Candle>): MasterCausalSeries? {
        val m = masterCandles.size
        if (m < 5) return null

        val times = LongArray(m)
        val momentum = DoubleArray(m)
        val zScore = DoubleArray(m)
        val ret1 = DoubleArray(m)
        val ret5 = DoubleArray(m)

        val k5 = 2.0 / 6.0
        val kOfi = 2.0 / 4.0
        var e5 = masterCandles[0].close
        var prevE5_1 = e5
        var prevE5_2 = e5
        var ofi = 0.0
        var atr = max(masterCandles[0].high - masterCandles[0].low, masterCandles[0].close * 0.001)

        val win = 20
        val closeBuf = DoubleArray(win)
        var cSum = 0.0
        var cSqSum = 0.0

        for (i in 0 until m) {
            val c = masterCandles[i]
            val prev = if (i > 0) masterCandles[i - 1] else c
            times[i] = c.openTimeMs

            if (i > 0) {
                prevE5_2 = prevE5_1
                prevE5_1 = e5
                e5 = c.close * k5 + e5 * (1.0 - k5)
            }

            val tr = maxOf(
                c.high - c.low,
                abs(c.high - prev.close),
                abs(c.low - prev.close)
            )
            atr = if (i == 0) tr else (atr * 13.0 + tr) / 14.0
            val safeAtr = maxOf(atr, c.close * 0.0004, 1e-9)

            val range = max(c.high - c.low, 1e-12)
            val rawOfi = ((c.close - c.low) - (c.high - c.close)) / range
            ofi = rawOfi * kOfi + ofi * (1.0 - kOfi)

            val emaVel = clampDouble((e5 - prevE5_2) / safeAtr, -3.0, 3.0)
            momentum[i] = clampDouble(emaVel * 0.65 + ofi * 0.85, -4.0, 4.0)

            val idx = i % win
            if (i >= win) {
                val oldC = closeBuf[idx]
                cSum -= oldC
                cSqSum -= oldC * oldC
            }
            closeBuf[idx] = c.close
            cSum += c.close
            cSqSum += c.close * c.close
            val cnt = min(i + 1, win)
            val mean = cSum / cnt.toDouble()
            val std = sqrt(max(0.0, cSqSum / cnt.toDouble() - mean * mean))
            zScore[i] = clampDouble((c.close - mean) / maxOf(std, c.close * 0.0002, 1e-9), -4.0, 4.0)

            ret1[i] = if (i > 0 && prev.close > 0.0) clampDouble((c.close - prev.close) / prev.close, -0.25, 0.25) else 0.0
            val c5 = if (i >= 5) masterCandles[i - 5].close else masterCandles[0].close
            ret5[i] = if (c5 > 0.0) clampDouble((c.close - c5) / c5, -0.35, 0.35) else 0.0
        }

        return MasterCausalSeries(times, momentum, zScore, ret1, ret5)
    }

    /**
     * Single-pass O(N) causal computation of all 18 scalping + Master (BTC) relationship features
     * plus optional chart overlays (EMA 5/13/34, VWAP, Bollinger Bands).
     */
    fun computeMatrix(
        candles: List<Candle>,
        timeframe: Timeframe,
        masterCandles: List<Candle> = emptyList()
    ): ComputedIndicators {
        val n = candles.size
        val features = FloatArray(n * FEATURE_COUNT)
        val atr14 = DoubleArray(n)
        val ema5 = DoubleArray(n)
        val ema13 = DoubleArray(n)
        val ema34 = DoubleArray(n)
        val vwap = DoubleArray(n)
        val bbUpper = DoubleArray(n)
        val bbLower = DoubleArray(n)
        val zScoreSeries = DoubleArray(n)
        val channelZSeries = DoubleArray(n)

        if (n == 0) {
            return ComputedIndicators(features, atr14, ema5, ema13, ema34, vwap, bbUpper, bbLower, zScoreSeries)
        }

        val master = if (masterCandles.size >= 5) buildMasterCausalSeries(masterCandles) else null
        var mPtr = 0

        val corrWin = 30
        val altR1Buf = DoubleArray(corrWin)
        val mR1Buf = DoubleArray(corrWin)
        var sumA = 0.0
        var sumM = 0.0
        var sumAA = 0.0
        var sumMM = 0.0
        var sumAM = 0.0

        val k5 = 2.0 / 6.0
        val k13 = 2.0 / 14.0
        val k34 = 2.0 / 35.0
        val k6 = 2.0 / 7.0
        val kMacdSig = 2.0 / 6.0
        val kOfi = 2.0 / 4.0

        var e5 = candles[0].close
        var e13 = candles[0].close
        var e34 = candles[0].close
        var e6 = candles[0].close
        var macdSig = 0.0
        var prevMacdHist = 0.0

        var avgGain7 = 0.0
        var avgLoss7 = 0.0
        val rsi7Arr = DoubleArray(n)

        var atr = max(candles[0].high - candles[0].low, candles[0].close * 0.001)
        var smoothPlusDm = 0.0
        var smoothMinusDm = 0.0
        var ofiEma = 0.0

        val vwapWin = when (timeframe) {
            Timeframe.M1 -> 60
            Timeframe.M3 -> 40
            else -> 30
        }
        val pvBuf = DoubleArray(vwapWin)
        val volBuf = DoubleArray(vwapWin)
        var pvSum = 0.0
        var volSum = 0.0

        val bbWin = 20
        val closeBuf = DoubleArray(bbWin)
        var closeSum = 0.0
        var closeSqSum = 0.0

        val tpWin = 14
        val tpBuf = DoubleArray(tpWin)
        var tpSum = 0.0

        val stochWin = 8
        val rsiWinBuf = DoubleArray(stochWin)
        var stochK = 50.0
        var stochD = 50.0

        val volWin = 20
        val volSmaBuf = DoubleArray(volWin)
        var volSmaSum = 0.0

        // Normalized linear-regression slope: least-squares line over the last lrWin closes.
        // Sums are kept incrementally (x = 0 for the oldest bar in the window).
        val lrWin = 20
        val lrBuf = DoubleArray(lrWin)
        var lrSy = 0.0
        var lrSxy = 0.0
        var lrSyy = 0.0

        // Donchian channel: highest high / lowest low of the last donWin bars.
        val donWin = 20
        val donHiBuf = DoubleArray(donWin)
        val donLoBuf = DoubleArray(donWin)

        // Regression channel: least-squares line over the last chWin closes, z = distance in std devs.
        val chWin = channelWindow(timeframe)
        val chBuf = DoubleArray(chWin)
        var chSy = 0.0
        var chSxy = 0.0
        var chSyy = 0.0

        var latestMasterZScore = 0.0
        var latestBtcCorrelation = 0.0
        var latestBtcBeta = 1.0
        var latestRelStrength = 0.0

        for (i in 0 until n) {
            val c = candles[i]
            val prev = if (i > 0) candles[i - 1] else c

            if (i > 0) {
                e5 = c.close * k5 + e5 * (1.0 - k5)
                e13 = c.close * k13 + e13 * (1.0 - k13)
                e34 = c.close * k34 + e34 * (1.0 - k34)
                e6 = c.close * k6 + e6 * (1.0 - k6)
            }
            ema5[i] = e5
            ema13[i] = e13
            ema34[i] = e34

            val tr = maxOf(
                c.high - c.low,
                abs(c.high - prev.close),
                abs(c.low - prev.close)
            )
            atr = if (i == 0) tr else (atr * 13.0 + tr) / 14.0
            val safeAtr = maxOf(atr, c.close * 0.0004, 1e-9)
            atr14[i] = safeAtr

            val upMove = c.high - prev.high
            val downMove = prev.low - c.low
            val plusDm = if (upMove > downMove && upMove > 0.0) upMove else 0.0
            val minusDm = if (downMove > upMove && downMove > 0.0) downMove else 0.0
            smoothPlusDm = (smoothPlusDm * 9.0 + plusDm) / 10.0
            smoothMinusDm = (smoothMinusDm * 9.0 + minusDm) / 10.0
            val diPlus = (smoothPlusDm / safeAtr) * 100.0
            val diMinus = (smoothMinusDm / safeAtr) * 100.0

            val chg = c.close - prev.close
            val gain = if (chg > 0.0) chg else 0.0
            val loss = if (chg < 0.0) -chg else 0.0
            avgGain7 = (avgGain7 * 6.0 + gain) / 7.0
            avgLoss7 = (avgLoss7 * 6.0 + loss) / 7.0
            val rs7 = when {
                avgLoss7 > 1e-12 -> avgGain7 / avgLoss7
                avgGain7 > 0.0 -> 100.0
                else -> 1.0
            }
            val rsi7 = 100.0 - 100.0 / (1.0 + rs7)
            rsi7Arr[i] = rsi7

            val rIdx = i % stochWin
            rsiWinBuf[rIdx] = rsi7
            var rMin = rsi7
            var rMax = rsi7
            val rCount = min(i + 1, stochWin)
            for (j in 0 until rCount) {
                val valR = rsiWinBuf[j]
                if (valR < rMin) rMin = valR
                if (valR > rMax) rMax = valR
            }
            val rawStoch = if (rMax - rMin > 1e-6) ((rsi7 - rMin) / (rMax - rMin)) * 100.0 else 50.0
            stochK = stochK * (2.0 / 3.0) + rawStoch * (1.0 / 3.0)
            stochD = stochD * (2.0 / 3.0) + stochK * (1.0 / 3.0)

            val macdLine = e6 - e13
            macdSig = macdLine * kMacdSig + macdSig * (1.0 - kMacdSig)
            val macdHist = macdLine - macdSig
            val macdHistDelta = macdHist - prevMacdHist
            prevMacdHist = macdHist

            val tp = (c.high + c.low + c.close) / 3.0
            val pv = tp * c.volume
            val vwIdx = i % vwapWin
            if (i >= vwapWin) {
                pvSum -= pvBuf[vwIdx]
                volSum -= volBuf[vwIdx]
            }
            pvBuf[vwIdx] = pv
            volBuf[vwIdx] = c.volume
            pvSum += pv
            volSum += c.volume
            vwap[i] = if (volSum > 1e-9) pvSum / volSum else tp

            val bbIdx = i % bbWin
            if (i >= bbWin) {
                val oldC = closeBuf[bbIdx]
                closeSum -= oldC
                closeSqSum -= oldC * oldC
            }
            closeBuf[bbIdx] = c.close
            closeSum += c.close
            closeSqSum += c.close * c.close
            val bbCount = min(i + 1, bbWin)
            val bbMean = closeSum / bbCount.toDouble()
            val variance = max(0.0, closeSqSum / bbCount.toDouble() - bbMean * bbMean)
            val bbStd = sqrt(variance)
            bbUpper[i] = bbMean + 2.0 * bbStd
            bbLower[i] = bbMean - 2.0 * bbStd

            val tpIdx = i % tpWin
            if (i >= tpWin) {
                tpSum -= tpBuf[tpIdx]
            }
            tpBuf[tpIdx] = tp
            tpSum += tp
            val tpCount = min(i + 1, tpWin)
            val tpMean = tpSum / tpCount.toDouble()
            var mad = 0.0
            for (j in 0 until tpCount) {
                mad += abs(tpBuf[j] - tpMean)
            }
            mad /= tpCount.toDouble()
            val cci14 = if (mad > 1e-12) (tp - tpMean) / (0.015 * mad) else 0.0

            val vsIdx = i % volWin
            if (i >= volWin) {
                volSmaSum -= volSmaBuf[vsIdx]
            }
            volSmaBuf[vsIdx] = c.volume
            volSmaSum += c.volume
            val volMean = max(volSmaSum / min(i + 1, volWin).toDouble(), 1e-9)

            val range = max(c.high - c.low, 1e-12)
            val rawOfi = ((c.close - c.low) - (c.high - c.close)) / range
            ofiEma = rawOfi * kOfi + ofiEma * (1.0 - kOfi)

            val e5Prev = if (i >= 2) ema5[i - 2] else ema5[0]
            val rsi7Prev = if (i >= 2) rsi7Arr[i - 2] else rsi7
            val halfBand = max(2.0 * bbStd, safeAtr * 0.5)
            val bbWidthRatio = (4.0 * bbStd) / (4.0 * safeAtr)
            val squeezeGain = 1.0 / clampDouble(bbWidthRatio, 0.45, 2.0)
            val bodyDir = if (c.close >= c.open) 1.0 else -1.0
            val volRatio = c.volume / volMean
            val rawZScore = (c.close - bbMean) / maxOf(bbStd, c.close * 0.0002, 1e-9)
            zScoreSeries[i] = rawZScore

            if (i >= lrWin) {
                val oldest = lrBuf[i % lrWin]
                lrSxy = lrSxy - (lrSy - oldest) + (lrWin - 1) * c.close
                lrSy = lrSy - oldest + c.close
                lrSyy = lrSyy - oldest * oldest + c.close * c.close
            } else {
                lrSxy += i * c.close
                lrSy += c.close
                lrSyy += c.close * c.close
            }
            lrBuf[i % lrWin] = c.close
            val lrM = min(i + 1, lrWin).toDouble()
            var fLinReg = 0f
            if (lrM >= 5.0) {
                val sx = lrM * (lrM - 1.0) / 2.0
                val sxx = (lrM - 1.0) * lrM * (2.0 * lrM - 1.0) / 6.0
                val denX = lrM * sxx - sx * sx
                val numXY = lrM * lrSxy - sx * lrSy
                val slope = if (denX > 1e-12) numXY / denX else 0.0
                val denY = lrM * lrSyy - lrSy * lrSy
                val r2 = if (denX > 1e-12 && denY > 1e-12) {
                    clampDouble((numXY * numXY) / (denX * denY), 0.0, 1.0)
                } else {
                    0.0
                }
                // Total drift across the window in ATRs, damped when the line fits poorly.
                val driftAtr = slope * (lrM - 1.0) / safeAtr
                fLinReg = clamp(driftAtr * 0.6 * (0.5 + 0.5 * r2), -4.0, 4.0)
            }

            donHiBuf[i % donWin] = c.high
            donLoBuf[i % donWin] = c.low
            var donHi = c.high
            var donLo = c.low
            val donCount = min(i + 1, donWin)
            for (j in 0 until donCount) {
                if (donHiBuf[j] > donHi) donHi = donHiBuf[j]
                if (donLoBuf[j] < donLo) donLo = donLoBuf[j]
            }
            val donPos = if (donHi - donLo > 1e-12) (c.close - donLo) / (donHi - donLo) else 0.5
            val fDonchian = clamp((donPos - 0.5) * 4.0, -2.0, 2.0)

            if (i >= chWin) {
                val oldest = chBuf[i % chWin]
                chSxy = chSxy - (chSy - oldest) + (chWin - 1) * c.close
                chSy = chSy - oldest + c.close
                chSyy = chSyy - oldest * oldest + c.close * c.close
            } else {
                chSxy += i * c.close
                chSy += c.close
                chSyy += c.close * c.close
            }
            chBuf[i % chWin] = c.close
            val chM = min(i + 1, chWin).toDouble()
            var chZ = 0.0
            if (chM >= 20.0) {
                val sx = chM * (chM - 1.0) / 2.0
                val sxx = (chM - 1.0) * chM * (2.0 * chM - 1.0) / 6.0
                val denX = chM * sxx - sx * sx
                if (denX > 1e-12) {
                    val slope = (chM * chSxy - sx * chSy) / denX
                    val intercept = (chSy - slope * sx) / chM
                    val fitted = intercept + slope * (chM - 1.0)
                    val meanY = chSy / chM
                    val syyC = chSyy - chM * meanY * meanY
                    val sxxC = sxx - sx * sx / chM
                    val sse = max(0.0, syyC - slope * slope * sxxC)
                    val sigma = max(sqrt(sse / chM), c.close * 0.0003)
                    chZ = clampDouble((c.close - fitted) / sigma, -4.0, 4.0)
                }
            }
            channelZSeries[i] = chZ
            val fChannel = clamp(chZ, -3.0, 3.0)

            var fMasterMom = 0f
            var fMasterZ = 0f
            var fAltBtcRs = 0f
            var fAltBtcCorr = 0f
            var fAltBtcBeta = 0f

            if (master != null) {
                while (mPtr + 1 < master.times.size && master.times[mPtr + 1] <= c.openTimeMs) {
                    mPtr++
                }
                if (master.times[mPtr] <= c.openTimeMs) {
                    val altRet1 = if (i > 0 && prev.close > 0.0) {
                        clampDouble((c.close - prev.close) / prev.close, -0.25, 0.25)
                    } else {
                        0.0
                    }
                    val mRet1 = master.ret1[mPtr]

                    val cIdx = i % corrWin
                    if (i >= corrWin) {
                        val oldA = altR1Buf[cIdx]
                        val oldM = mR1Buf[cIdx]
                        sumA -= oldA
                        sumM -= oldM
                        sumAA -= oldA * oldA
                        sumMM -= oldM * oldM
                        sumAM -= oldA * oldM
                    }
                    altR1Buf[cIdx] = altRet1
                    mR1Buf[cIdx] = mRet1
                    sumA += altRet1
                    sumM += mRet1
                    sumAA += altRet1 * altRet1
                    sumMM += mRet1 * mRet1
                    sumAM += altRet1 * mRet1

                    val wCnt = min(i + 1, corrWin)
                    var corr = 0.0
                    var beta = 1.0
                    if (wCnt >= 8) {
                        val covNum = wCnt * sumAM - sumA * sumM
                        val varA = max(0.0, wCnt * sumAA - sumA * sumA)
                        val varM = max(0.0, wCnt * sumMM - sumM * sumM)
                        val den = sqrt(varA * varM)
                        corr = if (den > 1e-12) clampDouble(covNum / den, -1.0, 1.0) else 0.0
                        beta = if (varM > 1e-12) clampDouble(covNum / varM, -0.5, 3.0) else 1.0
                    }

                    val c5Close = if (i >= 5) candles[i - 5].close else candles[0].close
                    val altRet5 = if (c5Close > 0.0) clampDouble((c.close - c5Close) / c5Close, -0.35, 0.35) else 0.0
                    val mRet5 = master.ret5[mPtr]
                    val safeAtrPct = max(safeAtr / max(c.close, 1e-9), 0.0005)
                    val relStrength = clampDouble((altRet5 - beta * mRet5) / (safeAtrPct * 2.2), -4.0, 4.0)

                    fMasterMom = master.momentum[mPtr].toFloat()
                    fMasterZ = master.zScore[mPtr].toFloat()
                    fAltBtcRs = relStrength.toFloat()
                    fAltBtcCorr = clamp(corr * 2.0, -4.0, 4.0)
                    fAltBtcBeta = clamp((beta - 1.0) * 1.5, -4.0, 4.0)

                    latestMasterZScore = master.zScore[mPtr]
                    latestBtcCorrelation = corr
                    latestBtcBeta = beta
                    latestRelStrength = relStrength
                }
            }

            val base = i * FEATURE_COUNT
            features[base + 0] = clamp(ofiEma * 1.6, -4.0, 4.0)
            features[base + 1] = clamp(bodyDir * ln(1.0 + min(volRatio, 12.0)) * 0.85, -4.0, 4.0)
            features[base + 2] = clamp((rsi7 - rsi7Prev) / 14.0, -4.0, 4.0)
            features[base + 3] = clamp((e5 - e5Prev) / safeAtr, -4.0, 4.0)
            features[base + 4] = clamp(((c.close - bbMean) / halfBand) * squeezeGain, -4.0, 4.0)
            features[base + 5] = clamp((stochK - stochD) / 22.0, -4.0, 4.0)
            features[base + 6] = clamp((c.close - vwap[i]) / (safeAtr * 1.5), -4.0, 4.0)
            features[base + 7] = clamp((macdHistDelta / safeAtr) * 3.0, -4.0, 4.0)
            features[base + 8] = clamp(((e5 - e13) * 0.65 + (e13 - e34) * 0.35) / safeAtr, -4.0, 4.0)
            features[base + 9] = clamp((rsi7 - 50.0) / 22.0, -4.0, 4.0)
            features[base + 10] = clamp(tanh(cci14 / 140.0) * 2.0, -4.0, 4.0)
            features[base + 11] = clamp((diPlus - diMinus) / 40.0, -4.0, 4.0)
            features[base + 12] = clamp(rawZScore, -4.0, 4.0)
            features[base + 13] = fMasterMom
            features[base + 14] = fMasterZ
            features[base + 15] = fAltBtcRs
            features[base + 16] = fAltBtcCorr
            features[base + 17] = fAltBtcBeta
            features[base + 18] = fLinReg
            features[base + 19] = fDonchian
            features[base + 20] = fChannel

            // Time of day / week (UTC): lets the model learn when its signals work or fail.
            val minuteOfDay = Math.floorMod(c.openTimeMs / 60_000L, 1440L).toDouble()
            val dayAngle = 2.0 * Math.PI * minuteOfDay / 1440.0
            val weekdayIdx = Math.floorMod(Math.floorDiv(c.openTimeMs, 86_400_000L) + 3L, 7L).toInt()
            features[base + 21] = Math.sin(dayAngle).toFloat()
            features[base + 22] = Math.cos(dayAngle).toFloat()
            features[base + 23] = Math.sin(2.0 * dayAngle).toFloat()
            features[base + 24] = Math.cos(2.0 * dayAngle).toFloat()
            features[base + 25] = if (weekdayIdx >= 5) 1f else 0f
        }

        return ComputedIndicators(
            features = features,
            atr14 = atr14,
            ema5 = ema5,
            ema13 = ema13,
            ema34 = ema34,
            vwap = vwap,
            bbUpper = bbUpper,
            bbLower = bbLower,
            zScoreSeries = zScoreSeries,
            channelZSeries = channelZSeries,
            latestMasterZScore = latestMasterZScore,
            latestBtcCorrelation = latestBtcCorrelation,
            latestBtcBeta = latestBtcBeta,
            latestRelStrength = latestRelStrength
        )
    }
}
