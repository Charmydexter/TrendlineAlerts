package com.trendlinealerts.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.IBinder
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.trendlinealerts.app.R
import com.trendlinealerts.app.TrendlineAlertsApp
import com.trendlinealerts.app.data.analytics.AssetEvaluationOutput
import com.trendlinealerts.app.data.local.AlertLogEntity
import com.trendlinealerts.app.data.local.SymbolStateEntity
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.data.remote.SymbolNotListedException
import com.trendlinealerts.app.data.repository.SymbolMonitorRow
import com.trendlinealerts.app.ui.MainActivity
import com.trendlinealerts.core.dispatcher.AlertDispatcher
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.SignalAction
import com.trendlinealerts.core.model.SignalCandidate
import com.trendlinealerts.core.model.SignalStateCodec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import retrofit2.HttpException

class NotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_MONITORING = "monitoring_status"
        const val CHANNEL_ALERTS = "scalp_ml_alerts_high"
        const val FOREGROUND_NOTIFICATION_ID = 1001
        const val STOPPED_NOTIFICATION_ID = 1002

        private const val GOOGLE_RED_INT = 0xFFEA4335.toInt()
        private const val GOOGLE_GREEN_INT = 0xFF34A853.toInt()
        private const val AMBER_INT = 0xFFF59E0B.toInt()
        private const val BLUE_INT = 0xFF3B82F6.toInt()
        private const val MAX_CLUSTER_LINES = 7
        private val idCounter = AtomicInteger(3000)
    }

    private val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannels() {
        val statusChannel = NotificationChannel(
            CHANNEL_MONITORING,
            "Monitoring Status",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Persistent notification with Start / Stop for Logistic ML monitoring"
            setShowBadge(false)
        }

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val audioAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val alertChannel = NotificationChannel(
            CHANNEL_ALERTS,
            "Scalp ML Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Long / Short scalping signals, Positioned Exit exhaustion alerts, and indicator updates"
            enableVibration(true)
            enableLights(true)
            setSound(soundUri, audioAttrs)
        }

        manager.createNotificationChannel(statusChannel)
        manager.createNotificationChannel(alertChannel)
    }

    private fun openAppIntent(requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun serviceActionIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, MonitoringForegroundService::class.java).apply { this.action = action }
        return PendingIntent.getForegroundService(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun buildForegroundNotification(
        title: String,
        contentText: String?,
        generalOn: Boolean
    ): Notification {
        ensureChannels()
        val builder = NotificationCompat.Builder(context, CHANNEL_MONITORING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent(0))
        if (!contentText.isNullOrBlank()) {
            builder.setContentText(contentText)
        }
        if (generalOn) {
            builder.addAction(R.drawable.ic_notification, "Stop", serviceActionIntent(MonitoringForegroundService.ACTION_STOP_GENERAL, 11))
        } else {
            builder.addAction(R.drawable.ic_notification, "Start", serviceActionIntent(MonitoringForegroundService.ACTION_START_GENERAL, 12))
        }
        return builder.build()
    }

    fun postStoppedNotification() {
        ensureChannels()
        val n = NotificationCompat.Builder(context, CHANNEL_MONITORING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Monitoring OFF")
            .setContentText("Tap Start to resume scalping ML watch")
            .setOngoing(false)
            .setAutoCancel(false)
            .setContentIntent(openAppIntent(0))
            .addAction(R.drawable.ic_notification, "Start", serviceActionIntent(MonitoringForegroundService.ACTION_START_GENERAL, 12))
            .build()
        manager.notify(STOPPED_NOTIFICATION_ID, n)
    }

    fun cancelStoppedNotification() {
        manager.cancel(STOPPED_NOTIFICATION_ID)
    }

    private fun fmtPrice(v: Double): String = when {
        v >= 1_000.0 -> String.format(Locale.US, "%.2f", v)
        v >= 1.0 -> String.format(Locale.US, "%.4f", v)
        v >= 0.01 -> String.format(Locale.US, "%.5f", v)
        else -> String.format(Locale.US, "%.7f", v)
    }

    private fun fmtClock(ms: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(ms))

    private fun label(e: SignalCandidate): String = when (e.eventType) {
        EventType.LONG_SIGNAL -> "LONG ${(e.pLong * 100).toInt()}%"
        EventType.SHORT_SIGNAL -> "SHORT ${(e.pShort * 100).toInt()}%"
        EventType.EXIT_LONG, EventType.EXIT_SHORT -> {
            val side = if (e.eventType == EventType.EXIT_LONG) "LONG" else "SHORT"
            val n = e.note.orEmpty()
            when {
                n.startsWith("Signal cancelled") -> "CANCEL $side"
                n.startsWith("Target") -> "TARGET HIT · $side"
                n.startsWith("Stop") -> "STOP HIT · $side"
                else -> "EXIT $side"
            }
        }
        EventType.INDICATOR_PROMOTED -> "NEW ${e.topIndicator}"
    }

    private fun accent(e: SignalCandidate): Int = when (e.eventType) {
        EventType.LONG_SIGNAL -> GOOGLE_GREEN_INT
        EventType.SHORT_SIGNAL -> GOOGLE_RED_INT
        EventType.EXIT_LONG, EventType.EXIT_SHORT -> AMBER_INT
        EventType.INDICATOR_PROMOTED -> BLUE_INT
    }

    fun sendAlertNotification(candidate: SignalCandidate) {
        ensureChannels()
        val headline = label(candidate)
        val color = accent(candidate)
        val styledTitle = SpannableString("$headline · ${candidate.symbol}").apply {
            setSpan(ForegroundColorSpan(color), 0, headline.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val sl = candidate.slPrice
        val tp = candidate.tpPrice
        val body = when {
            (candidate.eventType == EventType.LONG_SIGNAL || candidate.eventType == EventType.SHORT_SIGNAL) &&
                sl != null && tp != null ->
                "Price ${fmtPrice(candidate.price)} · Stop ${fmtPrice(sl)} · Target ${fmtPrice(tp)}"
            candidate.eventType == EventType.EXIT_LONG || candidate.eventType == EventType.EXIT_SHORT ->
                "Price ${fmtPrice(candidate.price)} · ${candidate.note ?: "The move looks used up. Consider closing."}"
            candidate.eventType == EventType.INDICATOR_PROMOTED ->
                "Price ${fmtPrice(candidate.price)} · ${candidate.note ?: "A new helpful signal"}"
            else -> "Price ${fmtPrice(candidate.price)}"
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(color)
            .setContentTitle(styledTitle)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(candidate.symbol.hashCode()))
            .build()
        manager.notify(idCounter.incrementAndGet(), notification)
    }

    fun sendClusterNotification(events: List<SignalCandidate>) {
        if (events.isEmpty()) return
        ensureChannels()
        val allLong = events.all { it.eventType == EventType.LONG_SIGNAL }
        val allShort = events.all { it.eventType == EventType.SHORT_SIGNAL }
        val color = when {
            allLong -> GOOGLE_GREEN_INT
            allShort -> GOOGLE_RED_INT
            else -> BLUE_INT
        }
        val title = if (events.size == 1) "${label(events[0])} · ${events[0].symbol}" else "${events.size} assets · Signals"
        val inbox = NotificationCompat.InboxStyle().setBigContentTitle(title)
        events.take(MAX_CLUSTER_LINES).forEach { e ->
            val sl = e.slPrice
            val tp = e.tpPrice
            inbox.addLine(
                if (sl != null && tp != null) "${label(e)}  ${e.symbol}  ${fmtPrice(e.price)}  SL ${fmtPrice(sl)}  TP ${fmtPrice(tp)}"
                else "${label(e)}  ${e.symbol}  ${fmtPrice(e.price)}"
            )
        }
        if (events.size > MAX_CLUSTER_LINES) inbox.setSummaryText("+${events.size - MAX_CLUSTER_LINES} more in Alert Log")

        val collapsed = events.take(4).joinToString(", ") { it.symbol } + if (events.size > 4) " +${events.size - 4}" else ""
        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(color)
            .setContentTitle(title)
            .setContentText(collapsed)
            .setStyle(inbox)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(7))
            .build()
        manager.notify(idCounter.incrementAndGet(), notification)
    }

    fun sendMissedNotification(symbol: String, events: List<SignalCandidate>, nowPrice: Double?) {
        if (events.isEmpty()) return
        ensureChannels()
        val sorted = events.sortedBy { it.eventTimeMs }
        val inbox = NotificationCompat.InboxStyle().setBigContentTitle("MISSED · $symbol")
        sorted.takeLast(MAX_CLUSTER_LINES - 1).forEach { e ->
            inbox.addLine("${fmtClock(e.eventTimeMs)}  ${label(e)}  @ ${fmtPrice(e.price)}")
        }
        if (nowPrice != null) inbox.addLine("Now ${fmtPrice(nowPrice)}")
        val last = sorted.last()
        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(accent(last))
            .setContentTitle("MISSED while offline · $symbol")
            .setContentText("${sorted.size} signal(s), last ${label(last)} at ${fmtClock(last.eventTimeMs)}")
            .setStyle(inbox)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(symbol.hashCode()))
            .build()
        manager.notify(idCounter.incrementAndGet(), notification)
    }

    fun sendTestNotification() {
        val now = System.currentTimeMillis()
        sendAlertNotification(
            SignalCandidate("SUIUSDT", EventType.EXIT_LONG, SignalAction.EXIT, 1.8420, 0.36, 0.59, 2.34, "Z-Score", now)
        )
        sendClusterNotification(
            listOf(
                SignalCandidate("XRPUSDT", EventType.LONG_SIGNAL, SignalAction.LONG, 2.1034, 0.71, 0.21, -1.25, "OFI", now),
                SignalCandidate("SOLUSDT", EventType.SHORT_SIGNAL, SignalAction.SHORT, 143.52, 0.19, 0.68, 1.82, "RSI7 d", now)
            )
        )
    }
}

private sealed interface PollItemResult {
    data class Success(val output: AssetEvaluationOutput) : PollItemResult
    data class Failure(val error: Exception) : PollItemResult
    data object Skipped : PollItemResult
}

class MonitoringForegroundService : Service() {

    companion object {
        const val ACTION_START_GENERAL = "com.trendlinealerts.action.START_GENERAL"
        const val ACTION_STOP_GENERAL = "com.trendlinealerts.action.STOP_GENERAL"
        const val ACTION_SYNC = "com.trendlinealerts.action.SYNC"
        const val ACTION_RETRAIN_NOW = "com.trendlinealerts.action.RETRAIN_NOW"

        private const val CONCURRENCY = 4
        private const val FAILOVER_AFTER_FAILED_CYCLES = 2

        fun startGeneral(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_START_GENERAL
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stopGeneral(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_STOP_GENERAL
            }
            runCatching { context.startService(intent) }
        }

        fun syncPriorityService(context: Context, shouldBeRunning: Boolean) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_SYNC
            }
            if (shouldBeRunning) {
                ContextCompat.startForegroundService(context, intent)
            } else {
                runCatching { context.startService(intent) }
            }
        }

        fun retrainNow(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_RETRAIN_NOW
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollLoopJob: Job? = null

    private var activeSource: DataSourceType? = null
    private var knownDefaultSource: DataSourceType? = null
    private var consecutiveFailedCycles = 0
    private var cycleCounter = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as TrendlineAlertsApp
        val container = app.container
        val helper = NotificationHelper(this)
        val action = intent?.action

        val initialGeneralOn = action != ACTION_STOP_GENERAL
        startForeground(
            NotificationHelper.FOREGROUND_NOTIFICATION_ID,
            helper.buildForegroundNotification(
                title = if (initialGeneralOn) "Scalp ML Monitoring ON" else "Scalp ML Monitoring OFF",
                contentText = "Initializing Logistic Regression engine...",
                generalOn = initialGeneralOn
            )
        )
        helper.cancelStoppedNotification()

        serviceScope.launch {
            container.watchlistRepository.ensureDefaultWatchlistSeeded()

            when (action) {
                ACTION_START_GENERAL -> {
                    container.settingsDataStore.setMonitoringEnabled(true)
                    container.monitorStateRepository.updateStatus { it.copy(lastPollError = null) }
                }
                ACTION_STOP_GENERAL -> container.settingsDataStore.setMonitoringEnabled(false)
                ACTION_RETRAIN_NOW -> {
                    container.mlOrchestrator.runSequentialDailyRetrain(force = true)
                }
            }

            val snapshot = container.settingsDataStore.getSnapshot()
            val hasPriority = container.watchlistRepository.hasAnyPriorityOverride()
            val shouldRun = snapshot.monitoringEnabled || hasPriority
            container.monitorStateRepository.setPriorityServiceActive(hasPriority)

            if (!shouldRun) {
                pollLoopJob?.cancel()
                pollLoopJob = null
                container.monitorStateRepository.updateStatus { it.copy(nextCheckAtMs = 0L, lastPollError = null) }
                stopForeground(STOP_FOREGROUND_REMOVE)
                if (action == ACTION_STOP_GENERAL) helper.postStoppedNotification()
                stopSelf()
                return@launch
            }

            pollLoopJob?.cancel()
            pollLoopJob = launch { runPollingLoop() }
        }

        return START_STICKY
    }

    private fun nextSourceAfter(current: DataSourceType): DataSourceType {
        val all = DataSourceType.entries
        return all[(all.indexOf(current) + 1) % all.size]
    }

    private fun sourceTitle(source: DataSourceType, marketType: MarketType): String = when (source) {
        DataSourceType.BYBIT -> if (marketType == MarketType.PERP) "Bybit Linear Perps" else "Bybit Spot"
        DataSourceType.BINANCE -> if (marketType == MarketType.PERP) "Binance USDT-M Futures" else "Binance Spot"
        DataSourceType.OKX -> if (marketType == MarketType.PERP) "OKX Perps" else "OKX Spot"
    }

    private suspend fun runPollingLoop() {
        val app = application as TrendlineAlertsApp
        val container = app.container
        val helper = NotificationHelper(this)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        while (serviceScope.isActive) {
            val snapshot = container.settingsDataStore.getSnapshot()
            val entities = container.watchlistRepository.getAllEntities()
            val positionedSymbols = entities.filter { it.isPriorityOverride }.map { it.symbol }.toSet()
            container.monitorStateRepository.setPriorityServiceActive(positionedSymbols.isNotEmpty())

            val generalOn = snapshot.monitoringEnabled
            if (!generalOn && positionedSymbols.isEmpty()) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                helper.postStoppedNotification()
                stopSelf()
                return
            }

            val tf = snapshot.alertSettings.timeframe
            val market = snapshot.marketType
            val defaultSource = snapshot.dataSource
            val settings = snapshot.alertSettings

            container.mlOrchestrator.clearForConfigChangeIfNeeded(
                tf,
                market,
                settings.effectiveMinProfitMultiplier,
                settings.observeWithMaster,
                settings.effectiveMasterAsset,
                settings.stopLossPct
            )

            if (knownDefaultSource != null && knownDefaultSource != defaultSource) {
                activeSource = defaultSource
                consecutiveFailedCycles = 0
            }
            knownDefaultSource = defaultSource
            if (activeSource == null) activeSource = defaultSource

            val activeEntities = if (generalOn) entities else entities.filter { it.isPriorityOverride }

            if (activeSource != defaultSource) {
                val probeSymbol = activeEntities.firstOrNull()?.symbol ?: "BTCUSDT"
                val defaultAlive = runCatching {
                    container.marketDataCoordinator.fetch1mCandles(probeSymbol, defaultSource, market, 2).isNotEmpty()
                }.getOrDefault(false)
                if (defaultAlive) {
                    activeSource = defaultSource
                    consecutiveFailedCycles = 0
                    container.monitorStateRepository.updateStatus {
                        it.copy(failoverMessage = "Back on default source: ${sourceTitle(defaultSource, market)}.")
                    }
                }
            }
            val source = activeSource ?: defaultSource
            container.monitorStateRepository.updateStatus { it.copy(activeSource = source) }

            val statusLabel = if (generalOn) {
                "LR ML ${activeEntities.size} assets (${tf.label}) · ${source.name.lowercase().replaceFirstChar { it.uppercase() }}"
            } else {
                null
            }
            val (notifTitle, notifText) = buildPersistentNotificationContent(
                generalOn = generalOn,
                positionedSymbolsOrdered = entities.filter { it.isPriorityOverride }.map { it.symbol },
                fallbackSubtext = statusLabel
            )
            manager.notify(
                NotificationHelper.FOREGROUND_NOTIFICATION_ID,
                helper.buildForegroundNotification(notifTitle, notifText, generalOn)
            )

            // Daily sequential retrain across all assets + Master Model update
            runCatching {
                container.mlOrchestrator.runSequentialDailyRetrain(sourceOverride = source, force = false)
            }

            if (cycleCounter % 60 == 0) {
                runCatching {
                    val keep = entities.map { it.symbol } + settings.effectiveMasterAsset
                    container.candleCache.prune(keep, tf)
                    if (keep.isNotEmpty()) container.symbolStateDao.deleteNotIn(keep)
                }
            }
            cycleCounter++

            val cycleNowMs = System.currentTimeMillis()
            val masterCandles = container.mlOrchestrator.fetchMasterCandlesIfEnabled(source, market, tf, settings, cycleNowMs)
            val existingRows = container.monitorStateRepository.symbolRows.value.associateBy { it.symbol }
            val results = ConcurrentHashMap<String, AssetEvaluationOutput>()
            var anySucceeded = false
            var cycleLastError: String? = null
            var rateLimited = false

            for (chunk in activeEntities.chunked(CONCURRENCY)) {
                val chunkResults: List<Pair<String, PollItemResult>> = coroutineScope {
                    chunk.map { entity ->
                        async {
                            val r: PollItemResult = try {
                                val out = container.mlOrchestrator.evaluatePollItem(entity, source, market, tf, settings, cycleNowMs, masterCandles)
                                if (out != null) PollItemResult.Success(out) else PollItemResult.Skipped
                            } catch (ce: CancellationException) {
                                throw ce
                            } catch (e: SymbolNotListedException) {
                                PollItemResult.Skipped
                            } catch (err: Exception) {
                                PollItemResult.Failure(err)
                            }
                            entity.symbol to r
                        }
                    }.awaitAll()
                }
                for ((sym, res) in chunkResults) {
                    when (res) {
                        is PollItemResult.Success -> {
                            anySucceeded = true
                            results[sym] = res.output
                        }
                        is PollItemResult.Failure -> {
                            cycleLastError = "${res.error::class.java.simpleName}: ${res.error.message}"
                            val e = res.error
                            if (e is HttpException && (e.code() == 429 || e.code() == 418)) rateLimited = true
                        }
                        PollItemResult.Skipped -> Unit
                    }
                }
                if (rateLimited) {
                    delay(10_000L)
                    break
                }
            }

            if (anySucceeded) {
                consecutiveFailedCycles = 0
                container.monitorStateRepository.updateStatus { it.copy(lastPollError = null) }
            } else if (activeEntities.isNotEmpty()) {
                consecutiveFailedCycles++
                container.monitorStateRepository.updateStatus { it.copy(lastPollError = cycleLastError ?: "No market data returned") }
                if (consecutiveFailedCycles >= FAILOVER_AFTER_FAILED_CYCLES && !rateLimited) {
                    val next = nextSourceAfter(source)
                    activeSource = next
                    consecutiveFailedCycles = 0
                    val msg = "${sourceTitle(source, market)} failed — using ${sourceTitle(next, market)}."
                    container.monitorStateRepository.updateStatus { it.copy(failoverMessage = msg, activeSource = next) }
                }
            }

            val allEvents = results.values.flatMap { it.events }
            val plan = AlertDispatcher.plan(allEvents, positionedSymbols, generalOn)

            withContext(NonCancellable) {
                val logs = mutableListOf<AlertLogEntity>()
                fun log(e: SignalCandidate, prefix: String) {
                    val probPct = ((if (e.eventType == EventType.SHORT_SIGNAL || e.eventType == EventType.EXIT_LONG) e.pShort else e.pLong) * 100.0).toInt()
                    logs.add(
                        AlertLogEntity(
                            symbol = e.symbol,
                            eventType = e.eventType.name,
                            slotId = "$probPct%",
                            price = e.price,
                            lineValue = e.zScore,
                            message = "$prefix${e.note ?: ""}",
                            timestampMs = if (e.missed) e.eventTimeMs else cycleNowMs
                        )
                    )
                }

                var lastAlertSymbol: String? = null
                plan.individual.forEachIndexed { idx, e ->
                    helper.sendAlertNotification(e)
                    container.watchlistRepository.markAlerted(e.symbol, e.timestampMs + idx)
                    log(e, "")
                    lastAlertSymbol = e.symbol
                }
                if (plan.cluster.isNotEmpty()) {
                    helper.sendClusterNotification(plan.cluster)
                    plan.cluster.forEachIndexed { idx, it ->
                        container.watchlistRepository.markAlerted(it.symbol, it.timestampMs + idx)
                        log(it, "")
                    }
                    lastAlertSymbol = plan.cluster.last().symbol
                }
                var missedIdx = 0
                for ((sym, evs) in plan.missed) {
                    val r = results[sym]
                    helper.sendMissedNotification(sym, evs, r?.row?.lastPrice)
                    container.watchlistRepository.markAlerted(sym, evs.maxOf { it.timestampMs } + missedIdx++)
                    evs.forEach { log(it, "MISSED: ") }
                    lastAlertSymbol = sym
                }
                plan.logOnly.forEach { log(it, "") }
                if (logs.isNotEmpty()) container.alertLogRepository.insertAll(logs)

                results.values.forEach { r ->
                    container.mlOrchestrator.updateStateInMemory(r.newState)
                    container.symbolStateDao.put(SymbolStateEntity(r.newState.symbol, SignalStateCodec.encode(r.newState)))
                }

                if (lastAlertSymbol != null) {
                    container.monitorStateRepository.updateStatus {
                        it.copy(lastAlertSymbol = lastAlertSymbol, lastAlertTimeMs = cycleNowMs)
                    }
                }
            }

            val rows = entities.map { entity ->
                results[entity.symbol]?.row
                    ?: existingRows[entity.symbol]?.copy(
                        isPriorityOverride = entity.isPriorityOverride,
                        lastAlertedAtMs = entity.lastAlertedAtMs
                    )
                    ?: SymbolMonitorRow(
                        symbol = entity.symbol,
                        lastPrice = null,
                        isPriorityOverride = entity.isPriorityOverride,
                        lastAlertedAtMs = entity.lastAlertedAtMs
                    )
            }
            container.monitorStateRepository.updateSymbolRows(rows)

            val nowMs = System.currentTimeMillis()
            val pollStepMs = if (tf.minutes <= 3) 30_000L else 60_000L
            val nextBoundaryMs = ((nowMs / pollStepMs) + 1L) * pollStepMs + 1_500L
            container.monitorStateRepository.updateStatus { it.copy(nextCheckAtMs = nextBoundaryMs) }

            val waitMs = (nextBoundaryMs - nowMs).coerceIn(5_000L, 62_000L)
            withTimeoutOrNull(waitMs) {
                container.settingsDataStore.settingsFlow.first {
                    it.dataSource != snapshot.dataSource ||
                        it.marketType != snapshot.marketType ||
                        it.alertSettings != snapshot.alertSettings ||
                        it.monitoringEnabled != snapshot.monitoringEnabled
                }
            }
        }
    }

    private fun stripUsdt(symbol: String): String {
        val upper = symbol.trim().uppercase(Locale.US)
        return if (upper.endsWith("USDT") && upper.length > 4) upper.dropLast(4) else upper
    }

    private fun buildPersistentNotificationContent(
        generalOn: Boolean,
        positionedSymbolsOrdered: List<String>,
        fallbackSubtext: String?
    ): Pair<String, String?> {
        if (positionedSymbolsOrdered.isEmpty()) {
            return (if (generalOn) "Scalp ML ON" else "Scalp ML OFF") to fallbackSubtext
        }
        val title = "Positioned: ${stripUsdt(positionedSymbolsOrdered.first())}"
        val others = positionedSymbolsOrdered.drop(1).map { stripUsdt(it) }
        val text = if (others.isNotEmpty()) others.joinToString(",") else fallbackSubtext
        return title to text
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val app = context.applicationContext as? TrendlineAlertsApp ?: return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = app.container.settingsDataStore.getSnapshot()
                val hasPriority = app.container.watchlistRepository.hasAnyPriorityOverride()
                if (settings.monitoringEnabled || hasPriority) {
                    MonitoringForegroundService.syncPriorityService(context, true)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
