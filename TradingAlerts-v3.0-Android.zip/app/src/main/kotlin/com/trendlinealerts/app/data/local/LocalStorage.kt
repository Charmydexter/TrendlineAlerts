package com.trendlinealerts.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.ChartCandleStyle
import com.trendlinealerts.core.model.Timeframe
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

@Entity(tableName = "watchlist")
data class WatchlistEntity(
    @PrimaryKey val symbol: String,
    val sortOrder: Int,
    val addedAtMs: Long,
    val isPriorityOverride: Boolean = false,
    val lastAlertedAtMs: Long = 0L,
    val lastCrossSide: String? = null,
    val lastEntryDirection: String? = null
)

@Entity(tableName = "alert_logs")
data class AlertLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val symbol: String,
    val eventType: String,
    val slotId: String,
    val price: Double,
    val lineValue: Double,
    val message: String,
    val timestampMs: Long
)

@Entity(tableName = "symbol_state")
data class SymbolStateEntity(
    @PrimaryKey val symbol: String,
    val json: String
)

@Dao
interface SymbolStateDao {
    @Query("SELECT json FROM symbol_state WHERE symbol = :symbol")
    suspend fun get(symbol: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entity: SymbolStateEntity)

    @Query("DELETE FROM symbol_state WHERE symbol = :symbol")
    suspend fun delete(symbol: String)

    @Query("DELETE FROM symbol_state WHERE symbol NOT IN (:keep)")
    suspend fun deleteNotIn(keep: List<String>)

    @Query("DELETE FROM symbol_state")
    suspend fun clear()
}

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM watchlist ORDER BY lastAlertedAtMs DESC, sortOrder ASC, addedAtMs ASC")
    fun observeAll(): Flow<List<WatchlistEntity>>

    @Query("SELECT * FROM watchlist ORDER BY lastAlertedAtMs DESC, sortOrder ASC, addedAtMs ASC")
    suspend fun getAll(): List<WatchlistEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<WatchlistEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: WatchlistEntity)

    @Query("DELETE FROM watchlist WHERE symbol = :symbol")
    suspend fun deleteBySymbol(symbol: String)

    @Query("DELETE FROM watchlist")
    suspend fun deleteAll()

    @Query("UPDATE watchlist SET isPriorityOverride = :enabled WHERE symbol = :symbol")
    suspend fun setPriorityOverride(symbol: String, enabled: Boolean)

    @Query("UPDATE watchlist SET lastEntryDirection = :direction WHERE symbol = :symbol")
    suspend fun updateLastEntryDirection(symbol: String, direction: String?)

    @Query("SELECT COUNT(*) FROM watchlist WHERE isPriorityOverride = 1")
    suspend fun countPriorityOverrides(): Int

    @Query("UPDATE watchlist SET lastAlertedAtMs = :timestampMs WHERE symbol = :symbol")
    suspend fun updateLastAlertedAt(symbol: String, timestampMs: Long)

    @Query("SELECT COUNT(*) FROM watchlist")
    suspend fun count(): Int
}

@Dao
interface AlertLogDao {
    @Query("SELECT * FROM alert_logs ORDER BY timestampMs DESC LIMIT 500")
    fun observeRecent(): Flow<List<AlertLogEntity>>

    @Query("SELECT * FROM alert_logs WHERE timestampMs >= :sinceMs ORDER BY timestampMs ASC")
    fun observeSince(sinceMs: Long): Flow<List<AlertLogEntity>>

    @Insert
    suspend fun insert(entity: AlertLogEntity)

    @Query("DELETE FROM alert_logs")
    suspend fun clearAll()

    @Query("DELETE FROM alert_logs WHERE id NOT IN (SELECT id FROM alert_logs ORDER BY timestampMs DESC, id DESC LIMIT :keep)")
    suspend fun trimTo(keep: Int)
}

@Database(
    entities = [
        WatchlistEntity::class,
        AlertLogEntity::class,
        SymbolStateEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchlistDao(): WatchlistDao
    abstract fun alertLogDao(): AlertLogDao
    abstract fun symbolStateDao(): SymbolStateDao

    companion object {
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `symbol_state` (`symbol` TEXT NOT NULL, `json` TEXT NOT NULL, PRIMARY KEY(`symbol`))"
                )
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("DROP TABLE IF EXISTS `htf_candles`")
                db.execSQL("DROP TABLE IF EXISTS `signal_candidates`")
            }
        }

        fun create(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "trading_alerts.db"
            )
                .addMigrations(MIGRATION_2_3, MIGRATION_5_6)
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}

data class AppSettingsSnapshot(
    val monitoringEnabled: Boolean = false,
    val dataSource: DataSourceType = DataSourceType.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val chartCandleStyle: ChartCandleStyle = ChartCandleStyle.HEIKIN_ASHI,
    val showEmaOverlay: Boolean = false,
    val showVwapOverlay: Boolean = false,
    val showBbOverlay: Boolean = false,
    val alertSettings: AlertSettings = AlertSettings()
)

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "trading_alerts_prefs_v3")

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val MONITORING_ENABLED = booleanPreferencesKey("monitoring_enabled")
        val DATA_SOURCE = stringPreferencesKey("data_source")
        val MARKET_TYPE = stringPreferencesKey("market_type")
        val TIMEFRAME = stringPreferencesKey("timeframe")
        val MIN_PROFIT_MULTIPLIER = doublePreferencesKey("min_profit_multiplier")
        val SIGNAL_THRESHOLD = doublePreferencesKey("signal_threshold")
        val OBSERVE_WITH_MASTER = booleanPreferencesKey("observe_with_master")
        val MASTER_ASSET = stringPreferencesKey("master_asset")
        val CHART_CANDLE_STYLE = stringPreferencesKey("chart_candle_style")
        val SHOW_EMA_OVERLAY = booleanPreferencesKey("show_ema_overlay")
        val SHOW_VWAP_OVERLAY = booleanPreferencesKey("show_vwap_overlay")
        val SHOW_BB_OVERLAY = booleanPreferencesKey("show_bb_overlay")
    }

    val settingsFlow: Flow<AppSettingsSnapshot> = context.dataStore.data.map { prefs ->
        val source = prefs[Keys.DATA_SOURCE]
            ?.let { runCatching { DataSourceType.valueOf(it) }.getOrNull() }
            ?: DataSourceType.BYBIT

        val marketType = prefs[Keys.MARKET_TYPE]
            ?.let { runCatching { MarketType.valueOf(it) }.getOrNull() }
            ?: MarketType.PERP

        val chartCandleStyle = prefs[Keys.CHART_CANDLE_STYLE]
            ?.let { runCatching { ChartCandleStyle.valueOf(it) }.getOrNull() }
            ?: ChartCandleStyle.HEIKIN_ASHI

        val timeframe = prefs[Keys.TIMEFRAME]
            ?.let { runCatching { Timeframe.valueOf(it) }.getOrNull() }
            ?: Timeframe.M1

        val minProfitMult = (prefs[Keys.MIN_PROFIT_MULTIPLIER] ?: 1.0)
            .coerceIn(AlertSettings.MIN_PROFIT_MULTIPLIER, AlertSettings.MAX_PROFIT_MULTIPLIER)
        val signalThreshold = (prefs[Keys.SIGNAL_THRESHOLD] ?: 0.58).coerceIn(0.50, 0.85)
        val observeWithMaster = prefs[Keys.OBSERVE_WITH_MASTER] ?: true
        val masterAsset = AlertSettings.normalizeMasterAsset(prefs[Keys.MASTER_ASSET])

        AppSettingsSnapshot(
            monitoringEnabled = prefs[Keys.MONITORING_ENABLED] ?: false,
            dataSource = source,
            marketType = marketType,
            chartCandleStyle = chartCandleStyle,
            showEmaOverlay = prefs[Keys.SHOW_EMA_OVERLAY] ?: false,
            showVwapOverlay = prefs[Keys.SHOW_VWAP_OVERLAY] ?: false,
            showBbOverlay = prefs[Keys.SHOW_BB_OVERLAY] ?: false,
            alertSettings = AlertSettings(
                timeframe = timeframe,
                minProfitMultiplier = minProfitMult,
                signalThreshold = signalThreshold,
                observeWithMaster = observeWithMaster,
                masterAsset = masterAsset
            )
        )
    }

    suspend fun getSnapshot(): AppSettingsSnapshot = settingsFlow.first()

    suspend fun setMonitoringEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.MONITORING_ENABLED] = enabled }
    }

    suspend fun setDataSource(source: DataSourceType) {
        context.dataStore.edit { it[Keys.DATA_SOURCE] = source.name }
    }

    suspend fun setMarketType(marketType: MarketType) {
        context.dataStore.edit { it[Keys.MARKET_TYPE] = marketType.name }
    }

    suspend fun setChartCandleStyle(style: ChartCandleStyle) {
        context.dataStore.edit { it[Keys.CHART_CANDLE_STYLE] = style.name }
    }

    suspend fun setShowEmaOverlay(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_EMA_OVERLAY] = enabled }
    }

    suspend fun setShowVwapOverlay(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_VWAP_OVERLAY] = enabled }
    }

    suspend fun setShowBbOverlay(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_BB_OVERLAY] = enabled }
    }

    suspend fun setTimeframe(timeframe: Timeframe) {
        context.dataStore.edit { it[Keys.TIMEFRAME] = timeframe.name }
    }

    suspend fun setMinProfitMultiplier(value: Double) {
        context.dataStore.edit { it[Keys.MIN_PROFIT_MULTIPLIER] = value.coerceIn(
            AlertSettings.MIN_PROFIT_MULTIPLIER,
            AlertSettings.MAX_PROFIT_MULTIPLIER
        ) }
    }

    suspend fun setSignalThreshold(value: Double) {
        context.dataStore.edit { it[Keys.SIGNAL_THRESHOLD] = value.coerceIn(0.50, 0.85) }
    }

    suspend fun setObserveWithMaster(enabled: Boolean) {
        context.dataStore.edit { it[Keys.OBSERVE_WITH_MASTER] = enabled }
    }

    suspend fun setMasterAsset(raw: String) {
        val normalized = AlertSettings.normalizeMasterAsset(raw)
        context.dataStore.edit { it[Keys.MASTER_ASSET] = normalized }
    }
}
