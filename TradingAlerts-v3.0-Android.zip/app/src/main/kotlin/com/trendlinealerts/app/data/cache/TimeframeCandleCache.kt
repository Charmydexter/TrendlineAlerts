package com.trendlinealerts.app.data.cache

import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.Timeframe
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Single-timeframe candle cache backed by memory + gzipped binary disk files.
 * Handles up to 28 days of 1m data (40,320 bars) cleanly without hitting SQLite CursorWindow limits.
 */
class TimeframeCandleCache(
    filesDir: File,
    private val coordinator: MarketDataCoordinator
) {
    private val cacheDir = File(filesDir, "candles_v3").apply { mkdirs() }
    private val memory = ConcurrentHashMap<String, List<Candle>>()
    private val historyExhausted = ConcurrentHashMap<String, Boolean>()
    private val locks = ConcurrentHashMap<String, Mutex>()

    private fun key(symbol: String, tf: Timeframe, source: DataSourceType, market: MarketType) =
        "$symbol|${tf.name}|${source.name}|${market.name}"

    private fun fileFor(symbol: String, tf: Timeframe, source: DataSourceType, market: MarketType): File =
        File(cacheDir, "${symbol}_${tf.name}_${source.name}_${market.name}.bin.gz")

    suspend fun getCandles(
        symbol: String,
        timeframe: Timeframe,
        source: DataSourceType,
        marketType: MarketType,
        forceFullRefresh: Boolean = false,
        nowMs: Long = System.currentTimeMillis()
    ): List<Candle> {
        val k = key(symbol, timeframe, source, marketType)
        val mutex = locks.getOrPut(k) { Mutex() }
        return mutex.withLock {
            val tfMs = timeframe.ms
            val targetBars = timeframe.targetBars
            val minBarsOk = (targetBars * 0.72).toInt().coerceAtLeast(180)
            val diskFile = fileFor(symbol, timeframe, source, marketType)

            var cached = if (forceFullRefresh) {
                emptyList()
            } else {
                memory[k] ?: readFromDisk(diskFile)
            }

            val expectedLastClosedOpen = (nowMs / tfMs) * tfMs - tfMs
            val lastCached = cached.lastOrNull()?.openTimeMs ?: 0L

            val barsToFetch = when {
                cached.size < minBarsOk && historyExhausted[k] != true -> targetBars
                lastCached < expectedLastClosedOpen -> {
                    val missing = ((expectedLastClosedOpen - lastCached) / tfMs).toInt().coerceAtLeast(1)
                    (missing + 4).coerceAtMost(targetBars)
                }
                else -> 4
            }

            if (barsToFetch > 0) {
                val fresh = coordinator.fetchTimeframeCandles(
                    symbol = symbol,
                    timeframe = timeframe,
                    source = source,
                    marketType = marketType,
                    limit = barsToFetch
                )
                if (barsToFetch == targetBars && fresh.size < minBarsOk) {
                    historyExhausted[k] = true
                }
                if (fresh.isNotEmpty()) {
                    val merged = TreeMap<Long, Candle>()
                    cached.forEach { merged[it.openTimeMs] = it }
                    fresh.forEach { merged[it.openTimeMs] = it }
                    val minKeepMs = nowMs - timeframe.historyDays * 86_400_000L - tfMs
                    cached = merged.values
                        .filter { it.openTimeMs >= minKeepMs }
                        .takeLast(targetBars)
                    writeToDisk(diskFile, cached)
                }
            }

            memory[k] = cached
            cached
        }
    }

    suspend fun prune(keepSymbols: Collection<String>, timeframe: Timeframe) = withContext(Dispatchers.IO) {
        if (keepSymbols.isEmpty()) return@withContext
        val keepSet = keepSymbols.toSet()
        val validTfNames = Timeframe.values().map { it.name }.toSet()
        // Keep only the active timeframe hot in RAM, while preserving all timeframes per kept asset on disk
        memory.keys.filter {
            val parts = it.split("|")
            parts.getOrNull(0) !in keepSet || parts.getOrNull(1) != timeframe.name
        }.forEach { memory.remove(it) }

        cacheDir.listFiles()?.forEach { file ->
            val parts = file.name.removeSuffix(".bin.gz").split("_")
            if (parts.size < 2 || parts[0] !in keepSet || parts[1] !in validTfNames) {
                file.delete()
            }
        }
    }

    private suspend fun readFromDisk(file: File): List<Candle> = withContext(Dispatchers.IO) {
        if (!file.exists()) return@withContext emptyList()
        runCatching {
            DataInputStream(BufferedInputStream(GZIPInputStream(FileInputStream(file)))).use { dis ->
                val count = dis.readInt().coerceIn(0, 100_000)
                val out = ArrayList<Candle>(count)
                repeat(count) {
                    out.add(
                        Candle(
                            openTimeMs = dis.readLong(),
                            open = dis.readDouble(),
                            high = dis.readDouble(),
                            low = dis.readDouble(),
                            close = dis.readDouble(),
                            volume = dis.readDouble(),
                            isClosed = true
                        )
                    )
                }
                out
            }
        }.getOrDefault(emptyList())
    }

    private suspend fun writeToDisk(file: File, candles: List<Candle>) = withContext(Dispatchers.IO) {
        runCatching {
            val tmp = File(file.parentFile, "${file.name}.tmp")
            DataOutputStream(BufferedOutputStream(GZIPOutputStream(FileOutputStream(tmp)))).use { dos ->
                dos.writeInt(candles.size)
                for (c in candles) {
                    dos.writeLong(c.openTimeMs)
                    dos.writeDouble(c.open)
                    dos.writeDouble(c.high)
                    dos.writeDouble(c.low)
                    dos.writeDouble(c.close)
                    dos.writeDouble(c.volume)
                }
            }
            if (file.exists()) file.delete()
            tmp.renameTo(file)
        }
    }
}
