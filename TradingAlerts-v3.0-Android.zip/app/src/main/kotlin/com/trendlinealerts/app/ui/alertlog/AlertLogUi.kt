package com.trendlinealerts.app.ui.alertlog

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.local.AlertLogEntity
import com.trendlinealerts.app.data.repository.AlertLogRepository
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.app.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AlertLogViewModel(
    private val alertLogRepository: AlertLogRepository
) : ViewModel() {

    val logs: StateFlow<List<AlertLogEntity>> = alertLogRepository.logsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = emptyList()
    )

    fun clearLogs() {
        viewModelScope.launch {
            alertLogRepository.clearAll()
        }
    }

    class Factory(
        private val alertLogRepository: AlertLogRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AlertLogViewModel(alertLogRepository) as T
        }
    }
}

@Composable
fun AlertLogScreen(
    viewModel: AlertLogViewModel
) {
    val logs by viewModel.logs.collectAsState()
    val expanded = remember { mutableStateMapOf<Long, Boolean>() }
    val items = remember(logs) { buildLogItems(logs) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Alert History",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            if (logs.isNotEmpty()) {
                IconButton(onClick = { viewModel.clearLogs() }) {
                    Icon(
                        imageVector = Icons.Filled.DeleteSweep,
                        contentDescription = "Clear alert history",
                        tint = GoogleRed
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (logs.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No alerts fired yet.",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(items = items, key = { it.key }) { item ->
                    when (item) {
                        is LogItem.Single -> AlertLogCard(log = item.log)
                        is LogItem.Group -> AlertLogGroup(
                            group = item,
                            isExpanded = expanded[item.minute] == true,
                            onToggle = { expanded[item.minute] = !(expanded[item.minute] ?: false) }
                        )
                    }
                }
            }
        }
    }
}

private sealed interface LogItem {
    val key: String

    data class Single(val log: AlertLogEntity) : LogItem {
        override val key: String get() = "s${log.id}"
    }

    data class Group(val minute: Long, val logs: List<AlertLogEntity>) : LogItem {
        override val key: String get() = "g$minute"
    }
}

private fun isClusterable(log: AlertLogEntity): Boolean =
    (log.eventType == "LONG_SIGNAL" || log.eventType == "SHORT_SIGNAL") && !log.message.startsWith("MISSED")

private fun buildLogItems(logs: List<AlertLogEntity>): List<LogItem> {
    val grouped = logs.filter { isClusterable(it) }.groupBy { it.timestampMs / 60_000L }
    val done = HashSet<Long>()
    val out = mutableListOf<LogItem>()
    for (log in logs) {
        if (isClusterable(log)) {
            val minute = log.timestampMs / 60_000L
            if (done.add(minute)) {
                val g = grouped.getValue(minute)
                out.add(if (g.size == 1) LogItem.Single(g[0]) else LogItem.Group(minute, g))
            }
        } else {
            out.add(LogItem.Single(log))
        }
    }
    return out
}

@Composable
private fun AlertLogGroup(
    group: LogItem.Group,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    val clock = SimpleDateFormat("HH:mm", Locale.US).format(Date(group.minute * 60_000L))
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$clock · ${group.logs.size} assets · Scalp Signals",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(text = if (isExpanded) "▴" else "▾", color = TextSecondary, fontSize = 16.sp)
            }
            if (isExpanded) {
                group.logs.forEach { AlertLogCard(log = it) }
            } else {
                Text(
                    text = group.logs.joinToString(", ") { it.symbol },
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun AlertLogCard(log: AlertLogEntity) {
    val (badgeLabel, badgeColor) = formatAlertBadge(log.eventType, log.slotId)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = badgeLabel,
                        color = badgeColor,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = log.symbol,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = formatTimestamp(log.timestampMs),
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Price: ${formatLogPrice(log.price)}",
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.5.sp
                )
                Text(
                    text = String.format(Locale.US, "Z-Score: %+.2f", log.lineValue),
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.5.sp
                )
            }
        }
    }
}

private fun formatAlertBadge(eventTypeName: String, detail: String): Pair<String, Color> = when (eventTypeName) {
    "LONG_SIGNAL" -> "LONG · $detail" to GoogleGreen
    "SHORT_SIGNAL" -> "SHORT · $detail" to GoogleRed
    "EXIT_LONG" -> "EXIT LONG · $detail" to WarningAmber
    "EXIT_SHORT" -> "EXIT SHORT · $detail" to WarningAmber
    "INDICATOR_PROMOTED" -> "NEW IND · $detail" to PrimaryBlue
    else -> "$eventTypeName · $detail" to TextPrimary
}

private fun formatTimestamp(timestampMs: Long): String {
    val formatter = SimpleDateFormat("MMM dd, HH:mm:ss", Locale.US)
    return formatter.format(Date(timestampMs))
}

private fun formatLogPrice(value: Double): String = when {
    value >= 1_000.0 -> String.format(Locale.US, "%.2f", value)
    value >= 1.0 -> String.format(Locale.US, "%.4f", value)
    value >= 0.01 -> String.format(Locale.US, "%.5f", value)
    else -> String.format(Locale.US, "%.6f", value)
}
