package com.trendlinealerts.app.data.remote

import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.Timeframe
import java.util.TreeMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonPrimitive
import retrofit2.HttpException
import retrofit2.http.GET
import retrofit2.http.Query

enum class DataSourceType {
    BYBIT,
    BINANCE,
    OKX
}

enum class MarketType {
    PERP,
    SPOT
}

class SymbolNotListedException(message: String) : Exception(message)

@Serializable
data class BybitResponse(
    @SerialName("retCode") val retCode: Int = -1,
    @SerialName("retMsg") val retMsg: String = "",
    @SerialName("result") val result: BybitResult? = null
)

@Serializable
data class BybitResult(
    @SerialName("list") val list: List<List<String>> = emptyList()
)

@Serializable
data class OkxResponse(
    @SerialName("code") val code: String = "-1",
    @SerialName("msg") val msg: String = "",
    @SerialName("data") val data: List<List<String>> = emptyList()
)

interface BybitApi {
    @GET("v5/market/kline")
    suspend fun getKlines(
        @Query("category") category: String,
        @Query("symbol") symbol: String,
        @Query("interval") interval: String,
        @Query("limit") limit: Int = 200,
        @Query("end") end: Long? = null
    ): BybitResponse
}

interface BinanceFuturesApi {
    @GET("fapi/v1/klines")
    suspend fun getKlines(
        @Query("symbol") symbol: String,
        @Query("interval") interval: String,
        @Query("limit") limit: Int = 200,
        @Query("endTime") endTime: Long? = null
    ): List<List<JsonPrimitive>>
}

interface BinanceSpotApi {
    @GET("api/v3/klines")
    suspend fun getKlines(
        @Query("symbol") symbol: String,
        @Query("interval") interval: String,
        @Query("limit") limit: Int = 200,
        @Query("endTime") endTime: Long? = null
    ): List<List<JsonPrimitive>>
}

interface OkxApi {
    @GET("api/v5/market/candles")
    suspend fun getCandles(
        @Query("instId") instId: String,
        @Query("bar") bar: String,
        @Query("limit") limit: Int = 100,
        @Query("after") after: String? = null
    ): OkxResponse
}

class MarketDataCoordinator(
    private val bybitApi: BybitApi,
    private val binanceFuturesApi: BinanceFuturesApi,
    private val binanceSpotApi: BinanceSpotApi,
    private val okxApi: OkxApi
) {
    companion object {
        fun pageSize(source: DataSourceType): Int = when (source) {
            DataSourceType.BYBIT -> 1000
            DataSourceType.BINANCE -> 1000
            DataSourceType.OKX -> 100
        }
    }

    suspend fun fetchCandles(
        symbol: String,
        intervalLabel: String,
        intervalMs: Long,
        source: DataSourceType,
        marketType: MarketType,
        limit: Int,
        endTimeMs: Long? = null
    ): List<Candle> {
        var attempt = 0
        var backoffMs = 1_500L
        while (true) {
            try {
                val rawCandles = when (source) {
                    DataSourceType.BYBIT -> fetchBybit(symbol, intervalLabel, intervalMs, marketType, limit, endTimeMs)
                    DataSourceType.BINANCE -> fetchBinance(symbol, intervalLabel, intervalMs, marketType, limit, endTimeMs)
                    DataSourceType.OKX -> fetchOkx(symbol, intervalLabel, intervalMs, marketType, limit, endTimeMs)
                }
                return rawCandles.sortedBy { it.openTimeMs }
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: HttpException) {
                if ((e.code() == 429 || e.code() == 418) && attempt < 3) {
                    attempt++
                    delay(backoffMs)
                    backoffMs *= 2
                } else {
                    throw e
                }
            }
        }
    }

    suspend fun fetchHistoryParallel(
        symbol: String,
        intervalLabel: String,
        intervalMs: Long,
        source: DataSourceType,
        marketType: MarketType,
        totalBars: Int,
        endTimeMs: Long? = null
    ): List<Candle> {
        val size = pageSize(source)
        val safeTotal = totalBars.coerceAtLeast(1)
        val all = TreeMap<Long, Candle>()

        val firstWant = minOf(size, safeTotal)
        val firstPage = fetchCandles(symbol, intervalLabel, intervalMs, source, marketType, firstWant, endTimeMs)
        if (firstPage.isEmpty()) return emptyList()
        firstPage.forEach { all[it.openTimeMs] = it }
        if (all.size >= safeTotal || firstPage.size < firstWant) {
            return all.values.toList().takeLast(safeTotal)
        }

        val oldestFirstOpen = firstPage.first().openTimeMs
        val remainingBars = safeTotal - all.size
        val pagesNeeded = ((remainingBars + size - 1) / size).coerceAtMost(if (source == DataSourceType.OKX) 80 else 60)
        val semaphore = Semaphore(4)

        val extraPages = coroutineScope {
            (1..pagesNeeded).map { pageIdx ->
                async {
                    semaphore.withPermit {
                        val pageEndMs = oldestFirstOpen - ((pageIdx - 1).toLong() * size.toLong() * intervalMs) - 1L
                        runCatching {
                            fetchCandles(symbol, intervalLabel, intervalMs, source, marketType, size, pageEndMs)
                        }.getOrDefault(emptyList())
                    }
                }
            }.awaitAll()
        }

        for (page in extraPages) {
            for (c in page) {
                all[c.openTimeMs] = c
            }
        }
        return all.values.toList().takeLast(safeTotal)
    }

    suspend fun fetchTimeframeCandles(
        symbol: String,
        timeframe: Timeframe,
        source: DataSourceType,
        marketType: MarketType,
        limit: Int = timeframe.targetBars,
        endTimeMs: Long? = null
    ): List<Candle> {
        val intervalLabel = when (source) {
            DataSourceType.BYBIT -> timeframe.bybitInterval
            DataSourceType.BINANCE -> timeframe.binanceInterval
            DataSourceType.OKX -> timeframe.okxBar
        }
        return fetchHistoryParallel(
            symbol = symbol,
            intervalLabel = intervalLabel,
            intervalMs = timeframe.ms,
            source = source,
            marketType = marketType,
            totalBars = limit.coerceAtMost(timeframe.targetBars),
            endTimeMs = endTimeMs
        )
    }

    suspend fun fetch1mCandles(
        symbol: String,
        source: DataSourceType,
        marketType: MarketType,
        limit: Int = 35,
        endTimeMs: Long? = null
    ): List<Candle> {
        val intervalLabel = when (source) {
            DataSourceType.BYBIT -> "1"
            DataSourceType.BINANCE -> "1m"
            DataSourceType.OKX -> "1m"
        }
        return fetchHistoryParallel(symbol, intervalLabel, 60_000L, source, marketType, limit, endTimeMs)
    }

    private suspend fun fetchBybit(
        symbol: String,
        interval: String,
        intervalMs: Long,
        marketType: MarketType,
        limit: Int,
        endTimeMs: Long?
    ): List<Candle> {
        val category = if (marketType == MarketType.PERP) "linear" else "spot"
        val resp = bybitApi.getKlines(
            category = category,
            symbol = symbol,
            interval = interval,
            limit = limit.coerceAtMost(1000),
            end = endTimeMs
        )
        if (resp.retCode == 10001) {
            throw SymbolNotListedException("Symbol $symbol not listed on Bybit ($category): ${resp.retMsg}")
        }
        if (resp.retCode != 0) {
            throw IllegalStateException("Bybit error ${resp.retCode}: ${resp.retMsg}")
        }
        val rows = resp.result?.list.orEmpty()
        if (rows.isEmpty()) return emptyList()
        val nowMs = System.currentTimeMillis()
        return rows.mapNotNull { row ->
            if (row.size < 6) return@mapNotNull null
            val openMs = row[0].toLongOrNull() ?: return@mapNotNull null
            Candle(
                openTimeMs = openMs,
                open = row[1].toDoubleOrNull() ?: return@mapNotNull null,
                high = row[2].toDoubleOrNull() ?: return@mapNotNull null,
                low = row[3].toDoubleOrNull() ?: return@mapNotNull null,
                close = row[4].toDoubleOrNull() ?: return@mapNotNull null,
                volume = row[5].toDoubleOrNull() ?: 0.0,
                isClosed = (openMs + intervalMs) <= nowMs
            )
        }
    }

    private suspend fun fetchBinance(
        symbol: String,
        interval: String,
        intervalMs: Long,
        marketType: MarketType,
        limit: Int,
        endTimeMs: Long?
    ): List<Candle> {
        val rows = try {
            if (marketType == MarketType.PERP) {
                binanceFuturesApi.getKlines(symbol = symbol, interval = interval, limit = limit.coerceAtMost(1000), endTime = endTimeMs)
            } else {
                binanceSpotApi.getKlines(symbol = symbol, interval = interval, limit = limit.coerceAtMost(1000), endTime = endTimeMs)
            }
        } catch (e: HttpException) {
            if (e.code() == 400) {
                throw SymbolNotListedException("Symbol $symbol not listed on Binance ($marketType)")
            }
            throw e
        }
        val nowMs = System.currentTimeMillis()
        return rows.mapNotNull { row ->
            if (row.size < 6) return@mapNotNull null
            val openMs = row[0].content.toLongOrNull() ?: return@mapNotNull null
            Candle(
                openTimeMs = openMs,
                open = row[1].content.toDoubleOrNull() ?: return@mapNotNull null,
                high = row[2].content.toDoubleOrNull() ?: return@mapNotNull null,
                low = row[3].content.toDoubleOrNull() ?: return@mapNotNull null,
                close = row[4].content.toDoubleOrNull() ?: return@mapNotNull null,
                volume = row[5].content.toDoubleOrNull() ?: 0.0,
                isClosed = (openMs + intervalMs) <= nowMs
            )
        }
    }

    private suspend fun fetchOkx(
        symbol: String,
        bar: String,
        intervalMs: Long,
        marketType: MarketType,
        limit: Int,
        endTimeMs: Long?
    ): List<Candle> {
        val instId = toOkxInstId(symbol, marketType)
        val resp = okxApi.getCandles(
            instId = instId,
            bar = bar,
            limit = limit.coerceAtMost(100),
            after = endTimeMs?.let { (it + 1).toString() }
        )
        if (resp.code == "51001") {
            throw SymbolNotListedException("Instrument $instId not listed on OKX")
        }
        if (resp.code != "0") {
            throw IllegalStateException("OKX error ${resp.code}: ${resp.msg}")
        }
        if (resp.data.isEmpty()) {
            throw SymbolNotListedException("No OKX candles for $instId")
        }
        val nowMs = System.currentTimeMillis()
        return resp.data.mapNotNull { row ->
            if (row.size < 6) return@mapNotNull null
            val openMs = row[0].toLongOrNull() ?: return@mapNotNull null
            val confirmFlag = row.getOrNull(8)
            val isClosed = if (confirmFlag != null) confirmFlag == "1" else (openMs + intervalMs) <= nowMs
            Candle(
                openTimeMs = openMs,
                open = row[1].toDoubleOrNull() ?: return@mapNotNull null,
                high = row[2].toDoubleOrNull() ?: return@mapNotNull null,
                low = row[3].toDoubleOrNull() ?: return@mapNotNull null,
                close = row[4].toDoubleOrNull() ?: return@mapNotNull null,
                volume = row[5].toDoubleOrNull() ?: 0.0,
                isClosed = isClosed
            )
        }
    }

    private fun toOkxInstId(symbol: String, marketType: MarketType): String {
        val upper = symbol.uppercase()
        val base = if (upper.endsWith("USDT")) upper.removeSuffix("USDT") else upper
        return if (marketType == MarketType.PERP) "$base-USDT-SWAP" else "$base-USDT"
    }
}
