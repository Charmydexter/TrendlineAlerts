package com.trendlinealerts.app.data.analytics

import com.trendlinealerts.app.data.cache.TimeframeCandleCache
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.local.SymbolStateDao
import com.trendlinealerts.app.data.local.SymbolStateEntity
import com.trendlinealerts.app.data.local.WatchlistEntity
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.data.remote.SymbolNotListedException
import com.trendlinealerts.app.data.repository.CachedSymbolSeries
import com.trendlinealerts.app.data.repository.ModelStateRepository
import com.trendlinealerts.app.data.repository.MonitorStateRepository
import com.trendlinealerts.app.data.repository.SymbolMonitorRow
import com.trendlinealerts.app.data.repository.WatchlistRepository
import com.trendlinealerts.core.indicators.ScalpingIndicators
import com.trendlinealerts.core.ml.EvaluatedAssetModel
import com.trendlinealerts.core.ml.LogisticMlEngine
import com.trendlinealerts.core.ml.SampledFeatureRow
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.SignalAction
import com.trendlinealerts.core.model.SignalCandidate
import com.trendlinealerts.core.model.SignalStateCodec
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.Timeframe
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

data class AssetEvaluationOutput(
    val evaluated: EvaluatedAssetModel,
    val row: SymbolMonitorRow,
    val events: List<SignalCandidate>,
    val newState: SymbolSignalState
)

class MlOrchestrator(
    private val candleCache: TimeframeCandleCache,
    private val watchlistRepo: WatchlistRepository,
    private val symbolStateDao: SymbolStateDao,
    private val settingsDataStore: SettingsDataStore,
    private val modelStateRepo: ModelStateRepository,
    private val monitorStateRepo: MonitorStateRepository
) {
    private val trainMutex = Mutex()
    private val evaluatedCache = ConcurrentHashMap<String, EvaluatedAssetModel>()
    private val samplePool = ConcurrentHashMap<String, List<SampledFeatureRow>>()
    private val stateMemory = ConcurrentHashMap<String, SymbolSignalState>()
    private var lastConfigKey: String? = null
    private var lastSequentialRetrainAtMs: Long = 0L

    private fun configKey(
        tf: Timeframe,
        market: MarketType,
        mult: Double,
        observeWithMaster: Boolean,
        masterAsset: String
    ): String =
        "${tf.name}|${market.name}|${String.format(java.util.Locale.US, "%.2f", mult)}|$observeWithMaster|$masterAsset"

    suspend fun loadState(symbol: String, positioned: Boolean, watchlistDir: String?): SymbolSignalState {
        val existing = stateMemory[symbol] ?: run {
            val raw = symbolStateDao.get(symbol)
            SignalStateCodec.decode(raw, symbol).also { stateMemory[symbol] = it }
        }
        val persistedDir = watchlistDir?.let { runCatching { EntryDirection.valueOf(it) }.getOrNull() }
        val resolvedDir = existing.lastSignalDirection ?: persistedDir
        return existing.copy(
            mode = if (positioned) AssetMode.POSITIONED else AssetMode.GENERAL,
            lastSignalDirection = resolvedDir
        )
    }

    suspend fun fetchMasterCandlesIfEnabled(
        source: DataSourceType,
        market: MarketType,
        tf: Timeframe,
        settings: AlertSettings,
        nowMs: Long
    ): List<Candle> {
        if (!settings.observeWithMaster) return emptyList()
        return runCatching {
            withContext(Dispatchers.IO) {
                candleCache.getCandles(settings.effectiveMasterAsset, tf, source, market, nowMs = nowMs)
            }
        }.getOrDefault(emptyList())
    }

    suspend fun clearForConfigChangeIfNeeded(
        tf: Timeframe,
        market: MarketType,
        mult: Double,
        observeWithMaster: Boolean,
        masterAsset: String
    ) {
        val key = configKey(tf, market, mult, observeWithMaster, masterAsset)
        if (lastConfigKey != null && lastConfigKey != key) {
            evaluatedCache.clear()
            samplePool.clear()
            stateMemory.clear()
            symbolStateDao.clear()
            lastSequentialRetrainAtMs = 0L
        }
        lastConfigKey = key
    }

    suspend fun evaluateSingleAsset(
        symbol: String,
        forceRefresh: Boolean = false
    ): EvaluatedAssetModel? = withContext(Dispatchers.Default) {
        val snap = settingsDataStore.getSnapshot()
        val settings = snap.alertSettings
        val tf = settings.timeframe
        val source = monitorStateRepo.statusFlow.value.activeSource ?: snap.dataSource
        val market = snap.marketType
        val entity = watchlistRepo.getAllEntities().firstOrNull { it.symbol == symbol }
        val positioned = entity?.isPriorityOverride == true

        val nowMs = System.currentTimeMillis()
        val candles = candleCache.getCandles(symbol, tf, source, market, forceFullRefresh = forceRefresh)
        if (candles.size < 40) return@withContext null
        val masterCandles = if (symbol == settings.effectiveMasterAsset && settings.observeWithMaster) {
            candles
        } else {
            fetchMasterCandlesIfEnabled(source, market, tf, settings, nowMs)
        }

        val prev = loadState(symbol, positioned, entity?.lastEntryDirection)
        val master = modelStateRepo.masterModel.value?.takeIf { it.timeframe == tf }
        val eval = LogisticMlEngine.trainAndEvaluateAsset(
            symbol = symbol,
            candles = candles,
            timeframe = tf,
            settings = settings,
            mode = if (positioned) AssetMode.POSITIONED else AssetMode.GENERAL,
            lastSignalDirection = prev.lastSignalDirection,
            previousActiveIndicators = prev.previousActiveIndicators,
            masterModel = master,
            nowMs = nowMs,
            masterCandles = masterCandles
        )
        evaluatedCache[symbol] = eval
        samplePool[symbol] = eval.sampledFeatures
        modelStateRepo.putAssetResult(
            snapshot = eval.snapshot,
            series = CachedSymbolSeries(symbol, candles, eval.computed)
        )
        eval
    }

    /**
     * Sequentially retrains every asset one after another, updates Master Model across pooled samples,
     * and refreshes Overview & Monitor snapshots.
     */
    suspend fun runSequentialDailyRetrain(
        sourceOverride: DataSourceType? = null,
        force: Boolean = false
    ) = trainMutex.withLock {
        val snap = settingsDataStore.getSnapshot()
        val settings = snap.alertSettings
        val tf = settings.timeframe
        val market = snap.marketType
        val source = sourceOverride ?: monitorStateRepo.statusFlow.value.activeSource ?: snap.dataSource

        clearForConfigChangeIfNeeded(
            tf,
            market,
            settings.effectiveMinProfitMultiplier,
            settings.observeWithMaster,
            settings.effectiveMasterAsset
        )

        val nowMs = System.currentTimeMillis()
        if (!force && lastSequentialRetrainAtMs > 0L && (nowMs - lastSequentialRetrainAtMs) < 86_400_000L) {
            return@withLock
        }

        val entities = watchlistRepo.getAllEntities()
        if (entities.isEmpty()) return@withLock

        val masterCandles = fetchMasterCandlesIfEnabled(source, market, tf, settings, nowMs)
        val currentMaster = modelStateRepo.masterModel.value?.takeIf { it.timeframe == tf }

        for ((index, entity) in entities.withIndex()) {
            val sym = entity.symbol
            monitorStateRepo.updateStatus {
                it.copy(retrainStatus = "Retraining ${index + 1}/${entities.size} · $sym")
            }
            try {
                val candles = withContext(Dispatchers.IO) {
                    candleCache.getCandles(sym, tf, source, market, nowMs = System.currentTimeMillis())
                }
                if (candles.size < 40) continue

                val prev = loadState(sym, entity.isPriorityOverride, entity.lastEntryDirection)
                val eval = withContext(Dispatchers.Default) {
                    LogisticMlEngine.trainAndEvaluateAsset(
                        symbol = sym,
                        candles = candles,
                        timeframe = tf,
                        settings = settings,
                        mode = if (entity.isPriorityOverride) AssetMode.POSITIONED else AssetMode.GENERAL,
                        lastSignalDirection = prev.lastSignalDirection,
                        previousActiveIndicators = prev.previousActiveIndicators,
                        masterModel = currentMaster,
                        nowMs = System.currentTimeMillis(),
                        masterCandles = masterCandles
                    )
                }
                evaluatedCache[sym] = eval
                samplePool[sym] = eval.sampledFeatures
                modelStateRepo.putAssetResult(
                    snapshot = eval.snapshot,
                    series = CachedSymbolSeries(sym, candles, eval.computed)
                )

                val updatedState = prev.copy(
                    lastTrainedAtMs = eval.snapshot.lastTrainedAtMs,
                    lastProcessedOpenMs = candles.last().openTimeMs,
                    previousActiveIndicators = eval.snapshot.activeIndicators,
                    lastSignalDirection = prev.lastSignalDirection ?: eval.snapshot.lastSignalDirection
                )
                stateMemory[sym] = updatedState
                symbolStateDao.put(SymbolStateEntity(sym, SignalStateCodec.encode(updatedState)))
            } catch (ce: CancellationException) {
                throw ce
            } catch (_: SymbolNotListedException) {
                // skip unlisted
            } catch (_: Exception) {
                // continue sequentially to next asset
            }
        }

        if (samplePool.isNotEmpty()) {
            val newMaster = withContext(Dispatchers.Default) {
                LogisticMlEngine.trainMasterModel(tf, samplePool.toMap(), System.currentTimeMillis(), settings.effectiveMasterAsset)
            }
            modelStateRepo.setMasterModel(newMaster)
            lastSequentialRetrainAtMs = System.currentTimeMillis()

            // Refresh rows with Master-blended predictions if observeWithMaster is active
            if (settings.observeWithMaster && newMaster != null) {
                val refreshedEntities = watchlistRepo.getAllEntities()
                val updatedRows = refreshedEntities.mapNotNull { entity ->
                    val cachedSeries = modelStateRepo.seriesBySymbol.value[entity.symbol] ?: return@mapNotNull null
                    val prevEval = evaluatedCache[entity.symbol] ?: return@mapNotNull null
                    val eval = withContext(Dispatchers.Default) {
                        LogisticMlEngine.trainAndEvaluateAsset(
                            symbol = entity.symbol,
                            candles = cachedSeries.candles,
                            timeframe = tf,
                            settings = settings,
                            mode = if (entity.isPriorityOverride) AssetMode.POSITIONED else AssetMode.GENERAL,
                            lastSignalDirection = loadState(entity.symbol, entity.isPriorityOverride, entity.lastEntryDirection).lastSignalDirection,
                            previousActiveIndicators = prevEval.snapshot.activeIndicators,
                            masterModel = newMaster,
                            nowMs = System.currentTimeMillis(),
                            masterCandles = masterCandles
                        )
                    }
                    evaluatedCache[entity.symbol] = eval
                    modelStateRepo.putAssetResult(eval.snapshot, cachedSeries)
                    snapshotToRow(eval.snapshot, entity)
                }
                if (updatedRows.isNotEmpty()) {
                    monitorStateRepo.updateSymbolRows(updatedRows)
                }
            }
        }

        monitorStateRepo.updateStatus {
            it.copy(retrainStatus = null, lastRetrainAtMs = System.currentTimeMillis())
        }
    }

    suspend fun evaluatePollItem(
        entity: WatchlistEntity,
        source: DataSourceType,
        market: MarketType,
        tf: Timeframe,
        settings: AlertSettings,
        nowMs: Long,
        masterCandles: List<Candle> = emptyList()
    ): AssetEvaluationOutput? {
        val sym = entity.symbol
        val positioned = entity.isPriorityOverride
        val candles = candleCache.getCandles(sym, tf, source, market, nowMs = nowMs)
        if (candles.size < 40) return null

        val prev = loadState(sym, positioned, entity.lastEntryDirection)
        val firstRun = prev.lastProcessedOpenMs == 0L
        val lastBarOpen = candles.last().openTimeMs
        val master = modelStateRepo.masterModel.value?.takeIf { it.timeframe == tf }

        val existingEval = evaluatedCache[sym]
        val needsFullTrain = existingEval == null ||
            existingEval.snapshot.timeframe != tf ||
            (nowMs - existingEval.snapshot.lastTrainedAtMs) >= 86_400_000L

        val eval = if (needsFullTrain) {
            LogisticMlEngine.trainAndEvaluateAsset(
                symbol = sym,
                candles = candles,
                timeframe = tf,
                settings = settings,
                mode = if (positioned) AssetMode.POSITIONED else AssetMode.GENERAL,
                lastSignalDirection = prev.lastSignalDirection,
                previousActiveIndicators = prev.previousActiveIndicators,
                masterModel = master,
                nowMs = nowMs,
                masterCandles = masterCandles
            ).also {
                evaluatedCache[sym] = it
                samplePool[sym] = it.sampledFeatures
            }
        } else {
            val computed = ScalpingIndicators.computeMatrix(
                candles = candles,
                timeframe = tf,
                masterCandles = if (settings.observeWithMaster) masterCandles else emptyList()
            )
            val lastIdx = candles.lastIndex
            val assetPLong = LogisticMlEngine.predictLogistic(computed.features, lastIdx, existingEval!!.longWeights)
            val assetPShort = LogisticMlEngine.predictLogistic(computed.features, lastIdx, existingEval.shortWeights)
            val mLong = master?.longWeights?.let { LogisticMlEngine.predictLogistic(computed.features, lastIdx, it) } ?: assetPLong
            val mShort = master?.shortWeights?.let { LogisticMlEngine.predictLogistic(computed.features, lastIdx, it) } ?: assetPShort
            val alpha = if (settings.observeWithMaster && master != null) 0.28 else 0.0
            val pLong = assetPLong * (1.0 - alpha) + mLong * alpha
            val pShort = assetPShort * (1.0 - alpha) + mShort * alpha
            val ofi = computed.features[lastIdx * ScalpingIndicators.FEATURE_COUNT + 0].toDouble()
            val rsiSlope = computed.features[lastIdx * ScalpingIndicators.FEATURE_COUNT + 2].toDouble()
            val z = computed.zScoreSeries[lastIdx]
            val dir = prev.lastSignalDirection ?: existingEval.snapshot.lastSignalDirection
            val dec = LogisticMlEngine.resolveSignalDecision(
                pLong = pLong,
                pShort = pShort,
                mode = if (positioned) AssetMode.POSITIONED else AssetMode.GENERAL,
                lastSignalDirection = dir,
                threshold = settings.effectiveSignalThreshold,
                ofiValue = ofi,
                rsi7SlopeValue = rsiSlope,
                zScore = z
            )
            val updatedSnap = existingEval.snapshot.copy(
                updatedAtMs = nowMs,
                lastPrice = candles.last().close,
                zScore = z,
                masterAsset = settings.effectiveMasterAsset,
                masterZScore = computed.latestMasterZScore,
                btcCorrelation = computed.latestBtcCorrelation,
                btcBeta = computed.latestBtcBeta,
                relStrengthVsMaster = computed.latestRelStrength,
                barCount = candles.size,
                currentAction = dec.action,
                pLong = pLong,
                pShort = pShort,
                exhaustionScore = dec.exhaustionScore,
                masterAgreement = (assetPLong >= assetPShort && mLong >= mShort) || (assetPShort > assetPLong && mShort > mLong),
                masterPLong = mLong,
                masterPShort = mShort,
                lastSignalDirection = dir
            )
            EvaluatedAssetModel(updatedSnap, existingEval.longWeights, existingEval.shortWeights, computed, existingEval.sampledFeatures).also {
                evaluatedCache[sym] = it
            }
        }

        modelStateRepo.putAssetResult(eval.snapshot, CachedSymbolSeries(sym, candles, eval.computed))

        val events = mutableListOf<SignalCandidate>()
        var nextDir = prev.lastSignalDirection ?: eval.snapshot.lastSignalDirection
        var nextSignalAt = prev.lastSignalAtMs
        var nextExitAt = prev.lastExitAlertAtMs

        val topIndLabel = eval.snapshot.activeIndicators.firstOrNull()?.shortLabel ?: "LR"
        val isNewBar = lastBarOpen > prev.lastProcessedOpenMs

        if (!firstRun) {
            when (eval.snapshot.currentAction) {
                SignalAction.LONG -> {
                    val cooldownOk = prev.lastSignalAtMs.let { last -> last == null || (nowMs - last) >= tf.ms * 4L }
                    if (prev.lastAction != SignalAction.LONG || (isNewBar && cooldownOk)) {
                        nextDir = EntryDirection.LONG
                        nextSignalAt = nowMs
                        watchlistRepo.updateLastEntryDirection(sym, EntryDirection.LONG)
                        events.add(
                            SignalCandidate(
                                symbol = sym,
                                eventType = EventType.LONG_SIGNAL,
                                action = SignalAction.LONG,
                                price = eval.snapshot.lastPrice,
                                pLong = eval.snapshot.pLong,
                                pShort = eval.snapshot.pShort,
                                zScore = eval.snapshot.zScore,
                                topIndicator = topIndLabel,
                                timestampMs = nowMs,
                                eventTimeMs = lastBarOpen
                            )
                        )
                    }
                }
                SignalAction.SHORT -> {
                    val cooldownOk = prev.lastSignalAtMs.let { last -> last == null || (nowMs - last) >= tf.ms * 4L }
                    if (prev.lastAction != SignalAction.SHORT || (isNewBar && cooldownOk)) {
                        nextDir = EntryDirection.SHORT
                        nextSignalAt = nowMs
                        watchlistRepo.updateLastEntryDirection(sym, EntryDirection.SHORT)
                        events.add(
                            SignalCandidate(
                                symbol = sym,
                                eventType = EventType.SHORT_SIGNAL,
                                action = SignalAction.SHORT,
                                price = eval.snapshot.lastPrice,
                                pLong = eval.snapshot.pLong,
                                pShort = eval.snapshot.pShort,
                                zScore = eval.snapshot.zScore,
                                topIndicator = topIndLabel,
                                timestampMs = nowMs,
                                eventTimeMs = lastBarOpen
                            )
                        )
                    }
                }
                SignalAction.EXIT -> {
                    val cooldownOk = prev.lastExitAlertAtMs.let { last -> last == null || (nowMs - last) >= tf.ms * 3L }
                    if (positioned && (prev.lastAction != SignalAction.EXIT || cooldownOk)) {
                        nextExitAt = nowMs
                        val evType = if (nextDir == EntryDirection.SHORT) EventType.EXIT_SHORT else EventType.EXIT_LONG
                        events.add(
                            SignalCandidate(
                                symbol = sym,
                                eventType = evType,
                                action = SignalAction.EXIT,
                                price = eval.snapshot.lastPrice,
                                pLong = eval.snapshot.pLong,
                                pShort = eval.snapshot.pShort,
                                zScore = eval.snapshot.zScore,
                                topIndicator = topIndLabel,
                                timestampMs = nowMs,
                                eventTimeMs = lastBarOpen,
                                note = "Exhaustion ${(eval.snapshot.exhaustionScore * 100).toInt()}%"
                            )
                        )
                    }
                }
                SignalAction.WAIT -> Unit
            }

            for (promoted in eval.snapshot.promotedIndicators) {
                if (promoted !in prev.previousActiveIndicators) {
                    events.add(
                        SignalCandidate(
                            symbol = sym,
                            eventType = EventType.INDICATOR_PROMOTED,
                            action = eval.snapshot.currentAction,
                            price = eval.snapshot.lastPrice,
                            pLong = eval.snapshot.pLong,
                            pShort = eval.snapshot.pShort,
                            zScore = eval.snapshot.zScore,
                            topIndicator = promoted.shortLabel,
                            timestampMs = nowMs,
                            eventTimeMs = lastBarOpen,
                            note = "Promoted ${promoted.label}"
                        )
                    )
                }
            }
        }

        val newState = prev.copy(
            mode = if (positioned) AssetMode.POSITIONED else AssetMode.GENERAL,
            lastProcessedOpenMs = lastBarOpen,
            lastTrainedAtMs = eval.snapshot.lastTrainedAtMs,
            lastAction = eval.snapshot.currentAction,
            lastSignalDirection = nextDir,
            lastSignalAtMs = nextSignalAt,
            lastExitAlertAtMs = nextExitAt,
            previousActiveIndicators = eval.snapshot.activeIndicators
        )

        val row = snapshotToRow(eval.snapshot, entity.copy(lastEntryDirection = nextDir?.name))
        return AssetEvaluationOutput(eval, row, events, newState)
    }

    fun updateStateInMemory(state: SymbolSignalState) {
        stateMemory[state.symbol] = state
    }

    fun snapshotToRow(snap: com.trendlinealerts.core.model.AssetModelSnapshot, entity: WatchlistEntity): SymbolMonitorRow {
        val b21 = snap.drift.benchmarks.d21
        val entityDir = entity.lastEntryDirection?.let { runCatching { EntryDirection.valueOf(it) }.getOrNull() }
        return SymbolMonitorRow(
            symbol = snap.symbol,
            lastPrice = snap.lastPrice,
            action = snap.currentAction,
            pLong = snap.pLong,
            pShort = snap.pShort,
            zScore = snap.zScore,
            btcCorrelation = snap.btcCorrelation,
            btcBeta = snap.btcBeta,
            exhaustionScore = snap.exhaustionScore,
            winRate21d = if (b21.tradeCount > 0) b21.winRatePct else null,
            netReturn21d = if (b21.tradeCount > 0) b21.netReturnPct else null,
            topIndicator = snap.activeIndicators.firstOrNull()?.shortLabel,
            masterAgreement = snap.masterAgreement,
            lastSignalDirection = entityDir ?: snap.lastSignalDirection,
            isPriorityOverride = entity.isPriorityOverride,
            lastAlertedAtMs = entity.lastAlertedAtMs
        )
    }
}
