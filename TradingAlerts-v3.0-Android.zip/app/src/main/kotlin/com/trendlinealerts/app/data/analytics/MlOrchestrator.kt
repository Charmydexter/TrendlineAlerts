package com.trendlinealerts.app.data.analytics

import kotlin.math.max
import kotlinx.coroutines.flow.StateFlow
import com.trendlinealerts.core.indicators.ComputedIndicators
import com.trendlinealerts.core.ml.ProvenGate
import com.trendlinealerts.core.ml.PersistedMaster
import com.trendlinealerts.core.ml.PersistedAssetModel
import com.trendlinealerts.core.ml.ModelPersistenceFormat
import com.trendlinealerts.core.ml.LongTermHistory
import com.trendlinealerts.core.ml.DailyRecord
import java.util.Locale
import com.trendlinealerts.core.model.plainName
import com.trendlinealerts.core.model.TradeCloseReason
import com.trendlinealerts.core.model.ActiveTrade
import com.trendlinealerts.core.trade.TradeTracker
import com.trendlinealerts.core.analytics.TradeRiskCalculator
import com.trendlinealerts.core.analytics.PriceFormat
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.launch
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.Job
import kotlinx.coroutines.CoroutineScope
import com.trendlinealerts.app.data.cache.TimeframeCandleCache
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.local.SymbolStateDao
import com.trendlinealerts.app.data.local.SymbolStateEntity
import com.trendlinealerts.app.data.local.WatchlistEntity
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.data.remote.SymbolNotListedException
import com.trendlinealerts.app.data.repository.CachedSymbolSeries
import com.trendlinealerts.app.data.repository.ModelStateRepository
import com.trendlinealerts.app.data.repository.MonitorStateRepository
import com.trendlinealerts.app.data.repository.SymbolMonitorRow
import com.trendlinealerts.app.data.repository.WatchlistRepository
import com.trendlinealerts.core.indicators.ScalpingIndicators
import com.trendlinealerts.core.ml.EvaluatedAssetModel
import com.trendlinealerts.core.ml.LogisticMlEngine
import com.trendlinealerts.core.ml.SampledFeatureRow
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.SignalAction
import com.trendlinealerts.core.model.SignalCandidate
import com.trendlinealerts.core.model.SignalStateCodec
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.Timeframe
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

data class AssetEvaluationOutput(
    val evaluated: EvaluatedAssetModel,
    val row: SymbolMonitorRow,
    val events: List<SignalCandidate>,
    val newState: SymbolSignalState
)

class MlOrchestrator(
    private val candleCache: TimeframeCandleCache,
    private val watchlistRepo: WatchlistRepository,
    private val symbolStateDao: SymbolStateDao,
    private val settingsDataStore: SettingsDataStore,
    private val modelStateRepo: ModelStateRepository,
    private val monitorStateRepo: MonitorStateRepository,
    private val persistence: MlPersistence
) {
    /** Day-by-day results kept for a year (feeds the long-term card on the Overview). */
    val dailyRecords: StateFlow<List<DailyRecord>> get() = persistence.daily

    private val trainMutex = Mutex()
    private val evaluatedCache = ConcurrentHashMap<String, EvaluatedAssetModel>()
    private val samplePool = ConcurrentHashMap<String, List<SampledFeatureRow>>()
    private val stateMemory = ConcurrentHashMap<String, SymbolSignalState>()
    private var lastConfigKey: String? = null
    private var lastSequentialRetrainAtMs: Long = 0L

    private fun configKey(
        tf: Timeframe,
        market: MarketType,
        mult: Double,
        observeWithMaster: Boolean,
        masterAsset: String,
        stopLossPct: Double
    ): String =
        "${tf.name}|${market.name}|${String.format(java.util.Locale.US, "%.2f", mult)}|$observeWithMaster|$masterAsset|${String.format(java.util.Locale.US, "%.3f", stopLossPct)}"

    suspend fun loadState(symbol: String, positioned: Boolean, watchlistDir: String?): SymbolSignalState {
        val existing = stateMemory[symbol] ?: run {
            val raw = symbolStateDao.get(symbol)
            SignalStateCodec.decode(raw, symbol).also { stateMemory[symbol] = it }
        }
        val persistedDir = watchlistDir?.let { runCatching { EntryDirection.valueOf(it) }.getOrNull() }
        val resolvedDir = existing.lastSignalDirection ?: persistedDir
        return existing.copy(
            mode = if (positioned) AssetMode.POSITIONED else AssetMode.GENERAL,
            lastSignalDirection = resolvedDir
        )
    }

    suspend fun fetchMasterCandlesIfEnabled(
        source: DataSourceType,
        market: MarketType,
        tf: Timeframe,
        settings: AlertSettings,
        nowMs: Long
    ): List<Candle> {
        if (!settings.observeWithMaster) return emptyList()
        return runCatching {
            withContext(Dispatchers.IO) {
                candleCache.getCandles(settings.effectiveMasterAsset, tf, source, market, nowMs = nowMs)
            }
        }.getOrDefault(emptyList())
    }

    suspend fun clearForConfigChangeIfNeeded(
        tf: Timeframe,
        market: MarketType,
        mult: Double,
        observeWithMaster: Boolean,
        masterAsset: String,
        stopLossPct: Double = 0.0
    ) {
        val key = configKey(tf, market, mult, observeWithMaster, masterAsset, stopLossPct)
        val firstTime = lastConfigKey == null
        if (lastConfigKey != null && lastConfigKey != key) {
            evaluatedCache.clear()
            samplePool.clear()
            stateMemory.clear()
            symbolStateDao.clear()
            lastSequentialRetrainAtMs = 0L
            retrainedSymbols.clear()
        }
        lastConfigKey = key
        if (firstTime) hydrateFromDisk(tf, key)
    }

    private fun emptyComputed() = ComputedIndicators(
        FloatArray(0), DoubleArray(0), DoubleArray(0), DoubleArray(0), DoubleArray(0),
        DoubleArray(0), DoubleArray(0), DoubleArray(0), DoubleArray(0)
    )

    /** After a restart, reuse the models saved for these exact settings instead of retraining everything. */
    private suspend fun hydrateFromDisk(tf: Timeframe, key: String) {
        withContext(Dispatchers.IO) {
            runCatching {
                for (p in persistence.loadAssets(tf, key)) {
                    evaluatedCache[p.snapshot.symbol] = EvaluatedAssetModel(
                        snapshot = p.snapshot,
                        longWeights = p.longWeights,
                        shortWeights = p.shortWeights,
                        computed = emptyComputed(),
                        sampledFeatures = emptyList()
                    )
                    modelStateRepo.putSnapshot(p.snapshot)
                    lastSequentialRetrainAtMs = max(lastSequentialRetrainAtMs, p.savedAtMs)
                }
                persistence.loadMaster(tf, key)?.let { modelStateRepo.setMasterModel(it.master) }
            }
        }
    }

    /** Saves a freshly trained asset model and its day-by-day results. */
    private suspend fun persistEvaluation(tf: Timeframe, eval: EvaluatedAssetModel, nowMs: Long) {
        val key = lastConfigKey ?: return
        withContext(Dispatchers.IO) {
            runCatching {
                persistence.saveAsset(
                    tf,
                    PersistedAssetModel(
                        ModelPersistenceFormat.VERSION, ScalpingIndicators.FEATURE_COUNT, key, nowMs,
                        eval.snapshot, eval.longWeights, eval.shortWeights
                    )
                )
                persistence.upsertDaily(LongTermHistory.recordsFromSnapshot(eval.snapshot, nowMs), nowMs)
            }
        }
    }

    suspend fun evaluateSingleAsset(
        symbol: String,
        forceRefresh: Boolean = false
    ): EvaluatedAssetModel? = withContext(Dispatchers.Default) {
        val snap = settingsDataStore.getSnapshot()
        val settings = snap.alertSettings
        val tf = settings.timeframe
        val source = monitorStateRepo.statusFlow.value.activeSource ?: snap.dataSource
        val market = snap.marketType
        val entity = watchlistRepo.getAllEntities().firstOrNull { it.symbol == symbol }
        val positioned = entity?.isPriorityOverride == true

        val nowMs = System.currentTimeMillis()
        val candles = candleCache.getCandles(symbol, tf, source, market, forceFullRefresh = forceRefresh)
        if (candles.size < 40) return@withContext null
        val masterCandles = if (symbol == settings.effectiveMasterAsset && settings.observeWithMaster) {
            candles
        } else {
            fetchMasterCandlesIfEnabled(source, market, tf, settings, nowMs)
        }

        val prev = loadState(symbol, positioned, entity?.lastEntryDirection)
        val master = modelStateRepo.masterModel.value?.takeIf { it.timeframe == tf }
        val eval = LogisticMlEngine.trainAndEvaluateAsset(
            symbol = symbol,
            candles = candles,
            timeframe = tf,
            settings = settings,
            mode = if (positioned) AssetMode.POSITIONED else AssetMode.GENERAL,
            lastSignalDirection = prev.lastSignalDirection,
            previousActiveIndicators = prev.previousActiveIndicators,
            masterModel = master,
            nowMs = nowMs,
            masterCandles = masterCandles
        )
        evaluatedCache[symbol] = eval
        samplePool[symbol] = eval.sampledFeatures
        modelStateRepo.putAssetResult(
            snapshot = eval.snapshot,
            series = CachedSymbolSeries(symbol, candles, eval.computed)
        )
        eval
    }

    @Volatile
    private var stopRequested = false
    private var retrainJob: Job? = null
    private val retrainScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val retrainedSymbols: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /** Starts a full retrain that keeps going if the screen is closed. Does nothing if one is running. */
    fun startSequentialRetrain(resume: Boolean = false) {
        if (retrainJob?.isActive == true) return
        retrainJob = retrainScope.launch {
            runCatching { runSequentialDailyRetrain(force = true, resume = resume) }
        }
    }

    /** Stops a running retrain. Assets that are not finished can be picked up again with Resume. */
    fun stopSequentialRetrain() {
        stopRequested = true
        retrainJob?.cancel()
    }

    /**
     * Sequentially retrains every asset one after another, updates the Master Model across pooled
     * samples, and refreshes Overview & Monitor snapshots. The status line is always cleared when
     * this ends (finished, stopped or failed), so the button never stays stuck.
     */
    suspend fun runSequentialDailyRetrain(
        sourceOverride: DataSourceType? = null,
        force: Boolean = false,
        resume: Boolean = false
    ): Unit = trainMutex.withLock {
        stopRequested = false
        var finished = false
        var allSymbols: List<String> = emptyList()
        try {
            val snap = settingsDataStore.getSnapshot()
            val settings = snap.alertSettings
            val tf = settings.timeframe
            val market = snap.marketType
            val source = sourceOverride ?: monitorStateRepo.statusFlow.value.activeSource ?: snap.dataSource

            clearForConfigChangeIfNeeded(
                tf,
                market,
                settings.effectiveMinProfitMultiplier,
                settings.observeWithMaster,
                settings.effectiveMasterAsset,
                settings.stopLossPct
            )

            val nowMs = System.currentTimeMillis()
            if (!force && lastSequentialRetrainAtMs > 0L && (nowMs - lastSequentialRetrainAtMs) < 86_400_000L) {
                finished = true
                return@withLock
            }

            val entities = watchlistRepo.getAllEntities()
            allSymbols = entities.map { it.symbol }
            if (entities.isEmpty()) {
                finished = true
                return@withLock
            }
            if (!resume) retrainedSymbols.clear()
            val pending = entities.filter { !resume || it.symbol !in retrainedSymbols }

            val masterCandles = fetchMasterCandlesIfEnabled(source, market, tf, settings, nowMs)
            val currentMaster = modelStateRepo.masterModel.value?.takeIf { it.timeframe == tf }

            for ((index, entity) in pending.withIndex()) {
                if (stopRequested) break
                val sym = entity.symbol
                monitorStateRepo.updateStatus {
                    it.copy(retrainStatus = "Training ${index + 1}/${pending.size} · ${sym.removeSuffix("USDT")}")
                }
                try {
                    // A slow or hanging download must not freeze the whole run.
                    val candles = withTimeout(75_000L) {
                        withContext(Dispatchers.IO) {
                            candleCache.getCandles(sym, tf, source, market, nowMs = System.currentTimeMillis())
                        }
                    }
                    if (candles.size < 40) continue

                    val prev = loadState(sym, entity.isPriorityOverride, entity.lastEntryDirection)
                    val eval = withContext(Dispatchers.Default) {
                        LogisticMlEngine.trainAndEvaluateAsset(
                            symbol = sym,
                            candles = candles,
                            timeframe = tf,
                            settings = settings,
                            mode = if (entity.isPriorityOverride) AssetMode.POSITIONED else AssetMode.GENERAL,
                            lastSignalDirection = prev.lastSignalDirection,
                            previousActiveIndicators = prev.previousActiveIndicators,
                            masterModel = currentMaster,
                            nowMs = System.currentTimeMillis(),
                            masterCandles = masterCandles
                        )
                    }
                    evaluatedCache[sym] = eval
                    persistEvaluation(tf, eval, System.currentTimeMillis())
                    samplePool[sym] = eval.sampledFeatures
                    modelStateRepo.putAssetResult(
                        snapshot = eval.snapshot,
                        series = CachedSymbolSeries(sym, candles, eval.computed)
                    )

                    val updatedState = prev.copy(
                        lastTrainedAtMs = eval.snapshot.lastTrainedAtMs,
                        lastProcessedOpenMs = candles.last().openTimeMs,
                        previousActiveIndicators = eval.snapshot.activeIndicators,
                        lastSignalDirection = prev.lastSignalDirection ?: eval.snapshot.lastSignalDirection
                    )
                    stateMemory[sym] = updatedState
                    symbolStateDao.put(SymbolStateEntity(sym, SignalStateCodec.encode(updatedState)))
                    retrainedSymbols.add(sym)
                } catch (_: TimeoutCancellationException) {
                    // slow network: skip this asset, keep going
                } catch (ce: CancellationException) {
                    throw ce
                } catch (_: SymbolNotListedException) {
                    // skip unlisted
                } catch (_: Exception) {
                    // continue sequentially to next asset
                }
            }

            if (!stopRequested && samplePool.isNotEmpty()) {
                monitorStateRepo.updateStatus { it.copy(retrainStatus = "Combining market-leader knowledge…") }
                val newMaster = withContext(Dispatchers.Default) {
                    LogisticMlEngine.trainMasterModel(tf, samplePool.toMap(), System.currentTimeMillis(), settings.effectiveMasterAsset)
                }
                modelStateRepo.setMasterModel(newMaster)
                val configKeyNow = lastConfigKey
                if (newMaster != null && configKeyNow != null) {
                    withContext(Dispatchers.IO) {
                        runCatching {
                            persistence.saveMaster(
                                tf,
                                PersistedMaster(
                                    ModelPersistenceFormat.VERSION, ScalpingIndicators.FEATURE_COUNT,
                                    configKeyNow, System.currentTimeMillis(), newMaster
                                )
                            )
                        }
                    }
                }

                // Refresh rows with Master-blended predictions if observeWithMaster is active
                if (settings.observeWithMaster && newMaster != null) {
                    val refreshedEntities = watchlistRepo.getAllEntities()
                    val updatedRows = ArrayList<SymbolMonitorRow>()
                    for ((i, entity) in refreshedEntities.withIndex()) {
                        if (stopRequested) break
                        monitorStateRepo.updateStatus {
                            it.copy(retrainStatus = "Finishing ${i + 1}/${refreshedEntities.size} · ${entity.symbol.removeSuffix("USDT")}")
                        }
                        try {
                            val cachedSeries = modelStateRepo.seriesBySymbol.value[entity.symbol] ?: continue
                            val prevEval = evaluatedCache[entity.symbol] ?: continue
                            val eval = withContext(Dispatchers.Default) {
                                LogisticMlEngine.trainAndEvaluateAsset(
                                    symbol = entity.symbol,
                                    candles = cachedSeries.candles,
                                    timeframe = tf,
                                    settings = settings,
                                    mode = if (entity.isPriorityOverride) AssetMode.POSITIONED else AssetMode.GENERAL,
                                    lastSignalDirection = loadState(entity.symbol, entity.isPriorityOverride, entity.lastEntryDirection).lastSignalDirection,
                                    previousActiveIndicators = prevEval.snapshot.activeIndicators,
                                    masterModel = newMaster,
                                    nowMs = System.currentTimeMillis(),
                                    masterCandles = masterCandles
                                )
                            }
                            evaluatedCache[entity.symbol] = eval
                            modelStateRepo.putAssetResult(eval.snapshot, cachedSeries)
                            persistEvaluation(tf, eval, System.currentTimeMillis())
                            updatedRows.add(snapshotToRow(eval.snapshot, entity))
                        } catch (ce: CancellationException) {
                            throw ce
                        } catch (_: Exception) {
                            // keep the previous prediction for this asset
                        }
                    }
                    if (updatedRows.isNotEmpty()) {
                        monitorStateRepo.updateSymbolRows(updatedRows)
                    }
                }
            }

            if (!stopRequested) {
                finished = true
                lastSequentialRetrainAtMs = System.currentTimeMillis()
            }
        } finally {
            withContext(NonCancellable) {
                val left = if (finished) 0 else allSymbols.count { it !in retrainedSymbols }
                monitorStateRepo.updateStatus {
                    it.copy(
                        retrainStatus = null,
                        lastRetrainAtMs = if (finished) System.currentTimeMillis() else it.lastRetrainAtMs,
                        retrainResumeLeft = left
                    )
                }
            }
        }
    }

    suspend fun evaluatePollItem(
        entity: WatchlistEntity,
        source: DataSourceType,
        market: MarketType,
        tf: Timeframe,
        settings: AlertSettings,
        nowMs: Long,
        masterCandles: List<Candle> = emptyList()
    ): AssetEvaluationOutput? {
        val sym = entity.symbol
        val positioned = entity.isPriorityOverride
        val candles = candleCache.getCandles(sym, tf, source, market, nowMs = nowMs)
        if (candles.size < 40) return null

        val prev = loadState(sym, positioned, entity.lastEntryDirection)
        val activeTrade = prev.activeTrade
        // A trade started by an alert is followed for exits even if the Positioned switch is off.
        val tracking = positioned || activeTrade != null
        val firstRun = prev.lastProcessedOpenMs == 0L
        val lastBarOpen = candles.last().openTimeMs
        val master = modelStateRepo.masterModel.value?.takeIf { it.timeframe == tf }

        val existingEval = evaluatedCache[sym]
        val needsFullTrain = existingEval == null ||
            existingEval.snapshot.timeframe != tf ||
            (nowMs - existingEval.snapshot.lastTrainedAtMs) >= 86_400_000L

        val eval = if (needsFullTrain) {
            LogisticMlEngine.trainAndEvaluateAsset(
                symbol = sym,
                candles = candles,
                timeframe = tf,
                settings = settings,
                mode = if (tracking) AssetMode.POSITIONED else AssetMode.GENERAL,
                lastSignalDirection = activeTrade?.direction ?: prev.lastSignalDirection,
                previousActiveIndicators = prev.previousActiveIndicators,
                masterModel = master,
                nowMs = nowMs,
                masterCandles = masterCandles
            ).also {
                evaluatedCache[sym] = it
                samplePool[sym] = it.sampledFeatures
            }
        } else {
            val computed = ScalpingIndicators.computeMatrix(
                candles = candles,
                timeframe = tf,
                masterCandles = if (settings.observeWithMaster) masterCandles else emptyList()
            )
            val lastIdx = candles.lastIndex
            val assetPLong = LogisticMlEngine.predictLogistic(computed.features, lastIdx, existingEval!!.longWeights)
            val assetPShort = LogisticMlEngine.predictLogistic(computed.features, lastIdx, existingEval.shortWeights)
            val mLong = master?.longWeights?.let { LogisticMlEngine.predictLogistic(computed.features, lastIdx, it) } ?: assetPLong
            val mShort = master?.shortWeights?.let { LogisticMlEngine.predictLogistic(computed.features, lastIdx, it) } ?: assetPShort
            val alpha = if (settings.observeWithMaster && master != null) 0.28 else 0.0
            val pLong = assetPLong * (1.0 - alpha) + mLong * alpha
            val pShort = assetPShort * (1.0 - alpha) + mShort * alpha
            val ofi = computed.features[lastIdx * ScalpingIndicators.FEATURE_COUNT + 0].toDouble()
            val rsiSlope = computed.features[lastIdx * ScalpingIndicators.FEATURE_COUNT + 2].toDouble()
            val z = computed.zScoreSeries[lastIdx]
            val dir = activeTrade?.direction ?: prev.lastSignalDirection ?: existingEval.snapshot.lastSignalDirection
            val dec = LogisticMlEngine.resolveSignalDecision(
                pLong = pLong,
                pShort = pShort,
                mode = if (tracking) AssetMode.POSITIONED else AssetMode.GENERAL,
                lastSignalDirection = dir,
                threshold = settings.effectiveSignalThreshold,
                ofiValue = ofi,
                rsi7SlopeValue = rsiSlope,
                zScore = z,
                channelZ = computed.channelZSeries.getOrNull(lastIdx)
            )
            val updatedSnap = existingEval.snapshot.copy(
                updatedAtMs = nowMs,
                lastPrice = candles.last().close,
                zScore = z,
                channelZ = computed.channelZSeries.getOrNull(lastIdx) ?: 0.0,
                masterAsset = settings.effectiveMasterAsset,
                masterZScore = computed.latestMasterZScore,
                btcCorrelation = computed.latestBtcCorrelation,
                btcBeta = computed.latestBtcBeta,
                relStrengthVsMaster = computed.latestRelStrength,
                barCount = candles.size,
                currentAction = dec.action,
                pLong = pLong,
                pShort = pShort,
                exhaustionScore = dec.exhaustionScore,
                masterAgreement = (assetPLong >= assetPShort && mLong >= mShort) || (assetPShort > assetPLong && mShort > mLong),
                masterPLong = mLong,
                masterPShort = mShort,
                lastSignalDirection = dir
            )
            EvaluatedAssetModel(updatedSnap, existingEval.longWeights, existingEval.shortWeights, computed, existingEval.sampledFeatures).also {
                evaluatedCache[sym] = it
            }
        }

        modelStateRepo.putAssetResult(eval.snapshot, CachedSymbolSeries(sym, candles, eval.computed))
        if (needsFullTrain) persistEvaluation(tf, eval, nowMs)

        val events = mutableListOf<SignalCandidate>()
        var nextDir = prev.lastSignalDirection ?: eval.snapshot.lastSignalDirection
        var nextSignalAt = prev.lastSignalAtMs
        var nextExitAt = prev.lastExitAlertAtMs
        var nextTrade = activeTrade
        var nextClosed = prev.closedTrades

        val topIndLabel = eval.snapshot.activeIndicators.firstOrNull()?.shortLabel ?: "LR"
        val isNewBar = lastBarOpen > prev.lastProcessedOpenMs

        if (!firstRun && activeTrade != null) {
            val enteredNow = activeTrade.enteredByUser || positioned
            val trade = if (enteredNow != activeTrade.enteredByUser) activeTrade.copy(enteredByUser = enteredNow) else activeTrade
            nextTrade = trade
            val price = eval.snapshot.lastPrice
            val sideWord = if (trade.direction == EntryDirection.LONG) "long" else "short"
            var closure: TradeTracker.Closure? = null
            var message: String? = null
            var notify = true

            if (TradeTracker.phase(trade, nowMs) == TradeTracker.Phase.WAITING_ENTRY) {
                // Signal went bad before the assumed entry: tell the user to cancel a pending order.
                if (eval.snapshot.currentAction == SignalAction.EXIT) {
                    closure = TradeTracker.closeAt(trade, TradeCloseReason.CANCELLED, price)
                    message = "Signal cancelled before entry. If you placed an order, cancel it."
                }
            } else {
                val hit = TradeTracker.checkPriceExit(trade, candles)
                when {
                    hit != null && hit.reason == TradeCloseReason.TARGET_HIT -> {
                        closure = hit
                        message = String.format(Locale.US, "Target reached (+\$%.2f). Close the %s trade and take profit.", hit.pnlUsd, sideWord)
                        notify = trade.enteredByUser
                    }
                    hit != null -> {
                        closure = hit
                        message = String.format(Locale.US, "Stop hit (-\$%.2f). The %s trade is over.", -hit.pnlUsd, sideWord)
                        notify = trade.enteredByUser
                    }
                    eval.snapshot.currentAction == SignalAction.EXIT -> {
                        closure = TradeTracker.closeAt(trade, TradeCloseReason.ML_EXIT, price)
                        message = String.format(
                            Locale.US,
                            "The %s move looks used up. Consider closing now (%s\$%.2f).",
                            sideWord,
                            if (closure.pnlUsd >= 0.0) "+" else "-",
                            kotlin.math.abs(closure.pnlUsd)
                        )
                    }
                    nowMs >= trade.expiresAtMs -> {
                        closure = TradeTracker.closeAt(trade, TradeCloseReason.EXPIRED, price)
                        message = "The trade window ended without reaching target or stop."
                        notify = trade.enteredByUser
                    }
                }
            }

            if (closure != null && message != null) {
                val counted = when (closure.reason) {
                    TradeCloseReason.TARGET_HIT, TradeCloseReason.STOP_HIT, TradeCloseReason.EXPIRED ->
                        if (trade.enteredByUser) " Counted in your results." else " Not counted: Positioned was never switched on."
                    else -> ""
                }
                events.add(
                    SignalCandidate(
                        symbol = sym,
                        eventType = if (trade.direction == EntryDirection.LONG) EventType.EXIT_LONG else EventType.EXIT_SHORT,
                        action = SignalAction.EXIT,
                        price = closure.exitPrice,
                        pLong = eval.snapshot.pLong,
                        pShort = eval.snapshot.pShort,
                        zScore = eval.snapshot.zScore,
                        topIndicator = topIndLabel,
                        timestampMs = nowMs,
                        eventTimeMs = lastBarOpen,
                        note = message + counted,
                        silent = !notify
                    )
                )
                if (closure.reason != TradeCloseReason.CANCELLED) {
                    nextClosed = TradeTracker.appendClosed(nextClosed, TradeTracker.toClosed(trade, closure, nowMs))
                }
                nextTrade = null
                nextExitAt = nowMs
            }
        }

        // "Proven first": only alert on assets whose last 3 weeks of practice trades ended in profit.
        val allowAlerts = !settings.onlyProvenAssets || ProvenGate.check(eval.snapshot.trades21d, nowMs).proven

        if (!firstRun) {
            when (eval.snapshot.currentAction) {
                SignalAction.LONG -> {
                    val cooldownOk = prev.lastSignalAtMs.let { last -> last == null || (nowMs - last) >= tf.ms * 4L }
                    if (allowAlerts && (prev.lastAction != SignalAction.LONG || (isNewBar && cooldownOk))) {
                        nextDir = EntryDirection.LONG
                        nextSignalAt = nowMs
                        watchlistRepo.updateLastEntryDirection(sym, EntryDirection.LONG)
                        nextTrade = TradeTracker.open(EntryDirection.LONG, eval.snapshot.lastPrice, settings, nowMs, tf.lookaheadBars * tf.ms)
                        val lvLONG = TradeRiskCalculator.compute(eval.snapshot.lastPrice, EntryDirection.LONG, settings)
                        events.add(
                            SignalCandidate(
                                symbol = sym,
                                eventType = EventType.LONG_SIGNAL,
                                action = SignalAction.LONG,
                                price = eval.snapshot.lastPrice,
                                pLong = eval.snapshot.pLong,
                                pShort = eval.snapshot.pShort,
                                zScore = eval.snapshot.zScore,
                                topIndicator = topIndLabel,
                                timestampMs = nowMs,
                                eventTimeMs = lastBarOpen,
                                note = lvLONG?.let { "Stop ${PriceFormat.format(it.slPrice)} · Target ${PriceFormat.format(it.tpPrice)}" },
                                slPrice = lvLONG?.slPrice,
                                tpPrice = lvLONG?.tpPrice
                            )
                        )
                    }
                }
                SignalAction.SHORT -> {
                    val cooldownOk = prev.lastSignalAtMs.let { last -> last == null || (nowMs - last) >= tf.ms * 4L }
                    if (allowAlerts && (prev.lastAction != SignalAction.SHORT || (isNewBar && cooldownOk))) {
                        nextDir = EntryDirection.SHORT
                        nextSignalAt = nowMs
                        watchlistRepo.updateLastEntryDirection(sym, EntryDirection.SHORT)
                        nextTrade = TradeTracker.open(EntryDirection.SHORT, eval.snapshot.lastPrice, settings, nowMs, tf.lookaheadBars * tf.ms)
                        val lvSHORT = TradeRiskCalculator.compute(eval.snapshot.lastPrice, EntryDirection.SHORT, settings)
                        events.add(
                            SignalCandidate(
                                symbol = sym,
                                eventType = EventType.SHORT_SIGNAL,
                                action = SignalAction.SHORT,
                                price = eval.snapshot.lastPrice,
                                pLong = eval.snapshot.pLong,
                                pShort = eval.snapshot.pShort,
                                zScore = eval.snapshot.zScore,
                                topIndicator = topIndLabel,
                                timestampMs = nowMs,
                                eventTimeMs = lastBarOpen,
                                note = lvSHORT?.let { "Stop ${PriceFormat.format(it.slPrice)} · Target ${PriceFormat.format(it.tpPrice)}" },
                                slPrice = lvSHORT?.slPrice,
                                tpPrice = lvSHORT?.tpPrice
                            )
                        )
                    }
                }
                SignalAction.EXIT -> {
                    val cooldownOk = prev.lastExitAlertAtMs.let { last -> last == null || (nowMs - last) >= tf.ms * 3L }
                    if (positioned && activeTrade == null && (prev.lastAction != SignalAction.EXIT || cooldownOk)) {
                        nextExitAt = nowMs
                        val evType = if (nextDir == EntryDirection.SHORT) EventType.EXIT_SHORT else EventType.EXIT_LONG
                        events.add(
                            SignalCandidate(
                                symbol = sym,
                                eventType = evType,
                                action = SignalAction.EXIT,
                                price = eval.snapshot.lastPrice,
                                pLong = eval.snapshot.pLong,
                                pShort = eval.snapshot.pShort,
                                zScore = eval.snapshot.zScore,
                                topIndicator = topIndLabel,
                                timestampMs = nowMs,
                                eventTimeMs = lastBarOpen,
                                note = "Exhaustion ${(eval.snapshot.exhaustionScore * 100).toInt()}%"
                            )
                        )
                    }
                }
                SignalAction.WAIT -> Unit
            }

            for (promoted in eval.snapshot.promotedIndicators) {
                if (promoted !in prev.previousActiveIndicators) {
                    events.add(
                        SignalCandidate(
                            symbol = sym,
                            eventType = EventType.INDICATOR_PROMOTED,
                            action = eval.snapshot.currentAction,
                            price = eval.snapshot.lastPrice,
                            pLong = eval.snapshot.pLong,
                            pShort = eval.snapshot.pShort,
                            zScore = eval.snapshot.zScore,
                            topIndicator = promoted.shortLabel,
                            timestampMs = nowMs,
                            eventTimeMs = lastBarOpen,
                            note = "A new clue started helping on this asset: ${promoted.plainName()}. The model will now use it."
                        )
                    )
                }
            }
        }

        val newState = prev.copy(
            mode = if (positioned) AssetMode.POSITIONED else AssetMode.GENERAL,
            lastProcessedOpenMs = lastBarOpen,
            lastTrainedAtMs = eval.snapshot.lastTrainedAtMs,
            lastAction = eval.snapshot.currentAction,
            lastSignalDirection = nextDir,
            lastSignalAtMs = nextSignalAt,
            lastExitAlertAtMs = nextExitAt,
            previousActiveIndicators = eval.snapshot.activeIndicators,
            activeTrade = nextTrade,
            closedTrades = nextClosed
        )

        val row = snapshotToRow(eval.snapshot, entity.copy(lastEntryDirection = nextDir?.name), nextTrade, nowMs)
        return AssetEvaluationOutput(eval, row, events, newState)
    }

    fun updateStateInMemory(state: SymbolSignalState) {
        stateMemory[state.symbol] = state
    }

    fun snapshotToRow(
        snap: com.trendlinealerts.core.model.AssetModelSnapshot,
        entity: WatchlistEntity,
        trade: ActiveTrade? = stateMemory[snap.symbol]?.activeTrade,
        nowMs: Long = System.currentTimeMillis()
    ): SymbolMonitorRow {
        val b21 = snap.drift.benchmarks.d21
        val entityDir = entity.lastEntryDirection?.let { runCatching { EntryDirection.valueOf(it) }.getOrNull() }
        return SymbolMonitorRow(
            symbol = snap.symbol,
            lastPrice = snap.lastPrice,
            action = snap.currentAction,
            pLong = snap.pLong,
            pShort = snap.pShort,
            zScore = snap.zScore,
            channelZ = snap.channelZ,
            provenOk = ProvenGate.check(snap.trades21d, nowMs).proven,
            provenTrades = ProvenGate.check(snap.trades21d, nowMs).tradeCount,
            btcCorrelation = snap.btcCorrelation,
            btcBeta = snap.btcBeta,
            exhaustionScore = snap.exhaustionScore,
            winRate21d = if (b21.tradeCount > 0) b21.winRatePct else null,
            netReturn21d = if (b21.tradeCount > 0) b21.netReturnPct else null,
            topIndicator = snap.activeIndicators.firstOrNull()?.shortLabel,
            masterAgreement = snap.masterAgreement,
            lastSignalDirection = entityDir ?: snap.lastSignalDirection,
            isPriorityOverride = entity.isPriorityOverride,
            lastAlertedAtMs = entity.lastAlertedAtMs,
            tradeSide = trade?.direction,
            tradeWaiting = trade != null && TradeTracker.phase(trade, nowMs) == TradeTracker.Phase.WAITING_ENTRY,
            tradeEntersAtMs = trade?.entryAtMs,
            tradeEntry = trade?.entryPrice,
            tradeSl = trade?.slPrice,
            tradeTp = trade?.tpPrice,
            tradeSlUsd = trade?.slUsd,
            tradeTpUsd = trade?.tpUsd,
            tradeEntered = trade?.enteredByUser == true
        )
    }
}
