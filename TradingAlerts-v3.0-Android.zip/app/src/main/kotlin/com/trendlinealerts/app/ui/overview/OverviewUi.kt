package com.trendlinealerts.app.ui.overview

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.analytics.MlOrchestrator
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.repository.CachedSymbolSeries
import com.trendlinealerts.app.data.repository.ModelStateRepository
import com.trendlinealerts.app.data.repository.MonitorStateRepository
import com.trendlinealerts.app.data.repository.WatchlistRepository
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.SurfaceVariantDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.app.ui.theme.WarningAmber
import com.trendlinealerts.core.model.AssetModelSnapshot
import com.trendlinealerts.core.model.BacktestTrade
import com.trendlinealerts.core.model.ChartCandleStyle
import com.trendlinealerts.core.model.ChartRangeSpec
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.IndicatorEffectiveness
import com.trendlinealerts.core.model.IndicatorPriorityTier
import com.trendlinealerts.core.model.MasterModelSnapshot
import com.trendlinealerts.core.model.OverviewWindow
import com.trendlinealerts.core.model.SignalAction
import com.trendlinealerts.core.model.Timeframe
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AssetOverviewRow(
    val symbol: String,
    val tradeCount: Int,
    val winRatePct: Double,
    val netReturnPct: Double,
    val zScore: Double,
    val action: SignalAction
)

data class OverviewUiState(
    val timeframe: Timeframe = Timeframe.M1,
    val candleStyle: ChartCandleStyle = ChartCandleStyle.HEIKIN_ASHI,
    val showEmaOverlay: Boolean = false,
    val showVwapOverlay: Boolean = false,
    val showBbOverlay: Boolean = false,
    val minProfitMultiplier: Double = 1.0,
    val observeWithMaster: Boolean = true,
    val masterAsset: String = "BTCUSDT",
    val window: OverviewWindow = OverviewWindow.D21,
    val chartRange: ChartRangeSpec = Timeframe.M1.chartRanges.first(),
    val symbols: List<String> = emptyList(),
    val selectedSymbol: String = "SUIUSDT",
    val selectedSnapshot: AssetModelSnapshot? = null,
    val selectedSeries: CachedSymbolSeries? = null,
    val masterModel: MasterModelSnapshot? = null,
    val allAssetRows: List<AssetOverviewRow> = emptyList(),
    val retrainStatus: String? = null,
    val isLoadingAsset: Boolean = false,
    val chartError: String? = null
)

class OverviewViewModel(
    private val settingsDataStore: SettingsDataStore,
    watchlistRepo: WatchlistRepository,
    private val modelStateRepo: ModelStateRepository,
    private val monitorStateRepo: MonitorStateRepository,
    private val mlOrchestrator: MlOrchestrator
) : ViewModel() {

    private val windowFlow = MutableStateFlow(OverviewWindow.D21)
    private val selectedSymbolFlow = MutableStateFlow<String?>(null)
    private val chartRangeKeyFlow = MutableStateFlow<String?>(null)
    private val loadingAssetFlow = MutableStateFlow(false)
    private val chartErrorFlow = MutableStateFlow<String?>(null)

    private data class SelectionBundle(
        val window: OverviewWindow,
        val symbol: String?,
        val rangeKey: String?,
        val loading: Boolean,
        val error: String?
    )

    private val selectionFlow = combine(
        windowFlow,
        selectedSymbolFlow,
        chartRangeKeyFlow,
        loadingAssetFlow,
        chartErrorFlow
    ) { w, s, r, loading, err ->
        SelectionBundle(w, s, r, loading, err)
    }

    private data class RepoBundle(
        val settings: com.trendlinealerts.app.data.local.AppSettingsSnapshot,
        val entities: List<com.trendlinealerts.app.data.local.WatchlistEntity>,
        val snapshots: Map<String, AssetModelSnapshot>,
        val seriesMap: Map<String, CachedSymbolSeries>
    )

    private val repoBundleFlow = combine(
        settingsDataStore.settingsFlow,
        watchlistRepo.entitiesFlow,
        modelStateRepo.assetSnapshots,
        modelStateRepo.seriesBySymbol
    ) { settings, entities, snapshots, seriesMap ->
        RepoBundle(settings, entities, snapshots, seriesMap)
    }

    val uiState: StateFlow<OverviewUiState> = combine(
        repoBundleFlow,
        modelStateRepo.masterModel,
        monitorStateRepo.statusFlow,
        selectionFlow
    ) { repo, master, status, sel ->
        val settings = repo.settings
        val entities = repo.entities
        val snapshots = repo.snapshots
        val seriesMap = repo.seriesMap

        val tf = settings.alertSettings.timeframe
        val symbols = entities.map { it.symbol }
        val activeSymbol = sel.symbol?.takeIf { it in symbols }
            ?: symbols.firstOrNull { it == "SUIUSDT" }
            ?: symbols.firstOrNull()
            ?: "SUIUSDT"

        val selectedRange = tf.chartRanges.firstOrNull { it.key == sel.rangeKey } ?: tf.chartRanges.first()
        val nowMs = System.currentTimeMillis()
        val cutoffMs = nowMs - sel.window.days * 86_400_000L

        val assetRows = entities.mapNotNull { e ->
            val snap = snapshots[e.symbol] ?: return@mapNotNull null
            val sliced = snap.trades21d.filter { it.entryTimeMs >= cutoffMs }
            val wins = sliced.count { it.won }
            val wr = if (sliced.isNotEmpty()) (wins.toDouble() / sliced.size.toDouble()) * 100.0 else 0.0
            val net = sliced.sumOf { it.netReturnPct }
            AssetOverviewRow(
                symbol = e.symbol,
                tradeCount = sliced.size,
                winRatePct = wr,
                netReturnPct = net,
                zScore = snap.zScore,
                action = snap.currentAction
            )
        }.sortedByDescending { it.netReturnPct }

        OverviewUiState(
            timeframe = tf,
            candleStyle = settings.chartCandleStyle,
            showEmaOverlay = settings.showEmaOverlay,
            showVwapOverlay = settings.showVwapOverlay,
            showBbOverlay = settings.showBbOverlay,
            minProfitMultiplier = settings.alertSettings.effectiveMinProfitMultiplier,
            observeWithMaster = settings.alertSettings.observeWithMaster,
            masterAsset = settings.alertSettings.effectiveMasterAsset,
            window = sel.window,
            chartRange = selectedRange,
            symbols = symbols,
            selectedSymbol = activeSymbol,
            selectedSnapshot = snapshots[activeSymbol],
            selectedSeries = seriesMap[activeSymbol],
            masterModel = master,
            allAssetRows = assetRows,
            retrainStatus = status.retrainStatus,
            isLoadingAsset = sel.loading,
            chartError = sel.error
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = OverviewUiState()
    )

    fun selectWindow(window: OverviewWindow) {
        windowFlow.value = window
    }

    fun selectRange(range: ChartRangeSpec) {
        chartRangeKeyFlow.value = range.key
    }

    fun selectSymbol(symbol: String) {
        selectedSymbolFlow.value = symbol
        ensureSymbolLoaded(symbol, forceRefresh = false)
    }

    fun setCandleStyle(style: ChartCandleStyle) {
        viewModelScope.launch { settingsDataStore.setChartCandleStyle(style) }
    }

    fun setShowEma(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setShowEmaOverlay(enabled) }
    }

    fun setShowVwap(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setShowVwapOverlay(enabled) }
    }

    fun setShowBb(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setShowBbOverlay(enabled) }
    }

    fun ensureSymbolLoaded(symbol: String, forceRefresh: Boolean = false) {
        if (symbol.isBlank()) return
        val current = modelStateRepo.assetSnapshots.value[symbol]
        if (!forceRefresh && current != null && current.timeframe == uiState.value.timeframe) return
        viewModelScope.launch {
            loadingAssetFlow.value = true
            chartErrorFlow.value = null
            runCatching {
                mlOrchestrator.evaluateSingleAsset(symbol, forceRefresh = forceRefresh)
            }.onFailure { err ->
                chartErrorFlow.value = err.message ?: err::class.java.simpleName
            }
            loadingAssetFlow.value = false
        }
    }

    fun retrainAllSequentially() {
        viewModelScope.launch {
            chartErrorFlow.value = null
            runCatching {
                mlOrchestrator.runSequentialDailyRetrain(force = true)
            }.onFailure { err ->
                chartErrorFlow.value = err.message ?: "Sequential retrain failed"
            }
        }
    }

    class Factory(
        private val settingsDataStore: SettingsDataStore,
        private val watchlistRepo: WatchlistRepository,
        private val modelStateRepo: ModelStateRepository,
        private val monitorStateRepo: MonitorStateRepository,
        private val mlOrchestrator: MlOrchestrator
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return OverviewViewModel(
                settingsDataStore = settingsDataStore,
                watchlistRepo = watchlistRepo,
                modelStateRepo = modelStateRepo,
                monitorStateRepo = monitorStateRepo,
                mlOrchestrator = mlOrchestrator
            ) as T
        }
    }
}

@Composable
fun OverviewScreen(
    viewModel: OverviewViewModel,
    pendingSymbol: String?,
    onConsumePendingSymbol: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var symbolMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(pendingSymbol) {
        if (!pendingSymbol.isNullOrBlank()) {
            viewModel.selectSymbol(pendingSymbol)
            onConsumePendingSymbol()
        }
    }

    LaunchedEffect(state.selectedSymbol, state.timeframe) {
        viewModel.ensureSymbolLoaded(state.selectedSymbol, forceRefresh = false)
    }

    val snap = state.selectedSnapshot
    val series = state.selectedSeries

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header + Sequential Retrain Action
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Scalp ML Overview",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${state.timeframe.label} · Hist ${state.timeframe.historyDays}d · Mult ${String.format(Locale.US, "%.1f", state.minProfitMultiplier)}x",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
                Button(
                    onClick = { viewModel.retrainAllSequentially() },
                    enabled = state.retrainStatus == null,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    if (state.retrainStatus != null) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Training...", fontSize = 12.sp)
                    } else {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Retrain All", fontSize = 12.sp)
                    }
                }
            }
            if (!state.retrainStatus.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = state.retrainStatus.orEmpty(),
                    color = PrimaryBlue,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Performance Window Chips (21D max & default)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OverviewWindow.entries.forEach { win ->
                    FilterChip(
                        selected = state.window == win,
                        onClick = { viewModel.selectWindow(win) },
                        label = { Text(win.label, fontSize = 11.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = Color.White,
                            containerColor = SurfaceDark,
                            labelColor = TextPrimary
                        )
                    )
                }
            }
        }

        // Asset Picker
        item {
            Box {
                OutlinedButton(
                    onClick = { symbolMenuExpanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "${state.selectedSymbol}  ${snap?.let { fmtNum(it.lastPrice) } ?: ""}",
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = TextPrimary)
                }
                DropdownMenu(
                    expanded = symbolMenuExpanded,
                    onDismissRequest = { symbolMenuExpanded = false }
                ) {
                    state.symbols.forEach { sym ->
                        DropdownMenuItem(
                            text = { Text(sym) },
                            onClick = {
                                symbolMenuExpanded = false
                                viewModel.selectSymbol(sym)
                            }
                        )
                    }
                }
            }
        }

        // Chart (Heikin-Ashi default, all overlays OFF by default, 4H default range on 1m)
        item {
            OverviewChart(
                symbol = state.selectedSymbol,
                candles = series?.candles.orEmpty(),
                computed = series?.computed,
                timeframe = state.timeframe,
                selectedRange = state.chartRange,
                candleStyle = state.candleStyle,
                showEmaOverlay = state.showEmaOverlay,
                showVwapOverlay = state.showVwapOverlay,
                showBbOverlay = state.showBbOverlay,
                markers = snap?.chartMarkers.orEmpty(),
                currentAction = snap?.currentAction ?: SignalAction.WAIT,
                zScore = snap?.zScore ?: 0.0,
                pLong = snap?.pLong ?: 0.5,
                pShort = snap?.pShort ?: 0.5,
                isLoading = state.isLoadingAsset,
                error = state.chartError,
                onSelectRange = { viewModel.selectRange(it) },
                onSelectCandleStyle = { viewModel.setCandleStyle(it) },
                onToggleEma = { viewModel.setShowEma(it) },
                onToggleVwap = { viewModel.setShowVwap(it) },
                onToggleBb = { viewModel.setShowBb(it) },
                onRefresh = { viewModel.ensureSymbolLoaded(state.selectedSymbol, forceRefresh = true) }
            )
        }

        // Selected Asset Performance Summary + Master Model Status
        if (snap != null) {
            item {
                val cutoffMs = System.currentTimeMillis() - state.window.days * 86_400_000L
                val windowTrades = snap.trades21d.filter { it.entryTimeMs >= cutoffMs }
                val wins = windowTrades.count { it.won }
                val winRate = if (windowTrades.isNotEmpty()) (wins.toDouble() / windowTrades.size.toDouble()) * 100.0 else 0.0
                val netRet = windowTrades.sumOf { it.netReturnPct }
                val grossW = windowTrades.filter { it.netReturnPct > 0 }.sumOf { it.netReturnPct }
                val grossL = abs(windowTrades.filter { it.netReturnPct < 0 }.sumOf { it.netReturnPct })
                val pf = if (grossL > 0.0) grossW / grossL else if (grossW > 0.0) 3.0 else 1.0

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${snap.symbol} (${state.window.key})", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            val masterShort = snap.masterAsset.removeSuffix("USDT")
                            val masterLabel = if (state.observeWithMaster) {
                                String.format(
                                    Locale.US,
                                    "%s %s · r %.2f · b %.2f",
                                    masterShort,
                                    if (snap.masterAgreement) "AGREE" else "SPLIT",
                                    snap.btcCorrelation,
                                    snap.btcBeta
                                )
                            } else {
                                "$masterShort: OFF"
                            }
                            Text(
                                text = masterLabel,
                                color = if (snap.masterAgreement) GoogleGreen else WarningAmber,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            MetricCol("Trades", "${windowTrades.size}", TextPrimary)
                            MetricCol("Win Rate", String.format(Locale.US, "%.1f%%", winRate), TextPrimary)
                            MetricCol(
                                "Net Return",
                                String.format(Locale.US, "%+.2f%%", netRet),
                                if (netRet >= 0.0) GoogleGreen else GoogleRed
                            )
                            MetricCol("PF", String.format(Locale.US, "%.2f", min(pf, 9.99)), TextPrimary)
                        }
                        if (snap.promotedIndicators.isNotEmpty()) {
                            Text(
                                text = "Newly Effective: ${snap.promotedIndicators.joinToString(", ") { it.shortLabel }}",
                                color = PrimaryBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Rolling Drift & Retrain Comparison (3d, 7d, 14d, 21d + 1d vs 3d, 3d vs 7d, 7d * 3)
            item {
                RollingDriftCard(snap = snap)
            }

            // 13 Indicators Effectiveness & Priority Matrix
            item {
                IndicatorEffectivenessCard(stats = snap.indicatorStats)
            }
        }

        // All Assets Breakdown
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Watchlist ${state.window.key} Performance (tap to inspect)",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (state.allAssetRows.isEmpty()) {
                        Text(
                            text = "Tap 'Retrain All' to run sequential ML evaluation across all assets.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    } else {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text("Asset", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.2f))
                            Text("Z", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.65f))
                            Text("Trades", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.65f))
                            Text("Win%", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                            Text("Net%", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.85f))
                        }
                        HorizontalDivider(color = OutlineDark)
                        state.allAssetRows.forEach { r ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectSymbol(r.symbol) }
                                    .padding(vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(r.symbol, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.2f))
                                Text(String.format(Locale.US, "%+.1f", r.zScore), color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.65f))
                                Text("${r.tradeCount}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.65f))
                                Text(String.format(Locale.US, "%.1f%%", r.winRatePct), color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                                Text(
                                    text = String.format(Locale.US, "%+.2f%%", r.netReturnPct),
                                    color = if (r.netReturnPct >= 0.0) GoogleGreen else GoogleRed,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.weight(0.85f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Recent Trades in Selected Asset
        if (snap != null && snap.trades21d.isNotEmpty()) {
            item {
                Text(
                    text = "Recent Walk-Forward Trades (${snap.symbol})",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            items(snap.trades21d.takeLast(15).reversed()) { trade ->
                TradeRowCard(trade = trade)
            }
        }
    }
}

@Composable
private fun MetricCol(label: String, value: String, color: Color) {
    Column {
        Text(label, color = TextSecondary, fontSize = 11.sp)
        Text(value, color = color, fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun RollingDriftCard(snap: AssetModelSnapshot) {
    val d = snap.drift
    val benchmarks = listOf(d.benchmarks.d3, d.benchmarks.d7, d.benchmarks.d14, d.benchmarks.d21)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "Rolling Drift & Retrain Study (21d)",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                MetricCol(
                    "1d vs 3d Drift",
                    String.format(Locale.US, "%.2f (%+.1f%%)", d.day1VsDay3Drift, d.day1VsDay3AccuracyDelta),
                    if (d.day1VsDay3AccuracyDelta >= 0.0) GoogleGreen else WarningAmber
                )
                MetricCol(
                    "3d vs 7d Drift",
                    String.format(Locale.US, "%.2f (%+.1f%%)", d.day3VsDay7Drift, d.day3VsDay7AccuracyDelta),
                    if (d.day3VsDay7AccuracyDelta >= 0.0) GoogleGreen else WarningAmber
                )
            }
            Text(
                text = String.format(
                    Locale.US,
                    "7d × 3 Rolling: W1 %+.2f%% (%.0f%%) · W2 %+.2f%% (%.0f%%) · W3 %+.2f%% (%.0f%%)",
                    d.week1NetPct, d.week1WinRate,
                    d.week2NetPct, d.week2WinRate,
                    d.week3NetPct, d.week3WinRate
                ),
                color = TextSecondary,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
            HorizontalDivider(color = OutlineDark)
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Window", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
                Text("Trades", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                Text("Win%", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                Text("Acc%", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                Text("Net%", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.85f))
            }
            benchmarks.forEach { b ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(b.label, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    Text("${b.tradeCount}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                    Text(String.format(Locale.US, "%.1f%%", b.winRatePct), color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                    Text(String.format(Locale.US, "%.1f%%", b.accuracyPct), color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                    Text(
                        text = String.format(Locale.US, "%+.2f%%", b.netReturnPct),
                        color = if (b.netReturnPct >= 0.0) GoogleGreen else GoogleRed,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(0.85f)
                    )
                }
            }
        }
    }
}

@Composable
private fun IndicatorEffectivenessCard(stats: List<IndicatorEffectiveness>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "18 Scalping & BTC Coupling Indicators",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Indicator", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.6f))
                Text("Tier", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(0.7f))
                Text("1d/7d/21d", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1.1f))
                Text("LR W", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
            }
            HorizontalDivider(color = OutlineDark)
            stats.forEach { s ->
                val tierColor = when (s.tier) {
                    IndicatorPriorityTier.LEAD -> GoogleGreen
                    IndicatorPriorityTier.CORE -> PrimaryBlue
                    IndicatorPriorityTier.SUPPORT -> WarningAmber
                    IndicatorPriorityTier.SECONDARY -> TextSecondary
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(modifier = Modifier.weight(1.6f), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = s.id.shortLabel,
                            color = if (s.isActive) TextPrimary else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (s.isActive) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (s.isNewlyEffective) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "NEW",
                                color = PrimaryBlue,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = s.tier.name.take(4),
                        color = tierColor,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(0.7f)
                    )
                    Text(
                        text = String.format(Locale.US, "%.2f/%.2f/%.2f", s.score1d, s.score7d, s.score21d),
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.5.sp,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(1.1f)
                    )
                    val wMag = max(abs(s.longWeight), abs(s.shortWeight))
                    Text(
                        text = String.format(Locale.US, "%.2f", wMag),
                        color = if (s.isActive) TextPrimary else TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(0.7f)
                    )
                }
            }
        }
    }
}

@Composable
private fun TradeRowCard(trade: BacktestTrade) {
    val dirColor = if (trade.direction == EntryDirection.LONG) GoogleGreen else GoogleRed
    val retColor = if (trade.won) GoogleGreen else GoogleRed
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "${trade.direction.name} · ${(trade.probability * 100.0).toInt()}%",
                    color = dirColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${fmtTimestamp(trade.entryTimeMs)} · ${fmtNum(trade.entryPrice)} -> ${fmtNum(trade.exitPrice)}",
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
            Text(
                text = String.format(Locale.US, "%+.2f%%", trade.netReturnPct),
                color = retColor,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun fmtNum(price: Double): String = when {
    price >= 1_000.0 -> String.format(Locale.US, "%.2f", price)
    price >= 1.0 -> String.format(Locale.US, "%.4f", price)
    price >= 0.01 -> String.format(Locale.US, "%.5f", price)
    else -> String.format(Locale.US, "%.6f", price)
}

private fun fmtTimestamp(ms: Long): String =
    SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date(ms))
