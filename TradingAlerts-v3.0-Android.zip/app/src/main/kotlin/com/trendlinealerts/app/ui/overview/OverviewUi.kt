package com.trendlinealerts.app.ui.overview

import kotlinx.coroutines.flow.Flow
import com.trendlinealerts.core.model.trendWord
import com.trendlinealerts.core.model.helpfulness
import com.trendlinealerts.core.model.plainName
import com.trendlinealerts.core.ml.LongTermPeriod
import com.trendlinealerts.core.ml.LongTermHistory
import com.trendlinealerts.app.data.repository.SymbolMonitorRow
import com.trendlinealerts.core.analytics.TradeLevels
import com.trendlinealerts.core.model.AlertSettings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.analytics.MlOrchestrator
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.repository.CachedSymbolSeries
import com.trendlinealerts.app.data.repository.ModelStateRepository
import com.trendlinealerts.app.data.repository.MonitorStateRepository
import com.trendlinealerts.app.data.repository.WatchlistRepository
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.SurfaceVariantDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.app.ui.theme.WarningAmber
import com.trendlinealerts.core.model.AssetModelSnapshot
import com.trendlinealerts.core.model.BacktestTrade
import com.trendlinealerts.core.model.ChartCandleStyle
import com.trendlinealerts.core.model.ChartRangeSpec
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.IndicatorEffectiveness
import com.trendlinealerts.core.model.IndicatorPriorityTier
import com.trendlinealerts.core.model.MasterModelSnapshot
import com.trendlinealerts.core.model.OverviewWindow
import com.trendlinealerts.core.model.SignalAction
import com.trendlinealerts.core.model.Timeframe
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AssetOverviewRow(
    val symbol: String,
    val tradeCount: Int,
    val winRatePct: Double,
    val netReturnPct: Double,
    val zScore: Double,
    val action: SignalAction
)

/** Selected-asset key meaning "show every asset together". */
private const val ALL_ASSETS_KEY = "ALL"

data class AllAssetsSummary(
    val trades: Int = 0,
    val winRatePct: Double = 0.0,
    val netReturnPct: Double = 0.0,
    val profitFactor: Double = 1.0,
    val assetCount: Int = 0,
    val profitableAssets: Int = 0
)

data class OverviewUiState(
    val timeframe: Timeframe = Timeframe.M1,
    val candleStyle: ChartCandleStyle = ChartCandleStyle.HEIKIN_ASHI,
    val showEmaOverlay: Boolean = false,
    val showVwapOverlay: Boolean = false,
    val showBbOverlay: Boolean = false,
    val showChannelOverlay: Boolean = true,
    val minProfitMultiplier: Double = 1.0,
    val observeWithMaster: Boolean = true,
    val masterAsset: String = "BTCUSDT",
    val window: OverviewWindow = OverviewWindow.D21,
    val chartRange: ChartRangeSpec = Timeframe.M1.chartRanges.first(),
    val symbols: List<String> = emptyList(),
    val selectedSymbol: String = "SUIUSDT",
    val selectedSnapshot: AssetModelSnapshot? = null,
    val selectedSeries: CachedSymbolSeries? = null,
    val masterModel: MasterModelSnapshot? = null,
    val allAssetRows: List<AssetOverviewRow> = emptyList(),
    val retrainStatus: String? = null,
    val alertSettings: AlertSettings = AlertSettings(),
    /** The selected asset's live row, used to draw the running trade on the chart. */
    val selectedRow: SymbolMonitorRow? = null,
    /** 1, 3, 6 and 12 month results, kept on the phone long after the raw candles are gone. */
    val longTerm: List<LongTermPeriod> = emptyList(),
    val retrainResumeLeft: Int = 0,
    val allSummary: AllAssetsSummary = AllAssetsSummary(),
    val isLoadingAsset: Boolean = false,
    val chartError: String? = null
) {
    val isAllView: Boolean get() = selectedSymbol == ALL_ASSETS_KEY
}

class OverviewViewModel(
    private val settingsDataStore: SettingsDataStore,
    watchlistRepo: WatchlistRepository,
    private val modelStateRepo: ModelStateRepository,
    private val monitorStateRepo: MonitorStateRepository,
    private val mlOrchestrator: MlOrchestrator
) : ViewModel() {

    private val windowFlow = MutableStateFlow(OverviewWindow.D21)
    private val selectedSymbolFlow = MutableStateFlow<String?>(null)
    private val chartRangeKeyFlow = MutableStateFlow<String?>(null)
    private val loadingAssetFlow = MutableStateFlow(false)
    private val chartErrorFlow = MutableStateFlow<String?>(null)

    private data class SelectionBundle(
        val window: OverviewWindow,
        val symbol: String?,
        val rangeKey: String?,
        val loading: Boolean,
        val error: String?
    )

    private val selectionFlow = combine(
        windowFlow,
        selectedSymbolFlow,
        chartRangeKeyFlow,
        loadingAssetFlow,
        chartErrorFlow
    ) { w, s, r, loading, err ->
        SelectionBundle(w, s, r, loading, err)
    }

    private data class RepoBundle(
        val settings: com.trendlinealerts.app.data.local.AppSettingsSnapshot,
        val entities: List<com.trendlinealerts.app.data.local.WatchlistEntity>,
        val snapshots: Map<String, AssetModelSnapshot>,
        val seriesMap: Map<String, CachedSymbolSeries>
    )

    private val repoBundleFlow = combine(
        settingsDataStore.settingsFlow,
        watchlistRepo.entitiesFlow,
        modelStateRepo.assetSnapshots,
        modelStateRepo.seriesBySymbol
    ) { settings, entities, snapshots, seriesMap ->
        RepoBundle(settings, entities, snapshots, seriesMap)
    }

    private val baseState: Flow<OverviewUiState> = combine(
        repoBundleFlow,
        modelStateRepo.masterModel,
        monitorStateRepo.statusFlow,
        selectionFlow,
        monitorStateRepo.symbolRows
    ) { repo, master, status, sel, liveRows ->
        val settings = repo.settings
        val entities = repo.entities
        val snapshots = repo.snapshots
        val seriesMap = repo.seriesMap

        val tf = settings.alertSettings.timeframe
        val symbols = entities.map { it.symbol }
        // Default to the all-assets overview; a single asset is shown only when picked.
        val activeSymbol = sel.symbol?.takeIf { it == ALL_ASSETS_KEY || it in symbols } ?: ALL_ASSETS_KEY

        val selectedRange = tf.chartRanges.firstOrNull { it.key == sel.rangeKey } ?: tf.chartRanges.first()
        val nowMs = System.currentTimeMillis()
        val cutoffMs = nowMs - sel.window.days * 86_400_000L

        val assetRows = entities.mapNotNull { e ->
            val snap = snapshots[e.symbol] ?: return@mapNotNull null
            val sliced = snap.trades21d.filter { it.entryTimeMs >= cutoffMs }
            val wins = sliced.count { it.won }
            val wr = if (sliced.isNotEmpty()) (wins.toDouble() / sliced.size.toDouble()) * 100.0 else 0.0
            val net = sliced.sumOf { it.netReturnPct }
            AssetOverviewRow(
                symbol = e.symbol,
                tradeCount = sliced.size,
                winRatePct = wr,
                netReturnPct = net,
                zScore = snap.zScore,
                action = snap.currentAction
            )
        }.sortedByDescending { it.netReturnPct }

        val windowTrades = entities.flatMap { e ->
            snapshots[e.symbol]?.trades21d.orEmpty().filter { it.entryTimeMs >= cutoffMs }
        }
        val grossWon = windowTrades.filter { it.netReturnPct > 0 }.sumOf { it.netReturnPct }
        val grossLost = abs(windowTrades.filter { it.netReturnPct < 0 }.sumOf { it.netReturnPct })
        val summary = AllAssetsSummary(
            trades = windowTrades.size,
            winRatePct = if (windowTrades.isNotEmpty()) windowTrades.count { it.won } * 100.0 / windowTrades.size else 0.0,
            netReturnPct = windowTrades.sumOf { it.netReturnPct },
            profitFactor = when {
                grossLost > 0.0 -> min(grossWon / grossLost, 9.99)
                grossWon > 0.0 -> 9.99
                else -> 1.0
            },
            assetCount = assetRows.size,
            profitableAssets = assetRows.count { it.netReturnPct > 0.0 }
        )

        OverviewUiState(
            timeframe = tf,
            candleStyle = settings.chartCandleStyle,
            showEmaOverlay = settings.showEmaOverlay,
            showVwapOverlay = settings.showVwapOverlay,
            showBbOverlay = settings.showBbOverlay,
            showChannelOverlay = settings.showChannelOverlay,
            minProfitMultiplier = settings.alertSettings.effectiveMinProfitMultiplier,
            alertSettings = settings.alertSettings,
            observeWithMaster = settings.alertSettings.observeWithMaster,
            masterAsset = settings.alertSettings.effectiveMasterAsset,
            window = sel.window,
            chartRange = selectedRange,
            symbols = symbols,
            selectedSymbol = activeSymbol,
            selectedSnapshot = snapshots[activeSymbol],
            selectedSeries = seriesMap[activeSymbol],
            masterModel = master,
            allAssetRows = assetRows,
            retrainStatus = status.retrainStatus,
            selectedRow = liveRows.firstOrNull { it.symbol == activeSymbol },
            retrainResumeLeft = status.retrainResumeLeft,
            allSummary = summary,
            isLoadingAsset = sel.loading,
            chartError = sel.error
        )
    }

    val uiState: StateFlow<OverviewUiState> = combine(baseState, mlOrchestrator.dailyRecords) { s, records ->
        s.copy(
            longTerm = LongTermHistory.periods(
                records = records,
                symbol = if (s.isAllView) null else s.selectedSymbol,
                timeframe = s.timeframe,
                nowMs = System.currentTimeMillis()
            )
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = OverviewUiState()
    )

    fun selectWindow(window: OverviewWindow) {
        windowFlow.value = window
    }

    fun selectRange(range: ChartRangeSpec) {
        chartRangeKeyFlow.value = range.key
    }

    fun selectSymbol(symbol: String) {
        selectedSymbolFlow.value = symbol
        ensureSymbolLoaded(symbol, forceRefresh = false)
    }

    fun setCandleStyle(style: ChartCandleStyle) {
        viewModelScope.launch { settingsDataStore.setChartCandleStyle(style) }
    }

    fun setShowEma(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setShowEmaOverlay(enabled) }
    }

    fun setShowVwap(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setShowVwapOverlay(enabled) }
    }

    fun setShowChannel(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setShowChannelOverlay(enabled) }
    }

    fun setShowBb(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setShowBbOverlay(enabled) }
    }

    fun ensureSymbolLoaded(symbol: String, forceRefresh: Boolean = false) {
        if (symbol.isBlank() || symbol == ALL_ASSETS_KEY) return
        val current = modelStateRepo.assetSnapshots.value[symbol]
        if (!forceRefresh && current != null && current.timeframe == uiState.value.timeframe) return
        viewModelScope.launch {
            loadingAssetFlow.value = true
            chartErrorFlow.value = null
            runCatching {
                mlOrchestrator.evaluateSingleAsset(symbol, forceRefresh = forceRefresh)
            }.onFailure { err ->
                chartErrorFlow.value = err.message ?: err::class.java.simpleName
            }
            loadingAssetFlow.value = false
        }
    }

    /** Runs in the app (not tied to this screen), so leaving the Overview no longer cancels it. */
    fun retrainAllSequentially() {
        chartErrorFlow.value = null
        mlOrchestrator.startSequentialRetrain(resume = false)
    }

    fun resumeRetrain() {
        chartErrorFlow.value = null
        mlOrchestrator.startSequentialRetrain(resume = true)
    }

    fun stopRetrain() {
        mlOrchestrator.stopSequentialRetrain()
    }

    class Factory(
        private val settingsDataStore: SettingsDataStore,
        private val watchlistRepo: WatchlistRepository,
        private val modelStateRepo: ModelStateRepository,
        private val monitorStateRepo: MonitorStateRepository,
        private val mlOrchestrator: MlOrchestrator
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return OverviewViewModel(
                settingsDataStore = settingsDataStore,
                watchlistRepo = watchlistRepo,
                modelStateRepo = modelStateRepo,
                monitorStateRepo = monitorStateRepo,
                mlOrchestrator = mlOrchestrator
            ) as T
        }
    }
}

@Composable
fun OverviewScreen(
    viewModel: OverviewViewModel,
    pendingSymbol: String?,
    onConsumePendingSymbol: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(pendingSymbol) {
        if (!pendingSymbol.isNullOrBlank()) {
            viewModel.selectSymbol(pendingSymbol)
            onConsumePendingSymbol()
        }
    }

    LaunchedEffect(state.selectedSymbol, state.timeframe) {
        viewModel.ensureSymbolLoaded(state.selectedSymbol, forceRefresh = false)
    }

    val snap = state.selectedSnapshot
    val series = state.selectedSeries

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header + Sequential Retrain Action
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ML Overview",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${state.timeframe.label} candles · last ${state.timeframe.historyDays} days of data",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (state.retrainStatus != null) {
                        // Always possible to stop, so a stuck run can never lock the button.
                        Button(
                            onClick = { viewModel.stopRetrain() },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = WarningAmber),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Stop", fontSize = 12.sp)
                        }
                    } else {
                        if (state.retrainResumeLeft > 0) {
                            Button(
                                onClick = { viewModel.resumeRetrain() },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Resume (${state.retrainResumeLeft} left)", fontSize = 12.sp)
                            }
                        }
                        Button(
                            onClick = { viewModel.retrainAllSequentially() },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (state.retrainResumeLeft > 0) SurfaceVariantDark else PrimaryBlue
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (state.retrainResumeLeft > 0) "Start over" else "Retrain all", fontSize = 12.sp)
                        }
                    }
                }
            }
            if (!state.retrainStatus.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = state.retrainStatus.orEmpty(),
                    color = PrimaryBlue,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Performance Window Chips (21D max & default)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OverviewWindow.entries.forEach { win ->
                    FilterChip(
                        selected = state.window == win,
                        onClick = { viewModel.selectWindow(win) },
                        label = { Text(win.label, fontSize = 11.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = Color.White,
                            containerColor = SurfaceDark,
                            labelColor = TextPrimary
                        )
                    )
                }
            }
        }

        // Asset chips: "All" plus every asset, scrollable sideways like the time-window chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = state.isAllView,
                    onClick = { viewModel.selectSymbol(ALL_ASSETS_KEY) },
                    label = { Text("All", fontSize = 11.5.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryBlue,
                        selectedLabelColor = Color.White,
                        containerColor = SurfaceDark,
                        labelColor = TextPrimary
                    )
                )
                state.symbols.forEach { sym ->
                    FilterChip(
                        selected = !state.isAllView && state.selectedSymbol == sym,
                        onClick = { viewModel.selectSymbol(sym) },
                        label = { Text(sym.removeSuffix("USDT"), fontSize = 11.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = Color.White,
                            containerColor = SurfaceDark,
                            labelColor = TextPrimary
                        )
                    )
                }
            }
        }

        // Chart (single asset only; candle style is chosen in Settings)
        if (!state.isAllView) item {
            OverviewChart(
                symbol = state.selectedSymbol,
                candles = series?.candles.orEmpty(),
                computed = series?.computed,
                timeframe = state.timeframe,
                selectedRange = state.chartRange,
                candleStyle = state.candleStyle,
                showEmaOverlay = state.showEmaOverlay,
                showVwapOverlay = state.showVwapOverlay,
                showBbOverlay = state.showBbOverlay,
                showChannelOverlay = state.showChannelOverlay,
                markers = snap?.chartMarkers.orEmpty(),
                currentAction = snap?.currentAction ?: SignalAction.WAIT,
                zScore = snap?.zScore ?: 0.0,
                pLong = snap?.pLong ?: 0.5,
                pShort = snap?.pShort ?: 0.5,
                alertSettings = state.alertSettings,
                activeTrade = state.selectedRow?.let { r ->
                    val e = r.tradeEntry
                    val sl = r.tradeSl
                    val tp = r.tradeTp
                    if (r.tradeSide != null && e != null && sl != null && tp != null && e > 0.0) {
                        TradeLevels(
                            entryPrice = e,
                            tpPrice = tp,
                            slPrice = sl,
                            tpPct = abs(tp - e) / e * 100.0,
                            slPct = abs(sl - e) / e * 100.0,
                            tpUsd = r.tradeTpUsd ?: 0.0,
                            slUsd = r.tradeSlUsd ?: 0.0
                        )
                    } else null
                },
                isLoading = state.isLoadingAsset,
                error = state.chartError,
                onSelectRange = { viewModel.selectRange(it) },
                onSelectCandleStyle = { viewModel.setCandleStyle(it) },
                onToggleEma = { viewModel.setShowEma(it) },
                onToggleVwap = { viewModel.setShowVwap(it) },
                onToggleBb = { viewModel.setShowBb(it) },
                onToggleChannel = { viewModel.setShowChannel(it) },
                onRefresh = { viewModel.ensureSymbolLoaded(state.selectedSymbol, forceRefresh = true) }
            )
        }

        // Selected Asset Performance Summary + Master Model Status
        if (!state.isAllView && snap != null) {
            item {
                val cutoffMs = System.currentTimeMillis() - state.window.days * 86_400_000L
                val windowTrades = snap.trades21d.filter { it.entryTimeMs >= cutoffMs }
                val wins = windowTrades.count { it.won }
                val winRate = if (windowTrades.isNotEmpty()) (wins.toDouble() / windowTrades.size.toDouble()) * 100.0 else 0.0
                val netRet = windowTrades.sumOf { it.netReturnPct }
                val grossW = windowTrades.filter { it.netReturnPct > 0 }.sumOf { it.netReturnPct }
                val grossL = abs(windowTrades.filter { it.netReturnPct < 0 }.sumOf { it.netReturnPct })
                val pf = if (grossL > 0.0) grossW / grossL else if (grossW > 0.0) 3.0 else 1.0

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${snap.symbol} (${state.window.key})", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            val masterShort = snap.masterAsset.removeSuffix("USDT")
                            val masterLabel = if (state.observeWithMaster) {
                                if (snap.masterAgreement) "$masterShort agrees" else "$masterShort disagrees"
                            } else {
                                "$masterShort check off"
                            }
                            Text(
                                text = masterLabel,
                                color = if (snap.masterAgreement) GoogleGreen else WarningAmber,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            MetricCol("Trades", "${windowTrades.size}", TextPrimary)
                            MetricCol("Win rate", String.format(Locale.US, "%.1f%%", winRate), TextPrimary)
                            MetricCol(
                                "Profit",
                                String.format(Locale.US, "%+.2f%%", netRet),
                                if (netRet >= 0.0) GoogleGreen else GoogleRed
                            )
                            MetricCol("Profit factor", String.format(Locale.US, "%.2f", min(pf, 9.99)), TextPrimary)
                        }
                        Text(
                            text = "Profit = total gain or loss of all trades in price-move % after fees. " +
                                "Profit factor = money won ÷ money lost; above 1.0 means winners beat losers.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                        if (snap.promotedIndicators.isNotEmpty()) {
                            Text(
                                text = "New helpful clue: ${snap.promotedIndicators.joinToString(", ") { it.plainName() }}",
                                color = PrimaryBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Rolling Drift & Retrain Comparison (3d, 7d, 14d, 21d + 1d vs 3d, 3d vs 7d, 7d * 3)
            item {
                RollingDriftCard(snap = snap)
            }

            // 13 Indicators Effectiveness & Priority Matrix
            item {
                IndicatorEffectivenessCard(stats = snap.indicatorStats)
            }
        }

        // Overall summary across every asset
        if (state.isAllView) item {
            AllAssetsSummaryCard(summary = state.allSummary, windowKey = state.window.key)
        }

        // Results saved day by day (1, 3, 6, 12 months)
        item {
            LongTermCard(
                periods = state.longTerm,
                scope = if (state.isAllView) "all assets" else state.selectedSymbol.removeSuffix("USDT")
            )
        }

        // All Assets Breakdown
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Each asset · ${state.window.key} (tap one to open it)",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (state.allAssetRows.isEmpty()) {
                        Text(
                            text = "Tap Retrain all to study every asset. Results appear here when it finishes.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    } else {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text("Asset", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.2f))
                            Text("Now", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.65f))
                            Text("Trades", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.65f))
                            Text("Win%", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                            Text("Net%", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.85f))
                        }
                        HorizontalDivider(color = OutlineDark)
                        state.allAssetRows.forEach { r ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectSymbol(r.symbol) }
                                    .padding(vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(r.symbol.removeSuffix("USDT"), color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.2f))
                                Text(
                                    text = when (r.action) {
                                        SignalAction.LONG -> "Long"
                                        SignalAction.SHORT -> "Short"
                                        SignalAction.EXIT -> "Exit"
                                        SignalAction.WAIT -> "Wait"
                                    },
                                    color = when (r.action) {
                                        SignalAction.LONG -> GoogleGreen
                                        SignalAction.SHORT -> GoogleRed
                                        SignalAction.EXIT -> WarningAmber
                                        SignalAction.WAIT -> TextSecondary
                                    },
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.weight(0.65f)
                                )
                                Text("${r.tradeCount}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.65f))
                                Text(String.format(Locale.US, "%.1f%%", r.winRatePct), color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                                Text(
                                    text = String.format(Locale.US, "%+.2f%%", r.netReturnPct),
                                    color = if (r.netReturnPct >= 0.0) GoogleGreen else GoogleRed,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.weight(0.85f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Recent Trades in Selected Asset
        if (!state.isAllView && snap != null && snap.trades21d.isNotEmpty()) {
            item {
                Text(
                    text = "Recent trades (${snap.symbol.removeSuffix("USDT")})",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            items(snap.trades21d.takeLast(15).reversed()) { trade ->
                TradeRowCard(trade = trade)
            }
        }
    }
}

@Composable
private fun AllAssetsSummaryCard(summary: AllAssetsSummary, windowKey: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("All assets · $windowKey", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            if (summary.trades == 0) {
                Text(
                    text = "No results yet. Tap Retrain all so the app can study each asset.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            } else {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricCol("Trades", "${summary.trades}", TextPrimary)
                    MetricCol("Win rate", String.format(Locale.US, "%.1f%%", summary.winRatePct), TextPrimary)
                    MetricCol(
                        "Profit",
                        String.format(Locale.US, "%+.2f%%", summary.netReturnPct),
                        if (summary.netReturnPct >= 0.0) GoogleGreen else GoogleRed
                    )
                    MetricCol("Profit factor", String.format(Locale.US, "%.2f", summary.profitFactor), TextPrimary)
                }
                Text(
                    text = "${summary.profitableAssets} of ${summary.assetCount} assets are in profit. " +
                        "Profit factor = money won ÷ money lost; above 1.0 means winners beat losers.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun MetricCol(label: String, value: String, color: Color) {
    Column {
        Text(label, color = TextSecondary, fontSize = 11.sp)
        Text(value, color = color, fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

private fun prettyWindow(label: String): String = when (label.lowercase(Locale.US)) {
    "21d" -> "3wks"
    "14d" -> "2wks"
    "7d" -> "1wk"
    else -> label.lowercase(Locale.US)
}

@Composable
private fun RollingDriftCard(snap: AssetModelSnapshot) {
    val d = snap.drift
    val benchmarks = listOf(d.benchmarks.d3, d.benchmarks.d7, d.benchmarks.d14, d.benchmarks.d21)

    fun trendLine(label: String, delta: Double): Pair<String, Color> = when {
        delta >= 1.0 -> "$label: better (${String.format(Locale.US, "%+.1f", delta)} points)" to GoogleGreen
        delta <= -1.0 -> "$label: worse (${String.format(Locale.US, "%+.1f", delta)} points)" to WarningAmber
        else -> "$label: about the same" to TextSecondary
    }
    val dayTrend = trendLine("Last day vs the 3 days before", d.day1VsDay3AccuracyDelta)
    val threeDayTrend = trendLine("Last 3 days vs the 4 days before", d.day3VsDay7AccuracyDelta)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "Is it still working?",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "How the model's practice trades did recently compared with earlier. Win rate is the share of trades that reached their target.",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Text(dayTrend.first, color = dayTrend.second, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(threeDayTrend.first, color = threeDayTrend.second, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(
                text = String.format(
                    Locale.US,
                    "Week by week: this week %+.2f%% (win %.0f%%) · last week %+.2f%% (win %.0f%%) · 2 weeks ago %+.2f%% (win %.0f%%)",
                    d.week1NetPct, d.week1WinRate,
                    d.week2NetPct, d.week2WinRate,
                    d.week3NetPct, d.week3WinRate
                ),
                color = TextSecondary,
                fontSize = 11.sp
            )
            HorizontalDivider(color = OutlineDark)
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Last", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
                Text("Trades", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
                Text("Win rate", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.9f))
                Text("Profit", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.9f))
            }
            benchmarks.forEach { b ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(prettyWindow(b.label), color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    Text("${b.tradeCount}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
                    Text(String.format(Locale.US, "%.0f%%", b.winRatePct), color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.9f))
                    Text(
                        text = String.format(Locale.US, "%+.2f%%", b.netReturnPct),
                        color = if (b.netReturnPct >= 0.0) GoogleGreen else GoogleRed,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(0.9f)
                    )
                }
            }
        }
    }
}

@Composable
private fun IndicatorEffectivenessCard(stats: List<IndicatorEffectiveness>) {
    val sorted = stats.sortedWith(
        compareByDescending<IndicatorEffectiveness> { it.isActive }.thenByDescending { it.score21d }
    )
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Clues the model watches",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "The model studies ${stats.size} market clues for this asset. Bold ones are the ones it is using now. " +
                    "It re-checks every day which clues have been helping.",
                color = TextSecondary,
                fontSize = 11.sp
            )
            HorizontalDivider(color = OutlineDark)
            sorted.forEach { s ->
                val helpful = s.helpfulness()
                val helpColor = when (helpful) {
                    "Helpful" -> GoogleGreen
                    "A little helpful" -> PrimaryBlue
                    else -> TextSecondary
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(modifier = Modifier.weight(1.5f), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = s.id.plainName().replaceFirstChar { it.uppercase() },
                            color = if (s.isActive) TextPrimary else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (s.isActive) FontWeight.Bold else FontWeight.Normal
                        )
                        if (s.isNewlyEffective) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "New", color = PrimaryBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                        Text(text = helpful, color = helpColor, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = s.trendWord(), color = TextSecondary, fontSize = 10.5.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun LongTermCard(periods: List<LongTermPeriod>, scope: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Long-term results · $scope",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            if (periods.all { it.trades == 0 }) {
                Text(
                    text = "Building up. Results are saved every day, so this fills in over the coming weeks and months, " +
                        "even after the old price data is gone.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            } else {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Last", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.1f))
                    Text("Trades", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
                    Text("Win rate", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.9f))
                    Text("Profit", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                }
                periods.forEach { p ->
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(p.label, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1.1f))
                        Text("${p.trades}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
                        Text(
                            text = if (p.trades > 0) String.format(Locale.US, "%.0f%%", p.winRatePct) else "-",
                            color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                            textAlign = TextAlign.End, modifier = Modifier.weight(0.9f)
                        )
                        Text(
                            text = if (p.trades > 0) String.format(Locale.US, "%+.2f%%", p.netReturnPct) else "-",
                            color = if (p.netReturnPct >= 0.0) GoogleGreen else GoogleRed,
                            fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                            textAlign = TextAlign.End, modifier = Modifier.weight(1f)
                        )
                    }
                }
                val clues = periods.lastOrNull { it.topClues.isNotEmpty() }?.topClues.orEmpty()
                if (clues.isNotEmpty()) {
                    Text(
                        text = "Clues it leaned on most: " + clues.joinToString(", ") { it.plainName() } + ".",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
                Text(
                    text = "These are the model's practice trades, saved daily. Profit is the total price-move % after fees.",
                    color = TextSecondary,
                    fontSize = 10.5.sp
                )
            }
        }
    }
}

@Composable
private fun TradeRowCard(trade: BacktestTrade) {
    val dirColor = if (trade.direction == EntryDirection.LONG) GoogleGreen else GoogleRed
    val retColor = if (trade.won) GoogleGreen else GoogleRed
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "${if (trade.direction == EntryDirection.LONG) "Long" else "Short"} · ${(trade.probability * 100.0).toInt()}% sure",
                    color = dirColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${fmtTimestamp(trade.entryTimeMs)} · ${fmtNum(trade.entryPrice)} -> ${fmtNum(trade.exitPrice)}",
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
            Text(
                text = String.format(Locale.US, "%+.2f%%", trade.netReturnPct),
                color = retColor,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun fmtNum(price: Double): String = when {
    price >= 1_000.0 -> String.format(Locale.US, "%.2f", price)
    price >= 1.0 -> String.format(Locale.US, "%.4f", price)
    price >= 0.01 -> String.format(Locale.US, "%.5f", price)
    else -> String.format(Locale.US, "%.6f", price)
}

private fun fmtTimestamp(ms: Long): String =
    SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date(ms))
