package com.trendlinealerts.app.data.analytics

import android.content.Context
import com.trendlinealerts.core.ml.DailyRecord
import com.trendlinealerts.core.ml.LongTermHistory
import com.trendlinealerts.core.ml.ModelPersistenceFormat
import com.trendlinealerts.core.ml.PersistedAssetModel
import com.trendlinealerts.core.ml.PersistedMaster
import com.trendlinealerts.core.indicators.ScalpingIndicators
import com.trendlinealerts.core.model.Timeframe
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Keeps what the model has learned on the phone:
 *  - one small file per asset with its trained weights and results (so a restart needs no retraining),
 *  - the market-leader model,
 *  - a day-by-day results record kept for a year (so history outlives the 28-day candle window).
 * Files from an older layout or different settings are ignored, never misread.
 */
class MlPersistence(context: Context) {
    private val dir = File(context.applicationContext.filesDir, "ml").apply { mkdirs() }
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val dailySerializer = ListSerializer(DailyRecord.serializer())
    private val dailyFile = File(dir, "daily_records.json")

    private val _daily = MutableStateFlow(readDaily())
    val daily: StateFlow<List<DailyRecord>> = _daily.asStateFlow()

    private fun safe(symbol: String) = symbol.replace(Regex("[^A-Za-z0-9_-]"), "_")
    private fun assetFile(tf: Timeframe, symbol: String) = File(dir, "asset_${tf.name}_${safe(symbol)}.json")
    private fun masterFile(tf: Timeframe) = File(dir, "master_${tf.name}.json")

    @Synchronized
    fun saveAsset(tf: Timeframe, model: PersistedAssetModel) {
        writeAtomic(assetFile(tf, model.snapshot.symbol), json.encodeToString(PersistedAssetModel.serializer(), model))
    }

    fun loadAssets(tf: Timeframe, configKey: String): List<PersistedAssetModel> {
        val prefix = "asset_${tf.name}_"
        val files = dir.listFiles { f -> f.isFile && f.name.startsWith(prefix) && f.name.endsWith(".json") } ?: return emptyList()
        return files.mapNotNull { f ->
            runCatching { json.decodeFromString(PersistedAssetModel.serializer(), f.readText()) }.getOrNull()
        }.filter {
            it.formatVersion == ModelPersistenceFormat.VERSION &&
                it.featureCount == ScalpingIndicators.FEATURE_COUNT &&
                it.configKey == configKey &&
                it.snapshot.timeframe == tf
        }
    }

    @Synchronized
    fun saveMaster(tf: Timeframe, master: PersistedMaster) {
        writeAtomic(masterFile(tf), json.encodeToString(PersistedMaster.serializer(), master))
    }

    fun loadMaster(tf: Timeframe, configKey: String): PersistedMaster? {
        val f = masterFile(tf)
        if (!f.exists()) return null
        return runCatching { json.decodeFromString(PersistedMaster.serializer(), f.readText()) }.getOrNull()
            ?.takeIf {
                it.formatVersion == ModelPersistenceFormat.VERSION &&
                    it.featureCount == ScalpingIndicators.FEATURE_COUNT &&
                    it.configKey == configKey
            }
    }

    /** Adds or replaces day records (never double counts) and keeps one year. */
    @Synchronized
    fun upsertDaily(fresh: List<DailyRecord>, nowMs: Long) {
        val merged = LongTermHistory.upsert(_daily.value, fresh, nowMs)
        writeAtomic(dailyFile, json.encodeToString(dailySerializer, merged))
        _daily.value = merged
    }

    private fun readDaily(): List<DailyRecord> =
        runCatching {
            if (dailyFile.exists()) json.decodeFromString(dailySerializer, dailyFile.readText()) else emptyList()
        }.getOrDefault(emptyList())

    private fun writeAtomic(target: File, text: String) {
        runCatching {
            val tmp = File(target.parentFile, target.name + ".tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(target)) {
                target.delete()
                tmp.renameTo(target)
            }
        }
    }
}
