package com.trendlinealerts.app.ui.watchlist

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.local.WatchlistEntity
import com.trendlinealerts.app.data.repository.WatchlistRepository
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class WatchlistUiState(
    val items: List<WatchlistEntity> = emptyList(),
    val isBusy: Boolean = false,
    val statusMessage: String? = null,
    val isError: Boolean = false
)

class WatchlistViewModel(
    private val watchlistRepository: WatchlistRepository,
    private val settingsDataStore: SettingsDataStore
) : ViewModel() {

    private val isBusyFlow = MutableStateFlow(false)
    private val feedbackFlow = MutableStateFlow<Pair<String?, Boolean>>(null to false)

    val uiState: StateFlow<WatchlistUiState> = combine(
        watchlistRepository.entitiesFlow,
        isBusyFlow,
        feedbackFlow
    ) { items, busy, feedback ->
        WatchlistUiState(
            items = items,
            isBusy = busy,
            statusMessage = feedback.first,
            isError = feedback.second
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = WatchlistUiState()
    )

    fun addSymbol(rawInput: String) {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return

        viewModelScope.launch {
            isBusyFlow.value = true
            feedbackFlow.value = null to false
            runCatching {
                val marketType = settingsDataStore.getSnapshot().marketType
                watchlistRepository.addSymbol(trimmed, marketType)
            }.onSuccess { added ->
                feedbackFlow.value = "Added $added" to false
            }.onFailure { err ->
                feedbackFlow.value = (err.message ?: "Failed to add $trimmed") to true
            }
            isBusyFlow.value = false
        }
    }

    fun removeSymbol(symbol: String) {
        viewModelScope.launch {
            runCatching {
                watchlistRepository.removeSymbol(symbol)
            }.onFailure { err ->
                feedbackFlow.value = (err.message ?: "Failed to remove $symbol") to true
            }
        }
    }

    fun resetToDefault20() {
        viewModelScope.launch {
            isBusyFlow.value = true
            feedbackFlow.value = null to false
            runCatching {
                watchlistRepository.resetToDefault20()
            }.onSuccess {
                feedbackFlow.value = "Reset to default 20 assets" to false
            }.onFailure { err ->
                feedbackFlow.value = (err.message ?: "Reset failed") to true
            }
            isBusyFlow.value = false
        }
    }

    class Factory(
        private val watchlistRepository: WatchlistRepository,
        private val settingsDataStore: SettingsDataStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return WatchlistViewModel(
                watchlistRepository = watchlistRepository,
                settingsDataStore = settingsDataStore
            ) as T
        }
    }
}

@Composable
fun WatchlistScreen(
    viewModel: WatchlistViewModel
) {
    val state by viewModel.uiState.collectAsState()
    var input by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(16.dp)
    ) {
        Text(
            text = "Watchlist",
            color = TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("Add symbol (e.g. BTC or SUIUSDT)", color = TextSecondary) },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = OutlineDark,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = {
                    val toAdd = input
                    input = ""
                    viewModel.addSymbol(toAdd)
                },
                enabled = !state.isBusy && input.isNotBlank(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Icon(imageVector = Icons.Filled.Add, contentDescription = "Add")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add")
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${state.items.size} / 20 assets",
                color = TextSecondary,
                fontSize = 13.sp
            )
            OutlinedButton(
                onClick = { viewModel.resetToDefault20() },
                enabled = !state.isBusy,
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Refresh,
                    contentDescription = null,
                    tint = TextPrimary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Reset to Default 20", color = TextPrimary, fontSize = 13.sp)
            }
        }

        if (!state.statusMessage.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = state.statusMessage.orEmpty(),
                color = if (state.isError) GoogleRed else GoogleGreen,
                fontSize = 13.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(items = state.items, key = { it.symbol }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.symbol,
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (item.isPriorityOverride) {
                                Text(
                                    text = "Positioned (EXIT exhaustion alerts ON)",
                                    color = GoogleGreen,
                                    fontSize = 12.sp
                                )
                            }
                        }
                        IconButton(onClick = { viewModel.removeSymbol(item.symbol) }) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Remove ${item.symbol}",
                                tint = GoogleRed
                            )
                        }
                    }
                }
            }
        }
    }
}
