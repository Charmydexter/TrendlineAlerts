package com.trendlinealerts.app.data.repository

import com.trendlinealerts.app.data.local.AlertLogDao
import com.trendlinealerts.app.data.local.AlertLogEntity
import com.trendlinealerts.app.data.local.WatchlistDao
import com.trendlinealerts.app.data.local.WatchlistEntity
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.core.indicators.ComputedIndicators
import com.trendlinealerts.core.model.AssetModelSnapshot
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.MasterModelSnapshot
import com.trendlinealerts.core.model.SignalAction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SymbolMonitorRow(
    val symbol: String,
    val lastPrice: Double?,
    val action: SignalAction = SignalAction.WAIT,
    val pLong: Double = 0.5,
    val pShort: Double = 0.5,
    val zScore: Double = 0.0,
    val btcCorrelation: Double = 0.0,
    val btcBeta: Double = 1.0,
    val exhaustionScore: Double = 0.0,
    val winRate21d: Double? = null,
    val netReturn21d: Double? = null,
    val topIndicator: String? = null,
    val masterAgreement: Boolean = true,
    val lastSignalDirection: EntryDirection? = null,
    val isPriorityOverride: Boolean = false,
    val lastAlertedAtMs: Long = 0L
)

data class MonitorStatusSnapshot(
    val lastAlertSymbol: String? = null,
    val lastAlertTimeMs: Long = 0L,
    val nextCheckAtMs: Long = 0L,
    val failoverMessage: String? = null,
    val lastPollError: String? = null,
    val activeSource: DataSourceType? = null,
    val retrainStatus: String? = null,
    val lastRetrainAtMs: Long = 0L
)

data class CachedSymbolSeries(
    val symbol: String,
    val candles: List<Candle>,
    val computed: ComputedIndicators
)

class WatchlistRepository(
    private val dao: WatchlistDao,
    private val coordinator: MarketDataCoordinator
) {
    companion object {
        val DEFAULT_20_SYMBOLS = listOf(
            "GRAMUSDT",
            "HYPEUSDT",
            "XLMUSDT",
            "XRPUSDT",
            "SOLUSDT",
            "ZECUSDT",
            "SUIUSDT",
            "SEIUSDT",
            "HBARUSDT",
            "1INCHUSDT",
            "APTUSDT",
            "CAKEUSDT",
            "ATOMUSDT",
            "FILUSDT",
            "INJUSDT",
            "NEARUSDT",
            "IOTAUSDT",
            "POLUSDT",
            "SANDUSDT",
            "WLDUSDT"
        )
    }

    val entitiesFlow: Flow<List<WatchlistEntity>> = dao.observeAll()

    suspend fun ensureDefaultWatchlistSeeded() {
        if (dao.count() == 0) {
            seedDefault20()
        }
    }

    suspend fun seedDefault20() {
        val now = System.currentTimeMillis()
        val entities = DEFAULT_20_SYMBOLS.mapIndexed { idx, sym ->
            WatchlistEntity(
                symbol = sym,
                sortOrder = idx,
                addedAtMs = now + idx,
                isPriorityOverride = false,
                lastAlertedAtMs = 0L
            )
        }
        dao.insertAll(entities)
    }

    suspend fun resetToDefault20() {
        dao.deleteAll()
        seedDefault20()
    }

    suspend fun getAllEntities(): List<WatchlistEntity> = dao.getAll()

    suspend fun addSymbol(rawInput: String, marketType: MarketType): String {
        val cleaned = rawInput.trim().uppercase().replace("/", "").replace("-", "")
        require(cleaned.isNotBlank()) { "Enter a valid ticker symbol" }
        val normalized = if (cleaned.endsWith("USDT")) cleaned else "${cleaned}USDT"

        var validated = false
        var lastError: Throwable? = null
        for (source in listOf(DataSourceType.BYBIT, DataSourceType.BINANCE, DataSourceType.OKX)) {
            val result = runCatching {
                coordinator.fetch1mCandles(
                    symbol = normalized,
                    source = source,
                    marketType = marketType,
                    limit = 5
                )
            }
            if (result.isSuccess && result.getOrNull()?.isNotEmpty() == true) {
                validated = true
                break
            } else {
                lastError = result.exceptionOrNull()
            }
        }
        if (!validated) {
            throw IllegalArgumentException(
                "Could not verify $normalized (${lastError?.message ?: "symbol unavailable"})"
            )
        }

        val currentCount = dao.count()
        dao.upsert(
            WatchlistEntity(
                symbol = normalized,
                sortOrder = currentCount,
                addedAtMs = System.currentTimeMillis(),
                isPriorityOverride = false,
                lastAlertedAtMs = 0L
            )
        )
        return normalized
    }

    suspend fun removeSymbol(symbol: String) {
        dao.deleteBySymbol(symbol)
    }

    suspend fun setPriorityOverride(symbol: String, enabled: Boolean) {
        dao.setPriorityOverride(symbol, enabled)
    }

    suspend fun updateLastEntryDirection(symbol: String, direction: EntryDirection?) {
        dao.updateLastEntryDirection(symbol, direction?.name)
    }

    suspend fun hasAnyPriorityOverride(): Boolean {
        return dao.countPriorityOverrides() > 0
    }

    suspend fun markAlerted(symbol: String, timestampMs: Long) {
        dao.updateLastAlertedAt(symbol, timestampMs)
    }
}

class AlertLogRepository(
    private val dao: AlertLogDao
) {
    companion object {
        const val MAX_ROWS = 1000
    }

    val logsFlow: Flow<List<AlertLogEntity>> = dao.observeRecent()

    fun observeSince(sinceMs: Long): Flow<List<AlertLogEntity>> = dao.observeSince(sinceMs)

    suspend fun insert(entity: AlertLogEntity) {
        dao.insert(entity)
    }

    suspend fun insertAll(entities: List<AlertLogEntity>) {
        entities.forEach { dao.insert(it) }
        dao.trimTo(MAX_ROWS)
    }

    suspend fun clearAll() {
        dao.clearAll()
    }
}

class MonitorStateRepository {
    private val _symbolRows = MutableStateFlow<List<SymbolMonitorRow>>(emptyList())
    val symbolRows: StateFlow<List<SymbolMonitorRow>> = _symbolRows.asStateFlow()

    private val _statusFlow = MutableStateFlow(MonitorStatusSnapshot())
    val statusFlow: StateFlow<MonitorStatusSnapshot> = _statusFlow.asStateFlow()

    private val _isPriorityServiceActive = MutableStateFlow(false)
    val isPriorityServiceActive: StateFlow<Boolean> = _isPriorityServiceActive.asStateFlow()

    fun updateSymbolRows(rows: List<SymbolMonitorRow>) {
        _symbolRows.value = rows
    }

    fun updateStatus(transform: (MonitorStatusSnapshot) -> MonitorStatusSnapshot) {
        _statusFlow.value = transform(_statusFlow.value)
    }

    fun setPriorityServiceActive(active: Boolean) {
        _isPriorityServiceActive.value = active
    }
}

class ModelStateRepository {
    private val _assetSnapshots = MutableStateFlow<Map<String, AssetModelSnapshot>>(emptyMap())
    val assetSnapshots: StateFlow<Map<String, AssetModelSnapshot>> = _assetSnapshots.asStateFlow()

    private val _masterModel = MutableStateFlow<MasterModelSnapshot?>(null)
    val masterModel: StateFlow<MasterModelSnapshot?> = _masterModel.asStateFlow()

    private val _seriesBySymbol = MutableStateFlow<Map<String, CachedSymbolSeries>>(emptyMap())
    val seriesBySymbol: StateFlow<Map<String, CachedSymbolSeries>> = _seriesBySymbol.asStateFlow()

    fun putAssetResult(snapshot: AssetModelSnapshot, series: CachedSymbolSeries) {
        _assetSnapshots.value = _assetSnapshots.value + (snapshot.symbol to snapshot)
        _seriesBySymbol.value = _seriesBySymbol.value + (snapshot.symbol to series)
    }

    fun setMasterModel(master: MasterModelSnapshot?) {
        _masterModel.value = master
    }
}
