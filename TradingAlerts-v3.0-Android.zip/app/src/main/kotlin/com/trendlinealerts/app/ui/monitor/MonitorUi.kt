package com.trendlinealerts.app.ui.monitor

import com.trendlinealerts.core.ml.ProvenGate
import kotlin.math.abs
import com.trendlinealerts.core.indicators.ScalpingIndicators
import java.util.Date
import java.text.SimpleDateFormat
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.analytics.TradeRiskCalculator
import com.trendlinealerts.core.analytics.PriceFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.data.repository.MonitorStateRepository
import com.trendlinealerts.app.data.repository.SymbolMonitorRow
import com.trendlinealerts.app.data.repository.WatchlistRepository
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SignalGreen
import com.trendlinealerts.app.ui.theme.SignalGrey
import com.trendlinealerts.app.ui.theme.SignalRed
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.SurfaceVariantDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.app.ui.theme.WarningAmber
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.SignalAction
import com.trendlinealerts.core.model.Timeframe
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MonitorUiState(
    val isGeneralMonitoring: Boolean = false,
    val isServiceActive: Boolean = false,
    val isPriorityActive: Boolean = false,
    val dataSource: DataSourceType = DataSourceType.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val timeframe: Timeframe = Timeframe.M1,
    val minProfitMultiplier: Double = 1.0,
    val alertSettings: AlertSettings = AlertSettings(),
    val signalThreshold: Double = 0.58,
    val observeWithMaster: Boolean = true,
    val masterAsset: String = "BTCUSDT",
    val lastAlertSymbol: String? = null,
    val lastAlertTimeMs: Long = 0L,
    val nextCheckAtMs: Long = 0L,
    val failoverMessage: String? = null,
    val lastPollError: String? = null,
    val activeSource: DataSourceType? = null,
    val retrainStatus: String? = null,
    val rows: List<SymbolMonitorRow> = emptyList()
)

class MonitorViewModel(
    settingsDataStore: SettingsDataStore,
    private val watchlistRepository: WatchlistRepository,
    monitorStateRepository: MonitorStateRepository
) : ViewModel() {

    val uiState: StateFlow<MonitorUiState> = combine(
        settingsDataStore.settingsFlow,
        watchlistRepository.entitiesFlow,
        monitorStateRepository.symbolRows,
        monitorStateRepository.statusFlow,
        monitorStateRepository.isPriorityServiceActive
    ) { settings, entities, liveRows, status, priorityServiceActive ->
        val liveBySymbol = liveRows.associateBy { it.symbol }
        val mergedRows = entities.map { entity ->
            val entityDir = entity.lastEntryDirection?.let { runCatching { EntryDirection.valueOf(it) }.getOrNull() }
            val live = liveBySymbol[entity.symbol]
            live?.copy(
                isPriorityOverride = entity.isPriorityOverride,
                lastAlertedAtMs = entity.lastAlertedAtMs,
                lastSignalDirection = entityDir ?: live.lastSignalDirection
            ) ?: SymbolMonitorRow(
                symbol = entity.symbol,
                lastPrice = null,
                action = SignalAction.WAIT,
                lastSignalDirection = entityDir,
                isPriorityOverride = entity.isPriorityOverride,
                lastAlertedAtMs = entity.lastAlertedAtMs
            )
        }

        val hasPriority = entities.any { it.isPriorityOverride }
        MonitorUiState(
            isGeneralMonitoring = settings.monitoringEnabled,
            isServiceActive = settings.monitoringEnabled || priorityServiceActive,
            isPriorityActive = hasPriority,
            dataSource = settings.dataSource,
            marketType = settings.marketType,
            timeframe = settings.alertSettings.timeframe,
            minProfitMultiplier = settings.alertSettings.effectiveMinProfitMultiplier,
            alertSettings = settings.alertSettings,
            signalThreshold = settings.alertSettings.effectiveSignalThreshold,
            observeWithMaster = settings.alertSettings.observeWithMaster,
            masterAsset = settings.alertSettings.effectiveMasterAsset,
            lastAlertSymbol = status.lastAlertSymbol,
            lastAlertTimeMs = status.lastAlertTimeMs,
            nextCheckAtMs = status.nextCheckAtMs,
            failoverMessage = status.failoverMessage,
            lastPollError = status.lastPollError,
            activeSource = status.activeSource,
            retrainStatus = status.retrainStatus,
            rows = mergedRows
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = MonitorUiState()
    )

    fun flipPositionedSide(symbol: String, currentDir: EntryDirection?) {
        val next = if (currentDir == EntryDirection.LONG) EntryDirection.SHORT else EntryDirection.LONG
        viewModelScope.launch {
            watchlistRepository.updateLastEntryDirection(symbol, next)
        }
    }

    class Factory(
        private val settingsDataStore: SettingsDataStore,
        private val watchlistRepository: WatchlistRepository,
        private val monitorStateRepository: MonitorStateRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MonitorViewModel(
                settingsDataStore = settingsDataStore,
                watchlistRepository = watchlistRepository,
                monitorStateRepository = monitorStateRepository
            ) as T
        }
    }
}

@Composable
fun MonitorScreen(
    viewModel: MonitorViewModel,
    onToggleGeneralMonitoring: (Boolean) -> Unit,
    onTogglePriorityOverride: (String, Boolean) -> Unit,
    onOpenAssetChart: (String) -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(1_000L)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "monitoring_button") {
            Button(
                onClick = { onToggleGeneralMonitoring(!state.isGeneralMonitoring) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (state.isGeneralMonitoring) GoogleRed else PrimaryBlue,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = if (state.isGeneralMonitoring) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (state.isGeneralMonitoring) "STOP MONITORING" else "START MONITORING",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.6.sp
                )
            }
        }

        if (!state.isGeneralMonitoring && state.isPriorityActive) {
            item(key = "priority_banner") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Text(
                        text = "General monitoring is OFF — Positioned assets remain active for EXIT alerts.",
                        color = GoogleGreen,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
            }
        }

        if (!state.failoverMessage.isNullOrBlank()) {
            item(key = "failover_banner") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B210B))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null,
                            tint = WarningAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = state.failoverMessage.orEmpty(),
                            color = Color(0xFFFDE68A),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        if (!state.lastPollError.isNullOrBlank()) {
            item(key = "poll_error") {
                Text(
                    text = "Last poll error: ${state.lastPollError}",
                    color = GoogleRed,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item(key = "status_card") {
            StatusCard(state = state, nowMs = nowMs)
        }

        item(key = "table_header") {
            Column(modifier = Modifier.fillMaxWidth()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SYMBOL / POSITIONED",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "PRICE · SIGNAL · Z-SCORE",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.8.sp
                    )
                }
                HorizontalDivider(color = OutlineDark, thickness = 1.dp)
            }
        }

        items(items = state.rows, key = { it.symbol }) { row ->
            SymbolRowItem(
                row = row,
                alertSettings = state.alertSettings,
                onTogglePriorityOverride = { enabled ->
                    onTogglePriorityOverride(row.symbol, enabled)
                },
                onFlipSide = {
                    viewModel.flipPositionedSide(row.symbol, row.lastSignalDirection)
                },
                onOpenAssetChart = { onOpenAssetChart(row.symbol) }
            )
            HorizontalDivider(color = OutlineDark.copy(alpha = 0.6f), thickness = 1.dp)
        }
    }
}

@Composable
private fun StatusCard(
    state: MonitorUiState,
    nowMs: Long
) {
    val nextCheckRemainingSec = if (state.nextCheckAtMs > nowMs) {
        ((state.nextCheckAtMs - nowMs) / 1_000L)
    } else {
        0L
    }

    val lastAlertText = if (state.lastAlertSymbol.isNullOrBlank()) "None" else state.lastAlertSymbol.orEmpty()
    val nextCheckText = if (!state.isServiceActive) "Paused" else formatMmSs(nextCheckRemainingSec)
    val defaultLabel = formatSourceLabel(state.dataSource, state.marketType)
    val activeSource = state.activeSource
    val sourceLabel = if (activeSource == null || activeSource == state.dataSource) {
        defaultLabel
    } else {
        "${formatSourceLabel(activeSource, state.marketType)} (fallback)"
    }
    val mlSummary = String.format(
        Locale.US,
        "%s · Mult %.1fx · Thr %.0f%% · Master %s %s",
        state.timeframe.label,
        state.minProfitMultiplier,
        state.signalThreshold * 100.0,
        state.masterAsset.removeSuffix("USDT"),
        if (state.observeWithMaster) "ON" else "OFF"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusLine(label = "Last alert", value = lastAlertText)
            StatusLine(label = "Next check in", value = nextCheckText)
            StatusLine(label = "Data source", value = sourceLabel)
            StatusLine(label = "ML Config", value = mlSummary)
            if (!state.retrainStatus.isNullOrBlank()) {
                StatusLine(label = "Retraining", value = state.retrainStatus)
            }
        }
    }
}

@Composable
private fun StatusLine(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 13.sp,
            modifier = Modifier.weight(0.35f)
        )
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(0.65f)
        )
    }
}

@Composable
private fun SymbolRowItem(
    alertSettings: AlertSettings,
    row: SymbolMonitorRow,
    onTogglePriorityOverride: (Boolean) -> Unit,
    onFlipSide: () -> Unit,
    onOpenAssetChart: () -> Unit
) {
    val dotColor = when (row.action) {
        SignalAction.LONG -> SignalGreen
        SignalAction.SHORT -> SignalRed
        SignalAction.EXIT -> WarningAmber
        SignalAction.WAIT -> SignalGrey
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenAssetChart)
            .padding(vertical = 8.dp, horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(dotColor)
        )

        Spacer(modifier = Modifier.width(6.dp))

        Switch(
            checked = row.isPriorityOverride,
            onCheckedChange = onTogglePriorityOverride,
            modifier = Modifier.scale(0.75f),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = GoogleGreen,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = OutlineDark
            )
        )

        Spacer(modifier = Modifier.width(6.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = row.symbol,
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (row.isPriorityOverride) {
                val side = row.lastSignalDirection ?: if (row.pLong >= row.pShort) EntryDirection.LONG else EntryDirection.SHORT
                val sideColor = if (side == EntryDirection.LONG) GoogleGreen else GoogleRed
                Text(
                    text = "In ${side.name} · tap to flip",
                    color = sideColor,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .background(SurfaceVariantDark, RoundedCornerShape(4.dp))
                        .clickable { onFlipSide() }
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                )
            } else if (row.tradeSide != null) {
                // A trade started by an alert: the entry is assumed 3 minutes after the alert.
                val sideName = if (row.tradeSide == EntryDirection.LONG) "long" else "short"
                val sideColor = if (row.tradeSide == EntryDirection.LONG) GoogleGreen else GoogleRed
                val statusText = when {
                    row.tradeWaiting && row.tradeEntersAtMs != null ->
                        "Signal sent · entry set at ${SimpleDateFormat("HH:mm", Locale.US).format(Date(row.tradeEntersAtMs))}"
                    row.tradeEntered -> "In $sideName trade (you)"
                    else -> "In $sideName trade (auto)"
                }
                Text(
                    text = statusText,
                    color = sideColor,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            } else if ((row.action == SignalAction.LONG || row.action == SignalAction.SHORT) &&
                alertSettings.onlyProvenAssets && !row.provenOk
            ) {
                Text(
                    text = "Signal seen but not alerted: this asset has not proven itself over the last 3 weeks yet " +
                        "(${row.provenTrades} practice trades so far; it needs ${ProvenGate.MIN_TRADES} that ended in profit).",
                    color = WarningAmber,
                    fontSize = 10.5.sp
                )
            } else if ((row.action == SignalAction.LONG || row.action == SignalAction.SHORT) && row.lastPrice != null) {
                // Where to put the stop and target if you enter on this signal
                val dir = if (row.action == SignalAction.LONG) EntryDirection.LONG else EntryDirection.SHORT
                val lv = TradeRiskCalculator.compute(row.lastPrice, dir, alertSettings)
                if (lv != null) {
                    Text(
                        text = "Stop ${PriceFormat.format(lv.slPrice)} · Target ${PriceFormat.format(lv.tpPrice)}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = String.format(Locale.US, "Risk \$%.2f to win \$%.2f", lv.slUsd, lv.tpUsd),
                        color = TextSecondary,
                        fontSize = 10.5.sp
                    )
                }
            } else if (row.action == SignalAction.WAIT && abs(row.channelZ) >= ScalpingIndicators.CHANNEL_ENTRY_Z) {
                Text(
                    text = if (row.channelZ < 0.0) {
                        "Setup forming: price is at the bottom of its channel. Waiting for the model to agree (possible long)."
                    } else {
                        "Setup forming: price is at the top of its channel. Waiting for the model to agree (possible short)."
                    },
                    color = WarningAmber,
                    fontSize = 10.5.sp
                )
            } else if (row.winRate21d != null) {
                Text(
                    text = String.format(Locale.US, "Win rate %.0f%% (3wks)", row.winRate21d),
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
            if (row.tradeSide != null && row.tradeEntry != null && row.tradeSl != null && row.tradeTp != null) {
                Text(
                    text = "Entry ${PriceFormat.format(row.tradeEntry)} · Stop ${PriceFormat.format(row.tradeSl)} · Target ${PriceFormat.format(row.tradeTp)}",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = row.lastPrice?.let { formatPrice(it) } ?: "--",
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            // "Proven first": a signal on an asset that has not proven itself is shown but not alerted.
            val gated = alertSettings.onlyProvenAssets && !row.provenOk && row.tradeSide == null
            val actionLabel = when (row.action) {
                SignalAction.LONG -> if (gated) "Watching" else "Long ${(row.pLong * 100.0).toInt()}%"
                SignalAction.SHORT -> if (gated) "Watching" else "Short ${(row.pShort * 100.0).toInt()}%"
                SignalAction.EXIT -> "Exit"
                SignalAction.WAIT -> if (row.tradeSide != null) "Hold" else "Wait"
            }
            val actionColor = when (row.action) {
                SignalAction.LONG -> if (gated) TextSecondary else GoogleGreen
                SignalAction.SHORT -> if (gated) TextSecondary else GoogleRed
                SignalAction.EXIT -> WarningAmber
                SignalAction.WAIT -> TextSecondary
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = actionLabel,
                    color = actionColor,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

private fun formatSourceLabel(source: DataSourceType, marketType: MarketType): String = when (source) {
    DataSourceType.BYBIT -> if (marketType == MarketType.PERP) "Bybit Linear Perps" else "Bybit Spot"
    DataSourceType.BINANCE -> if (marketType == MarketType.PERP) "Binance USDT-M Futures" else "Binance Spot"
    DataSourceType.OKX -> if (marketType == MarketType.PERP) "OKX Perps" else "OKX Spot"
}

private fun formatMmSs(totalSeconds: Long): String {
    val safe = totalSeconds.coerceAtLeast(0L)
    val mins = safe / 60L
    val secs = safe % 60L
    return String.format(Locale.US, "%02d:%02d", mins, secs)
}

private fun formatPrice(price: Double): String = when {
    price >= 1_000.0 -> String.format(Locale.US, "%.2f", price)
    price >= 1.0 -> String.format(Locale.US, "%.4f", price)
    price >= 0.01 -> String.format(Locale.US, "%.5f", price)
    else -> String.format(Locale.US, "%.6f", price)
}
