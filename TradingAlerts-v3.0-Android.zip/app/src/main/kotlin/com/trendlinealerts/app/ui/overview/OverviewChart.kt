package com.trendlinealerts.app.ui.overview

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trendlinealerts.app.ui.theme.ChartFuchsia
import com.trendlinealerts.app.ui.theme.ChartYellow
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.SurfaceVariantDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.app.ui.theme.WarningAmber
import com.trendlinealerts.core.analytics.HeikinAshiConverter
import com.trendlinealerts.core.indicators.ComputedIndicators
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.ChartCandleStyle
import com.trendlinealerts.core.model.ChartRangeSpec
import com.trendlinealerts.core.model.ChartSignalMarker
import com.trendlinealerts.core.model.SignalAction
import com.trendlinealerts.core.model.Timeframe
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private const val RIGHT_SPACING_BARS = 5

@Composable
fun OverviewChart(
    symbol: String,
    candles: List<Candle>,
    computed: ComputedIndicators?,
    timeframe: Timeframe,
    selectedRange: ChartRangeSpec,
    candleStyle: ChartCandleStyle,
    showEmaOverlay: Boolean,
    showVwapOverlay: Boolean,
    showBbOverlay: Boolean,
    markers: List<ChartSignalMarker>,
    currentAction: SignalAction,
    zScore: Double,
    pLong: Double,
    pShort: Double,
    isLoading: Boolean,
    error: String?,
    onSelectRange: (ChartRangeSpec) -> Unit,
    onSelectCandleStyle: (ChartCandleStyle) -> Unit,
    onToggleEma: (Boolean) -> Unit,
    onToggleVwap: (Boolean) -> Unit,
    onToggleBb: (Boolean) -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sliceCount = min(candles.size, selectedRange.bars.coerceAtLeast(15))
    val sliceOffset = max(0, candles.size - sliceCount)
    val rawSlice = remember(candles, sliceCount, sliceOffset) {
        if (candles.isEmpty()) emptyList() else candles.subList(sliceOffset, candles.size)
    }

    val displayCandles = remember(rawSlice, candleStyle) {
        if (rawSlice.isEmpty()) emptyList()
        else if (candleStyle == ChartCandleStyle.HEIKIN_ASHI) HeikinAshiConverter.convert(rawSlice)
        else rawSlice
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceDark, RoundedCornerShape(12.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Row 1: Chart View Ranges (4H default, 1H, 30m, 15m for 1m) + Z-Score + Refresh
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                timeframe.chartRanges.forEach { rangeSpec ->
                    FilterChip(
                        selected = selectedRange.key == rangeSpec.key,
                        onClick = { onSelectRange(rangeSpec) },
                        label = { Text(rangeSpec.label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = Color.White,
                            containerColor = SurfaceVariantDark,
                            labelColor = TextPrimary
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.width(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                val zColor = when {
                    abs(zScore) >= 2.0 -> WarningAmber
                    zScore >= 0.0 -> GoogleGreen
                    else -> GoogleRed
                }
                Text(
                    text = String.format(Locale.US, "Z %+.2f", zScore),
                    color = zColor,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = PrimaryBlue,
                        strokeWidth = 2.dp
                    )
                } else {
                    IconButton(onClick = onRefresh, modifier = Modifier.size(30.dp)) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh chart",
                            tint = PrimaryBlue,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                }
            }
        }

        // Row 2: Heikin Ashi (default) / Candles + Optional Off-by-Default Indicator Overlays
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = candleStyle == ChartCandleStyle.HEIKIN_ASHI,
                onClick = { onSelectCandleStyle(ChartCandleStyle.HEIKIN_ASHI) },
                label = { Text("Heikin Ashi", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PrimaryBlue,
                    selectedLabelColor = Color.White,
                    containerColor = SurfaceVariantDark,
                    labelColor = TextPrimary
                )
            )
            FilterChip(
                selected = candleStyle == ChartCandleStyle.CANDLES,
                onClick = { onSelectCandleStyle(ChartCandleStyle.CANDLES) },
                label = { Text("Candles", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PrimaryBlue,
                    selectedLabelColor = Color.White,
                    containerColor = SurfaceVariantDark,
                    labelColor = TextPrimary
                )
            )
            FilterChip(
                selected = showEmaOverlay,
                onClick = { onToggleEma(!showEmaOverlay) },
                label = { Text("EMA", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ChartYellow.copy(alpha = 0.25f),
                    selectedLabelColor = ChartYellow,
                    containerColor = SurfaceVariantDark,
                    labelColor = TextSecondary
                )
            )
            FilterChip(
                selected = showVwapOverlay,
                onClick = { onToggleVwap(!showVwapOverlay) },
                label = { Text("VWAP", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PrimaryBlue.copy(alpha = 0.25f),
                    selectedLabelColor = PrimaryBlue,
                    containerColor = SurfaceVariantDark,
                    labelColor = TextSecondary
                )
            )
            FilterChip(
                selected = showBbOverlay,
                onClick = { onToggleBb(!showBbOverlay) },
                label = { Text("BB", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ChartFuchsia.copy(alpha = 0.25f),
                    selectedLabelColor = ChartFuchsia,
                    containerColor = SurfaceVariantDark,
                    labelColor = TextSecondary
                )
            )
        }

        if (!error.isNullOrBlank()) {
            Text(
                text = "Chart error ($symbol): $error",
                color = GoogleRed,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        if (displayCandles.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isLoading) "Loading $symbol ${timeframe.label} history..." else "No candles loaded for $symbol. Tap refresh.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
            return@Column
        }

        val barByOpen = remember(displayCandles) {
            HashMap<Long, Int>(displayCandles.size * 2).apply {
                displayCandles.forEachIndexed { idx, c -> put(c.openTimeMs, idx) }
            }
        }

        val (yMin, yMax) = remember(displayCandles, computed, sliceOffset, showEmaOverlay, showVwapOverlay, showBbOverlay) {
            var lo = Double.POSITIVE_INFINITY
            var hi = Double.NEGATIVE_INFINITY
            for (i in displayCandles.indices) {
                val c = displayCandles[i]
                if (c.low < lo) lo = c.low
                if (c.high > hi) hi = c.high
                val srcIdx = sliceOffset + i
                if (computed != null && srcIdx in computed.atr14.indices) {
                    if (showBbOverlay) {
                        lo = min(lo, computed.bbLower[srcIdx])
                        hi = max(hi, computed.bbUpper[srcIdx])
                    }
                    if (showVwapOverlay) {
                        lo = min(lo, computed.vwap[srcIdx])
                        hi = max(hi, computed.vwap[srcIdx])
                    }
                    if (showEmaOverlay) {
                        lo = min(lo, computed.ema34[srcIdx])
                        hi = max(hi, computed.ema5[srcIdx])
                    }
                }
            }
            if (!lo.isFinite() || !hi.isFinite() || hi <= lo) {
                0.0 to 1.0
            } else {
                val pad = (hi - lo) * 0.08
                (lo - pad) to (hi + pad)
            }
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(Color(0xFF0A0E13), RoundedCornerShape(8.dp))
        ) {
            val w = size.width
            val h = size.height
            val n = displayCandles.size
            val stepX = w / (n + RIGHT_SPACING_BARS).toFloat()
            val bodyW = (stepX * 0.68f).coerceIn(1.5f, 12.dp.toPx())
            val ySpan = (yMax - yMin).coerceAtLeast(1e-9)

            fun xFor(idx: Int): Float = (idx + 0.5f) * stepX
            fun yFor(price: Double): Float = (h - ((price - yMin) / ySpan) * h).toFloat()

            clipRect {
                // Grid lines
                val gridEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                for (g in 1..3) {
                    val gy = h * g / 4f
                    drawLine(
                        color = OutlineDark.copy(alpha = 0.5f),
                        start = Offset(0f, gy),
                        end = Offset(w, gy),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = gridEffect
                    )
                }

                // Candles (Heikin-Ashi by default)
                for (i in displayCandles.indices) {
                    val c = displayCandles[i]
                    val cx = xFor(i)
                    val isUp = c.close >= c.open
                    val col = if (isUp) GoogleGreen else GoogleRed
                    val yHigh = yFor(c.high)
                    val yLow = yFor(c.low)
                    drawLine(
                        color = col,
                        start = Offset(cx, yHigh),
                        end = Offset(cx, yLow),
                        strokeWidth = 1.2.dp.toPx()
                    )
                    val yOpen = yFor(c.open)
                    val yClose = yFor(c.close)
                    val top = min(yOpen, yClose)
                    val rectH = max(abs(yClose - yOpen), 1.5.dp.toPx())
                    drawRect(
                        color = col,
                        topLeft = Offset(cx - bodyW / 2f, top),
                        size = Size(bodyW, rectH)
                    )
                }

                // Optional indicator overlays (all OFF by default)
                if (computed != null) {
                    fun drawSeries(series: DoubleArray, color: Color, widthDp: Float) {
                        val path = Path()
                        var started = false
                        for (i in displayCandles.indices) {
                            val srcIdx = sliceOffset + i
                            if (srcIdx !in series.indices) continue
                            val px = xFor(i)
                            val py = yFor(series[srcIdx])
                            if (!started) {
                                path.moveTo(px, py)
                                started = true
                            } else {
                                path.lineTo(px, py)
                            }
                        }
                        if (started) {
                            drawPath(path = path, color = color, style = Stroke(width = widthDp.dp.toPx()))
                        }
                    }

                    if (showEmaOverlay) {
                        drawSeries(computed.ema5, ChartYellow, 1.4f)
                        drawSeries(computed.ema13, PrimaryBlue, 1.3f)
                        drawSeries(computed.ema34, Color(0xFFEC4899), 1.3f)
                    }
                    if (showVwapOverlay) {
                        drawSeries(computed.vwap, PrimaryBlue, 1.6f)
                    }
                    if (showBbOverlay) {
                        drawSeries(computed.bbUpper, ChartFuchsia.copy(alpha = 0.7f), 1.2f)
                        drawSeries(computed.bbLower, ChartFuchsia.copy(alpha = 0.7f), 1.2f)
                    }
                }

                // Logistic ML Signal Markers (LONG / SHORT / EXIT)
                val markerR = 5.dp.toPx()
                markers.forEach { m ->
                    val idx = barByOpen[m.openTimeMs] ?: return@forEach
                    val bar = displayCandles[idx]
                    val cx = xFor(idx)
                    when (m.action) {
                        SignalAction.LONG -> {
                            val tipY = (yFor(bar.low) + 4.dp.toPx()).coerceAtMost(h - markerR)
                            val path = Path().apply {
                                moveTo(cx, tipY)
                                lineTo(cx - markerR, tipY + markerR * 1.4f)
                                lineTo(cx + markerR, tipY + markerR * 1.4f)
                                close()
                            }
                            drawPath(path = path, color = GoogleGreen, style = Fill)
                        }
                        SignalAction.SHORT -> {
                            val tipY = (yFor(bar.high) - 4.dp.toPx()).coerceAtLeast(markerR)
                            val path = Path().apply {
                                moveTo(cx, tipY)
                                lineTo(cx - markerR, tipY - markerR * 1.4f)
                                lineTo(cx + markerR, tipY - markerR * 1.4f)
                                close()
                            }
                            drawPath(path = path, color = GoogleRed, style = Fill)
                        }
                        SignalAction.EXIT -> {
                            val cy = yFor(bar.close).coerceIn(markerR, h - markerR)
                            val dPath = Path().apply {
                                moveTo(cx, cy - markerR)
                                lineTo(cx + markerR, cy)
                                lineTo(cx, cy + markerR)
                                lineTo(cx - markerR, cy)
                                close()
                            }
                            drawPath(path = dPath, color = WarningAmber, style = Fill)
                        }
                        SignalAction.WAIT -> Unit
                    }
                }
            }
        }

        val startClock = fmtTimeHm(displayCandles.first().openTimeMs)
        val endClock = fmtTimeHm(displayCandles.last().openTimeMs)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(startClock, color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text(
                "${timeframe.label} · Range ${selectedRange.label} · ▲Long ▼Short ◆Exit",
                color = TextSecondary,
                fontSize = 9.5.sp
            )
            Text(endClock, color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }

        HorizontalDivider(color = OutlineDark)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val (sigText, sigColor) = when (currentAction) {
                SignalAction.LONG -> "Signal: LONG" to GoogleGreen
                SignalAction.SHORT -> "Signal: SHORT" to GoogleRed
                SignalAction.EXIT -> "Signal: EXIT (Exhausted)" to WarningAmber
                SignalAction.WAIT -> "Signal: WAIT" to TextSecondary
            }
            Text(text = sigText, color = sigColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(
                text = String.format(Locale.US, "P(L) %.0f%% · P(S) %.0f%%", pLong * 100.0, pShort * 100.0),
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private fun fmtTimeHm(ms: Long): String = SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date(ms))
