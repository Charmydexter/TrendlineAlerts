package com.trendlinealerts.app.ui.settings

import com.trendlinealerts.core.ml.ProvenGate
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.WifiFind
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.SurfaceVariantDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.ChartCandleStyle
import com.trendlinealerts.core.model.Timeframe
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class SettingsUiState(
    val dataSource: DataSourceType = DataSourceType.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val chartCandleStyle: ChartCandleStyle = ChartCandleStyle.HEIKIN_ASHI,
    val showEmaOverlay: Boolean = false,
    val showVwapOverlay: Boolean = false,
    val showBbOverlay: Boolean = false,
    val alertSettings: AlertSettings = AlertSettings(),
    val isTestingConnection: Boolean = false,
    val connectionTestResult: String? = null,
    val connectionTestOk: Boolean = false
)

class SettingsViewModel(
    private val settingsDataStore: SettingsDataStore,
    private val marketDataCoordinator: MarketDataCoordinator
) : ViewModel() {

    private val isTestingFlow = MutableStateFlow(false)
    private val testResultFlow = MutableStateFlow<Pair<String?, Boolean>>(null to false)

    val uiState: StateFlow<SettingsUiState> = combine(
        settingsDataStore.settingsFlow,
        isTestingFlow,
        testResultFlow
    ) { snapshot, testing, testRes ->
        SettingsUiState(
            dataSource = snapshot.dataSource,
            marketType = snapshot.marketType,
            chartCandleStyle = snapshot.chartCandleStyle,
            showEmaOverlay = snapshot.showEmaOverlay,
            showVwapOverlay = snapshot.showVwapOverlay,
            showBbOverlay = snapshot.showBbOverlay,
            alertSettings = snapshot.alertSettings,
            isTestingConnection = testing,
            connectionTestResult = testRes.first,
            connectionTestOk = testRes.second
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = SettingsUiState()
    )

    fun setDataSource(source: DataSourceType) {
        viewModelScope.launch { settingsDataStore.setDataSource(source) }
    }

    fun setMarketType(marketType: MarketType) {
        viewModelScope.launch { settingsDataStore.setMarketType(marketType) }
    }

    fun setTimeframe(timeframe: Timeframe) {
        viewModelScope.launch { settingsDataStore.setTimeframe(timeframe) }
    }

    fun setOnlyProven(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setOnlyProvenAssets(enabled) }
    }

    fun setCapitalUsd(value: Double) {
        viewModelScope.launch { settingsDataStore.setCapitalUsd(value) }
    }

    fun setMaxLossUsd(value: Double) {
        viewModelScope.launch { settingsDataStore.setMaxLossUsd(value) }
    }

    fun setMinProfitMultiplier(value: Double) {
        viewModelScope.launch { settingsDataStore.setMinProfitMultiplier(value) }
    }

    fun setSignalThreshold(value: Double) {
        viewModelScope.launch { settingsDataStore.setSignalThreshold(value) }
    }

    fun setObserveWithMaster(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setObserveWithMaster(enabled) }
    }

    fun setMasterAsset(raw: String) {
        viewModelScope.launch { settingsDataStore.setMasterAsset(raw) }
    }

    fun setChartCandleStyle(style: ChartCandleStyle) {
        viewModelScope.launch { settingsDataStore.setChartCandleStyle(style) }
    }

    fun setShowEmaOverlay(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setShowEmaOverlay(enabled) }
    }

    fun setShowVwapOverlay(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setShowVwapOverlay(enabled) }
    }

    fun setShowBbOverlay(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.setShowBbOverlay(enabled) }
    }

    fun testConnection() {
        viewModelScope.launch {
            isTestingFlow.value = true
            testResultFlow.value = null to false
            val snap = settingsDataStore.getSnapshot()
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    marketDataCoordinator.fetch1mCandles(
                        symbol = "SUIUSDT",
                        source = snap.dataSource,
                        marketType = snap.marketType,
                        limit = 5
                    )
                }
            }
            result.onSuccess { candles ->
                val price = candles.lastOrNull()?.close
                testResultFlow.value = if (price != null) {
                    "Connected to ${snap.dataSource.name} ${snap.marketType.name} (SUIUSDT = $price)" to true
                } else {
                    "Connected, but empty candles returned" to false
                }
            }.onFailure { err ->
                testResultFlow.value = "${err::class.java.simpleName}: ${err.message}" to false
            }
            isTestingFlow.value = false
        }
    }

    class Factory(
        private val settingsDataStore: SettingsDataStore,
        private val marketDataCoordinator: MarketDataCoordinator
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(settingsDataStore, marketDataCoordinator) as T
        }
    }
}

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onSendTestNotification: () -> Unit,
    onRunSequentialRetrain: () -> Unit,
    onOpenBatteryOptimization: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Settings",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Single Scalping Timeframe (1m default; 1h & 4h excluded > 90d)
        item {
            SettingsCard(title = "Trading Timeframe (Single-TF · <= 90d Cap)") {
                val tf = state.alertSettings.timeframe
                Text(
                    text = "Selected: ${tf.label} · History ${tf.historyDays}d · Train W1 ${tf.initialTrainDays}d · Overview ${tf.evalDays}d",
                    color = GoogleGreen,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Timeframe.entries.forEach { item ->
                        FilterChip(
                            selected = tf == item,
                            onClick = { viewModel.setTimeframe(item) },
                            label = { Text(item.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = Color.White,
                                containerColor = SurfaceVariantDark,
                                labelColor = TextPrimary
                            )
                        )
                    }
                }
            }
        }

        // Trade amount + max loss: these decide the stop-loss and take-profit
        item {
            TradeSizeCard(
                alertSettings = state.alertSettings,
                onSaveCapital = viewModel::setCapitalUsd,
                onSaveMaxLoss = viewModel::setMaxLossUsd
            )
        }

        // Safety check: only alert on assets that have proven themselves
        item {
            SafetyCard(
                onlyProven = state.alertSettings.onlyProvenAssets,
                onToggle = viewModel::setOnlyProven
            )
        }

        // Signal strictness and profit target
        item {
            MlParametersCard(
                alertSettings = state.alertSettings,
                onSaveMultiplier = viewModel::setMinProfitMultiplier,
                onSaveThreshold = viewModel::setSignalThreshold,
                onToggleMaster = viewModel::setObserveWithMaster,
                onSaveMasterAsset = viewModel::setMasterAsset,
                onRunSequentialRetrain = onRunSequentialRetrain
            )
        }

        // Chart Defaults (Heikin-Ashi ON, Indicators OFF by default)
        item {
            SettingsCard(title = "Chart Defaults (Heikin-Ashi ON · Indicators OFF)") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = state.chartCandleStyle == ChartCandleStyle.HEIKIN_ASHI,
                        onClick = { viewModel.setChartCandleStyle(ChartCandleStyle.HEIKIN_ASHI) },
                        label = { Text("Heikin Ashi (Default)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = Color.White,
                            containerColor = SurfaceVariantDark,
                            labelColor = TextPrimary
                        )
                    )
                    FilterChip(
                        selected = state.chartCandleStyle == ChartCandleStyle.CANDLES,
                        onClick = { viewModel.setChartCandleStyle(ChartCandleStyle.CANDLES) },
                        label = { Text("Standard Candles") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = Color.White,
                            containerColor = SurfaceVariantDark,
                            labelColor = TextPrimary
                        )
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                ToggleRow("Show EMA (5/13/34) overlay", state.showEmaOverlay, viewModel::setShowEmaOverlay)
                ToggleRow("Show Rolling VWAP overlay", state.showVwapOverlay, viewModel::setShowVwapOverlay)
                ToggleRow("Show Bollinger Bands (20,2)", state.showBbOverlay, viewModel::setShowBbOverlay)
            }
        }

        // Exchange Data Source & Market Type
        item {
            SettingsCard(title = "Data Source & Market Type") {
                DataSourceType.entries.forEach { source ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setDataSource(source) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = state.dataSource == source,
                            onClick = { viewModel.setDataSource(source) },
                            colors = RadioButtonDefaults.colors(selectedColor = PrimaryBlue)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = source.name + if (state.dataSource == source) " (Default)" else "",
                            color = TextPrimary,
                            fontSize = 15.sp
                        )
                    }
                }
                HorizontalDivider(color = OutlineDark, modifier = Modifier.padding(vertical = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MarketType.entries.forEach { m ->
                        FilterChip(
                            selected = state.marketType == m,
                            onClick = { viewModel.setMarketType(m) },
                            label = { Text(if (m == MarketType.PERP) "Futures (Perp)" else "Spot") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = Color.White,
                                containerColor = SurfaceVariantDark,
                                labelColor = TextPrimary
                            )
                        )
                    }
                }
            }
        }

        // Diagnostics & Reliability
        item {
            SettingsCard(title = "Diagnostics & Background Reliability") {
                OutlinedButton(
                    onClick = { viewModel.testConnection() },
                    enabled = !state.isTestingConnection,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Filled.WifiFind, contentDescription = null, tint = PrimaryBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isTestingConnection) "Testing Connection..." else "Test Feed Connection",
                        color = TextPrimary
                    )
                }

                if (!state.connectionTestResult.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = state.connectionTestResult.orEmpty(),
                        color = if (state.connectionTestOk) GoogleGreen else GoogleRed,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onSendTestNotification,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Icon(imageVector = Icons.Filled.NotificationsActive, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Send Test Notification")
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = onOpenBatteryOptimization,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Filled.BatteryChargingFull, contentDescription = null, tint = GoogleGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Battery Optimization Setup", color = TextPrimary)
                }
            }
        }
    }
}

private fun moneyText(v: Double): String = String.format(Locale.US, "%.2f", v)

private fun cleanDecimal(raw: String): String {
    val cleaned = raw.replace(',', '.').filter { ch -> ch.isDigit() || ch == '.' }
    val firstDot = cleaned.indexOf('.')
    return if (firstDot < 0) cleaned
    else cleaned.substring(0, firstDot + 1) + cleaned.substring(firstDot + 1).replace(".", "")
}

@Composable
private fun TradeSizeCard(
    alertSettings: AlertSettings,
    onSaveCapital: (Double) -> Unit,
    onSaveMaxLoss: (Double) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val capital = alertSettings.effectiveCapitalUsd
    val maxLoss = alertSettings.effectiveMaxLossUsd

    var capitalText by remember { mutableStateOf(moneyText(capital)) }
    var lossText by remember { mutableStateOf(moneyText(maxLoss)) }
    var capitalFocused by remember { mutableStateOf(false) }
    var lossFocused by remember { mutableStateOf(false) }
    LaunchedEffect(capital) { if (!capitalFocused) capitalText = moneyText(capital) }
    LaunchedEffect(maxLoss) { if (!lossFocused) lossText = moneyText(maxLoss) }

    fun commitCapital() {
        val value = (capitalText.trim().toDoubleOrNull() ?: capital).coerceAtLeast(1.0)
        capitalText = moneyText(value)
        onSaveCapital(value)
    }

    fun commitLoss() {
        val value = (lossText.trim().toDoubleOrNull() ?: maxLoss).coerceAtLeast(0.01)
        lossText = moneyText(value)
        onSaveMaxLoss(value)
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = PrimaryBlue,
        unfocusedBorderColor = OutlineDark,
        focusedTextColor = TextPrimary,
        unfocusedTextColor = TextPrimary
    )

    SettingsCard(title = "Trade size & risk") {
        Text(
            text = "Your stop-loss and take-profit come from these two numbers. The stop sits where you would lose your max loss on a trade of this size. The model is trained on these same distances.",
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = capitalText,
                onValueChange = { capitalText = cleanDecimal(it) },
                label = { Text("Trade amount (USD)", fontSize = 12.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
                modifier = Modifier
                    .weight(1f)
                    .onFocusChanged { focus ->
                        val was = capitalFocused
                        capitalFocused = focus.isFocused
                        if (was && !focus.isFocused) commitCapital()
                    },
                colors = fieldColors
            )
            OutlinedTextField(
                value = lossText,
                onValueChange = { lossText = cleanDecimal(it) },
                label = { Text("Max loss (USD)", fontSize = 12.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    commitLoss()
                    focusManager.clearFocus()
                }),
                modifier = Modifier
                    .weight(1f)
                    .onFocusChanged { focus ->
                        val was = lossFocused
                        lossFocused = focus.isFocused
                        if (was && !focus.isFocused) commitLoss()
                    },
                colors = fieldColors
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = String.format(
                Locale.US,
                "Stop loss: -%.2f%% (lose \$%.2f) · Take profit: +%.2f%% (win \$%.2f)",
                alertSettings.stopLossPct,
                alertSettings.slUsd,
                alertSettings.takeProfitPct,
                alertSettings.tpUsd
            ),
            color = GoogleGreen,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp
        )
        Text(
            text = "Take profit = stop x the profit multiplier below. Very tight stops get hit by normal price movement, so expect more stop-outs. The stop is never tighter than 0.10%.",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
    }
}

@Composable
private fun SafetyCard(onlyProven: Boolean, onToggle: (Boolean) -> Unit) {
    SettingsCard(title = "Safety check") {
        ToggleRow("Only alert on assets that have proven themselves", onlyProven, onToggle)
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "The app practises on each asset's last 3 weeks of data. An asset is proven when at least " +
                "${ProvenGate.MIN_TRADES} practice trades were made and they ended in profit overall. " +
                "Until then you will see \"Signal seen but not alerted\" instead of an alert. Turn this off to get every signal.",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
    }
}

@Composable
private fun MlParametersCard(
    alertSettings: AlertSettings,
    onSaveMultiplier: (Double) -> Unit,
    onSaveThreshold: (Double) -> Unit,
    onToggleMaster: (Boolean) -> Unit,
    onSaveMasterAsset: (String) -> Unit,
    onRunSequentialRetrain: () -> Unit
) {
    val focusManager = LocalFocusManager.current
    val mult = alertSettings.effectiveMinProfitMultiplier
    val threshold = alertSettings.effectiveSignalThreshold

    var multText by remember { mutableStateOf(String.format(Locale.US, "%.2f", mult)) }
    var multFocused by remember { mutableStateOf(false) }
    // Follow the saved value only while the field is not being edited, so typing is never overwritten.
    LaunchedEffect(mult) {
        if (!multFocused) multText = String.format(Locale.US, "%.2f", mult)
    }

    fun commitMult() {
        val parsed = multText.trim().replace(',', '.').toDoubleOrNull()
        val clamped = ((parsed ?: mult).coerceIn(
            AlertSettings.MIN_PROFIT_MULTIPLIER,
            AlertSettings.MAX_PROFIT_MULTIPLIER
        ) * 100.0).roundToInt() / 100.0
        multText = String.format(Locale.US, "%.2f", clamped)
        onSaveMultiplier(clamped)
    }

    SettingsCard(title = "Signal strictness & profit target") {
        Text(
            text = String.format(
                Locale.US,
                "Profit target: %.2fx the stop (min 1.0) · Model must be %.0f%% sure",
                mult,
                threshold * 100.0
            ),
            color = GoogleGreen,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = multText,
                onValueChange = { raw ->
                    val cleaned = raw.replace(',', '.').filter { ch -> ch.isDigit() || ch == '.' }
                    val firstDot = cleaned.indexOf('.')
                    multText = if (firstDot < 0) cleaned
                    else cleaned.substring(0, firstDot + 1) + cleaned.substring(firstDot + 1).replace(".", "")
                },
                label = { Text("Min Profit Multiplier (decimal, min 1.0)", fontSize = 12.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    commitMult()
                    focusManager.clearFocus()
                }),
                modifier = Modifier
                    .weight(1f)
                    .onFocusChanged { focus ->
                        val wasFocused = multFocused
                        multFocused = focus.isFocused
                        // Save only when the user leaves the field, never on first composition.
                        if (wasFocused && !focus.isFocused) commitMult()
                    },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = OutlineDark,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            OutlinedButton(
                onClick = {
                    val next = ((mult - 0.1) * 100.0).roundToInt() / 100.0
                    onSaveMultiplier(next.coerceAtLeast(AlertSettings.MIN_PROFIT_MULTIPLIER))
                },
                enabled = mult > AlertSettings.MIN_PROFIT_MULTIPLIER + 1e-6,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
            ) { Text("-0.1", color = TextPrimary, fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = {
                    val next = ((mult + 0.1) * 100.0).roundToInt() / 100.0
                    onSaveMultiplier(next.coerceAtMost(AlertSettings.MAX_PROFIT_MULTIPLIER))
                },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
            ) { Text("+0.1", color = TextPrimary, fontWeight = FontWeight.Bold) }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("How sure the model must be (higher = fewer alerts)", color = TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onSaveThreshold((((threshold - 0.02) * 100.0).roundToInt() / 100.0).coerceAtLeast(0.50)) },
                    enabled = threshold > 0.50 + 1e-6,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                ) { Text("-", color = TextPrimary, fontWeight = FontWeight.Bold) }
                Text(
                    text = "${(threshold * 100.0).roundToInt()}%",
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                OutlinedButton(
                    onClick = { onSaveThreshold((((threshold + 0.02) * 100.0).roundToInt() / 100.0).coerceAtMost(0.85)) },
                    enabled = threshold < 0.85 - 1e-6,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                ) { Text("+", color = TextPrimary, fontWeight = FontWeight.Bold) }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        ToggleRow(
            "Also watch the market leader (${alertSettings.effectiveMasterAsset})",
            alertSettings.observeWithMaster,
            onToggleMaster
        )

        var masterText by remember { mutableStateOf(alertSettings.effectiveMasterAsset) }
        LaunchedEffect(alertSettings.masterAsset) {
            masterText = alertSettings.effectiveMasterAsset
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Market leader symbol (default BTCUSDT)",
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf("BTCUSDT", "ETHUSDT", "SOLUSDT").forEach { preset ->
                FilterChip(
                    selected = alertSettings.effectiveMasterAsset == preset,
                    onClick = {
                        masterText = preset
                        onSaveMasterAsset(preset)
                    },
                    label = { Text(preset.removeSuffix("USDT"), fontSize = 11.5.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryBlue,
                        selectedLabelColor = Color.White,
                        containerColor = SurfaceVariantDark,
                        labelColor = TextPrimary
                    )
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = masterText,
                onValueChange = { masterText = it.uppercase() },
                label = { Text("Market leader symbol", fontSize = 12.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    onSaveMasterAsset(masterText)
                    focusManager.clearFocus()
                }),
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = OutlineDark,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            OutlinedButton(
                onClick = {
                    onSaveMasterAsset(masterText)
                    focusManager.clearFocus()
                },
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text("Set", color = TextPrimary, fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = {
                commitMult()
                focusManager.clearFocus()
                onRunSequentialRetrain()
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
        ) {
            Icon(imageVector = Icons.Filled.AutoAwesome, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Trigger Sequential Asset Retrain")
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = PrimaryBlue,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = OutlineDark
            )
        )
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun BatteryOptimizationScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val isIgnoring = isIgnoringBatteryOptimizations(context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Text(
                text = "Battery Optimization",
                color = TextPrimary,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (isIgnoring) {
                        "Status: Unrestricted (Battery optimization disabled)"
                    } else {
                        "Status: Optimized (Android may pause background alerts)"
                    },
                    color = if (isIgnoring) GoogleGreen else GoogleRed,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Allow unrestricted background battery usage so daily sequential retraining and Positioned Exit alerts continue running reliably when the screen is off.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Button(
                    onClick = { openBatterySettings(context) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Open Battery Settings")
                }
            }
        }
    }
}

private fun isIgnoringBatteryOptimizations(context: Context): Boolean {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}

private fun openBatterySettings(context: Context) {
    val requestIntent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
        data = Uri.parse("package:${context.packageName}")
    }
    runCatching {
        context.startActivity(requestIntent)
    }.onFailure {
        val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        runCatching { context.startActivity(fallback) }
    }
}
