package com.trendlinealerts.app.di

import com.trendlinealerts.app.data.analytics.MlPersistence
import android.content.Context
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import com.trendlinealerts.app.data.analytics.MlOrchestrator
import com.trendlinealerts.app.data.cache.TimeframeCandleCache
import com.trendlinealerts.app.data.local.AppDatabase
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.remote.BinanceFuturesApi
import com.trendlinealerts.app.data.remote.BinanceSpotApi
import com.trendlinealerts.app.data.remote.BybitApi
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.OkxApi
import com.trendlinealerts.app.data.repository.AlertLogRepository
import com.trendlinealerts.app.data.repository.ModelStateRepository
import com.trendlinealerts.app.data.repository.MonitorStateRepository
import com.trendlinealerts.app.data.repository.WatchlistRepository
import java.util.concurrent.TimeUnit
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit

class AppContainer(context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .callTimeout(25, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("Accept", "application/json")
                .build()
            chain.proceed(req)
        }
        .build()

    private val contentType = "application/json".toMediaType()

    private fun buildRetrofit(baseUrl: String): Retrofit {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()
    }

    private val bybitApi: BybitApi = buildRetrofit("https://api.bybit.com/").create(BybitApi::class.java)
    private val binanceFuturesApi: BinanceFuturesApi = buildRetrofit("https://fapi.binance.com/").create(BinanceFuturesApi::class.java)
    private val binanceSpotApi: BinanceSpotApi = buildRetrofit("https://api.binance.com/").create(BinanceSpotApi::class.java)
    private val okxApi: OkxApi = buildRetrofit("https://www.okx.com/").create(OkxApi::class.java)

    val database: AppDatabase = AppDatabase.create(context)
    val settingsDataStore = SettingsDataStore(context)

    val marketDataCoordinator = MarketDataCoordinator(
        bybitApi = bybitApi,
        binanceFuturesApi = binanceFuturesApi,
        binanceSpotApi = binanceSpotApi,
        okxApi = okxApi
    )

    val candleCache = TimeframeCandleCache(
        filesDir = context.filesDir,
        coordinator = marketDataCoordinator
    )

    val watchlistRepository = WatchlistRepository(
        dao = database.watchlistDao(),
        coordinator = marketDataCoordinator
    )

    val symbolStateDao = database.symbolStateDao()
    val alertLogRepository = AlertLogRepository(database.alertLogDao())
    val monitorStateRepository = MonitorStateRepository()
    val modelStateRepository = ModelStateRepository()

    val mlPersistence = MlPersistence(context)

    val mlOrchestrator = MlOrchestrator(
        candleCache = candleCache,
        watchlistRepo = watchlistRepository,
        symbolStateDao = symbolStateDao,
        settingsDataStore = settingsDataStore,
        modelStateRepo = modelStateRepository,
        monitorStateRepo = monitorStateRepository,
        persistence = mlPersistence
    )
}
