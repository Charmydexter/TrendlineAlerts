# Trading Alerts v3.0 (Android Kotlin + Jetpack Compose)

Single-timeframe scalping machine learning alerts powered by L2-regularized Logistic Regression, 20 scalping indicators (including Rolling Price Z-Score, Normalized Linear Regression Slope and Donchian Channel Position), cross-asset Master Model observation, rolling 21-day drift analytics, and Positioned Exit exhaustion alerts.

## Architecture
- `core/`: Pure Kotlin JVM engine (`CoreModels.kt`, `ScalpingIndicators.kt`, `LogisticMlEngine.kt`, `AlertDispatcher.kt`, `HeikinAshiConverter`, JUnit4 unit tests).
- `app/`: Native Android app using Jetpack Compose, Foreground Service, Room + DataStore, gzipped binary candle cache (`TimeframeCandleCache`), and direct OkHttp/Retrofit feeds to Bybit, Binance, and OKX.

## Building the APK via GitHub Actions
1. Push this repository (or create a branch off `main` and push there).
2. GitHub Actions automatically runs `.github/workflows/build-apk.yml` (`gradle :core:test` + `gradle :app:assembleDebug`).
3. Open the **Actions** tab on GitHub, click the finished workflow run, and download the **`TradingAlerts-apk`** artifact (`TradingAlerts.apk`).


## v3.1 changes
- Retrain can be stopped and resumed, and no longer sticks; ML Overview has an All-assets view, short labels (3wks) and sideways asset chips.
- Trade amount + max loss set the stop-loss and take-profit (shown on the chart, rows and alerts); the model trains on the same distances.
- Trades started by an alert are followed: entry assumed 3 minutes after the alert, exit/cancel/target/stop alerts, not-entered trades are not counted.
- Entries need price at a regression-channel edge and the model to agree ("fewer, cleaner" signals); the channel is the default chart overlay.
- Time-of-day / weekend clues, a "proven first" safety check, saved models (restart without retraining) and 12 months of daily results.
- Alert Log, Overview and Settings reworded in plain language.
