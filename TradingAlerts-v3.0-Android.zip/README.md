# Trading Alerts v3.0 (Android Kotlin + Jetpack Compose)

Single-timeframe scalping machine learning alerts powered by L2-regularized Logistic Regression, 20 scalping indicators (including Rolling Price Z-Score, Normalized Linear Regression Slope and Donchian Channel Position), cross-asset Master Model observation, rolling 21-day drift analytics, and Positioned Exit exhaustion alerts.

## Architecture
- `core/`: Pure Kotlin JVM engine (`CoreModels.kt`, `ScalpingIndicators.kt`, `LogisticMlEngine.kt`, `AlertDispatcher.kt`, `HeikinAshiConverter`, JUnit4 unit tests).
- `app/`: Native Android app using Jetpack Compose, Foreground Service, Room + DataStore, gzipped binary candle cache (`TimeframeCandleCache`), and direct OkHttp/Retrofit feeds to Bybit, Binance, and OKX.

## Building the APK via GitHub Actions
1. Push this repository (or create a branch off `main` and push there).
2. GitHub Actions automatically runs `.github/workflows/build-apk.yml` (`gradle :core:test` + `gradle :app:assembleDebug`).
3. Open the **Actions** tab on GitHub, click the finished workflow run, and download the **`TradingAlerts-apk`** artifact (`TradingAlerts.apk`).
