package com.trendlinealerts.core.detector

import com.trendlinealerts.core.engine.EngineResult
import com.trendlinealerts.core.engine.HtfLineBook
import com.trendlinealerts.core.engine.LineProvider
import com.trendlinealerts.core.engine.TrendlineEngine
import com.trendlinealerts.core.model.ActiveTrendline
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.NearestLineInfo
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide
import kotlin.math.abs

data class SignalResult(
    val state: SymbolSignalState,
    val events: List<TrendlineCandidate>,
    /** Trendlines as of `nowMs` (for display / debug). */
    val current: EngineResult?,
    val nearestOverall: NearestLineInfo?,
    val nearestSupport: NearestLineInfo?,
    val nearestResistance: NearestLineInfo?,
    val lowestSupport: NearestLineInfo? = null,
    val highestResistance: NearestLineInfo? = null
)

/**
 * Runs closed 1m bars, in order, through the signal rules.
 *
 * GENERAL assets:
 *  - Bullish mode (Long only): entered when a newly formed resistance line is strictly higher than the other
 *    active resistance lines. Fires [EventType.LONG_ENTRY] when price hits the lowest support.
 *  - Bearish mode (Short only): entered when a newly formed support line is strictly lower than the other
 *    active support lines. Fires [EventType.SHORT_ENTRY] when price hits the highest resistance.
 *  - 1-hour individual reset: [GENERAL_COOLDOWN_MS] (1 hour) after LONG fires, Long resets so if still Bullish
 *    and price hits the lowest support again >= 1h later, Long fires again. Same independently for SHORT.
 *
 * POSITIONED assets -> CROSS alerts (+ NEW R1/S1 line alerts); no long / short.
 *
 * A bar "touches" a line when its range reaches the line while the line was on the approach side
 * of the bar's open (support below the open, resistance above it). Pierce and touch are the same.
 * Each bar is processed exactly once; replaying missed minutes uses the same code, with
 * `missed = true` on events older than [LIVE_WINDOW_MS].
 */
class SignalProcessor(private val engine: TrendlineEngine = TrendlineEngine()) {

    companion object {
        const val BAR_MS = 60_000L
        const val LIVE_WINDOW_MS = 150_000L
        const val GENERAL_COOLDOWN_MS = 3_600_000L
    }

    fun process(
        symbol: String,
        previous: SymbolSignalState,
        mode: AssetMode,
        htfClosed: List<Candle>,
        timeframe: Timeframe,
        bars1m: List<Candle>,
        lastPrice: Double,
        settings: AlertSettings,
        nowMs: Long,
        lineProvider: LineProvider? = null
    ): SignalResult {
        var st = if (previous.mode != mode) {
            SymbolSignalState(symbol = symbol, mode = mode, lastProcessedOpenMs = previous.lastProcessedOpenMs)
        } else previous

        val tfMs = timeframe.ms
        val book: LineProvider = lineProvider ?: HtfLineBook(engine, htfClosed, tfMs)
        val events = mutableListOf<TrendlineCandidate>()

        val ordered = bars1m.filter { it.isClosed && it.openTimeMs > st.lastProcessedOpenMs }.sortedBy { it.openTimeMs }
        for (bar in ordered) {
            val t = bar.openTimeMs + BAR_MS
            val missed = t < nowMs - LIVE_WINDOW_MS
            val res = book.resultAsOf(bar.openTimeMs)

            // Swap gap (Pine: one bar without a value when a slot's line is replaced).
            val skipped = HashSet<SlotId>()
            val newKeys = HashMap<String, String>()
            for (slot in SlotId.entries) {
                val key = res.lines[slot]?.pivotKey ?: ""
                if (st.slotKeys[slot.name] != key) skipped.add(slot)
                newKeys[slot.name] = key
            }
            st = st.copy(slotKeys = newKeys)

            val allEnabledLines = res.lines.values.filter { it.slotId in settings.enabledSlots }
            val lines = allEnabledLines.filter { it.slotId !in skipped }

            when (mode) {
                AssetMode.GENERAL -> st = stepGeneral(symbol, st, bar, t, allEnabledLines, skipped, nowMs, missed, events)
                AssetMode.POSITIONED -> st = stepPositioned(symbol, st, bar, t, lines, res, nowMs, missed, events)
            }
            st = st.copy(lastProcessedOpenMs = bar.openTimeMs)
        }

        val current = if (lineProvider != null || htfClosed.isNotEmpty()) book.resultAsOf(nowMs) else null
        var nearest: NearestLineInfo? = null
        var nearestS: NearestLineInfo? = null
        var nearestR: NearestLineInfo? = null
        var lowestS: NearestLineInfo? = null
        var highestR: NearestLineInfo? = null
        current?.lines?.values?.filter { it.slotId in settings.enabledSlots }?.forEach { line ->
            val v = line.valueAt(nowMs)
            if (v <= 0.0) return@forEach
            val info = NearestLineInfo(line.slotId, line.side, v, (lastPrice - v) / v * 100.0)
            if (nearest == null || abs(info.distancePct) < abs(nearest!!.distancePct)) nearest = info
            if (line.side == TrendlineSide.SUPPORT) {
                if (nearestS == null || abs(info.distancePct) < abs(nearestS!!.distancePct)) nearestS = info
                if (lowestS == null || v < lowestS!!.lineValue) lowestS = info
            } else {
                if (nearestR == null || abs(info.distancePct) < abs(nearestR!!.distancePct)) nearestR = info
                if (highestR == null || v > highestR!!.lineValue) highestR = info
            }
        }

        return SignalResult(st, events, current, nearest, nearestS, nearestR, lowestS, highestR)
    }

    // ───────────────────────────── GENERAL: regime + lowest S / highest R ─────────────────────────────

    private fun stepGeneral(
        symbol: String,
        st0: SymbolSignalState,
        bar: Candle,
        t: Long,
        allEnabledLines: List<ActiveTrendline>,
        skipped: Set<SlotId>,
        nowMs: Long,
        missed: Boolean,
        out: MutableList<TrendlineCandidate>
    ): SymbolSignalState {
        val resistances = allEnabledLines.filter { it.side == TrendlineSide.RESISTANCE }
        val supports = allEnabledLines.filter { it.side == TrendlineSide.SUPPORT }
        val currentRKeys = resistances.map { it.pivotKey }.toSet()
        val currentSKeys = supports.map { it.pivotKey }.toSet()

        if (!st0.generalInitialized) {
            return st0.copy(
                generalInitialized = true,
                knownResistanceKeys = currentRKeys,
                knownSupportKeys = currentSKeys
            )
        }

        val highestR = resistances.maxByOrNull { it.valueAt(t) }
        val lowestS = supports.minByOrNull { it.valueAt(t) }

        val newHighestR = highestR != null &&
            highestR.pivotKey !in st0.knownResistanceKeys &&
            resistances.all { it.slotId == highestR.slotId || highestR.valueAt(t) > it.valueAt(t) }

        val newLowestS = lowestS != null &&
            lowestS.pivotKey !in st0.knownSupportKeys &&
            supports.all { it.slotId == lowestS.slotId || lowestS.valueAt(t) < it.valueAt(t) }

        val nextBias = when {
            newHighestR && !newLowestS -> EntryDirection.LONG
            newLowestS && !newHighestR -> EntryDirection.SHORT
            else -> st0.trendBias
        }

        var st = st0.copy(
            trendBias = nextBias,
            knownResistanceKeys = currentRKeys,
            knownSupportKeys = currentSKeys
        )

        when (nextBias) {
            EntryDirection.LONG -> {
                val target = lowestS
                val cooldownElapsed = st.lastLongFiredAtMs == null || (t - st.lastLongFiredAtMs) >= GENERAL_COOLDOWN_MS
                if (target != null &&
                    target.slotId !in skipped &&
                    cooldownElapsed &&
                    onApproachSide(target.valueAt(t), bar, isSupport = true) &&
                    touched(target.valueAt(t), bar, isSupport = true)
                ) {
                    st = st.copy(
                        lastLongFiredAtMs = t,
                        lastEntryDirection = EntryDirection.LONG
                    )
                    out.add(
                        TrendlineCandidate(
                            symbol = symbol,
                            slotId = target.slotId,
                            side = target.side,
                            eventType = EventType.LONG_ENTRY,
                            price = bar.close,
                            lineValue = target.valueAt(t),
                            timestampMs = nowMs,
                            eventTimeMs = t,
                            missed = missed
                        )
                    )
                }
            }
            EntryDirection.SHORT -> {
                val target = highestR
                val cooldownElapsed = st.lastShortFiredAtMs == null || (t - st.lastShortFiredAtMs) >= GENERAL_COOLDOWN_MS
                if (target != null &&
                    target.slotId !in skipped &&
                    cooldownElapsed &&
                    onApproachSide(target.valueAt(t), bar, isSupport = false) &&
                    touched(target.valueAt(t), bar, isSupport = false)
                ) {
                    st = st.copy(
                        lastShortFiredAtMs = t,
                        lastEntryDirection = EntryDirection.SHORT
                    )
                    out.add(
                        TrendlineCandidate(
                            symbol = symbol,
                            slotId = target.slotId,
                            side = target.side,
                            eventType = EventType.SHORT_ENTRY,
                            price = bar.close,
                            lineValue = target.valueAt(t),
                            timestampMs = nowMs,
                            eventTimeMs = t,
                            missed = missed
                        )
                    )
                }
            }
            null -> Unit
        }
        return st
    }

    private fun onApproachSide(value: Double, bar: Candle, isSupport: Boolean) =
        if (isSupport) value < bar.open else value > bar.open

    private fun touched(value: Double, bar: Candle, isSupport: Boolean) =
        if (isSupport) bar.low <= value else bar.high >= value

    // ───────────────────────────── POSITIONED: cross alerts ─────────────────────────────

    private fun stepPositioned(
        symbol: String,
        st0: SymbolSignalState,
        bar: Candle,
        t: Long,
        lines: List<ActiveTrendline>,
        res: EngineResult,
        nowMs: Long,
        missed: Boolean,
        out: MutableList<TrendlineCandidate>
    ): SymbolSignalState {
        var st = st0

        // New R1 / S1 line (live only; skipped on the first bar and on replayed minutes).
        val r1Key = res.lines[SlotId.R1]?.pivotKey
        val s1Key = res.lines[SlotId.S1]?.pivotKey
        if (!missed) {
            if (st.r1Key != null && r1Key != null && r1Key != st.r1Key) {
                out.add(newLineEvent(symbol, res.lines.getValue(SlotId.R1), EventType.NEW_RESISTANCE, bar, t, nowMs))
            }
            if (st.s1Key != null && s1Key != null && s1Key != st.s1Key) {
                out.add(newLineEvent(symbol, res.lines.getValue(SlotId.S1), EventType.NEW_SUPPORT, bar, t, nowMs))
            }
        }
        st = st.copy(r1Key = r1Key ?: st.r1Key, s1Key = s1Key ?: st.s1Key)

        // Supports must be below the open, resistances above it. Highest support / lowest resistance is reached first.
        val s = if (st.lastCrossSide == TrendlineSide.SUPPORT) null else lines
            .filter { it.side == TrendlineSide.SUPPORT && onApproachSide(it.valueAt(t), bar, true) && touched(it.valueAt(t), bar, true) }
            .maxByOrNull { it.valueAt(t) }
        val r = if (st.lastCrossSide == TrendlineSide.RESISTANCE) null else lines
            .filter { it.side == TrendlineSide.RESISTANCE && onApproachSide(it.valueAt(t), bar, false) && touched(it.valueAt(t), bar, false) }
            .minByOrNull { it.valueAt(t) }

        val chosen = when {
            s != null && r != null -> if (abs(bar.open - s.valueAt(t)) <= abs(bar.open - r.valueAt(t))) s else r
            else -> s ?: r
        }
        if (chosen != null) {
            val isSupport = chosen.side == TrendlineSide.SUPPORT
            st = st.copy(lastCrossSide = chosen.side)
            out.add(
                TrendlineCandidate(
                    symbol = symbol,
                    slotId = chosen.slotId,
                    side = chosen.side,
                    eventType = if (isSupport) EventType.CROSS_SUPPORT else EventType.CROSS_RESISTANCE,
                    price = bar.close,
                    lineValue = chosen.valueAt(t),
                    timestampMs = nowMs,
                    eventTimeMs = t,
                    missed = missed
                )
            )
        }
        return st
    }

    private fun newLineEvent(
        symbol: String,
        line: ActiveTrendline,
        type: EventType,
        bar: Candle,
        t: Long,
        nowMs: Long
    ) = TrendlineCandidate(symbol, line.slotId, line.side, type, bar.close, line.valueAt(t), nowMs, t, false)
}
