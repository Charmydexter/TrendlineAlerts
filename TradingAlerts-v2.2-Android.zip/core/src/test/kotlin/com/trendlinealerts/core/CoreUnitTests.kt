package com.trendlinealerts.core

import com.trendlinealerts.core.detector.SignalProcessor
import com.trendlinealerts.core.detector.SignalResult
import com.trendlinealerts.core.dispatcher.AlertDispatcher
import com.trendlinealerts.core.engine.EngineResult
import com.trendlinealerts.core.engine.HtfLineBook
import com.trendlinealerts.core.engine.LineProvider
import com.trendlinealerts.core.engine.PivotStack
import com.trendlinealerts.core.engine.TrendlineEngine
import com.trendlinealerts.core.model.ActiveTrendline
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.PivotPoint
import com.trendlinealerts.core.model.SignalStateCodec
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreUnitTests {

    private val T0 = 6_000_000L
    private val TF = 180_000L
    private val BAR = 60_000L

    // ───────────────────────── helpers ─────────────────────────

    private fun piv(price: Double, idx: Int = 0, t: Long = 0L) = PivotPoint(idx, t, price)

    private fun htf(i: Int, high: Double) =
        Candle(T0 + i * TF, high - 1.0, high, high - 5.0, high - 1.0)

    private fun bar(i: Int, o: Double, h: Double, l: Double, c: Double) =
        Candle(T0 + i * BAR, o, h, l, c)

    /** A horizontal line. `id` makes its pivot pair (its identity) unique. */
    private fun flat(slot: SlotId, price: Double, id: Int) = ActiveTrendline(
        slotId = slot,
        side = slot.side,
        older = PivotPoint(0, id * 1000L, price),
        newer = PivotPoint(1, id * 1000L + TF, price),
        slopePerBar = 0.0,
        tfMs = TF
    )

    private fun provider(vararg lines: ActiveTrendline) = object : LineProvider {
        override fun resultAsOf(timeMs: Long) = EngineResult(
            lines = lines.associateBy { it.slotId },
            resistancePivots = emptyList(),
            supportPivots = emptyList(),
            pendingResistance = null,
            pendingSupport = null,
            resistanceCount = 0,
            supportCount = 0,
            closedBarCount = 0
        )
    }

    private val proc = SignalProcessor()

    /** nowMs = T0 keeps every event "live" (never flagged missed). */
    private fun run(
        mode: AssetMode,
        p: LineProvider,
        bars: List<Candle>,
        prev: SymbolSignalState = SymbolSignalState("TEST"),
        now: Long = T0
    ): SignalResult = proc.process(
        symbol = "TEST",
        previous = prev,
        mode = mode,
        htfClosed = emptyList(),
        timeframe = Timeframe.M3,
        bars1m = bars,
        lastPrice = bars.last().close,
        settings = AlertSettings(),
        nowMs = now,
        lineProvider = p
    )

    private fun types(r: SignalResult) = r.events.map { it.eventType to it.slotId }

    // ───────────────────────── pivot stack ─────────────────────────

    @Test
    fun resistanceStackKeepsDescendingOrder() {
        val s = PivotStack(1.0)
        listOf(100.0, 90.0, 80.0).forEach { s.onPivot(piv(it)) }
        assertEquals(listOf(80.0, 90.0, 100.0), s.newest(3).map { it.price })
        assertNull(s.pending)
    }

    @Test
    fun higherHighBecomesPendingThenPromotedWhenPivotComesBackInside() {
        val s = PivotStack(1.0)
        s.onPivot(piv(100.0))
        s.onPivot(piv(110.0))
        assertEquals(110.0, s.pending!!.price, 0.0)
        assertEquals(listOf(100.0), s.newest(4).map { it.price })

        s.onPivot(piv(105.0)) // came back inside: 110 is valid, pops the 100 it outranks
        assertNull(s.pending)
        assertEquals(listOf(105.0, 110.0), s.newest(4).map { it.price })
    }

    @Test
    fun moreExtremePivotReplacesPending() {
        val s = PivotStack(1.0)
        listOf(100.0, 110.0, 120.0).forEach { s.onPivot(piv(it)) }
        assertEquals(120.0, s.pending!!.price, 0.0)
        assertEquals(listOf(100.0), s.newest(4).map { it.price })
    }

    @Test
    fun supportStackMirrorsResistance() {
        val s = PivotStack(-1.0)
        listOf(100.0, 90.0, 95.0).forEach { s.onPivot(piv(it)) } // lower low pending, then promoted
        assertEquals(listOf(95.0, 90.0), s.newest(4).map { it.price })
    }

    @Test
    fun stackIsCappedAtFifty() {
        val s = PivotStack(1.0)
        for (i in 0 until 60) s.onPivot(piv(1000.0 - i, i, i.toLong()))
        assertEquals(50, s.size)
    }

    // ───────────────────────── engine ─────────────────────────

    @Test
    fun strictPivotChainBuildsLineWithBarSlope() {
        val highs = listOf(10, 20, 30, 20, 10, 10, 12, 20, 25, 20, 12, 10).map { it.toDouble() }
        val candles = highs.mapIndexed { i, h -> htf(i, h) }
        val r = TrendlineEngine().build(candles, TF)

        val r1 = r.lines[SlotId.R1]
        assertNotNull(r1)
        assertEquals(-5.0 / 6.0, r1!!.slopePerBar, 1e-9)
        // 3 bars after the newer pivot (index 8): 25 + 3 * (-5/6) = 22.5
        assertEquals(22.5, r1.valueAt(candles[11].openTimeMs), 1e-9)
        assertNull(r.lines[SlotId.R2])
        assertTrue(r.lines.keys.none { it.side == TrendlineSide.SUPPORT })
    }

    @Test
    fun equalHighsDoNotFormAPivot() {
        // 20 == 20 breaks the strict chain: no pivot, no line
        val highs = listOf(10, 20, 20, 20, 10, 10, 12, 20, 25, 20, 12, 10).map { it.toDouble() }
        val r = TrendlineEngine().build(highs.mapIndexed { i, h -> htf(i, h) }, TF)
        assertEquals(1, r.resistanceCount)
        assertTrue(r.lines.isEmpty())
    }

    @Test
    fun lineBookOnlyUsesFullyClosedHtfBars() {
        val candles = (0 until 12).map { htf(it, 10.0 + it) }
        val book = HtfLineBook(TrendlineEngine(), candles, TF)
        assertEquals(5, book.closedCountAsOf(T0 + 5 * TF))
        assertEquals(5, book.closedCountAsOf(T0 + 5 * TF + TF - 1))
        assertEquals(6, book.closedCountAsOf(T0 + 6 * TF))
    }

    // ───────────────────────── GENERAL: regime + 1h individual reset ─────────────────────────

    private val s1 get() = flat(SlotId.S1, 100.0, 1)
    private val s2 get() = flat(SlotId.S2, 98.0, 2)
    private val r1 get() = flat(SlotId.R1, 110.0, 3)
    private val r2 get() = flat(SlotId.R2, 112.0, 4)

    @Test
    fun firstBarAfterStartIsNeutralAndNeverAlerts() {
        val r = run(AssetMode.GENERAL, provider(s1, r1), listOf(bar(0, 105.0, 111.0, 99.0, 101.0)))
        assertTrue(r.events.isEmpty())
        assertTrue(r.state.generalInitialized)
        assertNull(r.state.trendBias)
    }

    @Test
    fun existingBiasIsRequiredBeforeFiringEvenWhenExtremeLinesAreTouched() {
        val r = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, r2),
            listOf(
                bar(0, 105.0, 106.0, 104.0, 105.0),
                bar(1, 105.0, 113.0, 97.5, 105.0) // touches both lowest support & highest resistance while still Neutral
            )
        )
        assertTrue(r.events.isEmpty())
        assertNull(r.state.trendBias)
    }

    @Test
    fun newHighestResistanceEntersBullishAndLowestSupportFiresLong() {
        val base = provider(s1, s2, r1, r2)
        val init = run(
            AssetMode.GENERAL,
            base,
            listOf(bar(0, 105.0, 106.0, 104.0, 105.0))
        )

        val r3High = flat(SlotId.R3, 115.0, 10)
        val withNewHighR = provider(s1, s2, r1, r2, r3High)
        val step = run(
            AssetMode.GENERAL,
            withNewHighR,
            listOf(
                bar(1, 105.0, 106.0, 99.5, 101.0), // R3 (115) forms -> Bullish; touches S1 (100, NOT lowest) -> no Long
                bar(2, 101.0, 101.5, 97.8, 98.5)  // touches S2 (98, lowest support) -> LONG_ENTRY S2
            ),
            prev = init.state
        )
        assertEquals(com.trendlinealerts.core.model.EntryDirection.LONG, step.state.trendBias)
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S2), types(step))
    }

    @Test
    fun newLowestSupportResetsToShortOnlyAndHighestResistanceFiresShort() {
        val bullStart = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, r2),
            listOf(bar(0, 105.0, 106.0, 104.0, 105.0))
        )
        val bullish = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, r2, flat(SlotId.R3, 115.0, 10)),
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0)),
            prev = bullStart.state
        )
        assertEquals(com.trendlinealerts.core.model.EntryDirection.LONG, bullish.state.trendBias)

        // New support S3 at 95 (< S1 100 and S2 98) resets asset to Bearish (Short only)
        val s3Low = flat(SlotId.S3, 95.0, 11)
        val r3High = flat(SlotId.R3, 115.0, 10)
        val bearish = run(
            AssetMode.GENERAL,
            provider(s1, s2, s3Low, r1, r2, r3High),
            listOf(
                bar(2, 105.0, 105.5, 94.5, 104.0), // S3 forms -> Short only; hitting S3 does NOT fire Long
                bar(3, 104.0, 112.5, 103.5, 111.5), // touches R2 (112, NOT highest 115) -> no Short
                bar(4, 111.5, 115.3, 111.0, 114.5)  // touches R3 (115, highest resistance) -> SHORT_ENTRY R3
            ),
            prev = bullish.state
        )
        assertEquals(com.trendlinealerts.core.model.EntryDirection.SHORT, bearish.state.trendBias)
        assertEquals(listOf(EventType.SHORT_ENTRY to SlotId.R3), types(bearish))
    }

    @Test
    fun newNonExtremeLineDoesNotFlipMode() {
        val init = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, r2),
            listOf(bar(0, 105.0, 106.0, 104.0, 105.0))
        )
        val bullish = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, r2, flat(SlotId.R3, 115.0, 10)),
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0)),
            prev = init.state
        )
        assertEquals(com.trendlinealerts.core.model.EntryDirection.LONG, bullish.state.trendBias)

        // New support S3 at 99 is NOT lower than S2 (98), so Bullish bias remains intact
        val s3Mid = flat(SlotId.S3, 99.0, 12)
        val afterMidSupport = run(
            AssetMode.GENERAL,
            provider(s1, s2, s3Mid, r1, r2, flat(SlotId.R3, 115.0, 10)),
            listOf(bar(2, 105.0, 115.5, 104.5, 114.0)),
            prev = bullish.state
        )
        assertEquals(com.trendlinealerts.core.model.EntryDirection.LONG, afterMidSupport.state.trendBias)
        assertTrue(afterMidSupport.events.isEmpty())
    }

    @Test
    fun longResetsAfterOneHourAndFiresAgainIfStillBullish() {
        val r3High = flat(SlotId.R3, 115.0, 10)
        val p = provider(s1, s2, r1, r2, r3High)
        val init = run(AssetMode.GENERAL, provider(s1, s2, r1, r2), listOf(bar(0, 105.0, 106.0, 104.0, 105.0)))
        val firstLong = run(
            AssetMode.GENERAL,
            p,
            listOf(
                bar(1, 105.0, 106.0, 104.0, 105.0), // R3 forms -> Bullish
                bar(2, 101.0, 101.5, 97.8, 98.5)   // t = T0 + 3*BAR -> LONG_ENTRY S2
            ),
            prev = init.state
        )
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S2), types(firstLong))

        // 59 minutes after fire -> still in 1-hour pause
        val beforeHour = run(
            AssetMode.GENERAL,
            p,
            listOf(bar(61, 101.0, 101.5, 97.8, 98.5)), // t = T0 + 62*BAR (59m after firstLong)
            prev = firstLong.state
        )
        assertTrue(beforeHour.events.isEmpty())

        // 60 minutes after fire (T0 + 63*BAR -> 60*BAR = 3,600,000ms) -> resets and fires again
        val afterHour = run(
            AssetMode.GENERAL,
            p,
            listOf(bar(62, 101.0, 101.5, 97.8, 98.5)),
            prev = beforeHour.state
        )
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S2), types(afterHour))
    }

    @Test
    fun longAndShortOneHourPausesAreTrackedIndividually() {
        val r3High = flat(SlotId.R3, 115.0, 10)
        val s3Low = flat(SlotId.S3, 95.0, 11)

        val st0 = run(AssetMode.GENERAL, provider(s1, s2, r1, r2), listOf(bar(0, 105.0, 106.0, 104.0, 105.0))).state
        // Bar 1: S3 forms -> Bearish; Bar 2: hits R2 (112, highest) -> SHORT_ENTRY at T0 + 3*BAR
        val afterShort = run(
            AssetMode.GENERAL,
            provider(s1, s2, s3Low, r1, r2),
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0), bar(2, 110.0, 112.5, 109.5, 111.5)),
            prev = st0
        )
        assertEquals(listOf(EventType.SHORT_ENTRY to SlotId.R2), types(afterShort))

        // Bar 3: R3 (115) forms -> flips Bullish immediately; Bar 4 (2m later): hits S3 (95) -> LONG_ENTRY fires!
        val afterLong = run(
            AssetMode.GENERAL,
            provider(s1, s2, s3Low, r1, r2, r3High),
            listOf(bar(3, 105.0, 106.0, 104.0, 105.0), bar(4, 97.0, 97.5, 94.5, 95.5)),
            prev = afterShort.state
        )
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S3), types(afterLong))

        // Bar 5: S4 (90) forms -> flips Bearish again; Bar 6 (only ~4m since SHORT_ENTRY) hits R3 -> SHORT still paused!
        val s4Lower = flat(SlotId.S1, 90.0, 12)
        val backBearishTooSoon = run(
            AssetMode.GENERAL,
            provider(s4Lower, s2, s3Low, r1, r2, r3High),
            listOf(bar(5, 105.0, 106.0, 104.0, 105.0), bar(6, 113.0, 115.5, 112.5, 114.5)),
            prev = afterLong.state
        )
        assertTrue(backBearishTooSoon.events.isEmpty())

        // Bar 62 (t = T0 + 63*BAR = 60m after Bar 2 SHORT_ENTRY) -> SHORT cooldown elapsed, fires again!
        val afterShortHour = run(
            AssetMode.GENERAL,
            provider(s4Lower, s2, s3Low, r1, r2, r3High),
            listOf(bar(62, 113.0, 115.5, 112.5, 114.5)),
            prev = backBearishTooSoon.state
        )
        assertEquals(listOf(EventType.SHORT_ENTRY to SlotId.R3), types(afterShortHour))
    }

    @Test
    fun supportAbovePriceCannotFireLong() {
        val r3High = flat(SlotId.R3, 115.0, 10)
        val st0 = run(AssetMode.GENERAL, provider(s1, r1), listOf(bar(0, 99.0, 99.5, 98.5, 99.0))).state
        val r = run(
            AssetMode.GENERAL,
            provider(s1, r1, r3High),
            listOf(
                bar(1, 99.0, 99.5, 98.5, 99.0),
                bar(2, 99.0, 100.5, 98.6, 100.2) // support S1=100 is above the open: not approached from above
            ),
            prev = st0
        )
        assertTrue(r.events.isEmpty())
    }

    // ───────────────────────── POSITIONED: cross alerts ─────────────────────────

    @Test
    fun positionedCrossesAlternateAndLowerSupportDoesNotRefire() {
        val p = provider(s1, s2, r1)
        val bars = listOf(
            bar(0, 105.0, 106.0, 104.0, 105.0),
            bar(1, 105.0, 105.0, 99.5, 101.0),   // CROSS_SUPPORT S1
            bar(2, 101.0, 101.0, 97.5, 98.0),    // lower support crossed: nothing
            bar(3, 98.0, 111.0, 97.9, 109.0),    // CROSS_RESISTANCE R1 (re-arms support)
            bar(4, 109.0, 109.5, 97.5, 99.0)     // CROSS_SUPPORT again
        )
        val r = run(AssetMode.POSITIONED, p, bars)
        assertEquals(
            listOf(
                EventType.CROSS_SUPPORT to SlotId.S1,
                EventType.CROSS_RESISTANCE to SlotId.R1,
                EventType.CROSS_SUPPORT to SlotId.S1
            ),
            types(r)
        )
    }

    @Test
    fun positionedNeverProducesLongOrShort() {
        val r = run(
            AssetMode.POSITIONED, provider(s1, s2),
            listOf(bar(0, 105.0, 106.0, 104.0, 105.0), bar(1, 105.0, 105.0, 99.5, 101.0))
        )
        assertTrue(r.events.none { it.eventType == EventType.LONG_ENTRY || it.eventType == EventType.SHORT_ENTRY })
    }

    @Test
    fun positionedSupportAbovePriceIsNotACross() {
        val r = run(
            AssetMode.POSITIONED, provider(s1),
            listOf(bar(0, 99.0, 99.5, 98.5, 99.0), bar(1, 99.0, 100.5, 98.6, 100.2))
        )
        assertTrue(r.events.isEmpty())
    }

    @Test
    fun oldEventsAreFlaggedMissed() {
        val bars = listOf(bar(0, 105.0, 106.0, 104.0, 105.0), bar(1, 105.0, 105.0, 99.5, 101.0))
        val r = run(AssetMode.POSITIONED, provider(s1), bars, now = T0 + 3_600_000L)
        assertEquals(1, r.events.size)
        assertTrue(r.events[0].missed)
    }

    @Test
    fun eachBarIsProcessedOnlyOnce() {
        val bars = listOf(bar(0, 105.0, 106.0, 104.0, 105.0), bar(1, 105.0, 105.0, 99.5, 101.0))
        val first = run(AssetMode.POSITIONED, provider(s1), bars)
        val again = run(AssetMode.POSITIONED, provider(s1), bars, prev = first.state)
        assertTrue(again.events.isEmpty())
    }

    @Test
    fun stateSurvivesJsonRoundTrip() {
        val init = run(AssetMode.GENERAL, provider(s1, s2, r1), listOf(bar(0, 105.0, 106.0, 104.0, 105.0)))
        val r = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, flat(SlotId.R3, 115.0, 10)),
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0), bar(2, 101.0, 101.5, 97.8, 98.5)),
            prev = init.state
        )
        assertNotNull(r.state.lastLongFiredAtMs)
        val back = SignalStateCodec.decode(SignalStateCodec.encode(r.state), "TEST")
        assertEquals(r.state, back)
        assertEquals(SymbolSignalState("X"), SignalStateCodec.decode("not json", "X"))
    }

    // ───────────────────────── dispatcher ─────────────────────────

    private fun cand(
        symbol: String,
        type: EventType,
        missed: Boolean = false,
        eventTime: Long = 1_000L
    ) = TrendlineCandidate(
        symbol = symbol,
        slotId = SlotId.S1,
        side = TrendlineSide.SUPPORT,
        eventType = type,
        price = 1.0,
        lineValue = 1.0,
        timestampMs = 5_000L,
        eventTimeMs = eventTime,
        missed = missed
    )

    @Test
    fun generalLongShortAreClusteredAndPositionedAreSeparate() {
        val plan = AlertDispatcher.plan(
            listOf(
                cand("AAA", EventType.LONG_ENTRY),
                cand("BBB", EventType.SHORT_ENTRY),
                cand("POS", EventType.CROSS_SUPPORT)
            ),
            positionedSymbols = setOf("POS"),
            generalMonitoringOn = true
        )
        assertEquals(listOf("AAA", "BBB"), plan.cluster.map { it.symbol })
        assertEquals(listOf("POS"), plan.individual.map { it.symbol })
        assertTrue(plan.missed.isEmpty())
    }

    @Test
    fun clusterKeepsOneRowPerAsset() {
        val plan = AlertDispatcher.plan(
            listOf(
                cand("AAA", EventType.LONG_ENTRY, eventTime = 1_000L),
                cand("AAA", EventType.SHORT_ENTRY, eventTime = 2_000L)
            ),
            emptySet(), true
        )
        assertEquals(1, plan.cluster.size)
        assertEquals(EventType.SHORT_ENTRY, plan.cluster[0].eventType)
    }

    @Test
    fun missedEventsPositionedNotifyGeneralOnlyLog() {
        val plan = AlertDispatcher.plan(
            listOf(
                cand("POS", EventType.CROSS_SUPPORT, missed = true, eventTime = 1L),
                cand("POS", EventType.CROSS_RESISTANCE, missed = true, eventTime = 2L),
                cand("GEN", EventType.LONG_ENTRY, missed = true)
            ),
            setOf("POS"), true
        )
        assertEquals(listOf("POS"), plan.missed.keys.toList())
        assertEquals(2, plan.missed.getValue("POS").size)
        assertEquals(listOf("GEN"), plan.logOnly.map { it.symbol })
        assertTrue(plan.cluster.isEmpty() && plan.individual.isEmpty())
    }

    @Test
    fun monitoringOffSilencesGeneralButNotPositioned() {
        val plan = AlertDispatcher.plan(
            listOf(cand("GEN", EventType.LONG_ENTRY), cand("POS", EventType.CROSS_RESISTANCE)),
            setOf("POS"), generalMonitoringOn = false
        )
        assertTrue(plan.cluster.isEmpty())
        assertEquals(listOf("POS"), plan.individual.map { it.symbol })
    }
}
