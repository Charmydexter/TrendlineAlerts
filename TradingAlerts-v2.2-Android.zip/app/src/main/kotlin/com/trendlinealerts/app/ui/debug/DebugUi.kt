package com.trendlinealerts.app.ui.debug

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.repository.DebugSnapshotRepository
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.SurfaceVariantDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.SymbolDebugSnapshot
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class DebugUiState(
    val selectedSymbol: String = "SUIUSDT",
    val availableSymbols: List<String> = emptyList(),
    val snapshot: SymbolDebugSnapshot? = null
)

class DebugViewModel(
    debugSnapshotRepository: DebugSnapshotRepository
) : ViewModel() {

    private val selectedSymbolFlow = MutableStateFlow("SUIUSDT")

    val uiState: StateFlow<DebugUiState> = combine(
        debugSnapshotRepository.snapshots,
        selectedSymbolFlow
    ) { map, selected ->
        val keys = map.keys.sorted()
        val chosen = if (map.containsKey(selected)) selected else keys.firstOrNull() ?: selected
        DebugUiState(
            selectedSymbol = chosen,
            availableSymbols = keys,
            snapshot = map[chosen]
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = DebugUiState()
    )

    fun selectSymbol(symbol: String) {
        selectedSymbolFlow.value = symbol
    }

    class Factory(
        private val debugSnapshotRepository: DebugSnapshotRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DebugViewModel(debugSnapshotRepository) as T
        }
    }
}

@Composable
fun DebugScreen(
    viewModel: DebugViewModel
) {
    val state by viewModel.uiState.collectAsState()
    var menuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(16.dp)
    ) {
        Text(
            text = "TradingView Debug Inspector",
            color = TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(10.dp))

        Box {
            OutlinedButton(
                onClick = { menuExpanded = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = "Symbol: ${state.selectedSymbol}",
                    color = TextPrimary,
                    fontSize = 15.sp
                )
            }
            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                modifier = Modifier.background(SurfaceVariantDark)
            ) {
                state.availableSymbols.forEach { sym ->
                    DropdownMenuItem(
                        text = { Text(sym, color = TextPrimary) },
                        onClick = {
                            menuExpanded = false
                            viewModel.selectSymbol(sym)
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        val snap = state.snapshot
        if (snap == null) {
            Text(
                text = "No engine snapshot yet. Start monitoring (or mark an asset Positioned) and wait for the first poll cycle.",
                color = TextSecondary,
                fontSize = 14.sp
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("Last Price: ${snap.lastPrice}", color = TextPrimary, fontFamily = FontFamily.Monospace)
                            Text("HTF Closed Bars: ${snap.htfBarCount}", color = TextSecondary, fontFamily = FontFamily.Monospace)
                            Text("R-Stack Pivots: ${snap.resistancePivotCount}", color = GoogleRed, fontFamily = FontFamily.Monospace)
                            Text("S-Stack Pivots: ${snap.supportPivotCount}", color = GoogleGreen, fontFamily = FontFamily.Monospace)
                            val biasText = when (snap.trendBias) {
                                EntryDirection.LONG -> "Bullish (Long only)"
                                EntryDirection.SHORT -> "Bearish (Short only)"
                                null -> "Neutral"
                            }
                            Text("Trend Bias: $biasText", color = TextPrimary, fontFamily = FontFamily.Monospace)
                            Text("Last Long Fired: ${snap.lastLongFiredAtMs?.let { "${fmtTime(it)} UTC" } ?: "None"}", color = GoogleGreen, fontFamily = FontFamily.Monospace)
                            Text("Last Short Fired: ${snap.lastShortFiredAtMs?.let { "${fmtTime(it)} UTC" } ?: "None"}", color = GoogleRed, fontFamily = FontFamily.Monospace)
                            Text("Last Cross Side: ${snap.lastCrossSide ?: "None"}", color = TextSecondary, fontFamily = FontFamily.Monospace)
                            Text("Last Entry Dir: ${snap.lastEntryDirection ?: "None"}", color = TextSecondary, fontFamily = FontFamily.Monospace)
                            snap.resistancePivots.forEachIndexed { i, pv ->
                                Text("R-P${i + 1}: ${fmtTime(pv.timeMs)} UTC @ ${pv.price}", color = GoogleRed, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            }
                            snap.pendingResistance?.let { pv ->
                                Text("R pending: ${fmtTime(pv.timeMs)} UTC @ ${pv.price}", color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            }
                            snap.supportPivots.forEachIndexed { i, pv ->
                                Text("S-P${i + 1}: ${fmtTime(pv.timeMs)} UTC @ ${pv.price}", color = GoogleGreen, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            }
                            snap.pendingSupport?.let { pv ->
                                Text("S pending: ${fmtTime(pv.timeMs)} UTC @ ${pv.price}", color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            }
                        }
                    }
                }

                items(snap.activeLines) { line ->
                    val isRes = line.slotId.name.startsWith("R")
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (isRes) "▲${line.slotId.name}" else "▼${line.slotId.name}",
                                    color = if (isRes) GoogleRed else GoogleGreen,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = String.format(Locale.US, "%.5f", line.currentValue),
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = "P1: ${fmtTime(line.p1TimeMs)} @ ${line.p1Price}",
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "P2: ${fmtTime(line.p2TimeMs)} @ ${line.p2Price}",
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun fmtTime(ms: Long): String {
    val f = SimpleDateFormat("MM-dd HH:mm", Locale.US)
    f.timeZone = java.util.TimeZone.getTimeZone("UTC")
    return f.format(Date(ms))
}
