package com.trendlinealerts.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.IBinder
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.trendlinealerts.app.R
import com.trendlinealerts.app.TrendlineAlertsApp
import com.trendlinealerts.app.data.local.AlertLogEntity
import com.trendlinealerts.app.data.local.SymbolStateEntity
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.data.remote.SymbolNotListedException
import com.trendlinealerts.app.data.repository.SignalDotColor
import com.trendlinealerts.app.data.repository.SymbolMonitorRow
import com.trendlinealerts.app.ui.MainActivity
import com.trendlinealerts.core.detector.SignalProcessor
import com.trendlinealerts.core.dispatcher.AlertDispatcher
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.DebugLineInfo
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.NearestLineInfo
import com.trendlinealerts.core.model.PivotInfo
import com.trendlinealerts.core.model.SignalCandidate
import com.trendlinealerts.core.model.SignalStateCodec
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.SymbolDebugSnapshot
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import retrofit2.HttpException

class NotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_MONITORING = "monitoring_status"
        const val CHANNEL_ALERTS = "trendline_alerts_high"
        const val FOREGROUND_NOTIFICATION_ID = 1001
        const val STOPPED_NOTIFICATION_ID = 1002

        private const val GOOGLE_RED_INT = 0xFFEA4335.toInt()
        private const val GOOGLE_GREEN_INT = 0xFF34A853.toInt()
        private const val BLUE_INT = 0xFF4285F4.toInt()
        private const val MAX_CLUSTER_LINES = 7
        private val idCounter = AtomicInteger(3000)
    }

    private val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannels() {
        val statusChannel = NotificationChannel(
            CHANNEL_MONITORING,
            "Monitoring Status",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Persistent notification with Start / Stop for monitoring"
            setShowBadge(false)
        }

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val audioAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val alertChannel = NotificationChannel(
            CHANNEL_ALERTS,
            "Trading Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Long / Short heads-up, crosses on positioned assets, and missed-alert catch-up"
            enableVibration(true)
            enableLights(true)
            setSound(soundUri, audioAttrs)
        }

        manager.createNotificationChannel(statusChannel)
        manager.createNotificationChannel(alertChannel)
    }

    private fun openAppIntent(requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun serviceActionIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, MonitoringForegroundService::class.java).apply { this.action = action }
        return PendingIntent.getForegroundService(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun buildForegroundNotification(
        title: String,
        contentText: String?,
        generalOn: Boolean
    ): Notification {
        ensureChannels()
        val builder = NotificationCompat.Builder(context, CHANNEL_MONITORING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent(0))
        if (!contentText.isNullOrBlank()) {
            builder.setContentText(contentText)
        }
        if (generalOn) {
            builder.addAction(R.drawable.ic_notification, "Stop", serviceActionIntent(MonitoringForegroundService.ACTION_STOP_GENERAL, 11))
        } else {
            builder.addAction(R.drawable.ic_notification, "Start", serviceActionIntent(MonitoringForegroundService.ACTION_START_GENERAL, 12))
        }
        return builder.build()
    }

    fun postStoppedNotification() {
        ensureChannels()
        val n = NotificationCompat.Builder(context, CHANNEL_MONITORING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Monitoring OFF")
            .setContentText("Tap Start to resume watching all assets")
            .setOngoing(false)
            .setAutoCancel(false)
            .setContentIntent(openAppIntent(0))
            .addAction(R.drawable.ic_notification, "Start", serviceActionIntent(MonitoringForegroundService.ACTION_START_GENERAL, 12))
            .build()
        manager.notify(STOPPED_NOTIFICATION_ID, n)
    }

    fun cancelStoppedNotification() {
        manager.cancel(STOPPED_NOTIFICATION_ID)
    }

    private fun fmtPrice(v: Double): String = when {
        v >= 1_000.0 -> String.format(Locale.US, "%.2f", v)
        v >= 1.0 -> String.format(Locale.US, "%.4f", v)
        v >= 0.01 -> String.format(Locale.US, "%.5f", v)
        else -> String.format(Locale.US, "%.7f", v)
    }

    private fun fmtClock(ms: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(ms))

    private fun label(e: TrendlineCandidate): String = when (e.eventType) {
        EventType.CROSS_RESISTANCE -> "▲${e.slotId.name} cross"
        EventType.CROSS_SUPPORT -> "▼${e.slotId.name} cross"
        EventType.LONG_ENTRY -> "LONG · ${e.slotId.name}"
        EventType.SHORT_ENTRY -> "SHORT · ${e.slotId.name}"
        EventType.NEW_RESISTANCE -> "New ▲${e.slotId.name}"
        EventType.NEW_SUPPORT -> "New ▼${e.slotId.name}"
    }

    private fun accent(e: TrendlineCandidate): Int = when (e.eventType) {
        EventType.CROSS_RESISTANCE, EventType.SHORT_ENTRY, EventType.NEW_RESISTANCE -> GOOGLE_RED_INT
        else -> GOOGLE_GREEN_INT
    }

    fun sendAlertNotification(candidate: TrendlineCandidate) {
        ensureChannels()
        val headline = when (candidate.eventType) {
            EventType.CROSS_RESISTANCE -> "▲${candidate.slotId.name}"
            EventType.CROSS_SUPPORT -> "▼${candidate.slotId.name}"
            EventType.LONG_ENTRY -> "Long"
            EventType.SHORT_ENTRY -> "Short"
            EventType.NEW_RESISTANCE -> "New ▲${candidate.slotId.name}"
            EventType.NEW_SUPPORT -> "New ▼${candidate.slotId.name}"
        }
        val accent = accent(candidate)
        val styledTitle = SpannableString("$headline · ${candidate.symbol}").apply {
            setSpan(ForegroundColorSpan(accent), 0, headline.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val body = "Price ${fmtPrice(candidate.price)} | Line ${fmtPrice(candidate.lineValue)}"

        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(accent)
            .setContentTitle(styledTitle)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(candidate.symbol.hashCode()))
            .build()
        manager.notify(idCounter.incrementAndGet(), notification)
    }

    fun sendClusterNotification(events: List<TrendlineCandidate>) {
        if (events.isEmpty()) return
        ensureChannels()
        val allLong = events.all { it.eventType == EventType.LONG_ENTRY }
        val allShort = events.all { it.eventType == EventType.SHORT_ENTRY }
        val color = when {
            allLong -> GOOGLE_GREEN_INT
            allShort -> GOOGLE_RED_INT
            else -> BLUE_INT
        }
        val title = if (events.size == 1) "${label(events[0])} · ${events[0].symbol}" else "${events.size} assets · Long / Short"
        val inbox = NotificationCompat.InboxStyle().setBigContentTitle(title)
        events.take(MAX_CLUSTER_LINES).forEach { e ->
            inbox.addLine("${label(e)}  ${e.symbol}  ${fmtPrice(e.price)}")
        }
        if (events.size > MAX_CLUSTER_LINES) inbox.setSummaryText("+${events.size - MAX_CLUSTER_LINES} more in Alert Log")

        val collapsed = events.take(4).joinToString(", ") { it.symbol } + if (events.size > 4) " +${events.size - 4}" else ""
        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(color)
            .setContentTitle(title)
            .setContentText(collapsed)
            .setStyle(inbox)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(7))
            .build()
        manager.notify(idCounter.incrementAndGet(), notification)
    }

    fun sendMissedNotification(symbol: String, events: List<TrendlineCandidate>, nowPrice: Double?, nearest: NearestLineInfo?) {
        if (events.isEmpty()) return
        ensureChannels()
        val sorted = events.sortedBy { it.eventTimeMs }
        val inbox = NotificationCompat.InboxStyle().setBigContentTitle("MISSED · $symbol")
        sorted.takeLast(MAX_CLUSTER_LINES - 1).forEach { e ->
            inbox.addLine("${fmtClock(e.eventTimeMs)}  ${label(e)}  @ ${fmtPrice(e.lineValue)}")
        }
        val nowLine = buildString {
            if (nowPrice != null) append("Now ${fmtPrice(nowPrice)}")
            if (nearest != null) {
                val arrow = if (nearest.side == TrendlineSide.RESISTANCE) "▲" else "▼"
                append("  ·  nearest $arrow${nearest.slotId.name} ${fmtPrice(nearest.lineValue)} (${String.format(Locale.US, "%+.2f", nearest.distancePct)}%)")
            }
        }
        if (nowLine.isNotBlank()) inbox.addLine(nowLine)

        val last = sorted.last()
        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(accent(last))
            .setContentTitle("MISSED while offline · $symbol")
            .setContentText("${sorted.size} event(s), last ${label(last)} at ${fmtClock(last.eventTimeMs)}")
            .setStyle(inbox)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(symbol.hashCode()))
            .build()
        manager.notify(idCounter.incrementAndGet(), notification)
    }

    fun sendTestNotification() {
        val now = System.currentTimeMillis()
        sendAlertNotification(
            TrendlineCandidate("SUIUSDT", SlotId.S1, TrendlineSide.SUPPORT, EventType.CROSS_SUPPORT, 0.6516, 0.6512, now)
        )
        sendClusterNotification(
            listOf(
                TrendlineCandidate("XRPUSDT", SlotId.S2, TrendlineSide.SUPPORT, EventType.LONG_ENTRY, 2.1034, 2.1021, now),
                TrendlineCandidate("SOLUSDT", SlotId.R1, TrendlineSide.RESISTANCE, EventType.SHORT_ENTRY, 143.52, 143.60, now),
                TrendlineCandidate("INJUSDT", SlotId.S1, TrendlineSide.SUPPORT, EventType.LONG_ENTRY, 9.412, 9.405, now)
            )
        )
    }
}

private sealed interface PollItemResult {
    data class Success(
        val row: SymbolMonitorRow,
        val events: List<TrendlineCandidate>,
        val candidates: List<SignalCandidate>,
        val newState: SymbolSignalState,
        val snapshot: SymbolDebugSnapshot,
        val lastPrice: Double?,
        val nearest: NearestLineInfo?
    ) : PollItemResult

    data class Failure(val error: Exception) : PollItemResult
    data object Skipped : PollItemResult
}

class MonitoringForegroundService : Service() {

    companion object {
        const val ACTION_START_GENERAL = "com.trendlinealerts.action.START_GENERAL"
        const val ACTION_STOP_GENERAL = "com.trendlinealerts.action.STOP_GENERAL"
        const val ACTION_SYNC = "com.trendlinealerts.action.SYNC"

        private const val CONCURRENCY = 5
        private const val WARMUP_BARS = 60
        private const val MAX_CATCHUP_BARS = 2880
        private const val FAILOVER_AFTER_FAILED_CYCLES = 2

        fun startGeneral(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_START_GENERAL
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stopGeneral(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_STOP_GENERAL
            }
            runCatching { context.startService(intent) }
        }

        fun syncPriorityService(context: Context, shouldBeRunning: Boolean) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_SYNC
            }
            if (shouldBeRunning) {
                ContextCompat.startForegroundService(context, intent)
            } else {
                runCatching { context.startService(intent) }
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollLoopJob: Job? = null

    private val processor = SignalProcessor()
    private val symbolStates = ConcurrentHashMap<String, SymbolSignalState>()

    private var activeSource: DataSourceType? = null
    private var knownDefaultSource: DataSourceType? = null
    private var knownTimeframeKey: String? = null
    private var consecutiveFailedCycles = 0
    private var cycleCounter = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as TrendlineAlertsApp
        val container = app.container
        val helper = NotificationHelper(this)
        val action = intent?.action

        val initialGeneralOn = action != ACTION_STOP_GENERAL
        startForeground(
            NotificationHelper.FOREGROUND_NOTIFICATION_ID,
            helper.buildForegroundNotification(
                title = if (initialGeneralOn) "Monitoring ON" else "Monitoring OFF",
                contentText = "Initializing market feed...",
                generalOn = initialGeneralOn
            )
        )
        helper.cancelStoppedNotification()

        serviceScope.launch {
            container.watchlistRepository.ensureDefaultWatchlistSeeded()

            when (action) {
                ACTION_START_GENERAL -> {
                    container.settingsDataStore.setMonitoringEnabled(true)
                    container.monitorStateRepository.updateStatus { it.copy(lastPollError = null) }
                }
                ACTION_STOP_GENERAL -> container.settingsDataStore.setMonitoringEnabled(false)
            }

            val snapshot = container.settingsDataStore.getSnapshot()
            val hasPriority = container.watchlistRepository.hasAnyPriorityOverride()
            val shouldRun = snapshot.monitoringEnabled || hasPriority
            container.monitorStateRepository.setPriorityServiceActive(hasPriority)

            if (!shouldRun) {
                pollLoopJob?.cancel()
                pollLoopJob = null
                container.monitorStateRepository.updateStatus { it.copy(nextCheckAtMs = 0L, lastPollError = null) }
                stopForeground(STOP_FOREGROUND_REMOVE)
                if (action == ACTION_STOP_GENERAL) helper.postStoppedNotification()
                stopSelf()
                return@launch
            }

            pollLoopJob?.cancel()
            pollLoopJob = launch { runPollingLoop() }
        }

        return START_STICKY
    }

    private fun nextSourceAfter(current: DataSourceType): DataSourceType {
        val all = DataSourceType.entries
        return all[(all.indexOf(current) + 1) % all.size]
    }

    private fun sourceTitle(source: DataSourceType, marketType: MarketType): String = when (source) {
        DataSourceType.BYBIT -> if (marketType == MarketType.PERP) "Bybit Linear Perps" else "Bybit Spot"
        DataSourceType.BINANCE -> if (marketType == MarketType.PERP) "Binance USDT-M Futures" else "Binance Spot"
        DataSourceType.OKX -> if (marketType == MarketType.PERP) "OKX Perps" else "OKX Spot"
    }

    private suspend fun loadState(symbol: String): SymbolSignalState {
        symbolStates[symbol]?.let { return it }
        val app = application as TrendlineAlertsApp
        val raw = app.container.symbolStateDao.get(symbol)
        val st = SignalStateCodec.decode(raw, symbol)
        symbolStates[symbol] = st
        return st
    }

    private suspend fun runPollingLoop() {
        val app = application as TrendlineAlertsApp
        val container = app.container
        val helper = NotificationHelper(this)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        while (serviceScope.isActive) {
            val snapshot = container.settingsDataStore.getSnapshot()
            val entities = container.watchlistRepository.getAllEntities()
            val positionedSymbols = entities.filter { it.isPriorityOverride }.map { it.symbol }.toSet()
            container.monitorStateRepository.setPriorityServiceActive(positionedSymbols.isNotEmpty())

            val generalOn = snapshot.monitoringEnabled
            if (!generalOn && positionedSymbols.isEmpty()) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                helper.postStoppedNotification()
                stopSelf()
                return
            }

            val tf = snapshot.alertSettings.timeframe
            val market = snapshot.marketType
            val defaultSource = snapshot.dataSource
            val settings = snapshot.alertSettings

            // Timeframe / market / slot changes reset line state; cooldown & volume filter NEVER reset it.
            val tfKey = "${tf.name}|${market.name}|${settings.enabledSlots.sortedBy { it.name }.joinToString(",")}"
            if (knownTimeframeKey != null && knownTimeframeKey != tfKey) {
                symbolStates.clear()
                container.symbolStateDao.clear()
            }
            knownTimeframeKey = tfKey

            if (knownDefaultSource != null && knownDefaultSource != defaultSource) {
                activeSource = defaultSource
                consecutiveFailedCycles = 0
            }
            knownDefaultSource = defaultSource
            if (activeSource == null) activeSource = defaultSource

            val activeEntities = if (generalOn) entities else entities.filter { it.isPriorityOverride }

            if (activeSource != defaultSource) {
                val probeSymbol = activeEntities.firstOrNull()?.symbol ?: "BTCUSDT"
                val defaultAlive = runCatching {
                    container.marketDataCoordinator.fetch1mCandles(probeSymbol, defaultSource, market, 2).isNotEmpty()
                }.getOrDefault(false)
                if (defaultAlive) {
                    activeSource = defaultSource
                    consecutiveFailedCycles = 0
                    container.monitorStateRepository.updateStatus {
                        it.copy(failoverMessage = "Back on default source: ${sourceTitle(defaultSource, market)}.")
                    }
                }
            }
            val source = activeSource ?: defaultSource

            container.monitorStateRepository.updateStatus { it.copy(activeSource = source) }

            val statusLabel = if (generalOn) {
                "Monitoring ${activeEntities.size} assets (${tf.label}) · ${source.name.lowercase().replaceFirstChar { it.uppercase() }}"
            } else {
                null
            }
            val (notifTitle, notifText) = buildPersistentNotificationContent(
                generalOn = generalOn,
                positionedSymbolsOrdered = entities.filter { it.isPriorityOverride }.map { it.symbol },
                fallbackSubtext = statusLabel
            )
            manager.notify(
                NotificationHelper.FOREGROUND_NOTIFICATION_ID,
                helper.buildForegroundNotification(notifTitle, notifText, generalOn)
            )

            if (cycleCounter % 60 == 0) {
                runCatching {
                    val keep = entities.map { it.symbol }
                    container.htfCandleCache.prune(keep, tf)
                    if (keep.isNotEmpty()) container.symbolStateDao.deleteNotIn(keep)
                }
            }
            cycleCounter++

            val cycleNowMs = System.currentTimeMillis()
            val existingRows = container.monitorStateRepository.symbolRows.value.associateBy { it.symbol }
            val results = ConcurrentHashMap<String, PollItemResult.Success>()
            var anySucceeded = false
            var cycleLastError: String? = null
            var rateLimited = false

            for (chunk in activeEntities.chunked(CONCURRENCY)) {
                val chunkResults: List<Pair<String, PollItemResult>> = coroutineScope {
                    chunk.map { entity ->
                        async<Pair<String, PollItemResult>> {
                            val r: PollItemResult = try {
                                pollSymbol(entity.symbol, entity.isPriorityOverride, source, market, tf, settings, cycleNowMs, container)
                            } catch (ce: CancellationException) {
                                throw ce
                            } catch (e: SymbolNotListedException) {
                                PollItemResult.Skipped
                            } catch (err: Exception) {
                                PollItemResult.Failure(err)
                            }
                            entity.symbol to r
                        }
                    }.awaitAll()
                }
                for ((sym, res) in chunkResults) {
                    when (res) {
                        is PollItemResult.Success -> {
                            anySucceeded = true
                            results[sym] = res
                        }
                        is PollItemResult.Failure -> {
                            cycleLastError = "${res.error::class.java.simpleName}: ${res.error.message}"
                            val e = res.error
                            if (e is HttpException && (e.code() == 429 || e.code() == 418)) rateLimited = true
                        }
                        PollItemResult.Skipped -> Unit
                    }
                }
                if (rateLimited) {
                    delay(10_000L)
                    break
                }
            }

            if (anySucceeded) {
                consecutiveFailedCycles = 0
                container.monitorStateRepository.updateStatus { it.copy(lastPollError = null) }
            } else if (activeEntities.isNotEmpty()) {
                consecutiveFailedCycles++
                container.monitorStateRepository.updateStatus { it.copy(lastPollError = cycleLastError ?: "No market data returned") }
                if (consecutiveFailedCycles >= FAILOVER_AFTER_FAILED_CYCLES && !rateLimited) {
                    val next = nextSourceAfter(source)
                    activeSource = next
                    consecutiveFailedCycles = 0
                    val msg = "${sourceTitle(source, market)} failed — using ${sourceTitle(next, market)}. " +
                        "Retrying ${sourceTitle(defaultSource, market)} every minute."
                    container.monitorStateRepository.updateStatus { it.copy(failoverMessage = msg, activeSource = next) }
                }
            }

            val allEvents = results.values.flatMap { it.events }
            val allCandidates = results.values.flatMap { it.candidates }
            val plan = AlertDispatcher.plan(allEvents, positionedSymbols, generalOn)

            withContext(NonCancellable) {
                val logs = mutableListOf<AlertLogEntity>()
                fun log(e: TrendlineCandidate, prefix: String) {
                    logs.add(
                        AlertLogEntity(
                            symbol = e.symbol,
                            eventType = e.eventType.name,
                            slotId = e.slotId.name,
                            price = e.price,
                            lineValue = e.lineValue,
                            message = "$prefix${e.eventType.name} on ${e.slotId.name}",
                            timestampMs = if (e.missed) e.eventTimeMs else cycleNowMs
                        )
                    )
                }

                var lastAlertSymbol: String? = null
                plan.individual.forEachIndexed { idx, e ->
                    helper.sendAlertNotification(e)
                    container.watchlistRepository.markAlerted(e.symbol, e.timestampMs + idx)
                    log(e, "")
                    lastAlertSymbol = e.symbol
                }
                if (plan.cluster.isNotEmpty()) {
                    helper.sendClusterNotification(plan.cluster)
                    plan.cluster.forEachIndexed { idx, it ->
                        container.watchlistRepository.markAlerted(it.symbol, it.timestampMs + idx)
                        log(it, "")
                    }
                    lastAlertSymbol = plan.cluster.last().symbol
                }
                var missedIdx = 0
                for ((sym, evs) in plan.missed) {
                    val r = results[sym]
                    helper.sendMissedNotification(sym, evs, r?.lastPrice, r?.nearest)
                    container.watchlistRepository.markAlerted(sym, evs.maxOf { it.timestampMs } + missedIdx++)
                    evs.forEach { log(it, "MISSED: ") }
                    lastAlertSymbol = sym
                }
                plan.logOnly.forEach { log(it, "MISSED (no alert): ") }
                if (logs.isNotEmpty()) container.alertLogRepository.insertAll(logs)
                if (allCandidates.isNotEmpty()) container.signalCandidateRepository.insertCandidates(allCandidates)

                results.values.forEach { r ->
                    symbolStates[r.newState.symbol] = r.newState
                    container.symbolStateDao.put(SymbolStateEntity(r.newState.symbol, SignalStateCodec.encode(r.newState)))
                    container.debugSnapshotRepository.putSnapshot(r.snapshot)
                }

                if (lastAlertSymbol != null) {
                    container.monitorStateRepository.updateStatus {
                        it.copy(lastAlertSymbol = lastAlertSymbol, lastAlertTimeMs = cycleNowMs)
                    }
                    val refreshedPositioned = container.watchlistRepository.getAllEntities()
                        .filter { it.isPriorityOverride }
                        .map { it.symbol }
                    val (updatedTitle, updatedText) = buildPersistentNotificationContent(
                        generalOn = generalOn,
                        positionedSymbolsOrdered = refreshedPositioned,
                        fallbackSubtext = statusLabel
                    )
                    manager.notify(
                        NotificationHelper.FOREGROUND_NOTIFICATION_ID,
                        helper.buildForegroundNotification(updatedTitle, updatedText, generalOn)
                    )
                }
            }

            runCatching {
                container.liveOutcomeResolver.resolvePending(source, market, System.currentTimeMillis())
            }

            val rows = entities.map { entity ->
                results[entity.symbol]?.row
                    ?: existingRows[entity.symbol]?.copy(
                        isPriorityOverride = entity.isPriorityOverride,
                        lastAlertedAtMs = entity.lastAlertedAtMs
                    )
                    ?: SymbolMonitorRow(
                        symbol = entity.symbol,
                        lastPrice = null,
                        dotColor = SignalDotColor.GREY,
                        isPriorityOverride = entity.isPriorityOverride,
                        lastAlertedAtMs = entity.lastAlertedAtMs
                    )
            }
            container.monitorStateRepository.updateSymbolRows(rows)

            val nowMs = System.currentTimeMillis()
            val nextBoundaryMs = ((nowMs / 60_000L) + 1L) * 60_000L + 2_000L
            container.monitorStateRepository.updateStatus { it.copy(nextCheckAtMs = nextBoundaryMs) }

            val waitMs = (nextBoundaryMs - nowMs).coerceIn(5_000L, 62_000L)
            withTimeoutOrNull(waitMs) {
                container.settingsDataStore.settingsFlow.first {
                    it.dataSource != snapshot.dataSource ||
                        it.marketType != snapshot.marketType ||
                        it.alertSettings != snapshot.alertSettings ||
                        it.monitoringEnabled != snapshot.monitoringEnabled
                }
            }
        }
    }

    private suspend fun pollSymbol(
        symbol: String,
        positioned: Boolean,
        source: DataSourceType,
        market: MarketType,
        tf: com.trendlinealerts.core.model.Timeframe,
        settings: com.trendlinealerts.core.model.AlertSettings,
        nowMs: Long,
        container: com.trendlinealerts.app.di.AppContainer
    ): PollItemResult {
        val mode = if (positioned) AssetMode.POSITIONED else AssetMode.GENERAL
        val prev = loadState(symbol)
        val lastClosedOpen = (nowMs / 60_000L) * 60_000L - 60_000L
        val firstRun = prev.lastProcessedOpenMs == 0L

        val missingBars = if (firstRun) WARMUP_BARS
        else ((lastClosedOpen - prev.lastProcessedOpenMs) / 60_000L).toInt().coerceIn(0, MAX_CATCHUP_BARS)
        val limit = MarketDataCoordinator.poll1mLimit(missingBars)

        val candles = container.marketDataCoordinator.fetch1mCandles(symbol, source, market, limit)
        if (candles.isEmpty()) return PollItemResult.Skipped
        val htf = container.htfCandleCache.getClosedCandles(symbol, tf, source, market, nowMs)
        if (htf.size < 10) return PollItemResult.Skipped

        val lastPrice = candles.last().close
        val closed1m = candles.filter { it.openTimeMs + 60_000L <= nowMs }

        val result = processor.process(
            symbol = symbol,
            previous = prev,
            mode = mode,
            htfClosed = htf,
            timeframe = tf,
            bars1m = closed1m,
            lastPrice = lastPrice,
            settings = settings,
            nowMs = nowMs,
            emitCandidates = !firstRun
        )

        val events = if (firstRun) emptyList() else result.events
        val candidates = if (firstRun) emptyList() else result.candidates

        val st = result.state
        val dot = if (mode == AssetMode.POSITIONED) {
            computeDotColor(st.lastCrossSide, result.nearestSupport, result.nearestResistance, settings.proximityPct)
        } else {
            when (st.trendBias) {
                EntryDirection.LONG -> computeDotColor(TrendlineSide.SUPPORT, result.lowestSupport, null, settings.proximityPct)
                EntryDirection.SHORT -> computeDotColor(TrendlineSide.RESISTANCE, null, result.highestResistance, settings.proximityPct)
                null -> SignalDotColor.GREY
            }
        }

        val displayLine = if (mode == AssetMode.POSITIONED) {
            result.nearestOverall
        } else {
            when (st.trendBias) {
                EntryDirection.LONG -> result.lowestSupport
                EntryDirection.SHORT -> result.highestResistance
                null -> listOfNotNull(result.lowestSupport, result.highestResistance)
                    .minByOrNull { abs(it.distancePct) }
            }
        }

        val cur = result.current
        val snapshot = SymbolDebugSnapshot(
            symbol = symbol,
            updatedAtMs = nowMs,
            lastPrice = lastPrice,
            htfBarCount = htf.size,
            activeLines = cur?.lines?.values?.map {
                DebugLineInfo(it.slotId, it.valueAt(nowMs), it.older.openTimeMs, it.older.price, it.newer.openTimeMs, it.newer.price)
            }.orEmpty(),
            resistancePivotCount = cur?.resistanceCount ?: 0,
            supportPivotCount = cur?.supportCount ?: 0,
            lastCrossSide = st.lastCrossSide,
            lastEntryDirection = st.lastEntryDirection,
            trendBias = st.trendBias,
            lastLongFiredAtMs = st.lastLongFiredAtMs,
            lastShortFiredAtMs = st.lastShortFiredAtMs,
            resistancePivots = cur?.resistancePivots?.map { PivotInfo(it.openTimeMs, it.price) }.orEmpty(),
            supportPivots = cur?.supportPivots?.map { PivotInfo(it.openTimeMs, it.price) }.orEmpty(),
            pendingResistance = cur?.pendingResistance?.let { PivotInfo(it.openTimeMs, it.price) },
            pendingSupport = cur?.pendingSupport?.let { PivotInfo(it.openTimeMs, it.price) }
        )

        val row = SymbolMonitorRow(
            symbol = symbol,
            lastPrice = lastPrice,
            dotColor = dot,
            nearestSlot = displayLine?.slotId,
            nearestSide = displayLine?.side,
            nearestDistancePct = displayLine?.distancePct,
            trendBias = if (mode == AssetMode.GENERAL) st.trendBias else null,
            isPriorityOverride = positioned,
            lastAlertedAtMs = 0L
        )
        return PollItemResult.Success(row, events, candidates, st, snapshot, lastPrice, result.nearestOverall)
    }

    private fun computeDotColor(
        lastSide: TrendlineSide?,
        nearestSupport: NearestLineInfo?,
        nearestResistance: NearestLineInfo?,
        proximityPct: Double
    ): SignalDotColor {
        val entryWindow = (proximityPct * 3.0).coerceAtLeast(0.1)
        return when (lastSide) {
            TrendlineSide.SUPPORT -> {
                val dist = nearestSupport?.distancePct
                if (dist != null && dist >= 0.0 && dist <= entryWindow) SignalDotColor.GREEN else SignalDotColor.GREY
            }
            TrendlineSide.RESISTANCE -> {
                val dist = nearestResistance?.distancePct
                if (dist != null && dist <= 0.0 && dist >= -entryWindow) SignalDotColor.RED else SignalDotColor.GREY
            }
            null -> SignalDotColor.GREY
        }
    }

    private fun stripUsdt(symbol: String): String {
        val upper = symbol.trim().uppercase(Locale.US)
        return if (upper.endsWith("USDT") && upper.length > 4) upper.dropLast(4) else upper
    }

    private fun buildPersistentNotificationContent(
        generalOn: Boolean,
        positionedSymbolsOrdered: List<String>,
        fallbackSubtext: String?
    ): Pair<String, String?> {
        if (positionedSymbolsOrdered.isEmpty()) {
            return (if (generalOn) "Monitoring ON" else "Monitoring OFF") to fallbackSubtext
        }
        val title = stripUsdt(positionedSymbolsOrdered.first())
        val others = positionedSymbolsOrdered.drop(1).map { stripUsdt(it) }
        val text = if (others.isNotEmpty()) others.joinToString(",") else null
        return title to text
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val app = context.applicationContext as? TrendlineAlertsApp ?: return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = app.container.settingsDataStore.getSnapshot()
                val hasPriority = app.container.watchlistRepository.hasAnyPriorityOverride()
                if (settings.monitoringEnabled || hasPriority) {
                    MonitoringForegroundService.syncPriorityService(context, true)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
