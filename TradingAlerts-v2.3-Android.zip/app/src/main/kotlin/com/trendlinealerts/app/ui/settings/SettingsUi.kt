package com.trendlinealerts.app.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.WifiFind
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.SurfaceVariantDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.VolumeMethod
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class SettingsUiState(
    val dataSource: DataSourceType = DataSourceType.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val alertSettings: AlertSettings = AlertSettings(),
    val isTestingConnection: Boolean = false,
    val connectionTestResult: String? = null,
    val connectionTestOk: Boolean = false
)

class SettingsViewModel(
    private val settingsDataStore: SettingsDataStore,
    private val marketDataCoordinator: MarketDataCoordinator
) : ViewModel() {

    private val isTestingFlow = MutableStateFlow(false)
    private val testResultFlow = MutableStateFlow<Pair<String?, Boolean>>(null to false)

    val uiState: StateFlow<SettingsUiState> = combine(
        settingsDataStore.settingsFlow,
        isTestingFlow,
        testResultFlow
    ) { snapshot, testing, testRes ->
        SettingsUiState(
            dataSource = snapshot.dataSource,
            marketType = snapshot.marketType,
            alertSettings = snapshot.alertSettings,
            isTestingConnection = testing,
            connectionTestResult = testRes.first,
            connectionTestOk = testRes.second
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = SettingsUiState()
    )

    fun setDataSource(source: DataSourceType) {
        viewModelScope.launch { settingsDataStore.setDataSource(source) }
    }

    fun setMarketType(marketType: MarketType) {
        viewModelScope.launch { settingsDataStore.setMarketType(marketType) }
    }

    fun setTimeframe(timeframe: Timeframe) {
        viewModelScope.launch { settingsDataStore.setTimeframe(timeframe) }
    }

    fun setCooldownMinutes(minutes: Int) {
        viewModelScope.launch { settingsDataStore.setCooldownMinutes(minutes) }
    }

    fun setCapitalUsd(value: Double) {
        viewModelScope.launch { settingsDataStore.setCapitalUsd(value.coerceAtLeast(1.0)) }
    }

    fun setMaxLossUsd(value: Double) {
        viewModelScope.launch { settingsDataStore.setMaxLossUsd(value.coerceAtLeast(0.10)) }
    }

    fun setTpMultiplier(value: Int) {
        viewModelScope.launch { settingsDataStore.setTpMultiplier(value.coerceAtLeast(1)) }
    }

    fun setVolumeMethod(method: VolumeMethod) {
        viewModelScope.launch { settingsDataStore.setVolumeMethod(method) }
    }

    fun setSpikeRatio(value: Double) {
        viewModelScope.launch { settingsDataStore.setSpikeRatio(value) }
    }

    fun setRisingRatio(value: Double) {
        viewModelScope.launch { settingsDataStore.setRisingRatio(value) }
    }

    fun setWickMinFraction(value: Double) {
        viewModelScope.launch { settingsDataStore.setWickMinFraction(value) }
    }

    fun setFloorRatio(value: Double) {
        viewModelScope.launch { settingsDataStore.setFloorRatio(value) }
    }

    fun resetVolumeDefaults() {
        viewModelScope.launch { settingsDataStore.resetVolumeDefaults() }
    }

    fun testConnection() {
        viewModelScope.launch {
            isTestingFlow.value = true
            testResultFlow.value = null to false
            val snap = settingsDataStore.getSnapshot()
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    marketDataCoordinator.fetch1mCandles(
                        symbol = "SUIUSDT",
                        source = snap.dataSource,
                        marketType = snap.marketType,
                        limit = 5
                    )
                }
            }
            result.onSuccess { candles ->
                val price = candles.lastOrNull()?.close
                testResultFlow.value = if (price != null) {
                    "Connected to ${snap.dataSource.name} ${snap.marketType.name} (SUIUSDT = $price)" to true
                } else {
                    "Connected, but empty candles returned" to false
                }
            }.onFailure { err ->
                testResultFlow.value = "${err::class.java.simpleName}: ${err.message}" to false
            }
            isTestingFlow.value = false
        }
    }

    class Factory(
        private val settingsDataStore: SettingsDataStore,
        private val marketDataCoordinator: MarketDataCoordinator
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(settingsDataStore, marketDataCoordinator) as T
        }
    }
}

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onSendTestNotification: () -> Unit,
    onOpenBatteryOptimization: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var tfMenuExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Settings",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            SettingsCard(title = "Default Data Source (app returns to it automatically)") {
                DataSourceType.entries.forEach { source ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setDataSource(source) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = state.dataSource == source,
                            onClick = { viewModel.setDataSource(source) },
                            colors = RadioButtonDefaults.colors(selectedColor = PrimaryBlue)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (source) {
                                DataSourceType.BYBIT -> "Bybit"
                                DataSourceType.BINANCE -> "Binance"
                                DataSourceType.OKX -> "OKX"
                            } + if (state.dataSource == source) " (Default)" else "",
                            color = TextPrimary,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        item {
            SettingsCard(title = "Market Type (Perp / Spot)") {
                MarketType.entries.forEach { market ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setMarketType(market) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = state.marketType == market,
                            onClick = { viewModel.setMarketType(market) },
                            colors = RadioButtonDefaults.colors(selectedColor = PrimaryBlue)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (market) {
                                MarketType.PERP -> "Perpetual Futures (Perp)"
                                MarketType.SPOT -> "Spot"
                            },
                            color = TextPrimary,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        item {
            SettingsCard(title = "Higher Timeframe (HTF)") {
                Box {
                    OutlinedButton(
                        onClick = { tfMenuExpanded = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "Selected HTF: ${state.alertSettings.timeframe.label}",
                            color = TextPrimary,
                            fontSize = 15.sp
                        )
                    }
                    DropdownMenu(
                        expanded = tfMenuExpanded,
                        onDismissRequest = { tfMenuExpanded = false },
                        modifier = Modifier.background(SurfaceVariantDark)
                    ) {
                        Timeframe.entries.forEach { tf ->
                            DropdownMenuItem(
                                text = { Text(tf.label, color = TextPrimary) },
                                onClick = {
                                    tfMenuExpanded = false
                                    viewModel.setTimeframe(tf)
                                }
                            )
                        }
                    }
                }
            }
        }

        item {
            TradeRiskCard(
                alertSettings = state.alertSettings,
                onSaveCapital = viewModel::setCapitalUsd,
                onSaveMaxLoss = viewModel::setMaxLossUsd,
                onSaveTpMultiplier = viewModel::setTpMultiplier
            )
        }

        item {
            SettingsCard(title = "Signal Cooldown (per asset & direction)") {
                Text(
                    text = "Only starts when a signal is sent (volume-blocked touches do not trigger cooldown).",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(30, 60, 120, 240).forEach { mins ->
                        val selected = state.alertSettings.cooldownMinutes == mins
                        FilterChip(
                            selected = selected,
                            onClick = { viewModel.setCooldownMinutes(mins) },
                            label = { Text("${mins}m") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = Color.White,
                                containerColor = SurfaceVariantDark,
                                labelColor = TextPrimary
                            )
                        )
                    }
                }
            }
        }

        item {
            SettingsCard(title = "Volume Filter (General Long / Short only)") {
                Text(
                    text = "Filters 1m touch bars silently against the 30-bar median baseline.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                VolumeMethod.entries.forEach { method ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setVolumeMethod(method) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        RadioButton(
                            selected = state.alertSettings.volumeMethod == method,
                            onClick = { viewModel.setVolumeMethod(method) },
                            colors = RadioButtonDefaults.colors(selectedColor = PrimaryBlue)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(modifier = Modifier.padding(top = 8.dp)) {
                            Text(
                                text = method.name,
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = volumeMethodDescription(method),
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = OutlineDark)
                Spacer(modifier = Modifier.height(10.dp))

                ThresholdStepperRow(
                    label = "Spike ratio",
                    value = state.alertSettings.spikeRatio,
                    step = 0.1,
                    min = 1.0,
                    max = 10.0,
                    onChange = { viewModel.setSpikeRatio(it) }
                )
                ThresholdStepperRow(
                    label = "Rising ratio",
                    value = state.alertSettings.risingRatio,
                    step = 0.1,
                    min = 1.0,
                    max = 5.0,
                    onChange = { viewModel.setRisingRatio(it) }
                )
                ThresholdStepperRow(
                    label = "Wick min fraction",
                    value = state.alertSettings.wickMinFraction,
                    step = 0.05,
                    min = 0.0,
                    max = 1.0,
                    onChange = { viewModel.setWickMinFraction(it) }
                )
                ThresholdStepperRow(
                    label = "Activity floor ratio",
                    value = state.alertSettings.floorRatio,
                    step = 0.05,
                    min = 0.0,
                    max = 3.0,
                    onChange = { viewModel.setFloorRatio(it) }
                )

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { viewModel.resetVolumeDefaults() },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Reset to defaults", color = TextPrimary)
                }
            }
        }

        item {
            SettingsCard(title = "Diagnostics & Background Reliability") {
                OutlinedButton(
                    onClick = { viewModel.testConnection() },
                    enabled = !state.isTestingConnection,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.WifiFind,
                        contentDescription = null,
                        tint = PrimaryBlue
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isTestingConnection) "Testing Connection..." else "Test Feed Connection",
                        color = TextPrimary
                    )
                }

                if (!state.connectionTestResult.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = state.connectionTestResult.orEmpty(),
                        color = if (state.connectionTestOk) GoogleGreen else GoogleRed,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onSendTestNotification,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Icon(imageVector = Icons.Filled.NotificationsActive, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Send Test Notification")
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = onOpenBatteryOptimization,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.BatteryChargingFull,
                        contentDescription = null,
                        tint = GoogleGreen
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Battery Optimization Setup", color = TextPrimary)
                }
            }
        }
    }
}

@Composable
private fun TradeRiskCard(
    alertSettings: AlertSettings,
    onSaveCapital: (Double) -> Unit,
    onSaveMaxLoss: (Double) -> Unit,
    onSaveTpMultiplier: (Int) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val capital = alertSettings.effectiveCapitalUsd
    val maxLoss = alertSettings.effectiveMaxLossUsd
    val tpMult = alertSettings.effectiveTpMultiplier
    val tpDollar = alertSettings.tpUsd

    var capText by remember { mutableStateOf(String.format(Locale.US, "%.2f", capital)) }
    var slText by remember { mutableStateOf(String.format(Locale.US, "%.2f", maxLoss)) }
    var multText by remember { mutableStateOf(tpMult.toString()) }

    LaunchedEffect(capital) {
        capText = String.format(Locale.US, "%.2f", capital)
    }
    LaunchedEffect(maxLoss) {
        slText = String.format(Locale.US, "%.2f", maxLoss)
    }
    LaunchedEffect(tpMult) {
        multText = tpMult.toString()
    }

    fun commitCapital() {
        val parsed = capText.trim().toDoubleOrNull()
        val clamped = (parsed ?: capital).coerceAtLeast(1.0)
        capText = String.format(Locale.US, "%.2f", clamped)
        onSaveCapital(clamped)
    }

    fun commitMaxLoss() {
        val parsed = slText.trim().toDoubleOrNull()
        val clamped = ((parsed ?: maxLoss).coerceAtLeast(0.10) * 100.0).roundToInt() / 100.0
        val finalSl = clamped.coerceAtLeast(0.10)
        slText = String.format(Locale.US, "%.2f", finalSl)
        onSaveMaxLoss(finalSl)
    }

    fun commitTpMult() {
        val parsed = multText.trim().toIntOrNull()
        val clamped = (parsed ?: tpMult).coerceAtLeast(1)
        multText = clamped.toString()
        onSaveTpMultiplier(clamped)
    }

    SettingsCard(title = "Trade Risk (TP / SL & Entry Dot)") {
        Text(
            text = String.format(
                Locale.US,
                "Capital: $%.2f · Max Loss (SL): $%.2f · Profit (TP %dx): $%.2f",
                capital,
                maxLoss,
                tpMult,
                tpDollar
            ),
            color = GoogleGreen,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Home dot turns Green when Long SL is below Support, Red when Short SL is above Resistance, else Grey.",
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Capital per trade ($)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = capText,
                onValueChange = { capText = it },
                label = { Text("Capital / trade ($)", fontSize = 12.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = {
                    commitCapital()
                    focusManager.clearFocus()
                }),
                modifier = Modifier
                    .weight(1f)
                    .onFocusChanged { if (!it.isFocused) commitCapital() },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = OutlineDark,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            OutlinedButton(
                onClick = { onSaveCapital((capital - 5.0).coerceAtLeast(1.0)) },
                enabled = capital > 1.0,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
            ) { Text("-5", color = TextPrimary, fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = { onSaveCapital(capital + 5.0) },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
            ) { Text("+5", color = TextPrimary, fontWeight = FontWeight.Bold) }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Max Loss / SL ($) - enforces min $0.10
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = slText,
                onValueChange = { slText = it },
                label = { Text("Max Loss SL ($ min 0.10)", fontSize = 12.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = {
                    commitMaxLoss()
                    focusManager.clearFocus()
                }),
                modifier = Modifier
                    .weight(1f)
                    .onFocusChanged { if (!it.isFocused) commitMaxLoss() },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = OutlineDark,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            OutlinedButton(
                onClick = {
                    val next = ((maxLoss - 0.10) * 100.0).roundToInt() / 100.0
                    onSaveMaxLoss(next.coerceAtLeast(0.10))
                },
                enabled = maxLoss > 0.10 + 1e-6,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
            ) { Text("-0.1", color = TextPrimary, fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = {
                    val next = ((maxLoss + 0.10) * 100.0).roundToInt() / 100.0
                    onSaveMaxLoss(next)
                },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
            ) { Text("+0.1", color = TextPrimary, fontWeight = FontWeight.Bold) }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // TP Multiplier (integer >= 1)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = multText,
                onValueChange = { multText = it.filter { ch -> ch.isDigit() } },
                label = { Text("TP Multiplier (× SL, min 1)", fontSize = 12.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = {
                    commitTpMult()
                    focusManager.clearFocus()
                }),
                modifier = Modifier
                    .weight(1f)
                    .onFocusChanged { if (!it.isFocused) commitTpMult() },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = OutlineDark,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            OutlinedButton(
                onClick = { onSaveTpMultiplier((tpMult - 1).coerceAtLeast(1)) },
                enabled = tpMult > 1,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
            ) { Text("-", color = TextPrimary, fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = { onSaveTpMultiplier(tpMult + 1) },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
            ) { Text("+", color = TextPrimary, fontWeight = FontWeight.Bold) }
        }

        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
            onClick = {
                commitCapital()
                commitMaxLoss()
                commitTpMult()
                focusManager.clearFocus()
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Apply Risk Settings", color = PrimaryBlue, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun ThresholdStepperRow(
    label: String,
    value: Double,
    step: Double,
    min: Double,
    max: Double,
    onChange: (Double) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { onChange(((value - step) * 100.0).roundToInt() / 100.0) },
                enabled = value > min + 1e-6,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
            ) {
                Text("-", color = TextPrimary, fontWeight = FontWeight.Bold)
            }
            Text(
                text = String.format(Locale.US, "%.2f", value),
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            OutlinedButton(
                onClick = { onChange(((value + step) * 100.0).roundToInt() / 100.0) },
                enabled = value < max - 1e-6,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
            ) {
                Text("+", color = TextPrimary, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun volumeMethodDescription(method: VolumeMethod): String = when (method) {
    VolumeMethod.OFF -> "No volume filter (every signal passes)."
    VolumeMethod.CHEAT_SHEET -> "Allows climax wicks; blocks rising thrusts & non-wick spikes."
    VolumeMethod.BLOCK_RISING -> "Blocks accelerating 3-bar volume thrusts into the line."
    VolumeMethod.EXHAUSTION_ONLY -> "Passes only falling, below-median volume approaches."
    VolumeMethod.CLIMAX_ONLY -> "Passes only high-volume spikes with rejection wick."
    VolumeMethod.ACTIVITY_FLOOR -> "Passes only when volume ratio meets floor ratio."
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun BatteryOptimizationScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val isIgnoring = isIgnoringBatteryOptimizations(context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }
            Text(
                text = "Battery Optimization",
                color = TextPrimary,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (isIgnoring) {
                        "Status: Unrestricted (Battery optimization disabled)"
                    } else {
                        "Status: Optimized (Android may pause background alerts)"
                    },
                    color = if (isIgnoring) GoogleGreen else GoogleRed,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Allow unrestricted background battery usage so general monitoring and Positioned alerts keep running reliably when the screen is off.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Button(
                    onClick = { openBatterySettings(context) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Open Battery Settings")
                }
            }
        }
    }
}

private fun isIgnoringBatteryOptimizations(context: Context): Boolean {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}

private fun openBatterySettings(context: Context) {
    val requestIntent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
        data = Uri.parse("package:${context.packageName}")
    }
    runCatching {
        context.startActivity(requestIntent)
    }.onFailure {
        val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        runCatching { context.startActivity(fallback) }
    }
}
