package com.trendlinealerts.app.ui.overview

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trendlinealerts.app.data.local.AlertLogEntity
import com.trendlinealerts.app.ui.theme.ChartFuchsia
import com.trendlinealerts.app.ui.theme.ChartYellow
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.SurfaceVariantDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.core.analytics.CandidateRecord
import com.trendlinealerts.core.analytics.HeikinAshiConverter
import com.trendlinealerts.core.analytics.TradeLevels
import com.trendlinealerts.core.engine.HtfLineBook
import com.trendlinealerts.core.engine.TrendlineEngine
import com.trendlinealerts.core.model.ActiveTrendline
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.CandidateDecision
import com.trendlinealerts.core.model.ChartCandleStyle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.TrendlineSide
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private const val RIGHT_SPACING_BARS = 6

private data class LineSegment(
    val line: ActiveTrendline,
    val startBarIndex: Int,
    val endBarIndex: Int,
    val isCurrentActive: Boolean
)

private data class ComputedChartData(
    val yMin: Double,
    val yMax: Double,
    val supportSegments: List<LineSegment>,
    val resistanceSegments: List<LineSegment>,
    val otherSegments: List<LineSegment>,
    val latestSupVal: Double?,
    val latestResVal: Double?
)

@Composable
fun OverviewChart(
    symbol: String,
    rawCandles1m: List<Candle>,
    htfClosed: List<Candle>,
    timeframe: Timeframe,
    enabledSlots: Set<SlotId>,
    candidates: List<CandidateRecord>,
    crossLogs: List<AlertLogEntity>,
    showOtherLines: Boolean,
    candleStyle: ChartCandleStyle,
    trendBias: EntryDirection?,
    tradeLevels: TradeLevels?,
    isLoading: Boolean,
    error: String?,
    onSelectCandleStyle: (ChartCandleStyle) -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val displayCandles = remember(rawCandles1m, candleStyle) {
        if (rawCandles1m.isEmpty()) {
            emptyList()
        } else if (candleStyle == ChartCandleStyle.HEIKIN_ASHI) {
            HeikinAshiConverter.convert(rawCandles1m).takeLast(240)
        } else {
            rawCandles1m.takeLast(240)
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceDark, RoundedCornerShape(12.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Chart toolbar: Candle style toggle (HA default / Candles) + Refresh button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(
                    selected = candleStyle == ChartCandleStyle.HEIKIN_ASHI,
                    onClick = { onSelectCandleStyle(ChartCandleStyle.HEIKIN_ASHI) },
                    label = { Text("Heikin Ashi", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryBlue,
                        selectedLabelColor = Color.White,
                        containerColor = SurfaceVariantDark,
                        labelColor = TextPrimary
                    )
                )
                FilterChip(
                    selected = candleStyle == ChartCandleStyle.CANDLES,
                    onClick = { onSelectCandleStyle(ChartCandleStyle.CANDLES) },
                    label = { Text("Candles", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryBlue,
                        selectedLabelColor = Color.White,
                        containerColor = SurfaceVariantDark,
                        labelColor = TextPrimary
                    )
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = PrimaryBlue,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "Refresh chart",
                        tint = PrimaryBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        if (!error.isNullOrBlank()) {
            Text(
                text = "Chart error ($symbol): $error",
                color = GoogleRed,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        if (displayCandles.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isLoading) "Loading $symbol 4h chart..." else "No candles loaded for $symbol. Tap refresh.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
            return@Column
        }

        val computed = remember(displayCandles, htfClosed, timeframe, enabledSlots, showOtherLines, tradeLevels) {
            val book = if (htfClosed.isNotEmpty()) HtfLineBook(TrendlineEngine(), htfClosed, timeframe.ms) else null
            val supportSegs = mutableListOf<LineSegment>()
            val resistanceSegs = mutableListOf<LineSegment>()
            val otherSegMap = linkedMapOf<SlotId, MutableList<LineSegment>>()

            var curSupLine: ActiveTrendline? = null
            var curSupStart = 0
            var curResLine: ActiveTrendline? = null
            var curResStart = 0

            val activeOthers = HashMap<SlotId, Pair<ActiveTrendline, Int>>()
            val lastIdx = displayCandles.lastIndex

            var latestSupVal: Double? = null
            var latestResVal: Double? = null

            if (book != null) {
                for (i in displayCandles.indices) {
                    val bar = displayCandles[i]
                    val t = bar.openTimeMs + 60_000L
                    val eng = book.resultAsOf(bar.openTimeMs)
                    val sStrong = eng.strongestSupportAt(t, enabledSlots)
                    val rStrong = eng.strongestResistanceAt(t, enabledSlots)

                    if (i == lastIdx) {
                        latestSupVal = sStrong?.valueAt(t)
                        latestResVal = rStrong?.valueAt(t)
                    }

                    // Support segments grouped by pivotKey (Pine line.new identity)
                    if (sStrong?.pivotKey != curSupLine?.pivotKey) {
                        curSupLine?.let { prev ->
                            supportSegs.add(LineSegment(prev, curSupStart, i - 1, isCurrentActive = false))
                        }
                        curSupLine = sStrong
                        curSupStart = i
                    }

                    // Resistance segments grouped by pivotKey
                    if (rStrong?.pivotKey != curResLine?.pivotKey) {
                        curResLine?.let { prev ->
                            resistanceSegs.add(LineSegment(prev, curResStart, i - 1, isCurrentActive = false))
                        }
                        curResLine = rStrong
                        curResStart = i
                    }

                    if (showOtherLines) {
                        val otherNow = eng.lines.values
                            .filter { it.slotId in enabledSlots && it.slotId != sStrong?.slotId && it.slotId != rStrong?.slotId }
                            .associateBy { it.slotId }
                        for (slot in SlotId.entries) {
                            val nowLine = otherNow[slot]
                            val prev = activeOthers[slot]
                            if (nowLine?.pivotKey != prev?.first?.pivotKey) {
                                if (prev != null) {
                                    otherSegMap.getOrPut(slot) { mutableListOf() }
                                        .add(LineSegment(prev.first, prev.second, i - 1, isCurrentActive = false))
                                }
                                if (nowLine != null) {
                                    activeOthers[slot] = nowLine to i
                                } else {
                                    activeOthers.remove(slot)
                                }
                            }
                        }
                    }
                }
                curSupLine?.let {
                    supportSegs.add(LineSegment(it, curSupStart, lastIdx, isCurrentActive = true))
                }
                curResLine?.let {
                    resistanceSegs.add(LineSegment(it, curResStart, lastIdx, isCurrentActive = true))
                }
                if (showOtherLines) {
                    activeOthers.forEach { (slot, pair) ->
                        otherSegMap.getOrPut(slot) { mutableListOf() }
                            .add(LineSegment(pair.first, pair.second, lastIdx, isCurrentActive = true))
                    }
                }
            }

            var minP = displayCandles.minOf { it.low }
            var maxP = displayCandles.maxOf { it.high }

            // Include strongest lines & valid TP/SL when near price without collapsing candles
            val candleSpan = (maxP - minP).coerceAtLeast(minP * 0.002)
            val includeCandidates = buildList {
                latestSupVal?.let { add(it) }
                latestResVal?.let { add(it) }
                if (tradeLevels?.isSlValid == true) {
                    add(tradeLevels.tpPrice)
                    add(tradeLevels.slPrice)
                }
            }
            includeCandidates.forEach { lv ->
                if (lv >= minP - candleSpan * 0.65 && lv <= maxP + candleSpan * 0.65) {
                    minP = min(minP, lv)
                    maxP = max(maxP, lv)
                }
            }
            val pad = ((maxP - minP) * 0.08).coerceAtLeast(minP * 0.0005)
            minP -= pad
            maxP += pad

            ComputedChartData(
                yMin = minP,
                yMax = maxP,
                supportSegments = supportSegs,
                resistanceSegments = resistanceSegs,
                otherSegments = otherSegMap.values.flatten(),
                latestSupVal = latestSupVal,
                latestResVal = latestResVal
            )
        }

        val yMin = computed.yMin
        val yMax = computed.yMax
        val latestSupVal = computed.latestSupVal
        val latestResVal = computed.latestResVal

        val barByOpen = remember(displayCandles) {
            displayCandles.withIndex().associate { (idx, c) -> c.openTimeMs to idx }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "H: ${fmtChartPrice(yMax)}",
                color = TextSecondary,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
            val edgeNote = buildString {
                if (latestResVal != null && latestResVal > yMax) append("▲Res above (${fmtChartPrice(latestResVal)})  ")
                if (latestSupVal != null && latestSupVal < yMin) append("▼Sup below (${fmtChartPrice(latestSupVal)})")
            }
            if (edgeNote.isNotEmpty()) {
                Text(
                    text = edgeNote.trim(),
                    color = PrimaryBlue,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
            }
            Text(
                text = "L: ${fmtChartPrice(yMin)}",
                color = TextSecondary,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(225.dp)
        ) {
            val w = size.width
            val h = size.height
            val n = displayCandles.size.coerceAtLeast(1)
            val totalXSlots = n + RIGHT_SPACING_BARS
            val stepX = w / totalXSlots.toFloat()
            val bodyW = (stepX * 0.65f).coerceIn(1.5f, 8f)
            val span = (yMax - yMin).coerceAtLeast(1e-9)

            val firstOpenMs = displayCandles.first().openTimeMs
            val leftEdgeTimeMs = firstOpenMs - 30_000L
            val rightEdgeTimeMs = firstOpenMs + ((totalXSlots - 0.5) * 60_000.0).toLong() + 60_000L

            fun yFor(price: Double): Float = ((yMax - price) / span * h).toFloat()
            fun xFor(idx: Int): Float = (idx + 0.5f) * stepX
            fun xForTime(timeMs: Long): Float {
                val barPos = (timeMs - firstOpenMs).toDouble() / 60_000.0
                return ((barPos + 0.5) * stepX).toFloat()
            }

            clipRect {
                // Horizontal reference grid
                for (g in 1..3) {
                    val gy = h * (g / 4f)
                    drawLine(OutlineDark, Offset(0f, gy), Offset(w, gy), strokeWidth = 1f)
                }

                // Pine line.new style straight-segment renderer:
                // - Draws from line's starting pivot (or left chart edge if pivot is older than 4h)
                // - No vertical step-jumps when S/R swaps; old segment ends cleanly at swap bar
                // - Currently active S/R extends past the last bar to the right edge of the chart
                fun drawPineSegment(seg: LineSegment, color: Color, strokePx: Float) {
                    val line = seg.line
                    val startPivotMs = line.older.openTimeMs
                    val leftTimeMs: Long
                    val xLeft: Float
                    if (startPivotMs <= firstOpenMs) {
                        leftTimeMs = leftEdgeTimeMs
                        xLeft = 0f
                    } else {
                        leftTimeMs = startPivotMs
                        xLeft = xForTime(startPivotMs).coerceIn(0f, xFor(seg.endBarIndex))
                    }

                    val rightTimeMs: Long
                    val xRight: Float
                    if (seg.isCurrentActive) {
                        rightTimeMs = rightEdgeTimeMs
                        xRight = w
                    } else {
                        rightTimeMs = displayCandles[seg.endBarIndex].openTimeMs + 60_000L
                        xRight = xFor(seg.endBarIndex)
                    }

                    val yLeft = yFor(line.valueAt(leftTimeMs))
                    val yRight = yFor(line.valueAt(rightTimeMs))
                    drawLine(
                        color = color,
                        start = Offset(xLeft, yLeft),
                        end = Offset(xRight, yRight),
                        strokeWidth = strokePx
                    )
                }

                if (showOtherLines) {
                    computed.otherSegments.forEach { seg ->
                        val col = (if (seg.line.side == TrendlineSide.RESISTANCE) ChartFuchsia else ChartYellow)
                            .copy(alpha = if (seg.isCurrentActive) 0.40f else 0.18f)
                        drawPineSegment(seg, col, strokePx = 1.4f)
                    }
                }

                computed.supportSegments.forEach { seg ->
                    val col = if (seg.isCurrentActive) ChartYellow else ChartYellow.copy(alpha = 0.45f)
                    drawPineSegment(seg, col, strokePx = if (seg.isCurrentActive) 2.6f else 1.8f)
                }

                computed.resistanceSegments.forEach { seg ->
                    val col = if (seg.isCurrentActive) ChartFuchsia else ChartFuchsia.copy(alpha = 0.45f)
                    drawPineSegment(seg, col, strokePx = if (seg.isCurrentActive) 2.6f else 1.8f)
                }

                // Live TP / SL horizontal dashed reference levels when valid
                if (tradeLevels?.isSlValid == true) {
                    val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                    val tpY = yFor(tradeLevels.tpPrice)
                    if (tpY in 0f..h) {
                        drawLine(
                            color = GoogleGreen.copy(alpha = 0.7f),
                            start = Offset(0f, tpY),
                            end = Offset(w, tpY),
                            strokeWidth = 1.4f,
                            pathEffect = dash
                        )
                    }
                    val slY = yFor(tradeLevels.slPrice)
                    if (slY in 0f..h) {
                        drawLine(
                            color = GoogleRed.copy(alpha = 0.7f),
                            start = Offset(0f, slY),
                            end = Offset(w, slY),
                            strokeWidth = 1.4f,
                            pathEffect = dash
                        )
                    }
                }

                // Candles (Heikin Ashi or Standard)
                displayCandles.forEachIndexed { idx, c ->
                    val cx = xFor(idx)
                    val up = c.close >= c.open
                    val col = if (up) GoogleGreen else GoogleRed
                    val yHigh = yFor(c.high)
                    val yLow = yFor(c.low)
                    val yOpen = yFor(c.open)
                    val yClose = yFor(c.close)

                    drawLine(col, Offset(cx, yHigh), Offset(cx, yLow), strokeWidth = max(1f, bodyW * 0.25f))
                    val top = min(yOpen, yClose)
                    val bot = max(yOpen, yClose)
                    drawRect(
                        color = col,
                        topLeft = Offset(cx - bodyW / 2f, top),
                        size = Size(bodyW, max(1.5f, bot - top))
                    )
                }

                // SignalCandidate markers (filled = SENT, hollow = BLOCKED/COOLDOWN)
                val markerR = 5.5.dp.toPx()
                candidates.forEach { cand ->
                    val idx = barByOpen[cand.barOpenMs] ?: return@forEach
                    val cx = xFor(idx)
                    val c = displayCandles[idx]
                    val isLong = cand.direction == EntryDirection.LONG
                    val col = if (isLong) GoogleGreen else GoogleRed
                    val path = Path()
                    if (isLong) {
                        val tipY = (yFor(c.low) + 4.dp.toPx()).coerceIn(markerR, h - 2f)
                        path.moveTo(cx, tipY)
                        path.lineTo(cx - markerR, tipY + markerR * 1.4f)
                        path.lineTo(cx + markerR, tipY + markerR * 1.4f)
                        path.close()
                    } else {
                        val tipY = (yFor(c.high) - 4.dp.toPx()).coerceIn(2f, h - markerR)
                        path.moveTo(cx, tipY)
                        path.lineTo(cx - markerR, tipY - markerR * 1.4f)
                        path.lineTo(cx + markerR, tipY - markerR * 1.4f)
                        path.close()
                    }
                    val style = if (cand.decision == CandidateDecision.SENT) Fill else Stroke(width = 2.dp.toPx())
                    drawPath(path = path, color = col, style = style)
                }

                // Positioned cross alerts from alert_logs -> diamonds
                crossLogs.forEach { log ->
                    if (!log.eventType.startsWith("CROSS_")) return@forEach
                    val barOpen = (log.timestampMs / 60_000L) * 60_000L - 60_000L
                    val idx = barByOpen[barOpen] ?: barByOpen[(log.timestampMs / 60_000L) * 60_000L] ?: return@forEach
                    val cx = xFor(idx)
                    val cy = yFor(log.lineValue).coerceIn(markerR, h - markerR)
                    val col = if (log.eventType == "CROSS_SUPPORT") ChartYellow else ChartFuchsia
                    val dPath = Path().apply {
                        moveTo(cx, cy - markerR)
                        lineTo(cx + markerR, cy)
                        lineTo(cx, cy + markerR)
                        lineTo(cx - markerR, cy)
                        close()
                    }
                    drawPath(path = dPath, color = col, style = Fill)
                }

                // Out-of-range edge arrows on right side
                if (latestResVal != null && latestResVal > yMax) {
                    val ax = w - 12.dp.toPx()
                    val ay = 4.dp.toPx()
                    val arrow = Path().apply {
                        moveTo(ax, ay)
                        lineTo(ax - 5.dp.toPx(), ay + 8.dp.toPx())
                        lineTo(ax + 5.dp.toPx(), ay + 8.dp.toPx())
                        close()
                    }
                    drawPath(arrow, ChartFuchsia, style = Fill)
                }
                if (latestSupVal != null && latestSupVal < yMin) {
                    val ax = w - 12.dp.toPx()
                    val ay = h - 4.dp.toPx()
                    val arrow = Path().apply {
                        moveTo(ax, ay)
                        lineTo(ax - 5.dp.toPx(), ay - 8.dp.toPx())
                        lineTo(ax + 5.dp.toPx(), ay - 8.dp.toPx())
                        close()
                    }
                    drawPath(arrow, ChartYellow, style = Fill)
                }
            }
        }

        val startClock = fmtTimeHm(displayCandles.first().openTimeMs)
        val endClock = fmtTimeHm(displayCandles.last().openTimeMs)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(startClock, color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("▲Sent △Blk ◆Cross · Yellow=Sup · Fuchsia=Res", color = TextSecondary, fontSize = 9.5.sp)
            Text(endClock, color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }

        // Live TP / SL strip directly below the chart
        HorizontalDivider(color = OutlineDark)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val biasText = when (trendBias) {
                EntryDirection.LONG -> "Signal: Bullish (Long)"
                EntryDirection.SHORT -> "Signal: Bearish (Short)"
                null -> "Signal: Neutral"
            }
            val biasColor = when (trendBias) {
                EntryDirection.LONG -> GoogleGreen
                EntryDirection.SHORT -> GoogleRed
                null -> TextSecondary
            }
            Text(
                text = biasText,
                color = biasColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )

            Column(horizontalAlignment = Alignment.End) {
                val valid = tradeLevels?.isSlValid == true
                val tpStr = if (valid && tradeLevels != null) {
                    "TP ${fmtChartPrice(tradeLevels.tpPrice)} (+$${String.format(Locale.US, "%.2f", tradeLevels.tpUsd)})"
                } else {
                    "TP --"
                }
                val slStr = if (valid && tradeLevels != null) {
                    "SL ${fmtChartPrice(tradeLevels.slPrice)} (-$${String.format(Locale.US, "%.2f", tradeLevels.slUsd)})"
                } else {
                    "SL --"
                }
                val tpCol = if (valid) GoogleGreen else TextSecondary
                val slCol = if (valid) GoogleRed else TextSecondary

                Text(slStr, color = slCol, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                Text(tpStr, color = tpCol, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private fun fmtTimeHm(ms: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(ms))

private fun fmtChartPrice(price: Double): String = when {
    price >= 1_000.0 -> String.format(Locale.US, "%.2f", price)
    price >= 1.0 -> String.format(Locale.US, "%.4f", price)
    price >= 0.01 -> String.format(Locale.US, "%.5f", price)
    else -> String.format(Locale.US, "%.6f", price)
}
