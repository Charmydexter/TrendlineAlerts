package com.trendlinealerts.app.ui.overview

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trendlinealerts.app.data.local.AlertLogEntity
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.core.analytics.CandidateRecord
import com.trendlinealerts.core.engine.HtfLineBook
import com.trendlinealerts.core.engine.TrendlineEngine
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.CandidateDecision
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.TrendlineSide
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private data class ChartStepPoint(
    val barIndex: Int,
    val value: Double
)

private data class ChartSlotSeries(
    val slotId: SlotId,
    val side: TrendlineSide,
    val points: List<ChartStepPoint>
)

@Composable
fun OverviewChart(
    candles1m: List<Candle>,
    htfClosed: List<Candle>,
    timeframe: Timeframe,
    enabledSlots: Set<SlotId>,
    candidates: List<CandidateRecord>,
    crossLogs: List<AlertLogEntity>,
    showOtherLines: Boolean,
    modifier: Modifier = Modifier
) {
    if (candles1m.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(SurfaceDark, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Loading 4h 1m candles...", color = TextSecondary, fontSize = 13.sp)
        }
        return
    }

    val computed = remember(candles1m, htfClosed, timeframe, enabledSlots, showOtherLines) {
        val book = if (htfClosed.isNotEmpty()) HtfLineBook(TrendlineEngine(), htfClosed, timeframe.ms) else null
        val strongestSup = mutableListOf<ChartStepPoint>()
        val strongestRes = mutableListOf<ChartStepPoint>()
        val otherMap = linkedMapOf<SlotId, MutableList<ChartStepPoint>>()

        var minP = candles1m.minOf { it.low }
        var maxP = candles1m.maxOf { it.high }

        if (book != null) {
            for (i in candles1m.indices) {
                val bar = candles1m[i]
                val t = bar.openTimeMs + 60_000L
                val eng = book.resultAsOf(bar.openTimeMs)
                val sStrong = eng.strongestSupportAt(t, enabledSlots)
                val rStrong = eng.strongestResistanceAt(t, enabledSlots)
                if (sStrong != null) strongestSup.add(ChartStepPoint(i, sStrong.valueAt(t)))
                if (rStrong != null) strongestRes.add(ChartStepPoint(i, rStrong.valueAt(t)))
                if (showOtherLines) {
                    eng.lines.values
                        .filter { it.slotId in enabledSlots && it.slotId != sStrong?.slotId && it.slotId != rStrong?.slotId }
                        .forEach { line ->
                            otherMap.getOrPut(line.slotId) { mutableListOf() }
                                .add(ChartStepPoint(i, line.valueAt(t)))
                        }
                }
            }
        }

        val lastIdx = candles1m.lastIndex
        val latestSupVal = strongestSup.lastOrNull { it.barIndex == lastIdx }?.value
        val latestResVal = strongestRes.lastOrNull { it.barIndex == lastIdx }?.value

        // Include strongest lines when close to price, cap vertical stretch so candles stay readable
        val candleSpan = (maxP - minP).coerceAtLeast(minP * 0.002)
        listOfNotNull(latestSupVal, latestResVal).forEach { lv ->
            if (lv >= minP - candleSpan * 0.6 && lv <= maxP + candleSpan * 0.6) {
                minP = min(minP, lv)
                maxP = max(maxP, lv)
            }
        }
        val pad = ((maxP - minP) * 0.08).coerceAtLeast(minP * 0.0005)
        minP -= pad
        maxP += pad

        val otherSeries = otherMap.entries.map { (slot, pts) ->
            ChartSlotSeries(slot, slot.side, pts)
        }
        Triple(
            Pair(minP, maxP),
            Triple(strongestSup, strongestRes, otherSeries),
            Pair(latestSupVal, latestResVal)
        )
    }

    val (yRange, lineData, latestExtremes) = computed
    val (yMin, yMax) = yRange
    val (strongestSup, strongestRes, otherSeries) = lineData
    val (latestSupVal, latestResVal) = latestExtremes

    val barByOpen = remember(candles1m) {
        candles1m.withIndex().associate { (idx, c) -> c.openTimeMs to idx }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceDark, RoundedCornerShape(12.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "H: ${fmtChartPrice(yMax)}",
                color = TextSecondary,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
            val edgeNote = buildString {
                if (latestResVal != null && latestResVal > yMax) append("▲Res above (${fmtChartPrice(latestResVal)})  ")
                if (latestSupVal != null && latestSupVal < yMin) append("▼Sup below (${fmtChartPrice(latestSupVal)})")
            }
            if (edgeNote.isNotEmpty()) {
                Text(
                    text = edgeNote.trim(),
                    color = PrimaryBlue,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
            }
            Text(
                text = "L: ${fmtChartPrice(yMin)}",
                color = TextSecondary,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
        ) {
            val w = size.width
            val h = size.height
            val n = candles1m.size.coerceAtLeast(1)
            val stepX = w / n.toFloat()
            val bodyW = (stepX * 0.65f).coerceIn(1.5f, 8f)
            val span = (yMax - yMin).coerceAtLeast(1e-9)

            fun yFor(price: Double): Float = ((yMax - price) / span * h).toFloat()
            fun xFor(idx: Int): Float = (idx + 0.5f) * stepX

            // Horizontal reference grid
            for (g in 1..3) {
                val gy = h * (g / 4f)
                drawLine(OutlineDark, Offset(0f, gy), Offset(w, gy), strokeWidth = 1f)
            }

            // Other lines (optional)
            if (showOtherLines) {
                otherSeries.forEach { series ->
                    val color = (if (series.side == TrendlineSide.RESISTANCE) GoogleRed else GoogleGreen).copy(alpha = 0.35f)
                    for (k in 1 until series.points.size) {
                        val p0 = series.points[k - 1]
                        val p1 = series.points[k]
                        if (p1.barIndex == p0.barIndex + 1) {
                            val y0 = yFor(p0.value)
                            val y1 = yFor(p1.value)
                            if (y0 in -20f..(h + 20f) || y1 in -20f..(h + 20f)) {
                                drawLine(color, Offset(xFor(p0.barIndex), y0), Offset(xFor(p1.barIndex), y1), strokeWidth = 1.5f)
                            }
                        }
                    }
                }
            }

            // Strongest Support & Resistance step lines
            fun drawStrongLine(pts: List<ChartStepPoint>, color: Color) {
                for (k in 1 until pts.size) {
                    val p0 = pts[k - 1]
                    val p1 = pts[k]
                    if (p1.barIndex == p0.barIndex + 1) {
                        val y0 = yFor(p0.value).coerceIn(-10f, h + 10f)
                        val y1 = yFor(p1.value).coerceIn(-10f, h + 10f)
                        drawLine(color, Offset(xFor(p0.barIndex), y0), Offset(xFor(p1.barIndex), y1), strokeWidth = 2.6f)
                    }
                }
            }
            drawStrongLine(strongestSup, GoogleGreen)
            drawStrongLine(strongestRes, GoogleRed)

            // Candles
            candles1m.forEachIndexed { idx, c ->
                val cx = xFor(idx)
                val up = c.close >= c.open
                val col = if (up) GoogleGreen else GoogleRed
                val yHigh = yFor(c.high)
                val yLow = yFor(c.low)
                val yOpen = yFor(c.open)
                val yClose = yFor(c.close)

                drawLine(col, Offset(cx, yHigh), Offset(cx, yLow), strokeWidth = max(1f, bodyW * 0.25f))
                val top = min(yOpen, yClose)
                val bot = max(yOpen, yClose)
                drawRect(
                    color = col,
                    topLeft = Offset(cx - bodyW / 2f, top),
                    size = Size(bodyW, max(1.5f, bot - top))
                )
            }

            // SignalCandidate markers (filled = SENT, hollow = BLOCKED/COOLDOWN)
            val markerR = 5.5.dp.toPx()
            candidates.forEach { cand ->
                val idx = barByOpen[cand.barOpenMs] ?: return@forEach
                val cx = xFor(idx)
                val c = candles1m[idx]
                val isLong = cand.direction == EntryDirection.LONG
                val col = if (isLong) GoogleGreen else GoogleRed
                val path = Path()
                if (isLong) {
                    val tipY = (yFor(c.low) + 4.dp.toPx()).coerceIn(markerR, h - 2f)
                    path.moveTo(cx, tipY)
                    path.lineTo(cx - markerR, tipY + markerR * 1.4f)
                    path.lineTo(cx + markerR, tipY + markerR * 1.4f)
                    path.close()
                } else {
                    val tipY = (yFor(c.high) - 4.dp.toPx()).coerceIn(2f, h - markerR)
                    path.moveTo(cx, tipY)
                    path.lineTo(cx - markerR, tipY - markerR * 1.4f)
                    path.lineTo(cx + markerR, tipY - markerR * 1.4f)
                    path.close()
                }
                val style = if (cand.decision == CandidateDecision.SENT) Fill else Stroke(width = 2.dp.toPx())
                drawPath(path = path, color = col, style = style)
            }

            // Positioned cross alerts from alert_logs -> diamonds
            crossLogs.forEach { log ->
                if (!log.eventType.startsWith("CROSS_")) return@forEach
                val barOpen = (log.timestampMs / 60_000L) * 60_000L - 60_000L
                val idx = barByOpen[barOpen] ?: barByOpen[(log.timestampMs / 60_000L) * 60_000L] ?: return@forEach
                val cx = xFor(idx)
                val cy = yFor(log.lineValue).coerceIn(markerR, h - markerR)
                val col = if (log.eventType == "CROSS_SUPPORT") GoogleGreen else GoogleRed
                val dPath = Path().apply {
                    moveTo(cx, cy - markerR)
                    lineTo(cx + markerR, cy)
                    lineTo(cx, cy + markerR)
                    lineTo(cx - markerR, cy)
                    close()
                }
                drawPath(path = dPath, color = col, style = Fill)
            }

            // Out-of-range edge arrows on right side
            if (latestResVal != null && latestResVal > yMax) {
                val ax = w - 12.dp.toPx()
                val ay = 4.dp.toPx()
                val arrow = Path().apply {
                    moveTo(ax, ay)
                    lineTo(ax - 5.dp.toPx(), ay + 8.dp.toPx())
                    lineTo(ax + 5.dp.toPx(), ay + 8.dp.toPx())
                    close()
                }
                drawPath(arrow, GoogleRed, style = Fill)
            }
            if (latestSupVal != null && latestSupVal < yMin) {
                val ax = w - 12.dp.toPx()
                val ay = h - 4.dp.toPx()
                val arrow = Path().apply {
                    moveTo(ax, ay)
                    lineTo(ax - 5.dp.toPx(), ay - 8.dp.toPx())
                    lineTo(ax + 5.dp.toPx(), ay - 8.dp.toPx())
                    close()
                }
                drawPath(arrow, GoogleGreen, style = Fill)
            }
        }

        val startClock = fmtTimeHm(candles1m.first().openTimeMs)
        val endClock = fmtTimeHm(candles1m.last().openTimeMs)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(startClock, color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("▲Filled=Sent  △Hollow=Blocked  ◆Cross", color = TextSecondary, fontSize = 10.sp)
            Text(endClock, color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }
    }
}

private fun fmtTimeHm(ms: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(ms))

private fun fmtChartPrice(price: Double): String = when {
    price >= 1_000.0 -> String.format(Locale.US, "%.2f", price)
    price >= 1.0 -> String.format(Locale.US, "%.4f", price)
    price >= 0.01 -> String.format(Locale.US, "%.5f", price)
    else -> String.format(Locale.US, "%.6f", price)
}
