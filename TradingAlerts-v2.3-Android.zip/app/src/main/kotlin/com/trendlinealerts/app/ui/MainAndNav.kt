package com.trendlinealerts.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.trendlinealerts.app.TrendlineAlertsApp
import com.trendlinealerts.app.service.MonitoringForegroundService
import com.trendlinealerts.app.service.NotificationHelper
import com.trendlinealerts.app.ui.alertlog.AlertLogScreen
import com.trendlinealerts.app.ui.alertlog.AlertLogViewModel
import com.trendlinealerts.app.ui.monitor.MonitorScreen
import com.trendlinealerts.app.ui.monitor.MonitorViewModel
import com.trendlinealerts.app.ui.overview.OverviewScreen
import com.trendlinealerts.app.ui.overview.OverviewViewModel
import com.trendlinealerts.app.ui.settings.BatteryOptimizationScreen
import com.trendlinealerts.app.ui.settings.SettingsScreen
import com.trendlinealerts.app.ui.settings.SettingsViewModel
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.TrendlineAlertsTheme
import com.trendlinealerts.app.ui.watchlist.WatchlistScreen
import com.trendlinealerts.app.ui.watchlist.WatchlistViewModel
import kotlinx.coroutines.launch

private enum class AppTab(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    HOME("home", "Home", Icons.Filled.Home),
    OVERVIEW("overview", "Overview", Icons.Filled.BarChart),
    ALERTS("alerts", "Alerts", Icons.Filled.History),
    WATCHLIST("watchlist", "Watchlist", Icons.Filled.List),
    SETTINGS("settings", "Settings", Icons.Filled.Settings)
}

private const val ROUTE_BATTERY = "battery"

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestNotificationPermissionIfNeeded()

        val container = (application as TrendlineAlertsApp).container
        val notificationHelper = NotificationHelper(this)
        notificationHelper.ensureChannels()

        setContent {
            TrendlineAlertsTheme {
                MainAppScaffold(
                    onToggleGeneralMonitoring = { enable ->
                        if (enable) {
                            requestNotificationPermissionIfNeeded()
                            MonitoringForegroundService.startGeneral(this)
                        } else {
                            MonitoringForegroundService.stopGeneral(this)
                        }
                    },
                    onTogglePriorityOverride = { symbol, enabled ->
                        if (enabled) {
                            requestNotificationPermissionIfNeeded()
                        }
                        lifecycleScope.launch {
                            container.watchlistRepository.setPriorityOverride(symbol, enabled)
                            val shouldRun = container.watchlistRepository.hasAnyPriorityOverride() ||
                                container.settingsDataStore.getSnapshot().monitoringEnabled
                            MonitoringForegroundService.syncPriorityService(
                                context = this@MainActivity,
                                shouldBeRunning = shouldRun
                            )
                        }
                    },
                    onSendTestNotification = {
                        requestNotificationPermissionIfNeeded()
                        notificationHelper.sendTestNotification()
                    }
                )
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}

@Composable
private fun MainAppScaffold(
    onToggleGeneralMonitoring: (Boolean) -> Unit,
    onTogglePriorityOverride: (String, Boolean) -> Unit,
    onSendTestNotification: () -> Unit
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    var pendingOverviewSymbol by rememberSaveable { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val container = (context.applicationContext as TrendlineAlertsApp).container

    fun navigateToTab(route: String) {
        if (currentRoute != route) {
            navController.navigate(route) {
                popUpTo(AppTab.HOME.route) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    Scaffold(
        bottomBar = {
            if (currentRoute != ROUTE_BATTERY) {
                NavigationBar(containerColor = SurfaceDark) {
                    AppTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = { navigateToTab(tab.route) },
                            icon = { Icon(imageVector = tab.icon, contentDescription = tab.label) },
                            label = { Text(text = tab.label, maxLines = 1, softWrap = false) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = AppTab.HOME.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(AppTab.HOME.route) {
                val vm: MonitorViewModel = viewModel(
                    factory = MonitorViewModel.Factory(
                        settingsDataStore = container.settingsDataStore,
                        watchlistRepository = container.watchlistRepository,
                        monitorStateRepository = container.monitorStateRepository
                    )
                )
                MonitorScreen(
                    viewModel = vm,
                    onToggleGeneralMonitoring = onToggleGeneralMonitoring,
                    onTogglePriorityOverride = onTogglePriorityOverride,
                    onOpenAssetChart = { symbol ->
                        pendingOverviewSymbol = symbol
                        navigateToTab(AppTab.OVERVIEW.route)
                    }
                )
            }

            composable(AppTab.OVERVIEW.route) {
                val vm: OverviewViewModel = viewModel(
                    factory = OverviewViewModel.Factory(
                        settingsDataStore = container.settingsDataStore,
                        watchlistRepo = container.watchlistRepository,
                        candidateRepo = container.signalCandidateRepository,
                        alertLogRepo = container.alertLogRepository,
                        htfCandleCache = container.htfCandleCache,
                        coordinator = container.marketDataCoordinator,
                        replayRunner = container.replayRunner
                    )
                )
                OverviewScreen(
                    viewModel = vm,
                    pendingSymbol = pendingOverviewSymbol,
                    onConsumePendingSymbol = { pendingOverviewSymbol = null }
                )
            }

            composable(AppTab.ALERTS.route) {
                val vm: AlertLogViewModel = viewModel(
                    factory = AlertLogViewModel.Factory(container.alertLogRepository)
                )
                AlertLogScreen(viewModel = vm)
            }

            composable(AppTab.WATCHLIST.route) {
                val vm: WatchlistViewModel = viewModel(
                    factory = WatchlistViewModel.Factory(
                        watchlistRepository = container.watchlistRepository,
                        settingsDataStore = container.settingsDataStore
                    )
                )
                WatchlistScreen(viewModel = vm)
            }

            composable(AppTab.SETTINGS.route) {
                val vm: SettingsViewModel = viewModel(
                    factory = SettingsViewModel.Factory(
                        settingsDataStore = container.settingsDataStore,
                        marketDataCoordinator = container.marketDataCoordinator
                    )
                )
                SettingsScreen(
                    viewModel = vm,
                    onSendTestNotification = onSendTestNotification,
                    onOpenBatteryOptimization = {
                        navController.navigate(ROUTE_BATTERY)
                    }
                )
            }

            composable(ROUTE_BATTERY) {
                BatteryOptimizationScreen(
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
