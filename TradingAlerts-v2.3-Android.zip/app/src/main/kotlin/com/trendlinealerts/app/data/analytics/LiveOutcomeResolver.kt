package com.trendlinealerts.app.data.analytics

import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.data.repository.SignalCandidateRepository
import com.trendlinealerts.core.analytics.OutcomeCalculator
import com.trendlinealerts.core.model.EntryDirection
import kotlinx.coroutines.CancellationException

class LiveOutcomeResolver(
    private val candidateRepo: SignalCandidateRepository,
    private val coordinator: MarketDataCoordinator,
    private val settingsDataStore: SettingsDataStore
) {
    companion object {
        private const val MIN_AGE_MS = 2 * 60_000L
        private const val MAX_SYMBOLS_PER_CYCLE = 5
        private const val FOUR_HOURS_MS = 240 * 60_000L
    }

    suspend fun resolvePending(
        source: DataSourceType,
        marketType: MarketType,
        nowMs: Long = System.currentTimeMillis()
    ) {
        val pending = candidateRepo.getUnresolvedLiveBefore(nowMs - MIN_AGE_MS)
        if (pending.isEmpty()) return

        val alertSettings = settingsDataStore.getSnapshot().alertSettings
        val bySymbol = pending.groupBy { it.symbol }.entries.take(MAX_SYMBOLS_PER_CYCLE)
        for ((symbol, items) in bySymbol) {
            try {
                val earliestOpenMs = items.minOf { it.barOpenMs }
                val latestNeedEndMs = minOf(nowMs, items.maxOf { it.timeMs } + FOUR_HOURS_MS)
                val barsNeeded = (((latestNeedEndMs - earliestOpenMs) / 60_000L).toInt() + 10)
                    .coerceIn(20, 3000)

                val bars1m = coordinator.fetch1mCandles(
                    symbol = symbol,
                    source = source,
                    marketType = marketType,
                    limit = barsNeeded,
                    endTimeMs = latestNeedEndMs
                ).filter { it.isClosed }.sortedBy { it.openTimeMs }

                if (bars1m.isEmpty()) continue

                for (entity in items) {
                    val dir = runCatching { EntryDirection.valueOf(entity.direction) }.getOrNull() ?: continue
                    val outcome = OutcomeCalculator.compute(
                        entryPrice = entity.entryPrice,
                        direction = dir,
                        barOpenMs = entity.barOpenMs,
                        future1mClosedSorted = bars1m,
                        nowMs = nowMs,
                        lineValue = entity.lineValue,
                        settings = alertSettings
                    )
                    candidateRepo.updateOutcome(entity.id, outcome)
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (_: Exception) {
                // Skip failing symbol cleanly; retry next cycle.
            }
        }
    }
}
