package com.trendlinealerts.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0B0F14)
val SurfaceDark = Color(0xFF121821)
val SurfaceVariantDark = Color(0xFF1A222E)
val OutlineDark = Color(0xFF263242)

val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)

val PrimaryBlue = Color(0xFF3B82F6)
val GoogleRed = Color(0xFFEA4335)
val GoogleGreen = Color(0xFF34A853)

val SignalGreen = GoogleGreen
val SignalRed = GoogleRed
val SignalGrey = Color(0xFF6B7280)
val SignalYellow = Color(0xFFFBBF24)
val ChartYellow = Color(0xFFFACC15)
val ChartFuchsia = Color(0xFFFF00FF)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = GoogleRed

private val AppDarkColorScheme = darkColorScheme(
    primary = PrimaryBlue,
    onPrimary = Color.White,
    secondary = GoogleGreen,
    onSecondary = Color.White,
    tertiary = WarningAmber,
    background = BgDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondary,
    outline = OutlineDark,
    error = GoogleRed,
    onError = Color.White
)

@Composable
fun TrendlineAlertsTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AppDarkColorScheme,
        content = content
    )
}
