package com.trendlinealerts.app.data.analytics

import com.trendlinealerts.app.data.cache.HtfCandleCache
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.local.SignalCandidateEntity
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.repository.SignalCandidateRepository
import com.trendlinealerts.app.data.repository.WatchlistRepository
import com.trendlinealerts.app.data.repository.toEntity
import com.trendlinealerts.core.analytics.OutcomeCalculator
import com.trendlinealerts.core.detector.SignalProcessor
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.CandidateOrigin
import com.trendlinealerts.core.model.SymbolSignalState
import java.util.Collections
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ReplayProgress(
    val isRunning: Boolean = false,
    val days: Int = 3,
    val completedSymbols: Int = 0,
    val totalSymbols: Int = 0,
    val currentSymbol: String? = null,
    val foundCandidates: Int = 0,
    val error: String? = null
)

class ReplayRunner(
    private val watchlistRepo: WatchlistRepository,
    private val settingsDataStore: SettingsDataStore,
    private val htfCandleCache: HtfCandleCache,
    private val coordinator: MarketDataCoordinator,
    private val candidateRepo: SignalCandidateRepository
) {
    companion object {
        private const val CONCURRENCY = 5
        private const val WARMUP_BARS_6H = 360
        private const val BASELINE_PAD_BARS = 35
    }

    private val _progress = MutableStateFlow(ReplayProgress())
    val progress: StateFlow<ReplayProgress> = _progress.asStateFlow()

    suspend fun run(days: Int) {
        val safeDays = days.coerceIn(1, 7)
        val entities = watchlistRepo.getAllEntities()
        if (entities.isEmpty()) {
            _progress.value = ReplayProgress(isRunning = false, days = safeDays, error = "Watchlist is empty")
            return
        }

        val snap = settingsDataStore.getSnapshot()
        val nowMs = System.currentTimeMillis()
        val lastClosedOpen = (nowMs / 60_000L) * 60_000L - 60_000L
        val windowBars = safeDays * 1_440
        val windowStartOpenMs = lastClosedOpen - windowBars * 60_000L
        val total1mBars = windowBars + WARMUP_BARS_6H + BASELINE_PAD_BARS

        _progress.value = ReplayProgress(
            isRunning = true,
            days = safeDays,
            completedSymbols = 0,
            totalSymbols = entities.size,
            currentSymbol = entities.firstOrNull()?.symbol,
            foundCandidates = 0,
            error = null
        )

        val processor = SignalProcessor()
        val collected = Collections.synchronizedList(mutableListOf<SignalCandidateEntity>())
        val doneCounter = AtomicInteger(0)

        try {
            for (chunk in entities.chunked(CONCURRENCY)) {
                coroutineScope {
                    chunk.map { entity ->
                        async {
                            val htf = htfCandleCache.getClosedCandles(
                                symbol = entity.symbol,
                                timeframe = snap.alertSettings.timeframe,
                                source = snap.dataSource,
                                marketType = snap.marketType,
                                nowMs = nowMs
                            )
                            if (htf.size >= 10) {
                                val bars1m = coordinator.fetch1mCandles(
                                    symbol = entity.symbol,
                                    source = snap.dataSource,
                                    marketType = snap.marketType,
                                    limit = total1mBars
                                ).filter { it.isClosed }.sortedBy { it.openTimeMs }

                                if (bars1m.isNotEmpty()) {
                                    val res = processor.process(
                                        symbol = entity.symbol,
                                        previous = SymbolSignalState(symbol = entity.symbol, mode = AssetMode.GENERAL),
                                        mode = AssetMode.GENERAL,
                                        htfClosed = htf,
                                        timeframe = snap.alertSettings.timeframe,
                                        bars1m = bars1m,
                                        lastPrice = bars1m.last().close,
                                        settings = snap.alertSettings,
                                        nowMs = nowMs,
                                        emitCandidates = true,
                                        candidateAfterMs = windowStartOpenMs,
                                        candidateOrigin = CandidateOrigin.REPLAY
                                    )
                                    res.candidates.forEach { cand ->
                                        val outcome = OutcomeCalculator.compute(
                                            entryPrice = cand.entryPrice,
                                            direction = cand.direction,
                                            barOpenMs = cand.barOpenMs,
                                            future1mClosedSorted = bars1m,
                                            nowMs = nowMs,
                                            lineValue = cand.lineValue,
                                            settings = snap.alertSettings
                                        )
                                        collected.add(cand.toEntity(outcome))
                                    }
                                }
                            }
                            val done = doneCounter.incrementAndGet()
                            _progress.value = ReplayProgress(
                                isRunning = true,
                                days = safeDays,
                                completedSymbols = done,
                                totalSymbols = entities.size,
                                currentSymbol = entity.symbol,
                                foundCandidates = collected.size,
                                error = null
                            )
                        }
                    }.awaitAll()
                }
            }

            candidateRepo.replaceReplay(collected.toList())
            _progress.value = ReplayProgress(
                isRunning = false,
                days = safeDays,
                completedSymbols = entities.size,
                totalSymbols = entities.size,
                currentSymbol = null,
                foundCandidates = collected.size,
                error = null
            )
        } catch (ce: CancellationException) {
            _progress.value = _progress.value.copy(isRunning = false, currentSymbol = null)
            throw ce
        } catch (e: Exception) {
            _progress.value = _progress.value.copy(
                isRunning = false,
                currentSymbol = null,
                error = "${e::class.java.simpleName}: ${e.message}"
            )
        }
    }
}
