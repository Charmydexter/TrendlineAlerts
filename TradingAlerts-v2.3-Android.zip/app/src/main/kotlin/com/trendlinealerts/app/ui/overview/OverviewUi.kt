package com.trendlinealerts.app.ui.overview

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.analytics.ReplayProgress
import com.trendlinealerts.app.data.analytics.ReplayRunner
import com.trendlinealerts.app.data.cache.HtfCandleCache
import com.trendlinealerts.app.data.local.AlertLogEntity
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.repository.AlertLogRepository
import com.trendlinealerts.app.data.repository.SignalCandidateRepository
import com.trendlinealerts.app.data.repository.WatchlistRepository
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.ChartFuchsia
import com.trendlinealerts.app.ui.theme.ChartYellow
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.SurfaceVariantDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.core.analytics.AssetBreakdownRow
import com.trendlinealerts.core.analytics.CandidateRecord
import com.trendlinealerts.core.analytics.DecisionBucketStats
import com.trendlinealerts.core.analytics.MethodEvaluation
import com.trendlinealerts.core.analytics.PerformanceStats
import com.trendlinealerts.core.analytics.StatsCalculator
import com.trendlinealerts.core.analytics.TradeLevels
import com.trendlinealerts.core.analytics.TradeRiskCalculator
import com.trendlinealerts.core.detector.SignalProcessor
import com.trendlinealerts.core.engine.HtfLineBook
import com.trendlinealerts.core.engine.TrendlineEngine
import com.trendlinealerts.core.model.ActiveTrendline
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.CandidateDecision
import com.trendlinealerts.core.model.ChartCandleStyle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.TradeOutcomeStatus
import com.trendlinealerts.core.model.TrendlineSide
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class OverviewScope { ALL_ASSETS, ONE_ASSET }

enum class OverviewRange(val label: String, val ms: Long?) {
    H24("24h", 24L * 3_600_000L),
    D3("3d", 3L * 24L * 3_600_000L),
    D7("7d", 7L * 24L * 3_600_000L),
    ALL("All", null)
}

data class ChartSeriesState(
    val symbol: String = "",
    val candles1m: List<Candle> = emptyList(),
    val htfClosed: List<Candle> = emptyList(),
    val lastPrice: Double? = null,
    val strongestSupport: ActiveTrendline? = null,
    val strongestResistance: ActiveTrendline? = null,
    val allLines: List<ActiveTrendline> = emptyList(),
    val trendBias: EntryDirection? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

data class OverviewUiState(
    val scope: OverviewScope = OverviewScope.ALL_ASSETS,
    val range: OverviewRange = OverviewRange.D3,
    val replayDays: Int = 3,
    val replayProgress: ReplayProgress = ReplayProgress(),
    val symbols: List<String> = emptyList(),
    val selectedSymbol: String = "",
    val showOtherLines: Boolean = false,
    val chartCandleStyle: ChartCandleStyle = ChartCandleStyle.HEIKIN_ASHI,
    val alertSettings: AlertSettings = AlertSettings(),
    val performance: PerformanceStats = StatsCalculator.computePerformance(emptyList()),
    val methodEvaluations: List<MethodEvaluation> = emptyList(),
    val assetBreakdown: List<AssetBreakdownRow> = emptyList(),
    val filteredCandidates: List<CandidateRecord> = emptyList(),
    val crossLogs: List<AlertLogEntity> = emptyList(),
    val chartState: ChartSeriesState = ChartSeriesState(),
    val chartTradeLevels: TradeLevels? = null
)

class OverviewViewModel(
    private val settingsDataStore: SettingsDataStore,
    private val watchlistRepo: WatchlistRepository,
    private val candidateRepo: SignalCandidateRepository,
    private val alertLogRepo: AlertLogRepository,
    private val htfCandleCache: HtfCandleCache,
    private val coordinator: MarketDataCoordinator,
    private val replayRunner: ReplayRunner
) : ViewModel() {

    private val scopeFlow = MutableStateFlow(OverviewScope.ALL_ASSETS)
    private val rangeFlow = MutableStateFlow(OverviewRange.D3)
    private val replayDaysFlow = MutableStateFlow(3)
    private val selectedSymbolFlow = MutableStateFlow("")
    private val showOtherLinesFlow = MutableStateFlow(false)
    private val chartStateFlow = MutableStateFlow(ChartSeriesState())

    private var replayJob: Job? = null
    private var chartPollJob: Job? = null

    init {
        viewModelScope.launch {
            watchlistRepo.entitiesFlow.collect { entities ->
                val syms = entities.map { it.symbol }
                val current = selectedSymbolFlow.value
                if (syms.isNotEmpty() && (current.isBlank() || current !in syms)) {
                    selectedSymbolFlow.value = syms.first()
                }
            }
        }
    }

    private val baseFlow = combine(
        scopeFlow,
        rangeFlow,
        replayDaysFlow,
        selectedSymbolFlow,
        showOtherLinesFlow
    ) { sc, rg, rDays, sel, showOther ->
        listOf(sc, rg, rDays, sel, showOther)
    }

    private val dataFlow = combine(
        settingsDataStore.settingsFlow,
        watchlistRepo.entitiesFlow,
        candidateRepo.observeSince(0L),
        alertLogRepo.observeSince(0L),
        replayRunner.progress
    ) { settings, watchlist, candidates, logs, progress ->
        listOf(settings, watchlist, candidates, logs, progress)
    }

    @Suppress("UNCHECKED_CAST")
    val uiState: StateFlow<OverviewUiState> = combine(
        baseFlow,
        dataFlow,
        chartStateFlow
    ) { base, data, rawChart ->
        val scope = base[0] as OverviewScope
        val range = base[1] as OverviewRange
        val replayDays = base[2] as Int
        val selRaw = base[3] as String
        val showOther = base[4] as Boolean

        val settingsSnap = data[0] as com.trendlinealerts.app.data.local.AppSettingsSnapshot
        val watchlist = data[1] as List<com.trendlinealerts.app.data.local.WatchlistEntity>
        val allCandidates = data[2] as List<CandidateRecord>
        val allLogs = data[3] as List<AlertLogEntity>
        val replayProg = data[4] as ReplayProgress

        val symbols = watchlist.map { it.symbol }
        val selectedSymbol = if (selRaw in symbols) selRaw else (symbols.firstOrNull() ?: "")

        val nowMs = System.currentTimeMillis()
        val cutoffMs = range.ms?.let { nowMs - it } ?: 0L
        val inRange = allCandidates.filter { it.timeMs >= cutoffMs }
        val scopedCandidates = if (scope == OverviewScope.ALL_ASSETS || selectedSymbol.isEmpty()) {
            inRange
        } else {
            inRange.filter { it.symbol == selectedSymbol }
        }
        val mergedScoped = StatsCalculator.mergeCandidates(scopedCandidates)

        val scopedCrossLogs = if (selectedSymbol.isNotEmpty()) {
            allLogs.filter { it.symbol == selectedSymbol && it.eventType.startsWith("CROSS_") }
        } else {
            emptyList()
        }

        // Never show a mismatched previous symbol's chart while switching symbols
        val activeChart = if (rawChart.symbol == selectedSymbol) {
            rawChart
        } else {
            ChartSeriesState(symbol = selectedSymbol, isLoading = selectedSymbol.isNotBlank())
        }

        val targetLineVal = when (activeChart.trendBias) {
            EntryDirection.LONG -> activeChart.strongestSupport?.valueAt(nowMs)
            EntryDirection.SHORT -> activeChart.strongestResistance?.valueAt(nowMs)
            null -> null
        }
        val tradeLevels = if (activeChart.lastPrice != null && activeChart.trendBias != null) {
            TradeRiskCalculator.compute(
                price = activeChart.lastPrice,
                direction = activeChart.trendBias,
                targetLineValue = targetLineVal,
                settings = settingsSnap.alertSettings
            )
        } else {
            null
        }

        OverviewUiState(
            scope = scope,
            range = range,
            replayDays = replayDays,
            replayProgress = replayProg,
            symbols = symbols,
            selectedSymbol = selectedSymbol,
            showOtherLines = showOther,
            chartCandleStyle = settingsSnap.chartCandleStyle,
            alertSettings = settingsSnap.alertSettings,
            performance = StatsCalculator.computePerformance(mergedScoped),
            methodEvaluations = StatsCalculator.evaluateAllMethods(mergedScoped, settingsSnap.alertSettings),
            assetBreakdown = StatsCalculator.assetBreakdown(inRange),
            filteredCandidates = mergedScoped.sortedByDescending { it.timeMs },
            crossLogs = scopedCrossLogs,
            chartState = activeChart,
            chartTradeLevels = tradeLevels
        )
    }.flowOn(Dispatchers.Default).stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = OverviewUiState()
    )

    fun setScope(scope: OverviewScope) {
        scopeFlow.value = scope
    }

    fun setRange(range: OverviewRange) {
        rangeFlow.value = range
    }

    fun setReplayDays(days: Int) {
        replayDaysFlow.value = days
    }

    fun selectSymbol(symbol: String) {
        if (symbol.isBlank()) return
        val changed = selectedSymbolFlow.value != symbol
        selectedSymbolFlow.value = symbol
        scopeFlow.value = OverviewScope.ONE_ASSET
        if (changed || chartStateFlow.value.symbol != symbol) {
            chartStateFlow.value = ChartSeriesState(symbol = symbol, isLoading = true)
        }
        startChartAutoRefresh()
    }

    fun openAssetFromHome(symbol: String) {
        selectSymbol(symbol)
    }

    fun setShowOtherLines(show: Boolean) {
        showOtherLinesFlow.value = show
    }

    fun setCandleStyle(style: ChartCandleStyle) {
        viewModelScope.launch {
            settingsDataStore.setChartCandleStyle(style)
        }
    }

    fun startReplay() {
        if (replayJob?.isActive == true) return
        val days = replayDaysFlow.value
        replayJob = viewModelScope.launch(Dispatchers.IO) {
            replayRunner.run(days)
        }
    }

    fun cancelReplay() {
        replayJob?.cancel()
        replayJob = null
    }

    fun startChartAutoRefresh() {
        val sym = selectedSymbolFlow.value.ifBlank { return }
        chartPollJob?.cancel()
        chartPollJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                loadChartOnce(sym)
                delay(60_000L)
            }
        }
    }

    fun stopChartAutoRefresh() {
        chartPollJob?.cancel()
        chartPollJob = null
    }

    fun refreshChartNow() {
        startChartAutoRefresh()
    }

    private suspend fun loadChartOnce(sym: String) {
        if (selectedSymbolFlow.value != sym) return
        chartStateFlow.value = if (chartStateFlow.value.symbol == sym) {
            chartStateFlow.value.copy(isLoading = true, error = null)
        } else {
            ChartSeriesState(symbol = sym, isLoading = true)
        }

        val snap = settingsDataStore.getSnapshot()
        val nowMs = System.currentTimeMillis()
        try {
            val htf = htfCandleCache.getClosedCandles(
                symbol = sym,
                timeframe = snap.alertSettings.timeframe,
                source = snap.dataSource,
                marketType = snap.marketType,
                nowMs = nowMs
            )
            val candles1m = coordinator.fetch1mCandles(
                symbol = sym,
                source = snap.dataSource,
                marketType = snap.marketType,
                limit = 275
            ).filter { it.isClosed }.sortedBy { it.openTimeMs }.takeLast(270)

            val lastPrice = candles1m.lastOrNull()?.close
            val res = if (htf.isNotEmpty()) {
                HtfLineBook(TrendlineEngine(), htf, snap.alertSettings.timeframe.ms).resultAsOf(nowMs)
            } else {
                null
            }
            val trendBias = if (htf.isNotEmpty() && candles1m.isNotEmpty() && lastPrice != null) {
                SignalProcessor(TrendlineEngine()).process(
                    symbol = sym,
                    previous = SymbolSignalState(symbol = sym, mode = AssetMode.GENERAL),
                    mode = AssetMode.GENERAL,
                    htfClosed = htf,
                    timeframe = snap.alertSettings.timeframe,
                    bars1m = candles1m,
                    lastPrice = lastPrice,
                    settings = snap.alertSettings,
                    nowMs = nowMs,
                    emitCandidates = false
                ).state.trendBias
            } else {
                null
            }

            if (selectedSymbolFlow.value != sym) return

            val enabled = snap.alertSettings.enabledSlots
            chartStateFlow.value = ChartSeriesState(
                symbol = sym,
                candles1m = candles1m,
                htfClosed = htf,
                lastPrice = lastPrice,
                strongestSupport = res?.strongestSupportAt(nowMs, enabled),
                strongestResistance = res?.strongestResistanceAt(nowMs, enabled),
                allLines = res?.lines?.values?.filter { it.slotId in enabled }?.sortedByDescending { it.valueAt(nowMs) }.orEmpty(),
                trendBias = trendBias,
                isLoading = false,
                error = null
            )
        } catch (e: Exception) {
            if (selectedSymbolFlow.value != sym) return
            chartStateFlow.value = chartStateFlow.value.copy(
                symbol = sym,
                isLoading = false,
                error = "${e::class.java.simpleName}: ${e.message}"
            )
        }
    }

    class Factory(
        private val settingsDataStore: SettingsDataStore,
        private val watchlistRepo: WatchlistRepository,
        private val candidateRepo: SignalCandidateRepository,
        private val alertLogRepo: AlertLogRepository,
        private val htfCandleCache: HtfCandleCache,
        private val coordinator: MarketDataCoordinator,
        private val replayRunner: ReplayRunner
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return OverviewViewModel(
                settingsDataStore,
                watchlistRepo,
                candidateRepo,
                alertLogRepo,
                htfCandleCache,
                coordinator,
                replayRunner
            ) as T
        }
    }
}

@Composable
fun OverviewScreen(
    viewModel: OverviewViewModel,
    pendingSymbol: String? = null,
    onConsumePendingSymbol: () -> Unit = {}
) {
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(pendingSymbol) {
        if (!pendingSymbol.isNullOrBlank()) {
            viewModel.openAssetFromHome(pendingSymbol)
            onConsumePendingSymbol()
        }
    }

    val shouldAutoRefresh = state.scope == OverviewScope.ONE_ASSET && state.selectedSymbol.isNotBlank()
    LaunchedEffect(shouldAutoRefresh, state.selectedSymbol) {
        if (shouldAutoRefresh) {
            viewModel.startChartAutoRefresh()
        } else {
            viewModel.stopChartAutoRefresh()
        }
    }
    DisposableEffect(Unit) {
        onDispose { viewModel.stopChartAutoRefresh() }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Overview", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        // Scope + Range controls
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = state.scope == OverviewScope.ALL_ASSETS,
                        onClick = { viewModel.setScope(OverviewScope.ALL_ASSETS) },
                        label = { Text("All assets") },
                        colors = chipColors()
                    )
                    FilterChip(
                        selected = state.scope == OverviewScope.ONE_ASSET,
                        onClick = { viewModel.setScope(OverviewScope.ONE_ASSET) },
                        label = { Text("One asset") },
                        colors = chipColors()
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OverviewRange.entries.forEach { rg ->
                        FilterChip(
                            selected = state.range == rg,
                            onClick = { viewModel.setRange(rg) },
                            label = { Text(rg.label) },
                            colors = chipColors()
                        )
                    }
                }
            }
        }

        // Analyze last N days card
        item {
            ReplayCard(
                replayDays = state.replayDays,
                progress = state.replayProgress,
                onSelectDays = viewModel::setReplayDays,
                onStart = viewModel::startReplay,
                onCancel = viewModel::cancelReplay
            )
        }

        if (state.scope == OverviewScope.ONE_ASSET) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    state.symbols.forEach { sym ->
                        FilterChip(
                            selected = state.selectedSymbol == sym,
                            onClick = { viewModel.selectSymbol(sym) },
                            label = { Text(sym.removeSuffix("USDT")) },
                            colors = chipColors()
                        )
                    }
                }
            }

            item {
                OverviewChart(
                    symbol = state.selectedSymbol,
                    rawCandles1m = state.chartState.candles1m,
                    htfClosed = state.chartState.htfClosed,
                    timeframe = state.alertSettings.timeframe,
                    enabledSlots = state.alertSettings.enabledSlots,
                    candidates = state.filteredCandidates,
                    crossLogs = state.crossLogs,
                    showOtherLines = state.showOtherLines,
                    candleStyle = state.chartCandleStyle,
                    trendBias = state.chartState.trendBias,
                    tradeLevels = state.chartTradeLevels,
                    isLoading = state.chartState.isLoading,
                    error = state.chartState.error,
                    onSelectCandleStyle = viewModel::setCandleStyle,
                    onRefresh = viewModel::refreshChartNow
                )
            }

            item {
                StrongestLinesCard(
                    chartState = state.chartState,
                    showOtherLines = state.showOtherLines,
                    onToggleShowOther = viewModel::setShowOtherLines
                )
            }
        }

        // Performance card
        item {
            PerformanceCard(state.performance)
        }

        // Volume Method Comparison
        item {
            MethodComparisonCard(
                evaluations = state.methodEvaluations,
                activeMethod = state.alertSettings.volumeMethod
            )
        }

        if (state.scope == OverviewScope.ALL_ASSETS) {
            item {
                AllAssetsBreakdownCard(
                    rows = state.assetBreakdown,
                    onSelectSymbol = { sym -> viewModel.selectSymbol(sym) }
                )
            }
        } else {
            item {
                Text(
                    text = "Recent Candidates (${state.filteredCandidates.size})",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            items(state.filteredCandidates.take(50)) { cand ->
                CandidateRowCard(cand)
            }
        }
    }
}

@Composable
private fun chipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = PrimaryBlue,
    selectedLabelColor = Color.White,
    containerColor = SurfaceVariantDark,
    labelColor = TextPrimary
)

@Composable
private fun ReplayCard(
    replayDays: Int,
    progress: ReplayProgress,
    onSelectDays: (Int) -> Unit,
    onStart: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Historical Replay", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(1, 3, 7).forEach { d ->
                        FilterChip(
                            selected = replayDays == d,
                            onClick = { onSelectDays(d) },
                            label = { Text("${d}d") },
                            colors = chipColors()
                        )
                    }
                }
            }
            if (progress.isRunning) {
                val frac = if (progress.totalSymbols > 0) {
                    progress.completedSymbols.toFloat() / progress.totalSymbols.toFloat()
                } else 0f
                LinearProgressIndicator(
                    progress = { frac.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = PrimaryBlue
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${progress.completedSymbols}/${progress.totalSymbols} · ${progress.currentSymbol ?: ""} (${progress.foundCandidates} hits)",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    OutlinedButton(onClick = onCancel) { Text("Cancel", color = GoogleRed) }
                }
            } else {
                Button(
                    onClick = onStart,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Analyze last $replayDays days")
                }
                if (progress.totalSymbols > 0 && progress.error == null) {
                    Text(
                        text = "Last replay (${progress.days}d): ${progress.foundCandidates} candidates found.",
                        color = GoogleGreen,
                        fontSize = 12.sp
                    )
                }
            }
            if (!progress.error.isNullOrBlank()) {
                Text(progress.error, color = GoogleRed, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun StrongestLinesCard(
    chartState: ChartSeriesState,
    showOtherLines: Boolean,
    onToggleShowOther: (Boolean) -> Unit
) {
    val nowMs = System.currentTimeMillis()
    val price = chartState.lastPrice
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${chartState.symbol} Strongest Lines",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Other lines", color = TextSecondary, fontSize = 12.sp, maxLines = 1)
                    Spacer(modifier = Modifier.width(4.dp))
                    Switch(
                        checked = showOtherLines,
                        onCheckedChange = onToggleShowOther,
                        modifier = Modifier.scale(0.8f)
                    )
                }
            }

            chartState.strongestResistance?.let { r ->
                LineInfoRow("▲ ${r.slotId.name} (Highest R)", r.valueAt(nowMs), price, ChartFuchsia)
            } ?: Text("No active resistance", color = TextSecondary, fontSize = 12.sp)

            chartState.strongestSupport?.let { s ->
                LineInfoRow("▼ ${s.slotId.name} (Lowest S)", s.valueAt(nowMs), price, ChartYellow)
            } ?: Text("No active support", color = TextSecondary, fontSize = 12.sp)

            if (showOtherLines) {
                val others = chartState.allLines.filter {
                    it.slotId != chartState.strongestResistance?.slotId &&
                        it.slotId != chartState.strongestSupport?.slotId
                }
                if (others.isNotEmpty()) {
                    HorizontalDivider(color = OutlineDark)
                    others.forEach { l ->
                        val col = if (l.side == TrendlineSide.RESISTANCE) ChartFuchsia.copy(alpha = 0.75f) else ChartYellow.copy(alpha = 0.75f)
                        val icon = if (l.side == TrendlineSide.RESISTANCE) "▲" else "▼"
                        LineInfoRow("$icon ${l.slotId.name}", l.valueAt(nowMs), price, col)
                    }
                }
            }
        }
    }
}

@Composable
private fun LineInfoRow(label: String, lineVal: Double, price: Double?, color: Color) {
    val distStr = if (price != null && lineVal > 0.0) {
        String.format(Locale.US, "%+.2f%%", (price - lineVal) / lineVal * 100.0)
    } else "--"
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(
            text = "${fmtNum(lineVal)} ($distStr)",
            color = TextPrimary,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun PerformanceCard(stats: PerformanceStats) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "PERFORMANCE · 2-BAR REVERSAL TP/SL (${stats.totalCandidates} signals)",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            BucketRow("SENT", stats.sent, GoogleGreen)
            HorizontalDivider(color = OutlineDark)
            BucketRow("BLOCKED", stats.blocked, GoogleRed)
        }
    }
}

@Composable
private fun BucketRow(title: String, b: DecisionBucketStats, accent: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("$title (${b.count})", color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(
                text = "TP Win: ${fmtPct(b.tradeWinRatePct, suffix = "%")} · Net ${fmtUsd(b.netPnlUsd)}",
                color = if (b.netPnlUsd >= 0.0) GoogleGreen else GoogleRed,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("W: ${b.tradeWins}  L: ${b.tradeLosses}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp)
            Text("NoEntry: ${b.tradeNoEntry}  Pend: ${b.tradePending}", color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("15m: ${fmtSigned(b.avgRet15mPct)}", color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp)
            Text("1h: ${fmtSigned(b.avgRet1hPct)}", color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp)
            Text("4h: ${fmtSigned(b.avgRet4hPct)}", color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("MFE(4h): ${fmtPct(b.avgMfe4hPct, suffix = "%")}", color = GoogleGreen, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            Text("MAE(4h): ${fmtPct(b.avgMae4hPct, suffix = "%")}", color = GoogleRed, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MethodComparisonCard(
    evaluations: List<MethodEvaluation>,
    activeMethod: com.trendlinealerts.core.model.VolumeMethod
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Volume Method Comparison", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Method", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.6f))
                Text("Sent", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.55f))
                Text("W/L", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.75f))
                Text("Win%", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.75f))
                Text("Net$", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.85f))
            }
            HorizontalDivider(color = OutlineDark)
            evaluations.forEach { ev ->
                val isCurrent = ev.method == activeMethod
                val s = ev.stats.sent
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isCurrent) "${ev.method.name} *" else ev.method.name,
                        color = if (isCurrent) PrimaryBlue else TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1.6f)
                    )
                    Text("${s.count}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.55f))
                    Text("${s.tradeWins}/${s.tradeLosses}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.75f))
                    Text(fmtPct(s.tradeWinRatePct), color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.75f))
                    Text(fmtUsd(s.netPnlUsd), color = colorForRet(s.netPnlUsd), fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.85f))
                }
            }
        }
    }
}

@Composable
private fun AllAssetsBreakdownCard(
    rows: List<AssetBreakdownRow>,
    onSelectSymbol: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("All Assets (tap to inspect)", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            if (rows.isEmpty()) {
                Text("No signal candidates recorded yet.", color = TextSecondary, fontSize = 13.sp)
            } else {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Symbol", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.3f))
                    Text("Sent/Blk", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
                    Text("W/L", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                    Text("Win%", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                    Text("Net$", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.85f))
                }
                HorizontalDivider(color = OutlineDark)
                rows.forEach { r ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectSymbol(r.symbol) }
                            .padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(r.symbol, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1.3f))
                        Text("${r.sentCount}/${r.blockedCount}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
                        Text("${r.tradeWins}/${r.tradeLosses}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                        Text(fmtPct(r.tradeWinRatePct), color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                        Text(fmtUsd(r.netPnlUsd), color = colorForRet(r.netPnlUsd), fontFamily = FontFamily.Monospace, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.85f))
                    }
                }
            }
        }
    }
}

@Composable
private fun CandidateRowCard(cand: CandidateRecord) {
    val dirColor = if (cand.direction == EntryDirection.LONG) GoogleGreen else GoogleRed
    val decColor = when (cand.decision) {
        CandidateDecision.SENT -> GoogleGreen
        CandidateDecision.BLOCKED_VOLUME -> GoogleRed
        CandidateDecision.COOLDOWN -> TextSecondary
    }
    val statusText = when (cand.tradeStatus) {
        TradeOutcomeStatus.WIN -> "WIN (${fmtUsd(cand.pnlUsd ?: 0.0)})"
        TradeOutcomeStatus.LOSS -> "LOSS (${fmtUsd(cand.pnlUsd ?: 0.0)})"
        TradeOutcomeStatus.NO_ENTRY -> "NO ENTRY"
        TradeOutcomeStatus.EXPIRED -> "EXPIRED"
        TradeOutcomeStatus.PENDING -> "PENDING"
    }
    val statusColor = when (cand.tradeStatus) {
        TradeOutcomeStatus.WIN -> GoogleGreen
        TradeOutcomeStatus.LOSS -> GoogleRed
        TradeOutcomeStatus.NO_ENTRY, TradeOutcomeStatus.EXPIRED, TradeOutcomeStatus.PENDING -> TextSecondary
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${cand.direction.name} · ${cand.slotId.name} (${cand.decision.name})", color = dirColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(fmtTimestamp(cand.timeMs), color = TextSecondary, fontSize = 11.sp)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Touch ${fmtNum(cand.entryPrice)} · Vol x${String.format(Locale.US, "%.2f", cand.volumeRatio)}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                Text("${cand.origin.name} · $statusText", color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
            val confirmEntry = cand.confirmEntryPrice
            val tp = cand.tpPrice
            val sl = cand.slPrice
            if (confirmEntry != null && tp != null && sl != null) {
                Text(
                    text = "Confirm ${fmtNum(confirmEntry)} | TP ${fmtNum(tp)} | SL ${fmtNum(sl)}",
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
            Text(
                text = "15m: ${fmtSigned(cand.ret15mPct)} | 1h: ${fmtSigned(cand.ret1hPct)} | 4h: ${fmtSigned(cand.ret4hPct)}",
                color = TextSecondary,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
        }
    }
}

private fun colorForRet(v: Double?): Color = when {
    v == null -> TextSecondary
    v >= 0.0 -> GoogleGreen
    else -> GoogleRed
}

private fun fmtPct(v: Double?, suffix: String = ""): String =
    v?.let { String.format(Locale.US, "%.1f%s", it, suffix) } ?: "--"

private fun fmtSigned(v: Double?): String =
    v?.let { String.format(Locale.US, "%+.2f%%", it) } ?: "--"

private fun fmtUsd(v: Double): String {
    val absVal = String.format(Locale.US, "%.2f", kotlin.math.abs(v))
    return if (v >= 0.0) "+$$absVal" else "-$$absVal"
}

private fun fmtNum(price: Double): String = when {
    price >= 1_000.0 -> String.format(Locale.US, "%.2f", price)
    price >= 1.0 -> String.format(Locale.US, "%.4f", price)
    price >= 0.01 -> String.format(Locale.US, "%.5f", price)
    else -> String.format(Locale.US, "%.6f", price)
}

private fun fmtTimestamp(ms: Long): String =
    SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date(ms))
