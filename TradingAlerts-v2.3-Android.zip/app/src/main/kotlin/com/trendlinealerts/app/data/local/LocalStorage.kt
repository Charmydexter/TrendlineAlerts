package com.trendlinealerts.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.VolumeMethod
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

@Entity(tableName = "watchlist")
data class WatchlistEntity(
    @PrimaryKey val symbol: String,
    val sortOrder: Int,
    val addedAtMs: Long,
    val isPriorityOverride: Boolean = false,
    val lastAlertedAtMs: Long = 0L,
    val lastCrossSide: String? = null,
    val lastEntryDirection: String? = null
)

@Entity(tableName = "alert_logs")
data class AlertLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val symbol: String,
    val eventType: String,
    val slotId: String,
    val price: Double,
    val lineValue: Double,
    val message: String,
    val timestampMs: Long
)

@Entity(
    tableName = "htf_candles",
    primaryKeys = ["symbol", "timeframe", "source", "marketType", "openTimeMs"]
)
data class HtfCandleEntity(
    val symbol: String,
    val timeframe: String,
    val source: String,
    val marketType: String,
    val openTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

/** Per-symbol signal memory (JSON of SymbolSignalState). Lets the app resume exactly where it stopped. */
@Entity(tableName = "symbol_state")
data class SymbolStateEntity(
    @PrimaryKey val symbol: String,
    val json: String
)

@Entity(
    tableName = "signal_candidates",
    indices = [
        Index(value = ["symbol", "direction", "barOpenMs", "origin"], unique = true),
        Index(value = ["origin", "timeMs"]),
        Index(value = ["resolved", "timeMs"])
    ]
)
data class SignalCandidateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val symbol: String,
    val direction: String,
    val slotId: String,
    val barOpenMs: Long,
    val timeMs: Long,
    val entryPrice: Double,
    val lineValue: Double,
    val volumeRatio: Double,
    val rising3: Boolean,
    val falling: Boolean,
    val wickFraction: Double,
    val baselineAvailable: Boolean,
    val decision: String,
    val origin: String,
    val ret15mPct: Double? = null,
    val ret1hPct: Double? = null,
    val ret4hPct: Double? = null,
    val maxFav4hPct: Double? = null,
    val maxAdv4hPct: Double? = null,
    val resolved: Boolean = false
)

@Dao
interface SymbolStateDao {
    @Query("SELECT json FROM symbol_state WHERE symbol = :symbol")
    suspend fun get(symbol: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entity: SymbolStateEntity)

    @Query("DELETE FROM symbol_state WHERE symbol = :symbol")
    suspend fun delete(symbol: String)

    @Query("DELETE FROM symbol_state WHERE symbol NOT IN (:keep)")
    suspend fun deleteNotIn(keep: List<String>)

    @Query("DELETE FROM symbol_state")
    suspend fun clear()
}

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM watchlist ORDER BY lastAlertedAtMs DESC, sortOrder ASC, addedAtMs ASC")
    fun observeAll(): Flow<List<WatchlistEntity>>

    @Query("SELECT * FROM watchlist ORDER BY lastAlertedAtMs DESC, sortOrder ASC, addedAtMs ASC")
    suspend fun getAll(): List<WatchlistEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<WatchlistEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: WatchlistEntity)

    @Query("DELETE FROM watchlist WHERE symbol = :symbol")
    suspend fun deleteBySymbol(symbol: String)

    @Query("DELETE FROM watchlist")
    suspend fun deleteAll()

    @Query("UPDATE watchlist SET isPriorityOverride = :enabled WHERE symbol = :symbol")
    suspend fun setPriorityOverride(symbol: String, enabled: Boolean)

    @Query("SELECT COUNT(*) FROM watchlist WHERE isPriorityOverride = 1")
    suspend fun countPriorityOverrides(): Int

    @Query("UPDATE watchlist SET lastAlertedAtMs = :timestampMs WHERE symbol = :symbol")
    suspend fun updateLastAlertedAt(symbol: String, timestampMs: Long)

    @Query("SELECT COUNT(*) FROM watchlist")
    suspend fun count(): Int
}

@Dao
interface AlertLogDao {
    @Query("SELECT * FROM alert_logs ORDER BY timestampMs DESC LIMIT 500")
    fun observeRecent(): Flow<List<AlertLogEntity>>

    @Query("SELECT * FROM alert_logs WHERE timestampMs >= :sinceMs ORDER BY timestampMs ASC")
    fun observeSince(sinceMs: Long): Flow<List<AlertLogEntity>>

    @Insert
    suspend fun insert(entity: AlertLogEntity)

    @Query("DELETE FROM alert_logs")
    suspend fun clearAll()

    @Query("DELETE FROM alert_logs WHERE id NOT IN (SELECT id FROM alert_logs ORDER BY timestampMs DESC, id DESC LIMIT :keep)")
    suspend fun trimTo(keep: Int)
}

@Dao
interface HtfCandleDao {
    @Query(
        "SELECT * FROM htf_candles WHERE symbol = :symbol AND timeframe = :timeframe AND source = :source AND marketType = :marketType ORDER BY openTimeMs ASC"
    )
    suspend fun getCandles(
        symbol: String,
        timeframe: String,
        source: String,
        marketType: String
    ): List<HtfCandleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<HtfCandleEntity>)

    @Query(
        "DELETE FROM htf_candles WHERE symbol = :symbol AND timeframe = :timeframe AND source = :source AND marketType = :marketType AND openTimeMs < :minKeepTimeMs"
    )
    suspend fun trimOlderThan(
        symbol: String,
        timeframe: String,
        source: String,
        marketType: String,
        minKeepTimeMs: Long
    )

    @Query("DELETE FROM htf_candles WHERE timeframe != :timeframe")
    suspend fun deleteOtherTimeframes(timeframe: String)

    @Query("DELETE FROM htf_candles WHERE symbol NOT IN (:keep)")
    suspend fun deleteSymbolsNotIn(keep: List<String>)
}

@Dao
interface SignalCandidateDao {
    @Query("SELECT * FROM signal_candidates WHERE timeMs >= :sinceMs ORDER BY timeMs ASC")
    fun observeSince(sinceMs: Long): Flow<List<SignalCandidateEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllIgnore(items: List<SignalCandidateEntity>)

    @Query("SELECT * FROM signal_candidates WHERE origin = 'LIVE' AND resolved = 0 AND timeMs <= :cutoffMs ORDER BY timeMs ASC")
    suspend fun getUnresolvedLiveBefore(cutoffMs: Long): List<SignalCandidateEntity>

    @Query(
        "UPDATE signal_candidates SET ret15mPct = :ret15m, ret1hPct = :ret1h, ret4hPct = :ret4h, " +
            "maxFav4hPct = :mfe4h, maxAdv4hPct = :mae4h, resolved = :resolved WHERE id = :id"
    )
    suspend fun updateOutcome(
        id: Long,
        ret15m: Double?,
        ret1h: Double?,
        ret4h: Double?,
        mfe4h: Double?,
        mae4h: Double?,
        resolved: Boolean
    )

    @Query("DELETE FROM signal_candidates WHERE origin = :origin")
    suspend fun deleteByOrigin(origin: String)

    @Query("DELETE FROM signal_candidates WHERE id NOT IN (SELECT id FROM signal_candidates ORDER BY timeMs DESC, id DESC LIMIT :keep)")
    suspend fun trimTo(keep: Int)
}

@Database(
    entities = [
        WatchlistEntity::class,
        AlertLogEntity::class,
        HtfCandleEntity::class,
        SymbolStateEntity::class,
        SignalCandidateEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchlistDao(): WatchlistDao
    abstract fun alertLogDao(): AlertLogDao
    abstract fun htfCandleDao(): HtfCandleDao
    abstract fun symbolStateDao(): SymbolStateDao
    abstract fun signalCandidateDao(): SignalCandidateDao

    companion object {
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `symbol_state` (`symbol` TEXT NOT NULL, `json` TEXT NOT NULL, PRIMARY KEY(`symbol`))"
                )
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `signal_candidates` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`symbol` TEXT NOT NULL, " +
                        "`direction` TEXT NOT NULL, " +
                        "`slotId` TEXT NOT NULL, " +
                        "`barOpenMs` INTEGER NOT NULL, " +
                        "`timeMs` INTEGER NOT NULL, " +
                        "`entryPrice` REAL NOT NULL, " +
                        "`lineValue` REAL NOT NULL, " +
                        "`volumeRatio` REAL NOT NULL, " +
                        "`rising3` INTEGER NOT NULL, " +
                        "`falling` INTEGER NOT NULL, " +
                        "`wickFraction` REAL NOT NULL, " +
                        "`baselineAvailable` INTEGER NOT NULL, " +
                        "`decision` TEXT NOT NULL, " +
                        "`origin` TEXT NOT NULL, " +
                        "`ret15mPct` REAL, " +
                        "`ret1hPct` REAL, " +
                        "`ret4hPct` REAL, " +
                        "`maxFav4hPct` REAL, " +
                        "`maxAdv4hPct` REAL, " +
                        "`resolved` INTEGER NOT NULL)"
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS `index_signal_candidates_symbol_direction_barOpenMs_origin` " +
                        "ON `signal_candidates` (`symbol`, `direction`, `barOpenMs`, `origin`)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_signal_candidates_origin_timeMs` " +
                        "ON `signal_candidates` (`origin`, `timeMs`)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_signal_candidates_resolved_timeMs` " +
                        "ON `signal_candidates` (`resolved`, `timeMs`)"
                )
            }
        }

        fun create(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "trading_alerts.db"
            )
                .addMigrations(MIGRATION_2_3, MIGRATION_3_4)
                .build()
        }
    }
}

data class AppSettingsSnapshot(
    val monitoringEnabled: Boolean = false,
    val dataSource: DataSourceType = DataSourceType.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val alertSettings: AlertSettings = AlertSettings()
)

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "trading_alerts_prefs")

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val MONITORING_ENABLED = booleanPreferencesKey("monitoring_enabled")
        val DATA_SOURCE = stringPreferencesKey("data_source")
        val MARKET_TYPE = stringPreferencesKey("market_type")
        val TIMEFRAME = stringPreferencesKey("timeframe")
        val PROXIMITY_PCT = doublePreferencesKey("proximity_pct")
        val ENABLED_SLOTS = stringSetPreferencesKey("enabled_slots")
        val COOLDOWN_MINUTES = intPreferencesKey("cooldown_minutes")
        val VOLUME_METHOD = stringPreferencesKey("volume_method")
        val SPIKE_RATIO = doublePreferencesKey("spike_ratio")
        val RISING_RATIO = doublePreferencesKey("rising_ratio")
        val WICK_MIN_FRACTION = doublePreferencesKey("wick_min_fraction")
        val FLOOR_RATIO = doublePreferencesKey("floor_ratio")
    }

    val settingsFlow: Flow<AppSettingsSnapshot> = context.dataStore.data.map { prefs ->
        val source = prefs[Keys.DATA_SOURCE]
            ?.let { runCatching { DataSourceType.valueOf(it) }.getOrNull() }
            ?: DataSourceType.BYBIT

        val marketType = prefs[Keys.MARKET_TYPE]
            ?.let { runCatching { MarketType.valueOf(it) }.getOrNull() }
            ?: MarketType.PERP

        val timeframe = prefs[Keys.TIMEFRAME]
            ?.let { runCatching { Timeframe.valueOf(it) }.getOrNull() }
            ?: Timeframe.M3

        val proximity = prefs[Keys.PROXIMITY_PCT] ?: 0.25

        val enabledSlots = prefs[Keys.ENABLED_SLOTS]
            ?.mapNotNull { runCatching { SlotId.valueOf(it) }.getOrNull() }
            ?.toSet()
            ?.takeIf { it.isNotEmpty() }
            ?: SlotId.entries.toSet()

        val rawCooldown = prefs[Keys.COOLDOWN_MINUTES] ?: 30
        val cooldownMinutes = if (rawCooldown in listOf(30, 60, 120, 240)) rawCooldown else 30

        val volumeMethod = prefs[Keys.VOLUME_METHOD]
            ?.let { runCatching { VolumeMethod.valueOf(it) }.getOrNull() }
            ?: VolumeMethod.OFF

        val spikeRatio = (prefs[Keys.SPIKE_RATIO] ?: 2.5).coerceIn(1.0, 10.0)
        val risingRatio = (prefs[Keys.RISING_RATIO] ?: 1.3).coerceIn(1.0, 5.0)
        val wickMinFraction = (prefs[Keys.WICK_MIN_FRACTION] ?: 0.5).coerceIn(0.0, 1.0)
        val floorRatio = (prefs[Keys.FLOOR_RATIO] ?: 0.5).coerceIn(0.0, 3.0)

        AppSettingsSnapshot(
            monitoringEnabled = prefs[Keys.MONITORING_ENABLED] ?: false,
            dataSource = source,
            marketType = marketType,
            alertSettings = AlertSettings(
                timeframe = timeframe,
                proximityPct = proximity,
                enabledSlots = enabledSlots,
                cooldownMinutes = cooldownMinutes,
                volumeMethod = volumeMethod,
                spikeRatio = spikeRatio,
                risingRatio = risingRatio,
                wickMinFraction = wickMinFraction,
                floorRatio = floorRatio
            )
        )
    }

    suspend fun getSnapshot(): AppSettingsSnapshot = settingsFlow.first()

    suspend fun setMonitoringEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.MONITORING_ENABLED] = enabled }
    }

    suspend fun setDataSource(source: DataSourceType) {
        context.dataStore.edit { it[Keys.DATA_SOURCE] = source.name }
    }

    suspend fun setMarketType(marketType: MarketType) {
        context.dataStore.edit { it[Keys.MARKET_TYPE] = marketType.name }
    }

    suspend fun setTimeframe(timeframe: Timeframe) {
        context.dataStore.edit { it[Keys.TIMEFRAME] = timeframe.name }
    }

    suspend fun setProximityPct(pct: Double) {
        context.dataStore.edit { it[Keys.PROXIMITY_PCT] = pct }
    }

    suspend fun setEnabledSlots(slots: Set<SlotId>) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ENABLED_SLOTS] = slots.map { it.name }.toSet()
        }
    }

    suspend fun setCooldownMinutes(minutes: Int) {
        val valid = if (minutes in listOf(30, 60, 120, 240)) minutes else 30
        context.dataStore.edit { it[Keys.COOLDOWN_MINUTES] = valid }
    }

    suspend fun setVolumeMethod(method: VolumeMethod) {
        context.dataStore.edit { it[Keys.VOLUME_METHOD] = method.name }
    }

    suspend fun setSpikeRatio(value: Double) {
        context.dataStore.edit { it[Keys.SPIKE_RATIO] = value.coerceIn(1.0, 10.0) }
    }

    suspend fun setRisingRatio(value: Double) {
        context.dataStore.edit { it[Keys.RISING_RATIO] = value.coerceIn(1.0, 5.0) }
    }

    suspend fun setWickMinFraction(value: Double) {
        context.dataStore.edit { it[Keys.WICK_MIN_FRACTION] = value.coerceIn(0.0, 1.0) }
    }

    suspend fun setFloorRatio(value: Double) {
        context.dataStore.edit { it[Keys.FLOOR_RATIO] = value.coerceIn(0.0, 3.0) }
    }

    suspend fun resetVolumeDefaults() {
        val defaults = AlertSettings()
        context.dataStore.edit { prefs ->
            prefs[Keys.VOLUME_METHOD] = defaults.volumeMethod.name
            prefs[Keys.SPIKE_RATIO] = defaults.spikeRatio
            prefs[Keys.RISING_RATIO] = defaults.risingRatio
            prefs[Keys.WICK_MIN_FRACTION] = defaults.wickMinFraction
            prefs[Keys.FLOOR_RATIO] = defaults.floorRatio
        }
    }
}
