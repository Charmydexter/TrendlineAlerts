package com.trendlinealerts.core

import com.trendlinealerts.core.analytics.CandidateRecord
import com.trendlinealerts.core.analytics.OutcomeCalculator
import com.trendlinealerts.core.analytics.StatsCalculator
import com.trendlinealerts.core.detector.SignalGate
import com.trendlinealerts.core.detector.SignalProcessor
import com.trendlinealerts.core.detector.SignalResult
import com.trendlinealerts.core.detector.VolumeFilter
import com.trendlinealerts.core.detector.VolumeMetrics
import com.trendlinealerts.core.detector.VolumeSnapshot
import com.trendlinealerts.core.dispatcher.AlertDispatcher
import com.trendlinealerts.core.engine.EngineResult
import com.trendlinealerts.core.engine.HtfLineBook
import com.trendlinealerts.core.engine.LineProvider
import com.trendlinealerts.core.engine.PivotStack
import com.trendlinealerts.core.engine.TrendlineEngine
import com.trendlinealerts.core.model.ActiveTrendline
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.CandidateDecision
import com.trendlinealerts.core.model.CandidateOrigin
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.PivotPoint
import com.trendlinealerts.core.model.SignalStateCodec
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide
import com.trendlinealerts.core.model.VolumeMethod
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreUnitTests {

    private val T0 = 6_000_000L
    private val TF = 180_000L
    private val BAR = 60_000L

    private fun piv(price: Double, idx: Int = 0, t: Long = 0L) = PivotPoint(idx, t, price)

    private fun htf(i: Int, high: Double) =
        Candle(T0 + i * TF, high - 1.0, high, high - 5.0, high - 1.0)

    private fun bar(i: Int, o: Double, h: Double, l: Double, c: Double, v: Double = 100.0) =
        Candle(T0 + i * BAR, o, h, l, c, volume = v, isClosed = true)

    private fun flat(slot: SlotId, price: Double, id: Int) = ActiveTrendline(
        slotId = slot,
        side = slot.side,
        older = PivotPoint(0, id * 1000L, price),
        newer = PivotPoint(1, id * 1000L + TF, price),
        slopePerBar = 0.0,
        tfMs = TF
    )

    private fun provider(vararg lines: ActiveTrendline) = object : LineProvider {
        override fun resultAsOf(timeMs: Long) = EngineResult(
            lines = lines.associateBy { it.slotId },
            resistancePivots = emptyList(),
            supportPivots = emptyList(),
            pendingResistance = null,
            pendingSupport = null,
            resistanceCount = 0,
            supportCount = 0,
            closedBarCount = 0
        )
    }

    private val proc = SignalProcessor()

    private fun run(
        mode: AssetMode,
        p: LineProvider,
        bars: List<Candle>,
        prev: SymbolSignalState = SymbolSignalState("TEST"),
        now: Long = T0,
        settings: AlertSettings = AlertSettings(),
        emitCandidates: Boolean = true,
        candidateAfterMs: Long = Long.MIN_VALUE
    ): SignalResult = proc.process(
        symbol = "TEST",
        previous = prev,
        mode = mode,
        htfClosed = emptyList(),
        timeframe = Timeframe.M3,
        bars1m = bars,
        lastPrice = bars.last().close,
        settings = settings,
        nowMs = now,
        lineProvider = p,
        emitCandidates = emitCandidates,
        candidateAfterMs = candidateAfterMs
    )

    private fun types(r: SignalResult) = r.events.map { it.eventType to it.slotId }

    // ───────────────────────── pivot stack ─────────────────────────

    @Test
    fun resistanceStackKeepsDescendingOrder() {
        val s = PivotStack(1.0)
        listOf(100.0, 90.0, 80.0).forEach { s.onPivot(piv(it)) }
        assertEquals(listOf(80.0, 90.0, 100.0), s.newest(3).map { it.price })
        assertNull(s.pending)
    }

    @Test
    fun higherHighBecomesPendingThenPromotedWhenPivotComesBackInside() {
        val s = PivotStack(1.0)
        s.onPivot(piv(100.0))
        s.onPivot(piv(110.0))
        assertEquals(110.0, s.pending!!.price, 0.0)
        assertEquals(listOf(100.0), s.newest(4).map { it.price })

        s.onPivot(piv(105.0))
        assertNull(s.pending)
        assertEquals(listOf(105.0, 110.0), s.newest(4).map { it.price })
    }

    @Test
    fun moreExtremePivotReplacesPending() {
        val s = PivotStack(1.0)
        listOf(100.0, 110.0, 120.0).forEach { s.onPivot(piv(it)) }
        assertEquals(120.0, s.pending!!.price, 0.0)
        assertEquals(listOf(100.0), s.newest(4).map { it.price })
    }

    @Test
    fun supportStackMirrorsResistance() {
        val s = PivotStack(-1.0)
        listOf(100.0, 90.0, 95.0).forEach { s.onPivot(piv(it)) }
        assertEquals(listOf(95.0, 90.0), s.newest(4).map { it.price })
    }

    @Test
    fun stackIsCappedAtFifty() {
        val s = PivotStack(1.0)
        for (i in 0 until 60) s.onPivot(piv(1000.0 - i, i, i.toLong()))
        assertEquals(50, s.size)
    }

    // ───────────────────────── engine ─────────────────────────

    @Test
    fun strictPivotChainBuildsLineWithBarSlope() {
        val highs = listOf(10, 20, 30, 20, 10, 10, 12, 20, 25, 20, 12, 10).map { it.toDouble() }
        val candles = highs.mapIndexed { i, h -> htf(i, h) }
        val r = TrendlineEngine().build(candles, TF)

        val r1 = r.lines[SlotId.R1]
        assertNotNull(r1)
        assertEquals(-5.0 / 6.0, r1!!.slopePerBar, 1e-9)
        assertEquals(22.5, r1.valueAt(candles[11].openTimeMs), 1e-9)
        assertNull(r.lines[SlotId.R2])
        assertTrue(r.lines.keys.none { it.side == TrendlineSide.SUPPORT })
    }

    @Test
    fun equalHighsDoNotFormAPivot() {
        val highs = listOf(10, 20, 20, 20, 10, 10, 12, 20, 25, 20, 12, 10).map { it.toDouble() }
        val r = TrendlineEngine().build(highs.mapIndexed { i, h -> htf(i, h) }, TF)
        assertEquals(1, r.resistanceCount)
        assertTrue(r.lines.isEmpty())
    }

    @Test
    fun lineBookOnlyUsesFullyClosedHtfBars() {
        val candles = (0 until 12).map { htf(it, 10.0 + it) }
        val book = HtfLineBook(TrendlineEngine(), candles, TF)
        assertEquals(5, book.closedCountAsOf(T0 + 5 * TF))
        assertEquals(5, book.closedCountAsOf(T0 + 5 * TF + TF - 1))
        assertEquals(6, book.closedCountAsOf(T0 + 6 * TF))
    }

    @Test
    fun engineStrongestSupportAndResistancePickExtremes() {
        val s1Low = flat(SlotId.S1, 100.0, 1)
        val s2Low = flat(SlotId.S2, 95.0, 2)
        val r1High = flat(SlotId.R1, 110.0, 3)
        val r2High = flat(SlotId.R2, 118.0, 4)
        val engineRes = provider(s1Low, s2Low, r1High, r2High).resultAsOf(T0)
        assertEquals(SlotId.S2, engineRes.strongestSupportAt(T0)?.slotId)
        assertEquals(SlotId.R2, engineRes.strongestResistanceAt(T0)?.slotId)
    }

    // ───────────────────────── GENERAL: regime + cooldown ─────────────────────────

    private val s1 get() = flat(SlotId.S1, 100.0, 1)
    private val s2 get() = flat(SlotId.S2, 98.0, 2)
    private val r1 get() = flat(SlotId.R1, 110.0, 3)
    private val r2 get() = flat(SlotId.R2, 112.0, 4)

    @Test
    fun firstBarAfterStartIsNeutralAndNeverAlerts() {
        val r = run(AssetMode.GENERAL, provider(s1, r1), listOf(bar(0, 105.0, 111.0, 99.0, 101.0)))
        assertTrue(r.events.isEmpty())
        assertTrue(r.state.generalInitialized)
        assertNull(r.state.trendBias)
    }

    @Test
    fun existingBiasIsRequiredBeforeFiringEvenWhenExtremeLinesAreTouched() {
        val r = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, r2),
            listOf(
                bar(0, 105.0, 106.0, 104.0, 105.0),
                bar(1, 105.0, 113.0, 97.5, 105.0)
            )
        )
        assertTrue(r.events.isEmpty())
        assertNull(r.state.trendBias)
    }

    @Test
    fun newHighestResistanceEntersBullishAndLowestSupportFiresLong() {
        val base = provider(s1, s2, r1, r2)
        val init = run(AssetMode.GENERAL, base, listOf(bar(0, 105.0, 106.0, 104.0, 105.0)))

        val r3High = flat(SlotId.R3, 115.0, 10)
        val step = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, r2, r3High),
            listOf(
                bar(1, 105.0, 106.0, 99.5, 101.0),
                bar(2, 101.0, 101.5, 97.8, 98.5)
            ),
            prev = init.state
        )
        assertEquals(EntryDirection.LONG, step.state.trendBias)
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S2), types(step))
    }

    @Test
    fun newLowestSupportResetsToShortOnlyAndHighestResistanceFiresShort() {
        val bullStart = run(AssetMode.GENERAL, provider(s1, s2, r1, r2), listOf(bar(0, 105.0, 106.0, 104.0, 105.0)))
        val bullish = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, r2, flat(SlotId.R3, 115.0, 10)),
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0)),
            prev = bullStart.state
        )
        assertEquals(EntryDirection.LONG, bullish.state.trendBias)

        val s3Low = flat(SlotId.S3, 95.0, 11)
        val r3High = flat(SlotId.R3, 115.0, 10)
        val bearish = run(
            AssetMode.GENERAL,
            provider(s1, s2, s3Low, r1, r2, r3High),
            listOf(
                bar(2, 105.0, 105.5, 94.5, 104.0),
                bar(3, 104.0, 112.5, 103.5, 111.5),
                bar(4, 111.5, 115.3, 111.0, 114.5)
            ),
            prev = bullish.state
        )
        assertEquals(EntryDirection.SHORT, bearish.state.trendBias)
        assertEquals(listOf(EventType.SHORT_ENTRY to SlotId.R3), types(bearish))
    }

    @Test
    fun newNonExtremeLineDoesNotFlipMode() {
        val init = run(AssetMode.GENERAL, provider(s1, s2, r1, r2), listOf(bar(0, 105.0, 106.0, 104.0, 105.0)))
        val bullish = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, r2, flat(SlotId.R3, 115.0, 10)),
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0)),
            prev = init.state
        )
        val s3Mid = flat(SlotId.S3, 99.0, 12)
        val afterMidSupport = run(
            AssetMode.GENERAL,
            provider(s1, s2, s3Mid, r1, r2, flat(SlotId.R3, 115.0, 10)),
            listOf(bar(2, 105.0, 115.5, 104.5, 114.0)),
            prev = bullish.state
        )
        assertEquals(EntryDirection.LONG, afterMidSupport.state.trendBias)
        assertTrue(afterMidSupport.events.isEmpty())
    }

    @Test
    fun longResetsAfterOneHourSettingAndFiresAgainIfStillBullish() {
        val r3High = flat(SlotId.R3, 115.0, 10)
        val p = provider(s1, s2, r1, r2, r3High)
        val settings60 = AlertSettings(cooldownMinutes = 60)
        val init = run(AssetMode.GENERAL, provider(s1, s2, r1, r2), listOf(bar(0, 105.0, 106.0, 104.0, 105.0)), settings = settings60)
        val firstLong = run(
            AssetMode.GENERAL,
            p,
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0), bar(2, 101.0, 101.5, 97.8, 98.5)),
            prev = init.state,
            settings = settings60
        )
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S2), types(firstLong))

        val beforeHour = run(
            AssetMode.GENERAL,
            p,
            listOf(bar(61, 101.0, 101.5, 97.8, 98.5)),
            prev = firstLong.state,
            settings = settings60
        )
        assertTrue(beforeHour.events.isEmpty())
        assertEquals(CandidateDecision.COOLDOWN, beforeHour.candidates.single().decision)

        val afterHour = run(
            AssetMode.GENERAL,
            p,
            listOf(bar(62, 101.0, 101.5, 97.8, 98.5)),
            prev = beforeHour.state,
            settings = settings60
        )
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S2), types(afterHour))
        assertEquals(CandidateDecision.SENT, afterHour.candidates.single().decision)
    }

    @Test
    fun longAndShortPausesAreTrackedIndividually() {
        val r3High = flat(SlotId.R3, 115.0, 10)
        val s3Low = flat(SlotId.S3, 95.0, 11)
        val settings60 = AlertSettings(cooldownMinutes = 60)
        val st0 = run(AssetMode.GENERAL, provider(s1, s2, r1, r2), listOf(bar(0, 105.0, 106.0, 104.0, 105.0)), settings = settings60).state
        val afterShort = run(
            AssetMode.GENERAL,
            provider(s1, s2, s3Low, r1, r2),
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0), bar(2, 110.0, 112.5, 109.5, 111.5)),
            prev = st0,
            settings = settings60
        )
        assertEquals(listOf(EventType.SHORT_ENTRY to SlotId.R2), types(afterShort))

        val afterLong = run(
            AssetMode.GENERAL,
            provider(s1, s2, s3Low, r1, r2, r3High),
            listOf(bar(3, 105.0, 106.0, 104.0, 105.0), bar(4, 97.0, 97.5, 94.5, 95.5)),
            prev = afterShort.state,
            settings = settings60
        )
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S3), types(afterLong))

        val s4Lower = flat(SlotId.S1, 90.0, 12)
        val backBearishTooSoon = run(
            AssetMode.GENERAL,
            provider(s4Lower, s2, s3Low, r1, r2, r3High),
            listOf(bar(5, 105.0, 106.0, 104.0, 105.0), bar(6, 113.0, 115.5, 112.5, 114.5)),
            prev = afterLong.state,
            settings = settings60
        )
        assertTrue(backBearishTooSoon.events.isEmpty())

        val afterShortHour = run(
            AssetMode.GENERAL,
            provider(s4Lower, s2, s3Low, r1, r2, r3High),
            listOf(bar(62, 113.0, 115.5, 112.5, 114.5)),
            prev = backBearishTooSoon.state,
            settings = settings60
        )
        assertEquals(listOf(EventType.SHORT_ENTRY to SlotId.R3), types(afterShortHour))
    }

    @Test
    fun cooldown30MinDefaultBoundaryAndBlockedDoesNotConsumeCooldown() {
        val r3High = flat(SlotId.R3, 115.0, 10)
        val p = provider(s1, s2, r1, r2, r3High)
        val settings = AlertSettings(cooldownMinutes = 30, volumeMethod = VolumeMethod.ACTIVITY_FLOOR, floorRatio = 0.5)

        val bars = mutableListOf<Candle>()
        bars.add(bar(0, 105.0, 106.0, 104.0, 105.0, 100.0))
        val init = run(AssetMode.GENERAL, provider(s1, s2, r1, r2), bars, settings = settings)

        val quietPrior = (1..15).map { idx -> bar(idx, 105.0, 106.0, 104.0, 105.0, 100.0) }
        // Bar 16 touches S2 with low volume (20 vs baseline 100 -> 0.2 < 0.5 floor) => BLOCKED_VOLUME, must NOT start cooldown!
        val blockedBar = bar(16, 101.0, 101.5, 97.8, 98.5, 20.0)
        // Bar 17 (1m later!) touches S2 with normal volume (100 -> 1.0 >= 0.5) => must fire SENT immediately!
        val sentBar = bar(17, 101.0, 101.5, 97.8, 98.5, 100.0)

        val afterBlockedThenSent = run(
            AssetMode.GENERAL,
            p,
            bars + quietPrior + listOf(blockedBar, sentBar),
            prev = init.state,
            settings = settings
        )
        assertEquals(2, afterBlockedThenSent.candidates.size)
        assertEquals(CandidateDecision.BLOCKED_VOLUME, afterBlockedThenSent.candidates[0].decision)
        assertEquals(CandidateDecision.SENT, afterBlockedThenSent.candidates[1].decision)
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S2), types(afterBlockedThenSent))

        // 29m after bar 17 -> bar 46 => still COOLDOWN; 30m after bar 17 -> bar 47 => SENT
        val fillers = (18..45).map { idx -> bar(idx, 105.0, 106.0, 104.0, 105.0, 100.0) }
        val at29m = bar(46, 101.0, 101.5, 97.8, 98.5, 100.0)
        val at30m = bar(47, 101.0, 101.5, 97.8, 98.5, 100.0)
        val cooldownCheck = run(
            AssetMode.GENERAL,
            p,
            bars + quietPrior + listOf(blockedBar, sentBar) + fillers + listOf(at29m, at30m),
            prev = afterBlockedThenSent.state,
            settings = settings
        )
        assertEquals(2, cooldownCheck.candidates.size)
        assertEquals(CandidateDecision.COOLDOWN, cooldownCheck.candidates[0].decision)
        assertEquals(CandidateDecision.SENT, cooldownCheck.candidates[1].decision)
    }

    // ───────────────────────── VOLUME METRICS & FILTERS ─────────────────────────

    @Test
    fun volumeMetricsHandlesUnavailableAndZeroRangeAndWicks() {
        val shortList = (0..9).map { bar(it, 100.0, 102.0, 98.0, 101.0, 50.0) }
        // Only 9 closed bars prior to index 9 -> baselineAvailable = false -> all methods pass
        val unavailable = VolumeMetrics.compute(shortList, 9, EntryDirection.LONG)
        assertFalse(unavailable.baselineAvailable)
        VolumeMethod.entries.forEach { m ->
            assertTrue(VolumeFilter.allows(unavailable, m, AlertSettings(volumeMethod = m)))
        }

        val zeroVolList = (0..12).map { bar(it, 100.0, 102.0, 98.0, 101.0, if (it == 12) 50.0 else 0.0) }
        val zeroBase = VolumeMetrics.compute(zeroVolList, 12, EntryDirection.LONG)
        assertFalse(zeroBase.baselineAvailable)

        // Flat bar -> wickFraction = 0.0
        val zeroRange = (0..11).map {
            if (it == 11) bar(it, 100.0, 100.0, 100.0, 100.0, 200.0)
            else bar(it, 100.0, 102.0, 98.0, 101.0, 100.0)
        }
        val flatSnap = VolumeMetrics.compute(zeroRange, 11, EntryDirection.LONG)
        assertTrue(flatSnap.baselineAvailable)
        assertEquals(0.0, flatSnap.wickFraction, 1e-9)

        // Short upper wick calculation: high=110, max(o,c)=104, low=100 -> upper wick = (110-104)/10 = 0.6
        val shortWickBars = (0..10).map { bar(it, 100.0, 102.0, 98.0, 101.0, 100.0) } +
            listOf(bar(11, 104.0, 110.0, 100.0, 102.0, 300.0))
        val shortSnap = VolumeMetrics.compute(shortWickBars, 11, EntryDirection.SHORT)
        assertEquals(0.6, shortSnap.wickFraction, 1e-9)
        assertEquals(3.0, shortSnap.volumeRatio, 1e-9)
    }

    @Test
    fun cheatSheetAndOtherVolumeMethodsBehaveAsSpecified() {
        val settings = AlertSettings(spikeRatio = 2.5, risingRatio = 1.3, wickMinFraction = 0.5, floorRatio = 0.5)
        // Climax absorption overrides rising3: spike + high wick -> PASS in CHEAT_SHEET & CLIMAX_ONLY
        val climaxAndRising = VolumeSnapshot(volumeRatio = 2.6, rising3 = true, falling = false, wickFraction = 0.6, baselineAvailable = true)
        assertTrue(VolumeFilter.allows(climaxAndRising, VolumeMethod.CHEAT_SHEET, settings))
        assertTrue(VolumeFilter.allows(climaxAndRising, VolumeMethod.CLIMAX_ONLY, settings))
        assertFalse(VolumeFilter.allows(climaxAndRising, VolumeMethod.BLOCK_RISING, settings))

        // Rising thrust without climax wick -> BLOCK in CHEAT_SHEET & BLOCK_RISING
        val risingThrust = VolumeSnapshot(volumeRatio = 1.5, rising3 = true, falling = false, wickFraction = 0.2, baselineAvailable = true)
        assertFalse(VolumeFilter.allows(risingThrust, VolumeMethod.CHEAT_SHEET, settings))
        assertFalse(VolumeFilter.allows(risingThrust, VolumeMethod.BLOCK_RISING, settings))

        // Exhaustion -> PASS in EXHAUSTION_ONLY & CHEAT_SHEET
        val exhaustion = VolumeSnapshot(volumeRatio = 0.4, rising3 = false, falling = true, wickFraction = 0.3, baselineAvailable = true)
        assertTrue(VolumeFilter.allows(exhaustion, VolumeMethod.EXHAUSTION_ONLY, settings))
        assertTrue(VolumeFilter.allows(exhaustion, VolumeMethod.CHEAT_SHEET, settings))
        assertFalse(VolumeFilter.allows(exhaustion, VolumeMethod.ACTIVITY_FLOOR, settings))
    }

    @Test
    fun emitCandidatesFalseAndCandidateAfterMsSuppressWarmupCandidates() {
        val p = provider(s1, s2, r1, r2, flat(SlotId.R3, 115.0, 10))
        val init = run(AssetMode.GENERAL, provider(s1, s2, r1, r2), listOf(bar(0, 105.0, 106.0, 104.0, 105.0)), emitCandidates = false)
        assertTrue(init.candidates.isEmpty())

        val warmSuppressed = run(
            AssetMode.GENERAL,
            p,
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0), bar(2, 101.0, 101.5, 97.8, 98.5)),
            prev = init.state,
            emitCandidates = false
        )
        assertTrue(warmSuppressed.candidates.isEmpty())

        // Reset and test candidateAfterMs filtering
        val r35 = run(
            AssetMode.GENERAL,
            p,
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0), bar(2, 101.0, 101.5, 97.8, 98.5)),
            prev = init.state,
            candidateAfterMs = T0 + 3 * BAR
        )
        assertTrue(r35.candidates.isEmpty())
    }

    // ───────────────────────── OUTCOME & STATS ─────────────────────────

    @Test
    fun outcomeCalculatorComputesDirectionalReturnsAndExcursions() {
        val touchOpen = T0
        val entryClose = touchOpen + BAR
        val future = (0 until 240).map { m ->
            val openMs = entryClose + m * BAR
            val closePrice = when (m) {
                14 -> 102.0 // +15m close: +2%
                59 -> 105.0 // +1h close: +5%
                239 -> 103.0 // +4h close: +3%
                else -> 101.0
            }
            Candle(openMs, 100.0, if (m == 30) 108.0 else 102.0, if (m == 10) 97.0 else 99.5, closePrice, 100.0, true)
        }
        val out = OutcomeCalculator.compute(100.0, EntryDirection.LONG, touchOpen, future, entryClose + 240 * BAR)
        assertTrue(out.resolved)
        assertEquals(2.0, out.ret15mPct!!, 1e-6)
        assertEquals(5.0, out.ret1hPct!!, 1e-6)
        assertEquals(3.0, out.ret4hPct!!, 1e-6)
        assertEquals(8.0, out.maxFav4hPct!!, 1e-6)
        assertEquals(3.0, out.maxAdv4hPct!!, 1e-6)
    }

    @Test
    fun statsCalculatorDeduplicatesLiveOverReplayAndEvaluatesMethods() {
        val t1 = T0 + 10 * BAR
        val replay = CandidateRecord(
            symbol = "BTCUSDT", direction = EntryDirection.LONG, slotId = SlotId.S1,
            barOpenMs = t1, timeMs = t1 + BAR, entryPrice = 100.0, lineValue = 99.5,
            volumeRatio = 1.6, rising3 = true, falling = false, wickFraction = 0.1,
            baselineAvailable = true, decision = CandidateDecision.SENT, origin = CandidateOrigin.REPLAY,
            ret15mPct = -0.5, ret1hPct = -2.0, ret4hPct = -3.0, maxFav4hPct = 0.5, maxAdv4hPct = 3.5, resolved = true
        )
        val live = replay.copy(origin = CandidateOrigin.LIVE, ret1hPct = -1.5)
        val merged = StatsCalculator.mergeCandidates(listOf(replay, live))
        assertEquals(1, merged.size)
        assertEquals(CandidateOrigin.LIVE, merged[0].origin)

        val evals = StatsCalculator.evaluateAllMethods(merged, AlertSettings())
        val off = evals.first { it.method == VolumeMethod.OFF }.stats
        val blockRising = evals.first { it.method == VolumeMethod.BLOCK_RISING }.stats
        assertEquals(1, off.sent.count)
        assertEquals(0, blockRising.sent.count)
        assertEquals(1, blockRising.blocked.count)
    }

    // ───────────────────────── POSITIONED + DISPATCHER ─────────────────────────

    @Test
    fun positionedCrossesAlternateAndLowerSupportDoesNotRefire() {
        val p = provider(s1, s2, r1)
        val bars = listOf(
            bar(0, 105.0, 106.0, 104.0, 105.0),
            bar(1, 105.0, 105.0, 99.5, 101.0),
            bar(2, 101.0, 101.0, 97.5, 98.0),
            bar(3, 98.0, 111.0, 97.9, 109.0),
            bar(4, 109.0, 109.5, 97.5, 99.0)
        )
        val r = run(AssetMode.POSITIONED, p, bars)
        assertEquals(
            listOf(
                EventType.CROSS_SUPPORT to SlotId.S1,
                EventType.CROSS_RESISTANCE to SlotId.R1,
                EventType.CROSS_SUPPORT to SlotId.S1
            ),
            types(r)
        )
    }

    @Test
    fun oldEventsAreFlaggedMissed() {
        val bars = listOf(bar(0, 105.0, 106.0, 104.0, 105.0), bar(1, 105.0, 105.0, 99.5, 101.0))
        val r = run(AssetMode.POSITIONED, provider(s1), bars, now = T0 + 3_600_000L)
        assertEquals(1, r.events.size)
        assertTrue(r.events[0].missed)
    }

    @Test
    fun stateSurvivesJsonRoundTrip() {
        val init = run(AssetMode.GENERAL, provider(s1, s2, r1), listOf(bar(0, 105.0, 106.0, 104.0, 105.0)))
        val r = run(
            AssetMode.GENERAL,
            provider(s1, s2, r1, flat(SlotId.R3, 115.0, 10)),
            listOf(bar(1, 105.0, 106.0, 104.0, 105.0), bar(2, 101.0, 101.5, 97.8, 98.5)),
            prev = init.state
        )
        assertNotNull(r.state.lastLongFiredAtMs)
        val back = SignalStateCodec.decode(SignalStateCodec.encode(r.state), "TEST")
        assertEquals(r.state, back)
        assertEquals(SymbolSignalState("X"), SignalStateCodec.decode("not json", "X"))
    }

    private fun cand(symbol: String, type: EventType, missed: Boolean = false, eventTime: Long = 1_000L) = TrendlineCandidate(
        symbol = symbol, slotId = SlotId.S1, side = TrendlineSide.SUPPORT,
        eventType = type, price = 1.0, lineValue = 1.0, timestampMs = 5_000L, eventTimeMs = eventTime, missed = missed
    )

    @Test
    fun generalLongShortAreClusteredAndPositionedAreSeparate() {
        val plan = AlertDispatcher.plan(
            listOf(cand("AAA", EventType.LONG_ENTRY), cand("BBB", EventType.SHORT_ENTRY), cand("POS", EventType.CROSS_SUPPORT)),
            positionedSymbols = setOf("POS"),
            generalMonitoringOn = true
        )
        assertEquals(listOf("AAA", "BBB"), plan.cluster.map { it.symbol })
        assertEquals(listOf("POS"), plan.individual.map { it.symbol })
    }

    @Test
    fun signalGateDecideRespectsCooldownBeforeVolumeFilter() {
        val blockedSnap = VolumeSnapshot(volumeRatio = 0.2, rising3 = false, falling = false, wickFraction = 0.0, baselineAvailable = true)
        val settings = AlertSettings(cooldownMinutes = 30, volumeMethod = VolumeMethod.ACTIVITY_FLOOR, floorRatio = 0.5)
        // Inside cooldown -> COOLDOWN even if volume would block
        assertEquals(
            CandidateDecision.COOLDOWN,
            SignalGate.decide(blockedSnap, VolumeMethod.ACTIVITY_FLOOR, settings, lastSentAtMs = T0, barCloseMs = T0 + 10 * BAR)
        )
        // Past cooldown -> BLOCKED_VOLUME
        assertEquals(
            CandidateDecision.BLOCKED_VOLUME,
            SignalGate.decide(blockedSnap, VolumeMethod.ACTIVITY_FLOOR, settings, lastSentAtMs = T0, barCloseMs = T0 + 30 * BAR)
        )
        // Pass volume past cooldown -> SENT
        val passSnap = blockedSnap.copy(volumeRatio = 1.0)
        assertEquals(
            CandidateDecision.SENT,
            SignalGate.decide(passSnap, VolumeMethod.ACTIVITY_FLOOR, settings, lastSentAtMs = T0, barCloseMs = T0 + 30 * BAR)
        )
    }
}
