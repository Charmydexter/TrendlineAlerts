package com.trendlinealerts.core.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/** Everything the signal logic must remember for one symbol. Persisted between runs. */
@Serializable
data class SymbolSignalState(
    val symbol: String,
    val mode: AssetMode = AssetMode.GENERAL,
    /** Open time of the last 1m bar that was processed. */
    val lastProcessedOpenMs: Long = 0L,
    /** pivotKey of the line currently in each slot ("" = no line). Used for the swap gap. */
    val slotKeys: Map<String, String> = emptyMap(),
    /** GENERAL: true after the first bar seeds known resistance/support lines so startup doesn't falsely flip bias. */
    val generalInitialized: Boolean = false,
    /** GENERAL: current regime bias (LONG = Bullish, SHORT = Bearish, null = Neutral). */
    val trendBias: EntryDirection? = null,
    /** GENERAL: bar close timestamp (ms) when LONG_ENTRY last fired for this asset. */
    val lastLongFiredAtMs: Long? = null,
    /** GENERAL: bar close timestamp (ms) when SHORT_ENTRY last fired for this asset. */
    val lastShortFiredAtMs: Long? = null,
    /** GENERAL: active resistance pivotKeys seen on the previous bar. */
    val knownResistanceKeys: Set<String> = emptySet(),
    /** GENERAL: active support pivotKeys seen on the previous bar. */
    val knownSupportKeys: Set<String> = emptySet(),
    /** Positioned assets: side of the last cross alert (only the opposite side re-arms). */
    val lastCrossSide: TrendlineSide? = null,
    val lastEntryDirection: EntryDirection? = null,
    val r1Key: String? = null,
    val s1Key: String? = null
)

object SignalStateCodec {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun encode(state: SymbolSignalState): String = json.encodeToString(SymbolSignalState.serializer(), state)

    fun decode(raw: String?, symbol: String): SymbolSignalState {
        if (raw.isNullOrBlank()) return SymbolSignalState(symbol)
        return runCatching { json.decodeFromString(SymbolSignalState.serializer(), raw) }
            .getOrElse { SymbolSignalState(symbol) }
    }
}
