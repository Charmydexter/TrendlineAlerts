package com.trendlinealerts.core.analytics

import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection

data class TradeLevels(
    val tpPrice: Double,
    val slPrice: Double,
    val isSlValid: Boolean,
    val tpUsd: Double,
    val slUsd: Double
)

object TradeRiskCalculator {

    /**
     * Computes live TP/SL prices for `price` using capital and maxLoss/tpMultiplier settings.
     *  - LONG: SL is valid when `slPrice < targetLineValue` (strictly below support).
     *  - SHORT: SL is valid when `slPrice > targetLineValue` (strictly above resistance).
     */
    fun compute(
        price: Double,
        direction: EntryDirection,
        targetLineValue: Double?,
        settings: AlertSettings
    ): TradeLevels? {
        if (price <= 0.0) return null
        val capital = settings.effectiveCapitalUsd
        val slUsd = settings.effectiveMaxLossUsd
        val tpUsd = settings.tpUsd
        val slFrac = slUsd / capital
        val tpFrac = tpUsd / capital

        return when (direction) {
            EntryDirection.LONG -> {
                val sl = price * (1.0 - slFrac)
                val tp = price * (1.0 + tpFrac)
                val valid = targetLineValue != null && sl < targetLineValue
                TradeLevels(
                    tpPrice = tp,
                    slPrice = sl,
                    isSlValid = valid,
                    tpUsd = tpUsd,
                    slUsd = slUsd
                )
            }
            EntryDirection.SHORT -> {
                val sl = price * (1.0 + slFrac)
                val tp = price * (1.0 - tpFrac)
                val valid = targetLineValue != null && sl > targetLineValue
                TradeLevels(
                    tpPrice = tp,
                    slPrice = sl,
                    isSlValid = valid,
                    tpUsd = tpUsd,
                    slUsd = slUsd
                )
            }
        }
    }
}

object HeikinAshiConverter {

    fun convert(candles: List<Candle>): List<Candle> {
        if (candles.isEmpty()) return emptyList()
        val out = ArrayList<Candle>(candles.size)
        var prevHaOpen = (candles[0].open + candles[0].close) / 2.0
        var prevHaClose = (candles[0].open + candles[0].high + candles[0].low + candles[0].close) / 4.0

        for (i in candles.indices) {
            val c = candles[i]
            val haClose = (c.open + c.high + c.low + c.close) / 4.0
            val haOpen = if (i == 0) {
                (c.open + c.close) / 2.0
            } else {
                (prevHaOpen + prevHaClose) / 2.0
            }
            val haHigh = maxOf(c.high, haOpen, haClose)
            val haLow = minOf(c.low, haOpen, haClose)
            out.add(
                Candle(
                    openTimeMs = c.openTimeMs,
                    open = haOpen,
                    high = haHigh,
                    low = haLow,
                    close = haClose,
                    volume = c.volume,
                    isClosed = c.isClosed
                )
            )
            prevHaOpen = haOpen
            prevHaClose = haClose
        }
        return out
    }
}
