package com.trendlinealerts.core.detector

import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.CandidateDecision
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.VolumeMethod
import kotlin.math.max
import kotlin.math.min

data class VolumeSnapshot(
    val volumeRatio: Double,
    val rising3: Boolean,
    val falling: Boolean,
    val wickFraction: Double,
    val baselineAvailable: Boolean
)

object VolumeMetrics {
    const val BASELINE_WINDOW = 30
    const val MIN_BASELINE_BARS = 10

    fun compute(
        bars1mSorted: List<Candle>,
        barIndex: Int,
        direction: EntryDirection
    ): VolumeSnapshot {
        val bar = bars1mSorted[barIndex]
        val start = max(0, barIndex - BASELINE_WINDOW)
        val priorClosed = bars1mSorted.subList(start, barIndex).filter { it.isClosed }

        val range = bar.high - bar.low
        val wickFraction = if (range <= 0.0) {
            0.0
        } else {
            val raw = when (direction) {
                EntryDirection.LONG -> (min(bar.open, bar.close) - bar.low) / range
                EntryDirection.SHORT -> (bar.high - max(bar.open, bar.close)) / range
            }
            raw.coerceIn(0.0, 1.0)
        }

        val rising3 = if (barIndex >= 2) {
            val v2 = bars1mSorted[barIndex - 2].volume
            val v1 = bars1mSorted[barIndex - 1].volume
            val v0 = bar.volume
            v2 < v1 && v1 < v0
        } else {
            false
        }

        if (priorClosed.size < MIN_BASELINE_BARS) {
            return VolumeSnapshot(
                volumeRatio = 0.0,
                rising3 = rising3,
                falling = false,
                wickFraction = wickFraction,
                baselineAvailable = false
            )
        }

        val baseline = median(priorClosed.map { it.volume })
        if (baseline <= 0.0) {
            return VolumeSnapshot(
                volumeRatio = 0.0,
                rising3 = rising3,
                falling = false,
                wickFraction = wickFraction,
                baselineAvailable = false
            )
        }

        val ratio = bar.volume / baseline
        val prevVol = bars1mSorted[barIndex - 1].volume
        val falling = bar.volume <= baseline && bar.volume < prevVol

        return VolumeSnapshot(
            volumeRatio = ratio,
            rising3 = rising3,
            falling = falling,
            wickFraction = wickFraction,
            baselineAvailable = true
        )
    }

    fun median(values: List<Double>): Double {
        if (values.isEmpty()) return 0.0
        val sorted = values.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 1) {
            sorted[mid]
        } else {
            (sorted[mid - 1] + sorted[mid]) * 0.5
        }
    }
}

object VolumeFilter {
    fun allows(
        snapshot: VolumeSnapshot,
        method: VolumeMethod,
        settings: AlertSettings
    ): Boolean {
        if (method == VolumeMethod.OFF || !snapshot.baselineAvailable) return true
        val spike = snapshot.volumeRatio >= settings.spikeRatio
        val rising = snapshot.volumeRatio >= settings.risingRatio && snapshot.rising3
        val climax = spike && snapshot.wickFraction >= settings.wickMinFraction

        return when (method) {
            VolumeMethod.OFF -> true
            VolumeMethod.CHEAT_SHEET -> when {
                climax -> true
                rising || (spike && snapshot.wickFraction < settings.wickMinFraction) -> false
                else -> true
            }
            VolumeMethod.BLOCK_RISING -> !rising
            VolumeMethod.EXHAUSTION_ONLY -> snapshot.falling
            VolumeMethod.CLIMAX_ONLY -> climax
            VolumeMethod.ACTIVITY_FLOOR -> snapshot.volumeRatio >= settings.floorRatio
        }
    }
}

object SignalGate {
    fun decide(
        snapshot: VolumeSnapshot,
        method: VolumeMethod,
        settings: AlertSettings,
        lastSentAtMs: Long?,
        barCloseMs: Long
    ): CandidateDecision {
        val cooldownMs = settings.cooldownMs
        if (lastSentAtMs != null && (barCloseMs - lastSentAtMs) < cooldownMs) {
            return CandidateDecision.COOLDOWN
        }
        return if (VolumeFilter.allows(snapshot, method, settings)) {
            CandidateDecision.SENT
        } else {
            CandidateDecision.BLOCKED_VOLUME
        }
    }
}
