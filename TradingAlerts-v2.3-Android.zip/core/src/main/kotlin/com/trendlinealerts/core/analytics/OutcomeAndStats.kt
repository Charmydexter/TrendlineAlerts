package com.trendlinealerts.core.analytics

import com.trendlinealerts.core.detector.SignalGate
import com.trendlinealerts.core.detector.VolumeSnapshot
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.CandidateDecision
import com.trendlinealerts.core.model.CandidateOrigin
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.TradeOutcomeStatus
import com.trendlinealerts.core.model.VolumeMethod
import kotlin.math.max

data class OutcomeResult(
    val ret15mPct: Double?,
    val ret1hPct: Double?,
    val ret4hPct: Double?,
    val maxFav4hPct: Double?,
    val maxAdv4hPct: Double?,
    val resolved: Boolean,
    val tradeStatus: TradeOutcomeStatus = TradeOutcomeStatus.PENDING,
    val confirmEntryPrice: Double? = null,
    val tpPrice: Double? = null,
    val slPrice: Double? = null,
    val pnlUsd: Double? = null,
    val tradeResolvedAtMs: Long? = null
)

object OutcomeCalculator {
    private const val MIN_MS = 60_000L
    private const val WINDOW_15M_MS = 15L * MIN_MS
    private const val WINDOW_1H_MS = 60L * MIN_MS
    private const val WINDOW_4H_MS = 240L * MIN_MS

    fun compute(
        entryPrice: Double,
        direction: EntryDirection,
        barOpenMs: Long,
        future1mClosedSorted: List<Candle>,
        nowMs: Long,
        lineValue: Double = entryPrice,
        settings: AlertSettings = AlertSettings()
    ): OutcomeResult {
        val entryCloseMs = barOpenMs + MIN_MS
        val horizonDone = nowMs >= entryCloseMs + WINDOW_4H_MS
        if (entryPrice <= 0.0) {
            return OutcomeResult(
                ret15mPct = null,
                ret1hPct = null,
                ret4hPct = null,
                maxFav4hPct = null,
                maxAdv4hPct = null,
                resolved = horizonDone,
                tradeStatus = if (horizonDone) TradeOutcomeStatus.NO_ENTRY else TradeOutcomeStatus.PENDING
            )
        }

        val barsAfter = future1mClosedSorted.filter {
            it.isClosed && it.openTimeMs >= entryCloseMs && it.openTimeMs < entryCloseMs + WINDOW_4H_MS
        }

        fun returnAtOffset(offsetMs: Long): Double? {
            if (nowMs < entryCloseMs + offsetMs) return null
            val targetCloseMs = entryCloseMs + offsetMs
            val exact = barsAfter.firstOrNull { (it.openTimeMs + MIN_MS) == targetCloseMs }
                ?: barsAfter.lastOrNull { (it.openTimeMs + MIN_MS) <= targetCloseMs }
                ?: return null
            return directionalReturnPct(entryPrice, exact.close, direction)
        }

        val ret15m = returnAtOffset(WINDOW_15M_MS)
        val ret1h = returnAtOffset(WINDOW_1H_MS)
        val ret4h = returnAtOffset(WINDOW_4H_MS)

        var mfe: Double? = null
        var mae: Double? = null
        if (barsAfter.isNotEmpty()) {
            var bestFav = 0.0
            var worstAdv = 0.0
            for (b in barsAfter) {
                val fav = when (direction) {
                    EntryDirection.LONG -> (b.high - entryPrice) / entryPrice * 100.0
                    EntryDirection.SHORT -> (entryPrice - b.low) / entryPrice * 100.0
                }
                val adv = when (direction) {
                    EntryDirection.LONG -> (entryPrice - b.low) / entryPrice * 100.0
                    EntryDirection.SHORT -> (b.high - entryPrice) / entryPrice * 100.0
                }
                bestFav = max(bestFav, fav)
                worstAdv = max(worstAdv, adv)
            }
            mfe = bestFav
            mae = worstAdv
        }

        // Two-candle reversal confirmation + valid SL + TP/SL trade simulation
        var consecutive = 0
        var confirmIdx = -1
        for (idx in barsAfter.indices) {
            val c = barsAfter[idx]
            val onRightSide = when (direction) {
                EntryDirection.LONG -> c.close > lineValue
                EntryDirection.SHORT -> c.close < lineValue
            }
            if (onRightSide) {
                consecutive++
                if (consecutive >= 2) {
                    confirmIdx = idx
                    break
                }
            } else {
                consecutive = 0
            }
        }

        var tradeStatus = TradeOutcomeStatus.PENDING
        var confirmEntryPrice: Double? = null
        var tpPrice: Double? = null
        var slPrice: Double? = null
        var pnlUsd: Double? = null
        var tradeResolvedAtMs: Long? = null

        if (confirmIdx == -1) {
            tradeStatus = if (horizonDone) TradeOutcomeStatus.NO_ENTRY else TradeOutcomeStatus.PENDING
        } else {
            val confirmBar = barsAfter[confirmIdx]
            val levels = TradeRiskCalculator.compute(
                price = confirmBar.close,
                direction = direction,
                targetLineValue = lineValue,
                settings = settings
            )
            if (levels == null || !levels.isSlValid) {
                tradeStatus = TradeOutcomeStatus.NO_ENTRY
            } else {
                confirmEntryPrice = confirmBar.close
                tpPrice = levels.tpPrice
                slPrice = levels.slPrice
                var decided = false
                for (m in (confirmIdx + 1) until barsAfter.size) {
                    val b = barsAfter[m]
                    val hitSl = when (direction) {
                        EntryDirection.LONG -> b.low <= levels.slPrice
                        EntryDirection.SHORT -> b.high >= levels.slPrice
                    }
                    val hitTp = when (direction) {
                        EntryDirection.LONG -> b.high >= levels.tpPrice
                        EntryDirection.SHORT -> b.low <= levels.tpPrice
                    }
                    if (hitSl) {
                        tradeStatus = TradeOutcomeStatus.LOSS
                        pnlUsd = -levels.slUsd
                        tradeResolvedAtMs = b.openTimeMs + MIN_MS
                        decided = true
                        break
                    } else if (hitTp) {
                        tradeStatus = TradeOutcomeStatus.WIN
                        pnlUsd = levels.tpUsd
                        tradeResolvedAtMs = b.openTimeMs + MIN_MS
                        decided = true
                        break
                    }
                }
                if (!decided) {
                    tradeStatus = if (horizonDone) TradeOutcomeStatus.EXPIRED else TradeOutcomeStatus.PENDING
                }
            }
        }

        val resolved = horizonDone ||
            tradeStatus == TradeOutcomeStatus.WIN ||
            tradeStatus == TradeOutcomeStatus.LOSS ||
            tradeStatus == TradeOutcomeStatus.NO_ENTRY

        return OutcomeResult(
            ret15mPct = ret15m,
            ret1hPct = ret1h,
            ret4hPct = ret4h,
            maxFav4hPct = mfe,
            maxAdv4hPct = mae,
            resolved = resolved && horizonDone,
            tradeStatus = tradeStatus,
            confirmEntryPrice = confirmEntryPrice,
            tpPrice = tpPrice,
            slPrice = slPrice,
            pnlUsd = pnlUsd,
            tradeResolvedAtMs = tradeResolvedAtMs
        )
    }

    fun directionalReturnPct(entryPrice: Double, exitPrice: Double, direction: EntryDirection): Double {
        return when (direction) {
            EntryDirection.LONG -> (exitPrice - entryPrice) / entryPrice * 100.0
            EntryDirection.SHORT -> (entryPrice - exitPrice) / entryPrice * 100.0
        }
    }
}

data class CandidateRecord(
    val id: Long = 0L,
    val symbol: String,
    val direction: EntryDirection,
    val slotId: SlotId,
    val barOpenMs: Long,
    val timeMs: Long,
    val entryPrice: Double,
    val lineValue: Double,
    val volumeRatio: Double,
    val rising3: Boolean,
    val falling: Boolean,
    val wickFraction: Double,
    val baselineAvailable: Boolean,
    val decision: CandidateDecision,
    val origin: CandidateOrigin,
    val ret15mPct: Double? = null,
    val ret1hPct: Double? = null,
    val ret4hPct: Double? = null,
    val maxFav4hPct: Double? = null,
    val maxAdv4hPct: Double? = null,
    val resolved: Boolean = false,
    val tradeStatus: TradeOutcomeStatus = TradeOutcomeStatus.PENDING,
    val confirmEntryPrice: Double? = null,
    val tpPrice: Double? = null,
    val slPrice: Double? = null,
    val pnlUsd: Double? = null,
    val tradeResolvedAtMs: Long? = null
)

data class DecisionBucketStats(
    val count: Int,
    val resolved1hCount: Int,
    val winRate1hPct: Double?,
    val avgRet15mPct: Double?,
    val avgRet1hPct: Double?,
    val avgRet4hPct: Double?,
    val avgMfe4hPct: Double?,
    val avgMae4hPct: Double?,
    val tradeWins: Int = 0,
    val tradeLosses: Int = 0,
    val tradeNoEntry: Int = 0,
    val tradePending: Int = 0,
    val tradeWinRatePct: Double? = null,
    val netPnlUsd: Double = 0.0
)

data class PerformanceStats(
    val totalCandidates: Int,
    val sent: DecisionBucketStats,
    val blocked: DecisionBucketStats
)

data class MethodEvaluation(
    val method: VolumeMethod,
    val stats: PerformanceStats
)

data class AssetBreakdownRow(
    val symbol: String,
    val sentCount: Int,
    val blockedCount: Int,
    val winRate1hPct: Double?,
    val avgRet1hPct: Double?,
    val avgRet4hPct: Double?,
    val tradeWins: Int = 0,
    val tradeLosses: Int = 0,
    val tradeWinRatePct: Double? = null,
    val netPnlUsd: Double = 0.0
)

object StatsCalculator {

    private data class DedupeKey(
        val symbol: String,
        val direction: EntryDirection,
        val barOpenMs: Long
    )

    /**
     * Merges LIVE and REPLAY records without double-counting the same touch bar.
     * Prefers LIVE when both exist, falling back to REPLAY outcome fields if needed.
     */
    fun mergeCandidates(records: List<CandidateRecord>): List<CandidateRecord> {
        val byKey = LinkedHashMap<DedupeKey, CandidateRecord>()
        for (r in records) {
            val k = DedupeKey(r.symbol, r.direction, r.barOpenMs)
            val existing = byKey[k]
            if (existing == null) {
                byKey[k] = r
            } else if (existing.origin == CandidateOrigin.REPLAY && r.origin == CandidateOrigin.LIVE) {
                byKey[k] = if (r.resolved || !existing.resolved) r else r.copy(
                    ret15mPct = r.ret15mPct ?: existing.ret15mPct,
                    ret1hPct = r.ret1hPct ?: existing.ret1hPct,
                    ret4hPct = r.ret4hPct ?: existing.ret4hPct,
                    maxFav4hPct = r.maxFav4hPct ?: existing.maxFav4hPct,
                    maxAdv4hPct = r.maxAdv4hPct ?: existing.maxAdv4hPct,
                    resolved = existing.resolved,
                    tradeStatus = if (r.tradeStatus != TradeOutcomeStatus.PENDING) r.tradeStatus else existing.tradeStatus,
                    confirmEntryPrice = r.confirmEntryPrice ?: existing.confirmEntryPrice,
                    tpPrice = r.tpPrice ?: existing.tpPrice,
                    slPrice = r.slPrice ?: existing.slPrice,
                    pnlUsd = r.pnlUsd ?: existing.pnlUsd,
                    tradeResolvedAtMs = r.tradeResolvedAtMs ?: existing.tradeResolvedAtMs
                )
            }
        }
        return byKey.values.sortedBy { it.timeMs }
    }

    fun summarizeBucket(records: List<CandidateRecord>): DecisionBucketStats {
        val with15m = records.mapNotNull { it.ret15mPct }
        val with1h = records.mapNotNull { it.ret1hPct }
        val with4h = records.mapNotNull { it.ret4hPct }
        val withMfe = records.mapNotNull { it.maxFav4hPct }
        val withMae = records.mapNotNull { it.maxAdv4hPct }
        val wins1h = with1h.count { it > 0.0 }

        val wins = records.count { it.tradeStatus == TradeOutcomeStatus.WIN }
        val losses = records.count { it.tradeStatus == TradeOutcomeStatus.LOSS }
        val noEntry = records.count { it.tradeStatus == TradeOutcomeStatus.NO_ENTRY }
        val pending = records.count { it.tradeStatus == TradeOutcomeStatus.PENDING }
        val closedTrades = wins + losses
        val tradeWinRate = if (closedTrades > 0) wins * 100.0 / closedTrades else null
        val netPnl = records.mapNotNull { it.pnlUsd }.sum()

        return DecisionBucketStats(
            count = records.size,
            resolved1hCount = with1h.size,
            winRate1hPct = if (with1h.isNotEmpty()) wins1h * 100.0 / with1h.size else null,
            avgRet15mPct = with15m.takeIf { it.isNotEmpty() }?.average(),
            avgRet1hPct = with1h.takeIf { it.isNotEmpty() }?.average(),
            avgRet4hPct = with4h.takeIf { it.isNotEmpty() }?.average(),
            avgMfe4hPct = withMfe.takeIf { it.isNotEmpty() }?.average(),
            avgMae4hPct = withMae.takeIf { it.isNotEmpty() }?.average(),
            tradeWins = wins,
            tradeLosses = losses,
            tradeNoEntry = noEntry,
            tradePending = pending,
            tradeWinRatePct = tradeWinRate,
            netPnlUsd = netPnl
        )
    }

    fun computePerformance(records: List<CandidateRecord>): PerformanceStats {
        val deduped = mergeCandidates(records)
        val sent = deduped.filter { it.decision == CandidateDecision.SENT }
        val blocked = deduped.filter { it.decision == CandidateDecision.BLOCKED_VOLUME }
        return PerformanceStats(
            totalCandidates = deduped.size,
            sent = summarizeBucket(sent),
            blocked = summarizeBucket(blocked)
        )
    }

    fun evaluateMethod(
        records: List<CandidateRecord>,
        method: VolumeMethod,
        settings: AlertSettings
    ): PerformanceStats {
        val deduped = mergeCandidates(records).sortedBy { it.timeMs }
        val lastSentBySymbolDir = HashMap<Pair<String, EntryDirection>, Long>()
        val sentList = mutableListOf<CandidateRecord>()
        val blockedList = mutableListOf<CandidateRecord>()

        for (rec in deduped) {
            val key = rec.symbol to rec.direction
            val snap = VolumeSnapshot(
                volumeRatio = rec.volumeRatio,
                rising3 = rec.rising3,
                falling = rec.falling,
                wickFraction = rec.wickFraction,
                baselineAvailable = rec.baselineAvailable
            )
            val decision = SignalGate.decide(
                snapshot = snap,
                method = method,
                settings = settings,
                lastSentAtMs = lastSentBySymbolDir[key],
                barCloseMs = rec.timeMs
            )
            when (decision) {
                CandidateDecision.SENT -> {
                    lastSentBySymbolDir[key] = rec.timeMs
                    sentList.add(rec)
                }
                CandidateDecision.BLOCKED_VOLUME -> blockedList.add(rec)
                CandidateDecision.COOLDOWN -> Unit
            }
        }
        return PerformanceStats(
            totalCandidates = deduped.size,
            sent = summarizeBucket(sentList),
            blocked = summarizeBucket(blockedList)
        )
    }

    fun evaluateAllMethods(
        records: List<CandidateRecord>,
        settings: AlertSettings
    ): List<MethodEvaluation> {
        val deduped = mergeCandidates(records)
        return VolumeMethod.entries.map { method ->
            MethodEvaluation(
                method = method,
                stats = evaluateMethod(deduped, method, settings)
            )
        }
    }

    fun assetBreakdown(records: List<CandidateRecord>): List<AssetBreakdownRow> {
        val deduped = mergeCandidates(records)
        return deduped.groupBy { it.symbol }.entries.map { (symbol, list) ->
            val sent = list.filter { it.decision == CandidateDecision.SENT }
            val blocked = list.filter { it.decision == CandidateDecision.BLOCKED_VOLUME }
            val sentStats = summarizeBucket(sent)
            AssetBreakdownRow(
                symbol = symbol,
                sentCount = sent.size,
                blockedCount = blocked.size,
                winRate1hPct = sentStats.winRate1hPct,
                avgRet1hPct = sentStats.avgRet1hPct,
                avgRet4hPct = sentStats.avgRet4hPct,
                tradeWins = sentStats.tradeWins,
                tradeLosses = sentStats.tradeLosses,
                tradeWinRatePct = sentStats.tradeWinRatePct,
                netPnlUsd = sentStats.netPnlUsd
            )
        }.sortedWith(compareByDescending<AssetBreakdownRow> { it.sentCount }.thenBy { it.symbol })
    }
}
