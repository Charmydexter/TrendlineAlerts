package com.trendlinealerts.core.analytics

import com.trendlinealerts.core.detector.SignalGate
import com.trendlinealerts.core.detector.VolumeSnapshot
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.CandidateDecision
import com.trendlinealerts.core.model.CandidateOrigin
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.VolumeMethod
import kotlin.math.max

data class OutcomeResult(
    val ret15mPct: Double?,
    val ret1hPct: Double?,
    val ret4hPct: Double?,
    val maxFav4hPct: Double?,
    val maxAdv4hPct: Double?,
    val resolved: Boolean
)

object OutcomeCalculator {
    private const val MIN_MS = 60_000L
    private const val WINDOW_15M_MS = 15L * MIN_MS
    private const val WINDOW_1H_MS = 60L * MIN_MS
    private const val WINDOW_4H_MS = 240L * MIN_MS

    fun compute(
        entryPrice: Double,
        direction: EntryDirection,
        barOpenMs: Long,
        future1mClosedSorted: List<Candle>,
        nowMs: Long
    ): OutcomeResult {
        if (entryPrice <= 0.0) {
            return OutcomeResult(null, null, null, null, null, resolved = nowMs >= barOpenMs + MIN_MS + WINDOW_4H_MS)
        }
        val entryCloseMs = barOpenMs + MIN_MS
        val barsAfter = future1mClosedSorted.filter { it.isClosed && it.openTimeMs >= entryCloseMs && it.openTimeMs < entryCloseMs + WINDOW_4H_MS }

        fun returnAtOffset(offsetMs: Long): Double? {
            if (nowMs < entryCloseMs + offsetMs) return null
            val targetCloseMs = entryCloseMs + offsetMs
            val exact = barsAfter.firstOrNull { (it.openTimeMs + MIN_MS) == targetCloseMs }
                ?: barsAfter.lastOrNull { (it.openTimeMs + MIN_MS) <= targetCloseMs }
                ?: return null
            return directionalReturnPct(entryPrice, exact.close, direction)
        }

        val ret15m = returnAtOffset(WINDOW_15M_MS)
        val ret1h = returnAtOffset(WINDOW_1H_MS)
        val ret4h = returnAtOffset(WINDOW_4H_MS)

        var mfe: Double? = null
        var mae: Double? = null
        if (barsAfter.isNotEmpty()) {
            var bestFav = 0.0
            var worstAdv = 0.0
            for (b in barsAfter) {
                val fav = when (direction) {
                    EntryDirection.LONG -> (b.high - entryPrice) / entryPrice * 100.0
                    EntryDirection.SHORT -> (entryPrice - b.low) / entryPrice * 100.0
                }
                val adv = when (direction) {
                    EntryDirection.LONG -> (entryPrice - b.low) / entryPrice * 100.0
                    EntryDirection.SHORT -> (b.high - entryPrice) / entryPrice * 100.0
                }
                bestFav = max(bestFav, fav)
                worstAdv = max(worstAdv, adv)
            }
            mfe = bestFav
            mae = worstAdv
        }

        val resolved = nowMs >= entryCloseMs + WINDOW_4H_MS
        return OutcomeResult(
            ret15mPct = ret15m,
            ret1hPct = ret1h,
            ret4hPct = ret4h,
            maxFav4hPct = mfe,
            maxAdv4hPct = mae,
            resolved = resolved
        )
    }

    fun directionalReturnPct(entryPrice: Double, exitPrice: Double, direction: EntryDirection): Double {
        return when (direction) {
            EntryDirection.LONG -> (exitPrice - entryPrice) / entryPrice * 100.0
            EntryDirection.SHORT -> (entryPrice - exitPrice) / entryPrice * 100.0
        }
    }
}

data class CandidateRecord(
    val id: Long = 0L,
    val symbol: String,
    val direction: EntryDirection,
    val slotId: SlotId,
    val barOpenMs: Long,
    val timeMs: Long,
    val entryPrice: Double,
    val lineValue: Double,
    val volumeRatio: Double,
    val rising3: Boolean,
    val falling: Boolean,
    val wickFraction: Double,
    val baselineAvailable: Boolean,
    val decision: CandidateDecision,
    val origin: CandidateOrigin,
    val ret15mPct: Double? = null,
    val ret1hPct: Double? = null,
    val ret4hPct: Double? = null,
    val maxFav4hPct: Double? = null,
    val maxAdv4hPct: Double? = null,
    val resolved: Boolean = false
)

data class DecisionBucketStats(
    val count: Int,
    val resolved1hCount: Int,
    val winRate1hPct: Double?,
    val avgRet15mPct: Double?,
    val avgRet1hPct: Double?,
    val avgRet4hPct: Double?,
    val avgMfe4hPct: Double?,
    val avgMae4hPct: Double?
)

data class PerformanceStats(
    val totalCandidates: Int,
    val sent: DecisionBucketStats,
    val blocked: DecisionBucketStats
)

data class MethodEvaluation(
    val method: VolumeMethod,
    val stats: PerformanceStats
)

data class AssetBreakdownRow(
    val symbol: String,
    val sentCount: Int,
    val blockedCount: Int,
    val winRate1hPct: Double?,
    val avgRet1hPct: Double?,
    val avgRet4hPct: Double?
)

object StatsCalculator {

    private data class DedupeKey(
        val symbol: String,
        val direction: EntryDirection,
        val barOpenMs: Long
    )

    /**
     * Merges LIVE and REPLAY records without double-counting the same touch bar.
     * Prefers LIVE when both exist, falling back to REPLAY outcome fields if needed.
     */
    fun mergeCandidates(records: List<CandidateRecord>): List<CandidateRecord> {
        val byKey = LinkedHashMap<DedupeKey, CandidateRecord>()
        for (r in records) {
            val k = DedupeKey(r.symbol, r.direction, r.barOpenMs)
            val existing = byKey[k]
            if (existing == null) {
                byKey[k] = r
            } else if (existing.origin == CandidateOrigin.REPLAY && r.origin == CandidateOrigin.LIVE) {
                byKey[k] = if (r.resolved || !existing.resolved) r else r.copy(
                    ret15mPct = r.ret15mPct ?: existing.ret15mPct,
                    ret1hPct = r.ret1hPct ?: existing.ret1hPct,
                    ret4hPct = r.ret4hPct ?: existing.ret4hPct,
                    maxFav4hPct = r.maxFav4hPct ?: existing.maxFav4hPct,
                    maxAdv4hPct = r.maxAdv4hPct ?: existing.maxAdv4hPct,
                    resolved = existing.resolved
                )
            }
        }
        return byKey.values.sortedBy { it.timeMs }
    }

    fun summarizeBucket(records: List<CandidateRecord>): DecisionBucketStats {
        val with15m = records.mapNotNull { it.ret15mPct }
        val with1h = records.mapNotNull { it.ret1hPct }
        val with4h = records.mapNotNull { it.ret4hPct }
        val withMfe = records.mapNotNull { it.maxFav4hPct }
        val withMae = records.mapNotNull { it.maxAdv4hPct }
        val wins1h = with1h.count { it > 0.0 }
        return DecisionBucketStats(
            count = records.size,
            resolved1hCount = with1h.size,
            winRate1hPct = if (with1h.isNotEmpty()) wins1h * 100.0 / with1h.size else null,
            avgRet15mPct = with15m.takeIf { it.isNotEmpty() }?.average(),
            avgRet1hPct = with1h.takeIf { it.isNotEmpty() }?.average(),
            avgRet4hPct = with4h.takeIf { it.isNotEmpty() }?.average(),
            avgMfe4hPct = withMfe.takeIf { it.isNotEmpty() }?.average(),
            avgMae4hPct = withMae.takeIf { it.isNotEmpty() }?.average()
        )
    }

    fun computePerformance(records: List<CandidateRecord>): PerformanceStats {
        val deduped = mergeCandidates(records)
        val sent = deduped.filter { it.decision == CandidateDecision.SENT }
        val blocked = deduped.filter { it.decision == CandidateDecision.BLOCKED_VOLUME }
        return PerformanceStats(
            totalCandidates = deduped.size,
            sent = summarizeBucket(sent),
            blocked = summarizeBucket(blocked)
        )
    }

    fun evaluateMethod(
        records: List<CandidateRecord>,
        method: VolumeMethod,
        settings: AlertSettings
    ): PerformanceStats {
        val deduped = mergeCandidates(records).sortedBy { it.timeMs }
        val lastSentBySymbolDir = HashMap<Pair<String, EntryDirection>, Long>()
        val sentList = mutableListOf<CandidateRecord>()
        val blockedList = mutableListOf<CandidateRecord>()

        for (rec in deduped) {
            val key = rec.symbol to rec.direction
            val snap = VolumeSnapshot(
                volumeRatio = rec.volumeRatio,
                rising3 = rec.rising3,
                falling = rec.falling,
                wickFraction = rec.wickFraction,
                baselineAvailable = rec.baselineAvailable
            )
            val decision = SignalGate.decide(
                snapshot = snap,
                method = method,
                settings = settings,
                lastSentAtMs = lastSentBySymbolDir[key],
                barCloseMs = rec.timeMs
            )
            when (decision) {
                CandidateDecision.SENT -> {
                    lastSentBySymbolDir[key] = rec.timeMs
                    sentList.add(rec)
                }
                CandidateDecision.BLOCKED_VOLUME -> blockedList.add(rec)
                CandidateDecision.COOLDOWN -> Unit
            }
        }
        return PerformanceStats(
            totalCandidates = deduped.size,
            sent = summarizeBucket(sentList),
            blocked = summarizeBucket(blockedList)
        )
    }

    fun evaluateAllMethods(
        records: List<CandidateRecord>,
        settings: AlertSettings
    ): List<MethodEvaluation> {
        val deduped = mergeCandidates(records)
        return VolumeMethod.entries.map { method ->
            MethodEvaluation(
                method = method,
                stats = evaluateMethod(deduped, method, settings)
            )
        }
    }

    fun assetBreakdown(records: List<CandidateRecord>): List<AssetBreakdownRow> {
        val deduped = mergeCandidates(records)
        return deduped.groupBy { it.symbol }.entries.map { (symbol, list) ->
            val sent = list.filter { it.decision == CandidateDecision.SENT }
            val blocked = list.filter { it.decision == CandidateDecision.BLOCKED_VOLUME }
            val sentStats = summarizeBucket(sent)
            AssetBreakdownRow(
                symbol = symbol,
                sentCount = sent.size,
                blockedCount = blocked.size,
                winRate1hPct = sentStats.winRate1hPct,
                avgRet1hPct = sentStats.avgRet1hPct,
                avgRet4hPct = sentStats.avgRet4hPct
            )
        }.sortedWith(compareByDescending<AssetBreakdownRow> { it.sentCount }.thenBy { it.symbol })
    }
}
