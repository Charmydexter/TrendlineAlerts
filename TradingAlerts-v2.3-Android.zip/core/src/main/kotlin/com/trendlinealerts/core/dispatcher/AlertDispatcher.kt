package com.trendlinealerts.core.dispatcher

import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.TrendlineCandidate

/**
 * What to do with the events found in one cycle.
 *  cluster   : LONG/SHORT of general assets -> ONE expandable notification (one row per asset, latest event).
 *  individual: live alerts of Positioned assets -> each its own notification (never clustered, never delayed).
 *  missed    : events of Positioned assets that happened while the app was offline -> ONE notification per asset.
 *  logOnly   : missed events of general assets -> written to the Alert Log only, no notification.
 */
data class DispatchPlan(
    val cluster: List<TrendlineCandidate>,
    val individual: List<TrendlineCandidate>,
    val missed: Map<String, List<TrendlineCandidate>>,
    val logOnly: List<TrendlineCandidate>
) {
    val isEmpty: Boolean
        get() = cluster.isEmpty() && individual.isEmpty() && missed.isEmpty() && logOnly.isEmpty()
}

object AlertDispatcher {

    fun plan(
        events: List<TrendlineCandidate>,
        positionedSymbols: Set<String>,
        generalMonitoringOn: Boolean
    ): DispatchPlan {
        val cluster = LinkedHashMap<String, TrendlineCandidate>()
        val individual = mutableListOf<TrendlineCandidate>()
        val missed = LinkedHashMap<String, MutableList<TrendlineCandidate>>()
        val logOnly = mutableListOf<TrendlineCandidate>()

        for (e in events.sortedBy { it.eventTimeMs }) {
            val positioned = e.symbol in positionedSymbols
            when {
                e.missed && positioned -> missed.getOrPut(e.symbol) { mutableListOf() }.add(e)
                e.missed -> logOnly.add(e)
                positioned -> individual.add(e)
                !generalMonitoringOn -> Unit
                e.eventType == EventType.LONG_ENTRY || e.eventType == EventType.SHORT_ENTRY -> cluster[e.symbol] = e
                else -> Unit
            }
        }
        return DispatchPlan(cluster.values.toList(), individual, missed, logOnly)
    }
}
