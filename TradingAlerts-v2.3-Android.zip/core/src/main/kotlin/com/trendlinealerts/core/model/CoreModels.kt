package com.trendlinealerts.core.model

import kotlinx.serialization.Serializable

@Serializable
data class Candle(
    val openTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0,
    val isClosed: Boolean = true
)

@Serializable
enum class Timeframe(
    val label: String,
    val minutes: Int,
    val binanceInterval: String,
    val bybitInterval: String,
    val okxBar: String
) {
    M3("3m", 3, "3m", "3", "3m"),
    M5("5m", 5, "5m", "5", "5m"),
    M15("15m", 15, "15m", "15", "15m"),
    M30("30m", 30, "30m", "30", "30m"),
    H1("1h", 60, "1h", "60", "1H"),
    H4("4h", 240, "4h", "240", "4H");

    val ms: Long get() = minutes * 60_000L
}

@Serializable
enum class SlotId(val side: TrendlineSide) {
    R1(TrendlineSide.RESISTANCE),
    R2(TrendlineSide.RESISTANCE),
    R3(TrendlineSide.RESISTANCE),
    S1(TrendlineSide.SUPPORT),
    S2(TrendlineSide.SUPPORT),
    S3(TrendlineSide.SUPPORT)
}

@Serializable
enum class TrendlineSide {
    RESISTANCE,
    SUPPORT
}

/**
 * CROSS_*  : Positioned assets only (the red/green triangles).
 * LONG/SHORT_ENTRY : General assets only (early heads-up).
 * NEW_*    : Positioned assets only, R1 / S1 replaced by a new line.
 */
@Serializable
enum class EventType {
    CROSS_RESISTANCE,
    CROSS_SUPPORT,
    LONG_ENTRY,
    SHORT_ENTRY,
    NEW_RESISTANCE,
    NEW_SUPPORT
}

@Serializable
enum class EntryDirection {
    LONG,
    SHORT
}

@Serializable
enum class RelativeSide {
    ABOVE,
    BELOW,
    ON_LINE
}

/** GENERAL = long/short signals. POSITIONED = cross signals (user has an open position). */
@Serializable
enum class AssetMode {
    GENERAL,
    POSITIONED
}

@Serializable
enum class VolumeMethod {
    OFF,
    CHEAT_SHEET,
    BLOCK_RISING,
    EXHAUSTION_ONLY,
    CLIMAX_ONLY,
    ACTIVITY_FLOOR
}

@Serializable
enum class CandidateOrigin {
    LIVE,
    REPLAY
}

@Serializable
enum class CandidateDecision {
    SENT,
    BLOCKED_VOLUME,
    COOLDOWN
}

@Serializable
data class AlertSettings(
    val timeframe: Timeframe = Timeframe.M3,
    val proximityPct: Double = 0.25,
    val enabledSlots: Set<SlotId> = SlotId.entries.toSet(),
    val cooldownMinutes: Int = 30,
    val volumeMethod: VolumeMethod = VolumeMethod.OFF,
    val spikeRatio: Double = 2.5,
    val risingRatio: Double = 1.3,
    val wickMinFraction: Double = 0.5,
    val floorRatio: Double = 0.5
) {
    val cooldownMs: Long get() = cooldownMinutes.coerceAtLeast(30) * 60_000L
}

/** A confirmed pivot. barIndex is the position in the closed HTF list that was analysed. */
@Serializable
data class PivotPoint(
    val barIndex: Int,
    val openTimeMs: Long,
    val price: Double
)

/**
 * One trendline. older -> newer pivot. Slope is price per HTF bar; x is measured in bars,
 * computed as elapsed time / HTF bar length (identical to Pine's time based line).
 */
@Serializable
data class ActiveTrendline(
    val slotId: SlotId,
    val side: TrendlineSide,
    val older: PivotPoint,
    val newer: PivotPoint,
    val slopePerBar: Double,
    val tfMs: Long
) {
    /** Identity of the line: it only changes when one of its two pivots changes. */
    val key: String get() = "${slotId.name}:${older.openTimeMs}:${newer.openTimeMs}"
    val pivotKey: String get() = "${older.openTimeMs}:${newer.openTimeMs}"

    fun valueAt(timeMs: Long): Double {
        val bars = (timeMs - newer.openTimeMs).toDouble() / tfMs.toDouble()
        return newer.price + slopePerBar * bars
    }

    fun ref(): LineRef = LineRef(pivotKey, newer.price, newer.openTimeMs, slopePerBar, tfMs)
}

/** Snapshot of a line that can outlive the line itself (needed after a swap). */
@Serializable
data class LineRef(
    val pivotKey: String,
    val newerPrice: Double,
    val newerTimeMs: Long,
    val slopePerBar: Double,
    val tfMs: Long
) {
    fun valueAt(timeMs: Long): Double {
        val bars = (timeMs - newerTimeMs).toDouble() / tfMs.toDouble()
        return newerPrice + slopePerBar * bars
    }
}

@Serializable
data class NearestLineInfo(
    val slotId: SlotId,
    val side: TrendlineSide,
    val lineValue: Double,
    val distancePct: Double
)

@Serializable
data class TrendlineCandidate(
    val symbol: String,
    val slotId: SlotId,
    val side: TrendlineSide,
    val eventType: EventType,
    val price: Double,
    val lineValue: Double,
    val timestampMs: Long,
    /** Close time of the 1m bar that produced the event. */
    val eventTimeMs: Long = timestampMs,
    /** True when the event happened while the app was not watching (offline catch-up). */
    val missed: Boolean = false
)

@Serializable
data class SignalCandidate(
    val symbol: String,
    val direction: EntryDirection,
    val slotId: SlotId,
    val barOpenMs: Long,
    val timeMs: Long,
    val entryPrice: Double,
    val lineValue: Double,
    val volumeRatio: Double,
    val rising3: Boolean,
    val falling: Boolean,
    val wickFraction: Double,
    val baselineAvailable: Boolean,
    val decision: CandidateDecision,
    val origin: CandidateOrigin = CandidateOrigin.LIVE
)

@Serializable
data class DebugLineInfo(
    val slotId: SlotId,
    val currentValue: Double,
    val p1TimeMs: Long,
    val p1Price: Double,
    val p2TimeMs: Long,
    val p2Price: Double
)

@Serializable
data class PivotInfo(val timeMs: Long, val price: Double)

@Serializable
data class SymbolDebugSnapshot(
    val symbol: String,
    val updatedAtMs: Long,
    val lastPrice: Double,
    val htfBarCount: Int,
    val activeLines: List<DebugLineInfo>,
    val resistancePivotCount: Int,
    val supportPivotCount: Int,
    val lastCrossSide: TrendlineSide? = null,
    val lastEntryDirection: EntryDirection? = null,
    val trendBias: EntryDirection? = null,
    val lastLongFiredAtMs: Long? = null,
    val lastShortFiredAtMs: Long? = null,
    val resistancePivots: List<PivotInfo> = emptyList(),
    val supportPivots: List<PivotInfo> = emptyList(),
    val pendingResistance: PivotInfo? = null,
    val pendingSupport: PivotInfo? = null
)
