# Trendline Alerts (Android v2.3)

Native Android (Kotlin + Jetpack Compose + Gradle) trendline alert terminal implementing the Pine-exact 5-bar pivot stack engine across Bybit, Binance, and OKX.

## v2.3 Highlights
- **Regime-based General Strategy:** Assets start neutral; forming a new highest resistance enters Bullish mode (Long signals on lowest support touches), and forming a new lowest support resets to Bearish mode (Short signals on highest resistance touches).
- **1-Hour Individual Reset:** Long and Short signals each have an independent 1-hour reset timer from their last alert timestamp.
- **Compact Persistent Notification:** When Positioned assets exist, the most recently alerted Positioned ticker (without `USDT`) replaces `Monitoring ON`/`OFF` as the title, with any remaining Positioned tickers listed horizontally comma-separated below.

## Build & Test
- `gradle :core:test --no-daemon` — Run core trendline engine & signal processor unit tests
- `gradle :app:assembleDebug --no-daemon` — Build debug APK (`app/build/outputs/apk/debug/app-debug.apk`)