package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import com.lrmlc.tradingalerts.data.model.RangePresets
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class ValidationCalibrationPresetAndReportTest {

    @Test
    fun feeAwareBreakEvenExceedsHalfOnSymmetricBarriersWithFees() {
        val samples = ArrayList<LabeledSample>()
        for (i in 0 until 40) {
            val isWin = i % 2 == 0
            // Symmetric 2.5% gross barrier minus 0.1% round-trip fee => +2.4% win, -2.6% loss
            val net = if (isWin) 0.024 else -0.026
            samples.add(
                LabeledSample(
                    timestampMs = i * 60_000L,
                    exitTimeMs = (i + 5) * 60_000L,
                    symbol = "BTCUSDT",
                    features = doubleArrayOf(0.0),
                    label = if (isWin) 1 else 0,
                    netReturnPct = net
                )
            )
        }
        val be = WalkForwardValidator.computeFeeAwareBreakEven(samples, rewardToRisk = 1.0)
        // avgLoss / (avgWin + avgLoss) = 0.026 / (0.024 + 0.026) = 0.52 > 0.50
        assertEquals(0.52, be, 1e-6)
        assertTrue(be > 0.50)

        // Fallback when fewer than 10 wins
        val tiny = samples.take(10)
        val fallbackBe = WalkForwardValidator.computeFeeAwareBreakEven(tiny, rewardToRisk = 1.0)
        assertEquals(0.50, fallbackBe, 1e-6)
    }

    @Test
    fun promotionRejectsTieMarginBelowThresholdAndLowHoldoutCountAndPromotesClearWin() {
        val baseTime = 1_700_000_000_000L
        fun metrics(trades: Int, exp: Double, baseExp: Double = 0.0001) = ValidationMetrics(
            foldCount = 1,
            totalOutOfSample = 100,
            tradesTaken = trades,
            threshold = 0.60,
            breakEvenThreshold = 0.52,
            winRate = 0.60,
            baselineWinRate = 0.45,
            netExpectancyPct = exp,
            baselineExpectancyPct = baseExp,
            profitFactor = 1.4,
            maxDrawdownPct = 0.05,
            brierScore = 0.21
        )

        val active = metrics(trades = 40, exp = 0.0020)

        // 1. Tie must NOT promote
        val (tieOk, _) = WalkForwardValidator.shouldPromote(
            candidateHoldoutMetrics = metrics(trades = 40, exp = 0.0020),
            activeHoldoutMetrics = active,
            isFirstValidatedModel = false,
            nowMs = baseTime + 48 * 3_600_000L
        )
        assertFalse(tieOk)

        // 2. Margin below MIN_PROMOTION_MARGIN (0.0005) must NOT promote
        val (tinyGainOk, _) = WalkForwardValidator.shouldPromote(
            candidateHoldoutMetrics = metrics(trades = 40, exp = 0.0023),
            activeHoldoutMetrics = active,
            isFirstValidatedModel = false,
            nowMs = baseTime + 48 * 3_600_000L
        )
        assertFalse(tinyGainOk)

        // 3. Fewer than 30 hold-out trades must NOT promote
        val (fewTradesOk, _) = WalkForwardValidator.shouldPromote(
            candidateHoldoutMetrics = metrics(trades = 25, exp = 0.0060),
            activeHoldoutMetrics = active,
            isFirstValidatedModel = false,
            nowMs = baseTime + 48 * 3_600_000L
        )
        assertFalse(fewTradesOk)

        // 4. Cooldown blocks promotion within 24h unless sample count grew >= 20%
        val (cooldownBlocked, _) = WalkForwardValidator.shouldPromote(
            candidateHoldoutMetrics = metrics(trades = 40, exp = 0.0050),
            activeHoldoutMetrics = active,
            isFirstValidatedModel = false,
            nowMs = baseTime + 2 * 3_600_000L,
            lastPromotedAtMs = baseTime,
            lastPromotedSampleCount = 500,
            currentSampleCount = 520
        )
        assertFalse(cooldownBlocked)

        // 5. Clear improvement after cooldown promotes
        val (clearOk, _) = WalkForwardValidator.shouldPromote(
            candidateHoldoutMetrics = metrics(trades = 45, exp = 0.0035),
            activeHoldoutMetrics = active,
            isFirstValidatedModel = false,
            nowMs = baseTime + 30 * 3_600_000L,
            lastPromotedAtMs = baseTime,
            lastPromotedSampleCount = 500,
            currentSampleCount = 520
        )
        assertTrue(clearOk)
    }

    @Test
    fun pureNoiseThresholdSelectionDoesNotChaseHighExtreme() {
        val rng = Random(17)
        // Pure noise predictions in [0.50, 0.86] on mixed outcomes; coverage floor max(30, n/10) prevents tiny tail peaks
        val preds = List(300) { i ->
            val p = rng.nextDouble(0.50, 0.86)
            val win = i % 2 == 0
            val s = LabeledSample(
                timestampMs = i * 60_000L,
                exitTimeMs = (i + 5) * 60_000L,
                symbol = "ETHUSDT",
                features = doubleArrayOf(0.0),
                label = if (win) 1 else 0,
                netReturnPct = if (win) 0.024 else -0.026
            )
            p to s
        }
        val selected = WalkForwardValidator.selectOptimalThreshold(preds, breakEvenThreshold = 0.52)
        // Must stay at high-coverage zone / break-even floor (not jump to >= 0.80 noise extreme)
        assertTrue("Expected non-extreme threshold, got $selected", selected in 0.52..0.75)
    }

    @Test
    fun wilsonIntervalAndBaselineBrierMatchReference() {
        val (lo, hi) = ModelExplainer.wilsonInterval(wins = 47, n = 82)
        assertTrue(lo in 0.45..0.48)
        assertTrue(hi in 0.66..0.70)
        assertEquals(0.24, ModelExplainer.baselineBrier(0.40), 1e-6)
    }

    @Test
    fun isotonicCalibrationIsMonotonicAndDoesNotDegradeBrier() {
        val rng = Random(99)
        // Inverted/overconfident middle buckets vs outcomes
        val preds = List(200) { i ->
            val raw = 0.35 + (i / 200.0) * 0.55
            val trueProb = 0.25 + (i / 200.0) * 0.50
            val label = if (rng.nextDouble() < trueProb) 1 else 0
            val s = LabeledSample(
                timestampMs = i * 60_000L,
                exitTimeMs = (i + 2) * 60_000L,
                symbol = "SOLUSDT",
                features = doubleArrayOf(0.0),
                label = label,
                netReturnPct = if (label == 1) 0.024 else -0.026
            )
            raw to s
        }
        val cal = IsotonicCalibrator.fit(preds)
        var prev = 0.0
        for (p in 20..90 step 5) {
            val calP = cal.calibrate(p / 100.0)
            assertTrue("Isotonic output must be non-decreasing", calP >= prev - 1e-12)
            prev = calP
        }
        val brierRaw = preds.map { (p, s) -> (p - s.label) * (p - s.label) }.average()
        val brierCal = preds.map { (p, s) ->
            val cp = cal.calibrate(p)
            (cp - s.label) * (cp - s.label)
        }.average()
        assertTrue("Isotonic fit must not worsen training Brier ($brierCal > $brierRaw)", brierCal <= brierRaw + 1e-9)
    }

    @Test
    fun presetSelectorPicksBestHandlesFallbackHysteresisAndTies() {
        fun sample(sym: String, net: Double, idx: Int) = LabeledSample(
            timestampMs = idx * 60_000L,
            exitTimeMs = (idx + 2) * 60_000L,
            symbol = sym,
            features = doubleArrayOf(0.0),
            label = if (net > 0) 1 else 0,
            netReturnPct = net
        )
        fun evalFor(preset: com.lrmlc.tradingalerts.data.model.RangePreset, symReturns: Map<String, List<Double>>): PresetCandidateEval {
            val preds = symReturns.flatMap { (sym, list) ->
                list.mapIndexed { idx, r -> 0.75 to sample(sym, r, idx) }
            }
            return PresetCandidateEval(
                preset = preset,
                metrics = ValidationMetrics(1, preds.size, preds.size, 0.60, 0.52, 0.60, 0.50, 0.002, 0.0, 1.3, 0.02, 0.22),
                oosPredictions = preds
            )
        }

        // Ties in pooled-best go to R240
        val tie60 = evalFor(RangePresets.R60, mapOf("BTCUSDT" to List(25) { 0.002 }))
        val tie240 = evalFor(RangePresets.R240, mapOf("BTCUSDT" to List(25) { 0.002 }))
        assertEquals("R240", PresetSelector.selectPooledBest(listOf(tie60, tie240)).id)

        // Asset selection: BTC wins clearly on R60, ETH has < 20 trades on R60 -> falls back to pooled R240
        val eR60 = evalFor(
            RangePresets.R60,
            mapOf(
                "BTCUSDT" to List(25) { 0.006 },
                "ETHUSDT" to List(10) { 0.008 } // < MIN_ASSET_TRADES (20)
            )
        )
        val eR240 = evalFor(
            RangePresets.R240,
            mapOf(
                "BTCUSDT" to List(25) { 0.002 },
                "ETHUSDT" to List(30) { 0.0025 }
            )
        )
        val pooledBest = PresetSelector.selectPooledBest(listOf(eR60, eR240))
        val btcChoice = PresetSelector.selectPresetForAsset(
            symbol = "BTCUSDT",
            assetSampleCounts = mapOf("R60" to 80, "R240" to 80),
            evals = listOf(eR60, eR240),
            pooledBestPreset = pooledBest
        )
        assertEquals("R60", btcChoice.selectedPreset.id)

        val ethChoice = PresetSelector.selectPresetForAsset(
            symbol = "ETHUSDT",
            assetSampleCounts = mapOf("R60" to 80, "R240" to 80),
            evals = listOf(eR60, eR240),
            pooledBestPreset = pooledBest
        )
        assertEquals(pooledBest.id, ethChoice.selectedPreset.id)
        assertTrue(ethChoice.usedPooledFallback)

        // Hysteresis keeps previous preset if new winner beats it by < MIN_PRESET_MARGIN (0.0005)
        val eR120 = evalFor(RangePresets.R120, mapOf("BTCUSDT" to List(25) { 0.0062 }))
        val hystChoice = PresetSelector.selectPresetForAsset(
            symbol = "BTCUSDT",
            assetSampleCounts = mapOf("R60" to 80, "R120" to 80, "R240" to 80),
            evals = listOf(eR60, eR120, eR240),
            pooledBestPreset = pooledBest,
            previousPresetId = "R60"
        )
        assertEquals("R60", hystChoice.selectedPreset.id)
    }

    @Test
    fun trainingReportBuilderSingleLimitedRangeTimelineAndTruncation() {
        val json = Json { encodeDefaults = true; ignoreUnknownKeys = true }
        val baseMetrics = ValidationMetrics(
            foldCount = 3,
            totalOutOfSample = 1500,
            tradesTaken = 200,
            threshold = 0.62,
            breakEvenThreshold = 0.52,
            winRate = 0.58,
            baselineWinRate = 0.48,
            netExpectancyPct = 0.0032,
            baselineExpectancyPct = -0.0002,
            profitFactor = 1.35,
            maxDrawdownPct = 0.04,
            brierScore = 0.215,
            calibrationBuckets = listOf(CalibrationBucket(0.60, 0.70, 120, 0.63, 0.60))
        )
        fun makeData(cap: Double, setups: Int) = TrainingReportData(
            jobType = "MANUAL",
            startedAtMs = 1_700_000_000_000L,
            endedAtMs = 1_700_000_012_000L,
            durationMs = 12_000L,
            exchange = "BYBIT",
            marketType = "PERP",
            capitalUsd = cap,
            maxLossUsd = 0.5,
            takeProfitUsd = 0.5,
            roundTripFeeRate = 0.001,
            labelHorizonBars = 30,
            windowLength = 240,
            minGap = 30,
            thresholdMode = "AUTO_EXPECTANCY",
            manualThreshold = 0.60,
            minSamplesForPerAssetModel = 60,
            retentionDays = 30,
            stopDistancePct = (0.5 / cap) * 100.0,
            tpDistancePct = (0.5 / cap) * 100.0,
            feeAsPctOfBarrier = (0.001 / (0.5 / cap)) * 100.0,
            symbolCount = 2,
            symbols = listOf("BTCUSDT", "ETHUSDT"),
            samplesPerSymbol = mapOf("BTCUSDT" to setups / 2, "ETHUSDT" to setups / 2),
            totalSetups = setups,
            dataWindowStartMs = 1_699_000_000_000L,
            dataWindowEndMs = 1_700_000_000_000L,
            winLabelShare = 0.45,
            timeoutCount = 300,
            globalMetrics = baseMetrics,
            promoted = true,
            promotionReason = "Hold-out win",
            perAssetRows = listOf(ReportPerAssetRow("BTCUSDT", "R60", 400, 0.60, 0.59, 0.004, 1.4, "Updated")),
            pooledPresetSummaries = listOf(PooledPresetSummary("R240", "4h", 240, 30, 200, 0.58, 0.0032, 0.0021, 0.62, 0.215))
        )

        val log1 = TrainingLogEntity(
            id = 1L,
            timestampMs = 1_700_000_012_000L,
            exchange = "BYBIT",
            marketType = "PERP",
            jobType = "INITIAL",
            promoted = true,
            summary = "Promoted",
            metricsJson = json.encodeToString(baseMetrics),
            reportJson = json.encodeToString(makeData(20.0, 1500))
        )
        val singleMd = TrainingReportBuilder.buildSingle(log1)
        assertTrue(singleMd.contains("(a) Preamble"))
        assertTrue(singleMd.contains("(c) Settings"))
        assertTrue(singleMd.contains("(g) Per-asset"))
        assertTrue(singleMd.contains("(j) Glossary"))
        assertFalse(singleMd.contains("apiKey", ignoreCase = true))

        // Legacy log without reportJson -> reduced report marked with limited-data notice
        val legacyLog = log1.copy(id = 2L, reportJson = null)
        val legacyMd = TrainingReportBuilder.buildSingle(legacyLog)
        assertTrue(legacyMd.contains("Limited data: this log was created before full report capture"))

        // Range report: 3 runs where Run 2 is identical to Run 1 and Run 3 changes capital & setups
        val log2 = log1.copy(id = 2L, timestampMs = log1.timestampMs + 3_600_000L)
        val log3 = log1.copy(
            id = 3L,
            timestampMs = log1.timestampMs + 7_200_000L,
            reportJson = json.encodeToString(makeData(100.0, 900))
        )
        val rangeMd = TrainingReportBuilder.buildRange(listOf(log1, log2, log3), "Last 7 days")
        assertTrue(rangeMd.contains("Same as Run 1."))
        assertTrue(rangeMd.contains("capital \$20.00 -> \$100.00"))
        assertTrue(rangeMd.contains("setups 1500 -> 900"))

        // 105 logs -> truncated to 100 with notice
        val many = (1..105).map { i -> log1.copy(id = i.toLong(), timestampMs = 1_700_000_000_000L + i * 60_000L) }
        val truncMd = TrainingReportBuilder.buildRange(many, "Last 30 days")
        assertTrue(truncMd.contains("truncated to the 100 most recent runs out of 105"))

        // Empty window
        val emptyMd = TrainingReportBuilder.buildRange(emptyList(), "Last 24 hours")
        assertTrue(emptyMd.contains("No training runs found"))
    }
}
