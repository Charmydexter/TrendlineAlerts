package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.EngineConfig
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.RangePresets
import com.lrmlc.tradingalerts.data.model.TimeoutLabelMode
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin
import kotlin.random.Random

class FeatureBuilderAndLabelerTest {

    @Test
    fun buildsAll71FeaturesIncludingVolumeSinceBirth() {
        val baseTime = 1_700_000_000_000L
        val candles = MutableList(300) { i ->
            val p = 100.0 + sin(i / 25.0) * 3.0
            val vol = 500.0 + (i % 20) * 25.0
            Candle(baseTime + i * 60_000L, p - 0.2, p + 0.5, p - 0.5, p + 0.2, vol)
        }
        candles[50] = candles[50].copy(high = 120.0, low = 96.0, volume = 1200.0)
        candles[240] = candles[240].copy(high = 108.0, low = 99.0, volume = 800.0)
        for (i in 241..274) {
            candles[i] = Candle(baseTime + i * 60_000L, 100.0, 100.3, 99.7, 100.0, 600.0 + (i - 241) * 40.0)
        }
        candles[275] = Candle(baseTime + 275 * 60_000L, 108.0, 111.0, 107.0, 110.5, 2500.0)

        val cfg = EngineConfig(capitalUsd = 20.0, maxLossUsd = 2.5, takeProfitUsd = 0.5)
        val engine = ConfluenceEngine(cfg, RangePresets.R240)
        val snaps = engine.evaluateAll(candles)
        val sigIdx = snaps.indexOfLast { it.candidateDirection != null }
        assertTrue("Expected at least one candidate signal", sigIdx >= 240)

        val feats = FeatureBuilder.buildFeatures(
            candles = candles,
            snapshots = snaps,
            barIndex = sigIdx,
            marketType = MarketType.PERP,
            lastSignalOutcome = 1,
            windowBars = RangePresets.R240.windowBars
        )
        assertNotNull(feats)
        assertEquals(FeatureSpec.FEATURE_COUNT, feats!!.size)
        assertTrue(feats.all { it.isFinite() })
        assertTrue("Expected positive volume ratio at signal bar vs birth avg", feats[51] > 0.0)
        assertTrue("Expected up-bar volume share in [0,1]", feats[43] in 0.0..1.0)
    }

    @Test
    fun featuresScaleWithWindowBarsAndFeatureSpecSubstitutesWindowLabel() {
        val baseTime = 1_700_000_000_000L
        val candles = MutableList(300) { i ->
            val p = 100.0 + sin(i / 10.0) * 1.5
            Candle(baseTime + i * 60_000L, p - 0.1, p + 0.4, p - 0.4, p + 0.1, 400.0 + (i % 15) * 20.0)
        }
        candles[220] = candles[220].copy(high = 107.0, low = 94.0)
        candles[265] = candles[265].copy(high = 104.0, low = 97.0)
        candles[266] = candles[266].copy(high = 101.0, low = 99.0)
        candles[275] = Candle(baseTime + 275 * 60_000L, 104.5, 106.5, 104.5, 106.0, 2000.0)

        val cfg = EngineConfig(capitalUsd = 20.0, maxLossUsd = 2.5, takeProfitUsd = 0.5)
        val snaps60 = ConfluenceEngine(cfg, RangePresets.R60).evaluateAll(candles)
        val f60 = FeatureBuilder.buildFeatures(candles, snaps60, 275, MarketType.PERP, 1, windowBars = 60)
        assertNotNull(f60)
        // Verify res_updates_win normalized by 60 (feature 9) matches snapshot / 60.0
        assertEquals(snaps60[275].resUpdatesInWindow / 60.0, f60!![9], 1e-6)

        val basisDef = FeatureSpec.DEFINITIONS.first { it.key == "dist_close_basis" }
        assertTrue(basisDef.title.contains("{W}"))
        assertEquals("Distance from 1h average", FeatureSpec.formatText(basisDef.title, "1h"))

        val ratioDef = FeatureSpec.DEFINITIONS.first { it.key == "struct_to_dollar_sl_ratio" }
        assertFalse(ratioDef.positiveExplanation.contains("$0.50"))
        assertFalse(ratioDef.negativeExplanation.contains("$0.50"))
    }

    @Test
    fun tripleBarrierConservativeSameBarSlPriorityAndFeeAdjustedTimeout() {
        val baseTime = 1_700_000_000_000L
        val sameBarCandles = listOf(
            Candle(baseTime, 100.0, 100.5, 99.5, 100.0, 100.0),
            Candle(baseTime + 60_000L, 100.0, 105.0, 96.0, 102.0, 200.0)
        )
        val resBoth = TripleBarrierLabeler.labelCandidate(
            candles = sameBarCandles,
            signalBarIndex = 0,
            direction = TradeDirection.LONG,
            entryPrice = 100.0,
            slPrice = 97.5,
            tpPrice = 102.5,
            horizonBars = 10
        )
        assertEquals(BarrierOutcome.SL_HIT, resBoth.outcome)
        assertEquals(0, resBoth.label)

        val tpCandles = listOf(
            Candle(baseTime, 100.0, 100.2, 99.8, 100.0, 100.0),
            Candle(baseTime + 60_000L, 100.0, 101.0, 99.2, 100.8, 100.0),
            Candle(baseTime + 120_000L, 100.8, 103.0, 100.5, 102.8, 150.0)
        )
        val resTp = TripleBarrierLabeler.labelCandidate(
            candles = tpCandles,
            signalBarIndex = 0,
            direction = TradeDirection.LONG,
            entryPrice = 100.0,
            slPrice = 97.5,
            tpPrice = 102.5,
            horizonBars = 10
        )
        assertEquals(BarrierOutcome.TP_HIT, resTp.outcome)
        assertEquals(1, resTp.label)
        assertEquals(0.008, resTp.maePct, 1e-6)
        assertEquals(0.03, resTp.mfePct, 1e-6)

        val timeoutCandles = listOf(
            Candle(baseTime, 100.0, 100.2, 99.8, 100.0, 100.0),
            Candle(baseTime + 60_000L, 100.0, 100.2, 99.8, 100.02, 100.0),
            Candle(baseTime + 120_000L, 100.02, 100.2, 99.8, 100.03, 100.0),
            Candle(baseTime + 180_000L, 100.03, 100.2, 99.8, 100.04, 100.0)
        )
        val resTimeout = TripleBarrierLabeler.labelCandidate(
            candles = timeoutCandles,
            signalBarIndex = 0,
            direction = TradeDirection.LONG,
            entryPrice = 100.0,
            slPrice = 95.0,
            tpPrice = 105.0,
            horizonBars = 3,
            roundTripFeeRate = 0.001,
            timeoutLabelMode = TimeoutLabelMode.SIGN_OF_NET_AFTER_FEES
        )
        assertEquals(BarrierOutcome.TIMEOUT_LOSS, resTimeout.outcome)
        assertEquals(0, resTimeout.label)
    }

    @Test
    fun exitModelPhaseAssignmentLabelSavingsAndPerCellPrecisionGate() {
        // Bucket boundaries [U22]
        assertEquals(0, ExitWarningFeatureBuilder.ageBucketFor(1))
        assertEquals(0, ExitWarningFeatureBuilder.ageBucketFor(2))
        assertEquals(1, ExitWarningFeatureBuilder.ageBucketFor(3))
        assertEquals(2, ExitWarningFeatureBuilder.ageBucketFor(10))
        assertEquals(3, ExitWarningFeatureBuilder.ageBucketFor(20))
        assertEquals(4, ExitWarningFeatureBuilder.ageBucketFor(21))

        assertEquals(0, ExitWarningFeatureBuilder.progressBucketFor(-0.21))
        assertEquals(1, ExitWarningFeatureBuilder.progressBucketFor(-0.20))
        assertEquals(1, ExitWarningFeatureBuilder.progressBucketFor(0.20))
        assertEquals(2, ExitWarningFeatureBuilder.progressBucketFor(0.21))
        assertEquals(2, ExitWarningFeatureBuilder.progressBucketFor(1.0))
        assertEquals(3, ExitWarningFeatureBuilder.progressBucketFor(1.01))
        // Progress keeps counting past TP, capped at 3
        assertEquals(1.5, ExitWarningFeatureBuilder.computeSignedProgress(TradeDirection.LONG, 103.0, 100.0, 98.0, 102.0), 1e-6)
        assertEquals(3.0, ExitWarningFeatureBuilder.computeSignedProgress(TradeDirection.LONG, 150.0, 100.0, 98.0, 102.0), 1e-6)
        // Beyond-TP label: profit given back >= 0.25 * TP distance
        assertEquals(1, ExitWarningFeatureBuilder.computeBeyondTpExitLabel(0.02, 0.005, 0.02))
        assertEquals(0, ExitWarningFeatureBuilder.computeBeyondTpExitLabel(0.02, 0.019, 0.02))

        // Signed progress Long vs Short
        assertEquals(0.5, ExitWarningFeatureBuilder.computeSignedProgress(TradeDirection.LONG, 101.0, 100.0, 98.0, 102.0), 1e-6)
        assertEquals(-0.5, ExitWarningFeatureBuilder.computeSignedProgress(TradeDirection.LONG, 99.0, 100.0, 98.0, 102.0), 1e-6)
        assertEquals(0.5, ExitWarningFeatureBuilder.computeSignedProgress(TradeDirection.SHORT, 99.0, 100.0, 102.0, 98.0), 1e-6)

        // Exit label requires loss + saving >= 0.25 * stopDistPct
        val savedLoss = ExitWarningFeatureBuilder.computeExitLabel(
            outcome = BarrierOutcome.SL_HIT,
            unrealizedNetPct = -0.005,
            finalNetPct = -0.020,
            stopDistPct = 0.025 // threshold = 0.00625; saved = 0.015 >= 0.00625
        )
        assertEquals(1, savedLoss)
        val tinySaveLoss = ExitWarningFeatureBuilder.computeExitLabel(
            outcome = BarrierOutcome.SL_HIT,
            unrealizedNetPct = -0.018,
            finalNetPct = -0.020,
            stopDistPct = 0.025 // saved = 0.002 < 0.00625
        )
        assertEquals(0, tinySaveLoss)
        val winningTrade = ExitWarningFeatureBuilder.computeExitLabel(
            outcome = BarrierOutcome.TP_HIT,
            unrealizedNetPct = 0.015,
            finalNetPct = 0.025,
            stopDistPct = 0.025
        )
        assertEquals(0, winningTrade)

        // Synthetic phase training:
        // - ageBucket 0 (1-2m) NEAR (1) has noisy 50% labels -> must stay SILENT
        // - ageBucket 2 (6-10m) NEAR (1) has separable strong reversal feature -> ENABLED
        // - ageBucket 4 (21+m) PROFIT (2) has separable reversal -> ENABLED
        // - ageBucket 3 (11-20m) LOSS (0) has 0 OOS states (<30) & silent group -> SILENT
        val rng = Random(42)
        val samples = ArrayList<ExitStateSample>()
        for (tradeIdx in 0 until 220) {
            val entryMs = (tradeIdx + 1) * 100 * 60_000L
            // 1) ageBucket 0 noisy
            run {
                val f = DoubleArray(ExitFeatureSpec.FEATURE_COUNT) { rng.nextDouble(-1.0, 1.0) }
                val lbl = if (tradeIdx % 2 == 0) 1 else 0
                val exitMs = entryMs + 10 * 60_000L
                val lSample = LabeledSample(entryMs + 60_000L, exitMs, "BTCUSDT", f, lbl, if (lbl == 1) 0.01 else -0.01)
                samples.add(
                    ExitStateSample(
                        entryTimeMs = entryMs,
                        sample = lSample,
                        ageBucket = 0,
                        progressBucket = 1,
                        structTriggered = lbl == 1 && rng.nextDouble() < 0.55,
                        savedRisk = if (lbl == 1) 0.4 else -0.2
                    )
                )
            }
            // 2) ageBucket 2 strong predictive signal in f[0]
            run {
                val f = DoubleArray(ExitFeatureSpec.FEATURE_COUNT) { rng.nextDouble(-0.4, 0.4) }
                val isPos = tradeIdx % 3 != 0
                f[0] = if (isPos) 2.5 + rng.nextDouble(0.0, 0.5) else -2.5 - rng.nextDouble(0.0, 0.5)
                val exitMs = entryMs + 10 * 60_000L
                val lbl = if (isPos) 1 else 0
                val lSample = LabeledSample(entryMs + 8 * 60_000L, exitMs, "BTCUSDT", f, lbl, if (isPos) 0.012 else -0.005)
                samples.add(
                    ExitStateSample(
                        entryTimeMs = entryMs,
                        sample = lSample,
                        ageBucket = 2,
                        progressBucket = 1,
                        structTriggered = false,
                        savedRisk = if (isPos) 0.5 else -0.1
                    )
                )
            }
            // 3) ageBucket 4 PROFIT predictive signal
            run {
                val f = DoubleArray(ExitFeatureSpec.FEATURE_COUNT) { rng.nextDouble(-0.5, 0.5) }
                val isPos = tradeIdx % 2 == 0
                f[0] = if (isPos) 2.2 else -2.2
                val exitMs = entryMs + 25 * 60_000L
                val lbl = if (isPos) 1 else 0
                val lSample = LabeledSample(entryMs + 22 * 60_000L, exitMs, "BTCUSDT", f, lbl, if (isPos) 0.015 else -0.005)
                samples.add(
                    ExitStateSample(
                        entryTimeMs = entryMs,
                        sample = lSample,
                        ageBucket = 4,
                        progressBucket = 2,
                        structTriggered = isPos,
                        savedRisk = if (isPos) 0.6 else -0.1
                    )
                )
            }
        }

        val trained = ExitWarningFeatureBuilder.trainAndEvaluatePhaseRules(
            samples = samples,
            exchange = "BYBIT",
            marketType = "PERP",
            horizonBars = 30
        )
        assertEquals(20, trained.rules.size)
        val noisyEarly = trained.rules.first { it.ageBucket == 0 && it.progressBucket == 1 }
        assertFalse("Noisy early bucket must stay silent", noisyEarly.mlEnabled || noisyEarly.structEnabled)

        val matureCell = trained.rules.first { it.ageBucket == 2 && it.progressBucket == 1 }
        assertTrue("Predictive mature cell should enable ML", matureCell.mlEnabled)
        assertTrue(matureCell.precision >= 0.70)

        val sparseCell = trained.rules.first { it.ageBucket == 3 && it.progressBucket == 0 }
        assertFalse("Sparse cell with silent group must stay silent", sparseCell.mlEnabled || sparseCell.structEnabled)

        val summary = ExitWarningFeatureBuilder.summarizeRules(trained.rules)
        assertTrue(summary.reliableCellCount > 0)
        assertEquals(6, summary.learnedMinBars)
    }
}
