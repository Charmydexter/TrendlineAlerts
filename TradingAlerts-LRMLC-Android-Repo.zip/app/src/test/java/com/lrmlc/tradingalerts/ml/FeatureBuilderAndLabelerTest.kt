package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.EngineConfig
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.TimeoutLabelMode
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

class FeatureBuilderAndLabelerTest {

    @Test
    fun buildsAll71FeaturesIncludingVolumeSinceBirth() {
        val baseTime = 1_700_000_000_000L
        val candles = MutableList(300) { i ->
            val p = 100.0 + sin(i / 25.0) * 3.0
            val vol = 500.0 + (i % 20) * 25.0
            Candle(baseTime + i * 60_000L, p - 0.2, p + 0.5, p - 0.5, p + 0.2, vol)
        }
        // Create clear trendline anchors + breakout candle at bar 275
        candles[50] = candles[50].copy(high = 120.0, low = 96.0, volume = 1200.0)
        candles[240] = candles[240].copy(high = 108.0, low = 99.0, volume = 800.0)
        // Keep bars 241..274 strictly inside channel with rising volume since birth
        for (i in 241..274) {
            candles[i] = Candle(baseTime + i * 60_000L, 100.0, 100.3, 99.7, 100.0, 600.0 + (i - 241) * 40.0)
        }
        candles[275] = Candle(baseTime + 275 * 60_000L, 108.0, 111.0, 107.0, 110.5, 2500.0)

        val cfg = EngineConfig(windowLength = 240, minGap = 30, capitalUsd = 20.0, maxLossUsd = 2.5, takeProfitUsd = 0.5)
        val engine = ConfluenceEngine(cfg)
        val snaps = engine.evaluateAll(candles)
        val sigIdx = snaps.indexOfLast { it.candidateDirection != null }
        assertTrue("Expected at least one candidate signal", sigIdx >= 240)

        val feats = FeatureBuilder.buildFeatures(
            candles = candles,
            snapshots = snaps,
            barIndex = sigIdx,
            marketType = MarketType.PERP,
            lastSignalOutcome = 1
        )
        assertNotNull(feats)
        assertEquals(FeatureSpec.FEATURE_COUNT, feats!!.size)
        assertTrue(feats.all { it.isFinite() })
        // Check volume-since-birth features are non-trivial and bounded
        assertTrue("Expected positive volume ratio at signal bar vs birth avg", feats[51] > 0.0)
        assertTrue("Expected up-bar volume share in [0,1]", feats[43] in 0.0..1.0)
    }

    @Test
    fun tripleBarrierConservativeSameBarSlPriorityAndFeeAdjustedTimeout() {
        val baseTime = 1_700_000_000_000L
        // 1) Both SL and TP touched on bar 1 -> SL wins (label = 0)
        val sameBarCandles = listOf(
            Candle(baseTime, 100.0, 100.5, 99.5, 100.0, 100.0),
            Candle(baseTime + 60_000L, 100.0, 105.0, 96.0, 102.0, 200.0)
        )
        val resBoth = TripleBarrierLabeler.labelCandidate(
            candles = sameBarCandles,
            signalBarIndex = 0,
            direction = TradeDirection.LONG,
            entryPrice = 100.0,
            slPrice = 97.5,
            tpPrice = 102.5,
            horizonBars = 10
        )
        assertEquals(BarrierOutcome.SL_HIT, resBoth.outcome)
        assertEquals(0, resBoth.label)

        // 2) TP hit cleanly on bar 2 -> label = 1 and positive MFE
        val tpCandles = listOf(
            Candle(baseTime, 100.0, 100.2, 99.8, 100.0, 100.0),
            Candle(baseTime + 60_000L, 100.0, 101.0, 99.2, 100.8, 100.0),
            Candle(baseTime + 120_000L, 100.8, 103.0, 100.5, 102.8, 150.0)
        )
        val resTp = TripleBarrierLabeler.labelCandidate(
            candles = tpCandles,
            signalBarIndex = 0,
            direction = TradeDirection.LONG,
            entryPrice = 100.0,
            slPrice = 97.5,
            tpPrice = 102.5,
            horizonBars = 10
        )
        assertEquals(BarrierOutcome.TP_HIT, resTp.outcome)
        assertEquals(1, resTp.label)
        assertEquals(0.008, resTp.maePct, 1e-6)
        assertEquals(0.03, resTp.mfePct, 1e-6)

        // 3) Timeout after 3 bars with small gain < 0.1% fee -> negative net return -> label 0
        val timeoutCandles = listOf(
            Candle(baseTime, 100.0, 100.2, 99.8, 100.0, 100.0),
            Candle(baseTime + 60_000L, 100.0, 100.2, 99.8, 100.02, 100.0),
            Candle(baseTime + 120_000L, 100.02, 100.2, 99.8, 100.03, 100.0),
            Candle(baseTime + 180_000L, 100.03, 100.2, 99.8, 100.04, 100.0)
        )
        val resTimeout = TripleBarrierLabeler.labelCandidate(
            candles = timeoutCandles,
            signalBarIndex = 0,
            direction = TradeDirection.LONG,
            entryPrice = 100.0,
            slPrice = 95.0,
            tpPrice = 105.0,
            horizonBars = 3,
            roundTripFeeRate = 0.001,
            timeoutLabelMode = TimeoutLabelMode.SIGN_OF_NET_AFTER_FEES
        )
        assertEquals(BarrierOutcome.TIMEOUT_LOSS, resTimeout.outcome)
        assertEquals(0, resTimeout.label)
    }
}
