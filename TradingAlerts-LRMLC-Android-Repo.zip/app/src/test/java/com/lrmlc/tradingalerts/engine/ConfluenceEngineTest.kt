package com.lrmlc.tradingalerts.engine

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.EngineConfig
import com.lrmlc.tradingalerts.data.model.RangePresets
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfluenceEngineTest {

    @Test
    fun resistanceConfirmedPeakAndPersistenceMatchPineRules() {
        val cfg = EngineConfig(windowLength = 50, minGap = 10, capitalUsd = 20.0, maxLossUsd = 0.5, takeProfitUsd = 0.5)
        val engine = ConfluenceEngine(cfg)

        val baseTime = 1_700_000_000_000L
        val candles = MutableList(60) { idx ->
            Candle(baseTime + idx * 60_000L, 100.0, 101.0, 99.0, 100.0, 10.0)
        }
        candles[10] = candles[10].copy(high = 120.0)
        candles[48] = candles[48].copy(high = 110.0)
        candles[49] = candles[49].copy(high = 105.0)
        candles[5] = candles[5].copy(low = 80.0)
        candles[47] = candles[47].copy(low = 90.0)
        candles[48] = candles[48].copy(low = 95.0)

        val snaps = engine.evaluateAll(candles)
        val snap49 = snaps[49]
        assertNotNull(snap49.resistance)
        assertEquals(10, snap49.resistance!!.x1)
        assertEquals(48, snap49.resistance!!.x2)
        assertEquals(49, snap49.resistance!!.birthBar)

        candles[50] = candles[50].copy(high = 115.0)
        candles[51] = candles[51].copy(high = 102.0)
        val snaps2 = engine.evaluateAll(candles)
        assertEquals(48, snaps2[50].resistance!!.x2)
        assertEquals(50, snaps2[51].resistance!!.x2)
    }

    @Test
    fun gateDisarmsOnFireAndReArmsOnBlockedOppositeRaw() {
        val baseTime = 1_700_000_000_000L
        val candles = MutableList(70) { idx ->
            Candle(baseTime + idx * 60_000L, 100.0, 101.0, 99.0, 100.0, 10.0)
        }
        candles[5] = candles[5].copy(high = 105.0, low = 95.0)
        candles[40] = candles[40].copy(high = 103.0, low = 97.0)
        candles[41] = candles[41].copy(high = 101.0, low = 99.0)

        val cfg2 = EngineConfig(windowLength = 50, minGap = 10, capitalUsd = 20.0, maxLossUsd = 1.2, takeProfitUsd = 0.5)
        val engine2 = ConfluenceEngine(cfg2)

        candles[50] = Candle(baseTime + 50 * 60_000L, 103.0, 104.0, 103.0, 103.5, 20.0)
        candles[51] = Candle(baseTime + 51 * 60_000L, 103.5, 104.5, 103.5, 104.0, 20.0)

        val snaps = engine2.evaluateAll(candles)
        assertTrue("Bar 50 should fire LONG", snaps[50].longFire)
        assertFalse("longArmed should become false after firing", snaps[50].longArmedAfter)
        assertFalse("Bar 51 must not fire while disarmed", snaps[51].longFire)
    }

    @Test
    fun riskFilterBlockedSignalDoesNotDisarmAndOppositeRawRearms() {
        val cfg = EngineConfig(windowLength = 50, minGap = 10, capitalUsd = 20.0, maxLossUsd = 0.2, takeProfitUsd = 0.5)
        val engine = ConfluenceEngine(cfg)
        val baseTime = 1_700_000_000_000L
        val candles = MutableList(65) { idx ->
            Candle(baseTime + idx * 60_000L, 100.0, 101.0, 99.0, 100.0, 10.0)
        }
        candles[5] = candles[5].copy(high = 110.0, low = 90.0)
        candles[40] = candles[40].copy(high = 104.0, low = 96.0)
        candles[41] = candles[41].copy(high = 101.0, low = 99.0)
        candles[55] = Candle(baseTime + 55 * 60_000L, 95.0, 95.0, 93.5, 94.0, 15.0)

        val snaps = engine.evaluateAll(candles)
        val s55 = snaps[55]
        assertTrue(s55.rawShort)
        assertFalse(s55.shortOk)
        assertFalse(s55.shortFire)
        assertTrue("Blocked short must NOT disarm shortArmed", s55.shortArmedAfter)
        assertTrue("Raw short must keep/re-arm longArmed", s55.longArmedAfter)
    }

    @Test
    fun rangePreset30ReallyUses30BarsNot50() {
        val cfg = EngineConfig(capitalUsd = 20.0, maxLossUsd = 0.5, takeProfitUsd = 0.5)
        val engine = ConfluenceEngine(cfg, RangePresets.R30)
        assertEquals(30, engine.windowBars)
        assertEquals(3, engine.effectiveMinGap)

        val baseTime = 1_700_000_000_000L
        val candles = MutableList(45) { idx ->
            Candle(baseTime + idx * 60_000L, 100.0, 101.0, 99.0, 100.0, 10.0)
        }
        candles[5] = candles[5].copy(high = 112.0, low = 88.0)
        candles[25] = candles[25].copy(high = 106.0, low = 94.0)
        candles[26] = candles[26].copy(high = 101.0, low = 99.0)

        val snaps = engine.evaluateAll(candles)
        // At bar 29 (before bar 50!), a 30-bar window already builds a trendline & rolling basis
        assertNotNull("Expected basis at bar 29 for 30-bar preset", snaps[29].basis)
        assertNotNull("Expected resistance at bar 29 for 30-bar preset", snaps[29].resistance)
        assertTrue("Expected non-negative resUpdatesInWindow", snaps[29].resUpdatesInWindow >= 0)
    }
}
