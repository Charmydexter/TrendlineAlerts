package com.lrmlc.tradingalerts.engine

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.EngineConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfluenceEngineTest {

    @Test
    fun resistanceConfirmedPeakAndPersistenceMatchPineRules() {
        // winLen = 50 (min allowed by Pine script), minGap = 10
        val cfg = EngineConfig(windowLength = 50, minGap = 10, capitalUsd = 20.0, maxLossUsd = 0.5, takeProfitUsd = 0.5)
        val engine = ConfluenceEngine(cfg)

        val baseTime = 1_700_000_000_000L
        val candles = MutableList(60) { idx ->
            Candle(baseTime + idx * 60_000L, 100.0, 101.0, 99.0, 100.0, 10.0)
        }
        // Highest high at bar 10 (y=120)
        candles[10] = candles[10].copy(high = 120.0)
        // Confirmed peak at bar 48 (y=110) followed by lower high at bar 49 (y=105)
        candles[48] = candles[48].copy(high = 110.0)
        candles[49] = candles[49].copy(high = 105.0)
        // Lowest low at bar 5 (y=80)
        candles[5] = candles[5].copy(low = 80.0)
        // Confirmed trough at bar 47 (y=90) followed by higher low at bar 48 (y=95)
        candles[47] = candles[47].copy(low = 90.0)
        candles[48] = candles[48].copy(low = 95.0)

        // Bar 49 is barIndex = 49 = winLen - 1. Note hi1 = 49 - 10 = 39, hi2 = 49 - 48 = 1 (confirmed because bar 49 has lower high 105 < 110!)
        val snaps = engine.evaluateAll(candles)
        val snap49 = snaps[49]
        assertNotNull(snap49.resistance)
        assertEquals(10, snap49.resistance!!.x1)
        assertEquals(48, snap49.resistance!!.x2)
        assertEquals(49, snap49.resistance!!.birthBar)

        // Bar 50 has an even higher candle at bar 50 itself (high=115) -> bar 0 is NOT eligible until confirmed by bar 51!
        candles[50] = candles[50].copy(high = 115.0)
        candles[51] = candles[51].copy(high = 102.0) // confirms bar 50 on bar 51!
        val snaps2 = engine.evaluateAll(candles)
        assertEquals(48, snaps2[50].resistance!!.x2) // bar 50 NOT yet confirmed on bar 50
        assertEquals(50, snaps2[51].resistance!!.x2) // bar 50 confirmed on bar 51!
    }

    @Test
    fun gateDisarmsOnFireAndReArmsOnBlockedOppositeRaw() {
        val cfg = EngineConfig(windowLength = 50, minGap = 10, capitalUsd = 20.0, maxLossUsd = 0.5, takeProfitUsd = 0.5)
        val engine = ConfluenceEngine(cfg)
        val baseTime = 1_700_000_000_000L

        val candles = MutableList(70) { idx ->
            Candle(baseTime + idx * 60_000L, 100.0, 101.0, 99.0, 100.0, 10.0)
        }
        // Build clean valid resistance and support anchors
        candles[5] = candles[5].copy(high = 105.0, low = 95.0)
        candles[40] = candles[40].copy(high = 103.0, low = 97.0)
        candles[41] = candles[41].copy(high = 101.0, low = 99.0)

        // Bar 50: rawLong AND longOK (close - 0.025*close < loLine): close = 102 -> slDist = 2.55 -> 102 - 2.55 = 99.45 < ~100
        // Let's push low above hiLine (~102.5) and keep close - slDist < loLine (~97.5):
        // With capital=20, maxLoss=0.5 => slDist = 2.5% of close. If hiLine ~ 102.5 and loLine ~ 97.5:
        // If bar 50 has low=103.0, close=103.1 -> 103.1 - 2.5775 = 100.52 > 97.5 -> blocked!
        // Use a wider maxLoss (1.2 -> 6% slDist) so longOK passes cleanly at bar 50, then test risk rejection on short at bar 55
        val cfg2 = EngineConfig(windowLength = 50, minGap = 10, capitalUsd = 20.0, maxLossUsd = 1.2, takeProfitUsd = 0.5)
        val engine2 = ConfluenceEngine(cfg2)

        // Bar 50: fires LONG
        candles[50] = Candle(baseTime + 50 * 60_000L, 103.0, 104.0, 103.0, 103.5, 20.0)
        // Bar 51: another rawLong while disarmed -> should NOT fire!
        candles[51] = Candle(baseTime + 51 * 60_000L, 103.5, 104.5, 103.5, 104.0, 20.0)

        // Bar 55: rawShort (high < loLine) with close too low? Actually with 6% slDist, if close is very low (< loLine - 6%), shortOK fails,
        // OR test with capital=20, maxLoss=0.5 on bar 55: let's verify exact state transitions!
        val snaps = engine2.evaluateAll(candles)
        assertTrue("Bar 50 should fire LONG", snaps[50].longFire)
        assertFalse("longArmed should become false after firing", snaps[50].longArmedAfter)
        assertFalse("Bar 51 must not fire while disarmed", snaps[51].longFire)
    }

    @Test
    fun riskFilterBlockedSignalDoesNotDisarmAndOppositeRawRearms() {
        // Verify: when rawShort occurs with shortOK=false, shortArmed remains true AND longArmed becomes true
        val cfg = EngineConfig(windowLength = 50, minGap = 10, capitalUsd = 20.0, maxLossUsd = 0.2, takeProfitUsd = 0.5) // slDist = 1%
        val engine = ConfluenceEngine(cfg)
        val baseTime = 1_700_000_000_000L
        val candles = MutableList(65) { idx ->
            Candle(baseTime + idx * 60_000L, 100.0, 101.0, 99.0, 100.0, 10.0)
        }
        candles[5] = candles[5].copy(high = 110.0, low = 90.0)
        candles[40] = candles[40].copy(high = 104.0, low = 96.0)
        candles[41] = candles[41].copy(high = 101.0, low = 99.0)

        // Bar 55: rawShort with high=95 < loLine (~97), close=94 -> close + 1% = 94.94 < hiLine (~102) -> shortOK = FALSE!
        candles[55] = Candle(baseTime + 55 * 60_000L, 95.0, 95.0, 93.5, 94.0, 15.0)

        val snaps = engine.evaluateAll(candles)
        val s55 = snaps[55]
        assertTrue(s55.rawShort)
        assertFalse(s55.shortOk)
        assertFalse(s55.shortFire)
        assertTrue("Blocked short must NOT disarm shortArmed", s55.shortArmedAfter)
        assertTrue("Raw short must keep/re-arm longArmed", s55.longArmedAfter)
    }
}
