package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.TradeDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RunOnModelTest {

    private fun c(i: Int, o: Double, h: Double, l: Double, cl: Double) =
        Candle(1_700_000_000_000L + i * 60_000L, o, h, l, cl, 10.0)

    // LONG entry 100, TP 101 (span 1), SL 99. Candle 0 = entry bar, candle 1 touches TP.
    @Test
    fun replayStopsAtEntryAndMeasuresPeak() {
        val candles = listOf(
            c(0, 100.0, 100.2, 99.9, 100.0),
            c(1, 100.0, 101.1, 100.0, 101.0),   // TP touch
            c(2, 101.0, 101.8, 100.8, 101.5),   // peak 1.8 TP distances
            c(3, 101.5, 101.6, 99.9, 100.0)     // back through entry -> ends, its high is not counted
        )
        val r = RunOnLabeler.replay(candles, 0, 1, TradeDirection.LONG, 100.0, 99.0, 101.0, 60)!!
        assertEquals("ENTRY", r.endReason)
        assertEquals(1.8, r.peakProgress, 1e-9)
        assertEquals(1, r.barsToPeak)
        assertTrue(r.ranFar)
    }

    @Test
    fun replayNotFarWhenPeakBelowOneAndHalf() {
        val candles = listOf(
            c(0, 100.0, 100.2, 99.9, 100.0),
            c(1, 100.0, 101.1, 100.0, 101.0),
            c(2, 101.0, 101.3, 99.8, 100.0)
        )
        val r = RunOnLabeler.replay(candles, 0, 1, TradeDirection.LONG, 100.0, 99.0, 101.0, 60)!!
        assertFalse(r.ranFar)
        assertEquals(1.1, r.peakProgress, 1e-9)
    }

    @Test
    fun replayEndsAtTimeLimit() {
        val candles = ArrayList<Candle>()
        candles.add(c(0, 100.0, 100.2, 99.9, 100.0))
        candles.add(c(1, 100.0, 101.1, 100.0, 101.0))
        for (i in 2..20) candles.add(c(i, 101.0, 101.2, 100.9, 101.1))
        val r = RunOnLabeler.replay(candles, 0, 1, TradeDirection.LONG, 100.0, 99.0, 101.0, 5)!!
        assertEquals("TIME", r.endReason)
        assertEquals(10, r.endIndex) // 2 x 5 bars from entry
    }

    @Test
    fun markerUsesHysteresis() {
        val rule = RunOnCellRule(1, 2, true, 0.70, 0.75, 40, 80, 0.4)
        assertFalse(RunOnTrainer.decideMarker(rule, 0.69, false))
        assertTrue(RunOnTrainer.decideMarker(rule, 0.71, false))
        assertTrue(RunOnTrainer.decideMarker(rule, 0.66, true))   // still above level - 5 points
        assertFalse(RunOnTrainer.decideMarker(rule, 0.64, true))
        assertFalse(RunOnTrainer.decideMarker(rule.copy(enabled = false), 0.99, true))
        assertFalse(RunOnTrainer.decideMarker(null, 0.99, false))
    }

    @Test
    fun noModelMeansNothingShown() {
        assertNotNull(RunOnTrainer.summaryLine(null))
        assertEquals(null, RunOnTrainer.train(emptyList(), 60, 0L))
    }
}
