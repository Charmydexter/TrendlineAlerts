package com.lrmlc.tradingalerts.ml

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.random.Random

class LogisticRegressionAndCheckpointTest {

    @Test
    fun analyticalGradientMatchesFiniteDifferenceCheck() {
        val rng = Random(7)
        val dim = 6
        val samples = List(30) { i ->
            LabeledSample(
                timestampMs = i * 60_000L,
                exitTimeMs = (i + 5) * 60_000L,
                symbol = "SOLUSDT",
                features = DoubleArray(dim) { rng.nextDouble(-2.0, 2.0) },
                label = if (i % 2 == 0) 1 else 0,
                netReturnPct = if (i % 2 == 0) 0.02 else -0.02
            )
        }
        val stats = StandardizationStats.fit(samples.map { it.features }, dim)
        val weights = DoubleArray(dim) { rng.nextDouble(-0.5, 0.5) }
        val bias = 0.15
        val (gradW, gradB) = LogisticRegressionTrainer.computeGradientForTest(samples, stats, weights, bias, l2Lambda = 0.05)

        val eps = 1e-6
        for (j in 0 until dim) {
            val wPlus = weights.copyOf().also { it[j] += eps }
            val wMinus = weights.copyOf().also { it[j] -= eps }
            val lPlus = LogisticRegressionTrainer.computeLossForTest(samples, stats, wPlus, bias, 0.05)
            val lMinus = LogisticRegressionTrainer.computeLossForTest(samples, stats, wMinus, bias, 0.05)
            val numGrad = (lPlus - lMinus) / (2 * eps)
            assertEquals("Gradient mismatch at index $j", numGrad, gradW[j], 1e-6)
        }

        val bPlus = LogisticRegressionTrainer.computeLossForTest(samples, stats, weights, bias + eps, 0.05)
        val bMinus = LogisticRegressionTrainer.computeLossForTest(samples, stats, weights, bias - eps, 0.05)
        val numGradB = (bPlus - bMinus) / (2 * eps)
        assertEquals(numGradB, gradB, 1e-6)
    }

    @Test
    fun convergesOnSyntheticDatasetAndMatchesResumedCheckpointsExactly() {
        val rng = Random(1234)
        val dim = 8
        val samples = List(120) { i ->
            val x = DoubleArray(dim) { rng.nextDouble(-1.5, 1.5) }
            val signalScore = 2.5 * x[0] - 1.8 * x[1] + 0.9 * x[2]
            val label = if (signalScore + rng.nextDouble(-0.2, 0.2) > 0.0) 1 else 0
            LabeledSample(
                timestampMs = i * 60_000L,
                exitTimeMs = (i + 3) * 60_000L,
                symbol = "BTCUSDT",
                features = x,
                label = label,
                netReturnPct = if (label == 1) 0.024 else -0.026
            )
        }
        val stats = StandardizationStats.fit(samples.map { it.features }, dim)
        val params = LogisticHyperParams(epochs = 20, batchSize = 16, learningRate = 0.05, l2Lambda = 0.01)

        // 1. Uninterrupted run
        val checkpoints = ArrayList<TrainingCheckpointState>()
        val fullModel = LogisticRegressionTrainer.trainWithCheckpoints(
            samples = samples,
            stats = stats,
            featureCount = dim,
            params = params,
            seed = 999L,
            onCheckpoint = { checkpoints.add(it) }
        )

        // Verify accuracy > 85% on synthetic separable dataset
        val correct = samples.count { s ->
            val pred = if (fullModel.predictProbability(s.features) >= 0.5) 1 else 0
            pred == s.label
        }
        assertTrue("Expected >85% convergence accuracy, got $correct/${samples.size}", correct >= (samples.size * 0.85).toInt())

        // 2. Simulate interruption at random mid-training checkpoint and resume
        val interruptIndex = checkpoints.size / 3
        val savedState = checkpoints[interruptIndex]

        val resumedModel = LogisticRegressionTrainer.trainWithCheckpoints(
            samples = samples,
            stats = stats,
            featureCount = dim,
            params = params,
            resumeState = savedState,
            seed = 999L
        )

        assertEquals(fullModel.bias, resumedModel.bias, 1e-12)
        for (j in 0 until dim) {
            assertEquals("Resumed weight[$j] must match uninterrupted run", fullModel.weights[j], resumedModel.weights[j], 1e-12)
            assertTrue(abs(fullModel.weights[j] - resumedModel.weights[j]) < 1e-12)
        }
    }
}
