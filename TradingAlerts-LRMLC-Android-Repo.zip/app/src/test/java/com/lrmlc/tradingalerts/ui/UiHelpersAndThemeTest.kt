package com.lrmlc.tradingalerts.ui

import androidx.compose.ui.graphics.toArgb
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.data.model.AccentColor
import com.lrmlc.tradingalerts.ml.CalibrationBucket
import com.lrmlc.tradingalerts.ml.ValidationMetrics
import com.lrmlc.tradingalerts.ui.alerts.formatAlertStatusLabel
import com.lrmlc.tradingalerts.ui.chart.ChartAxis
import com.lrmlc.tradingalerts.ui.home.computeFeedStatus
import com.lrmlc.tradingalerts.ui.home.formatSlTpLine
import com.lrmlc.tradingalerts.ui.home.sortWatchlistByRecentAlert
import com.lrmlc.tradingalerts.ui.insights.InsightsRange
import com.lrmlc.tradingalerts.ui.insights.InsightsStats
import com.lrmlc.tradingalerts.ui.theme.contrastRatio
import com.lrmlc.tradingalerts.ui.theme.paletteFor
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UiHelpersAndThemeTest {

    private fun signal(
        id: String,
        symbol: String,
        accepted: Boolean,
        status: String,
        timeMs: Long,
        exitMs: Long? = null,
        netReturnPct: Double? = null
    ) = SignalCandidateEntity(
        signalId = id,
        exchange = "BYBIT",
        marketType = "PERP",
        symbol = symbol,
        direction = "LONG",
        signalTimeMs = timeMs,
        barIndex = 10,
        entryPrice = 100.0,
        structuralSl = 98.0,
        defaultTp = 102.0,
        appliedSl = 98.0,
        appliedTp = 102.0,
        slAdjustmentNote = null,
        tpAdjustmentNote = null,
        manualOverride = false,
        pWin = 0.68,
        thresholdUsed = 0.60,
        modelWasTrained = true,
        accepted = accepted,
        status = status,
        label = netReturnPct?.let { if (it > 0) 1 else 0 },
        netReturnPct = netReturnPct,
        maePct = null,
        mfePct = null,
        exitTimeMs = exitMs,
        featuresJson = "[]",
        topReasonsJson = "[]"
    )

    @Test
    fun watchlistSortPutsNewestAcceptedAlertsFirstIgnoresShadowsAndKeepsOrder() {
        val watch = listOf(
            WatchlistEntity("BYBIT", "PERP", "BTCUSDT", displayOrder = 0),
            WatchlistEntity("BYBIT", "PERP", "ETHUSDT", displayOrder = 1),
            WatchlistEntity("BYBIT", "PERP", "SOLUSDT", displayOrder = 2),
            WatchlistEntity("BYBIT", "PERP", "XRPUSDT", displayOrder = 3)
        )
        val signals = listOf(
            signal("s1", "SOLUSDT", accepted = true, status = "CLOSED_TP", timeMs = 200L),
            signal("s2", "ETHUSDT", accepted = true, status = "ACTIVE", timeMs = 500L),
            // Shadow signal for XRP at time 999 must NOT promote XRP
            signal("s3", "XRPUSDT", accepted = false, status = "SHADOW_OPEN", timeMs = 999L)
        )

        val sorted = sortWatchlistByRecentAlert(watch, signals)
        assertEquals(listOf("ETHUSDT", "SOLUSDT", "BTCUSDT", "XRPUSDT"), sorted.map { it.symbol })
    }

    @Test
    fun feedStatusAndSlTpLineFormatAllStates() {
        val now = 1_700_000_100_000L
        val empty = listOf(WatchlistEntity("BYBIT", "PERP", "BTCUSDT", displayOrder = 0, lastCandleReceivedMs = 0L))
        assertEquals("No candles yet", computeFeedStatus(empty, now).label)

        val fresh = listOf(
            WatchlistEntity("BYBIT", "PERP", "BTCUSDT", displayOrder = 0, lastCandleReceivedMs = now - 5_000L),
            WatchlistEntity("BYBIT", "PERP", "ETHUSDT", displayOrder = 1, lastCandleReceivedMs = now - 14_000L)
        )
        val freshStatus = computeFeedStatus(fresh, now)
        assertTrue(freshStatus.isOk)
        assertEquals("Feed OK 14s", freshStatus.label)

        val stale = listOf(
            WatchlistEntity("BYBIT", "PERP", "BTCUSDT", displayOrder = 0, lastCandleReceivedMs = now - 5_000L),
            WatchlistEntity("BYBIT", "PERP", "ETHUSDT", displayOrder = 1, lastCandleReceivedMs = now - 150_000L)
        )
        val staleStatus = computeFeedStatus(stale, now)
        assertTrue(staleStatus.isStale)
        assertEquals("Feed stale · 1 of 2", staleStatus.label)

        assertEquals("--", formatSlTpLine(null).combinedText)
        val active = signal("a1", "BTCUSDT", true, "ACTIVE", now)
        val activeDisp = formatSlTpLine(active)
        assertTrue(activeDisp.isActive)
        assertTrue(activeDisp.combinedText.contains("SL"))
        assertTrue(activeDisp.combinedText.contains("TP"))
    }

    @Test
    fun alertStatusLabelMapsAllOutcomesCorrectly() {
        assertEquals("Active", formatAlertStatusLabel(signal("1", "BTCUSDT", true, "ACTIVE", 1L)))
        assertEquals("TP hit +2.40%", formatAlertStatusLabel(signal("2", "BTCUSDT", true, "CLOSED_TP", 1L, 2L, 0.024)))
        assertEquals("SL hit -2.60%", formatAlertStatusLabel(signal("3", "BTCUSDT", true, "CLOSED_SL", 1L, 2L, -0.026)))
        assertEquals("Closed on opposite signal (+0.50%)", formatAlertStatusLabel(signal("4", "BTCUSDT", true, "CLOSED_OPPOSITE", 1L, 2L, 0.005)))
        assertEquals("Closed manually (-0.10%)", formatAlertStatusLabel(signal("5", "BTCUSDT", true, "CLOSED_MANUAL", 1L, 2L, -0.001)))
    }

    @Test
    fun insightsStatsFiltersRangeComputesOutcomesAndHandlesEmptyData() {
        val now = 1_700_000_000_000L
        val signals = listOf(
            signal("1", "BTCUSDT", true, "CLOSED_TP", now - 2 * 3_600_000L, now - 3_600_000L, 0.024),
            signal("2", "ETHUSDT", true, "CLOSED_SL", now - 3 * 3_600_000L, now - 1_800_000L, -0.026),
            signal("3", "SOLUSDT", false, "SHADOW_WIN", now - 3_600_000L, now - 600_000L, 0.024), // shadow ignored
            signal("4", "XRPUSDT", true, "CLOSED_TP", now - 10 * 86_400_000L, now - 10 * 86_400_000L, 0.024) // outside 7d
        )
        val outcomes7d = InsightsStats.buildAlertOutcomes(signals, InsightsRange.D7, now)
        assertEquals(2, outcomes7d.totalCount)
        assertEquals(1, outcomes7d.tpCount)
        assertEquals(1, outcomes7d.slCount)
        assertEquals(listOf(-0.026, -0.002).size, outcomes7d.cumulativeReturnsPct.size)

        val empty = InsightsStats.buildAlertOutcomes(emptyList(), InsightsRange.D7, now)
        assertEquals(0, empty.totalCount)
        assertTrue(InsightsStats.extractCalibrationPoints(null).isEmpty())
        assertFalse(InsightsStats.extractKpis(null).hasMetrics)

        val json = Json { encodeDefaults = true }
        val metrics = ValidationMetrics(
            threshold = 0.60, breakEvenThreshold = 0.52, tradesTaken = 40, totalOutOfSample = 100,
            winRate = 0.58, netExpectancyPct = 0.003, profitFactor = 1.3, maxDrawdownPct = 0.02, brierScore = 0.21,
            baselineExpectancyPct = 0.0, baselineWinRate = 0.50,
            calibrationBuckets = listOf(CalibrationBucket(0.6, 0.7, 25, 0.62, 0.60))
        )
        val logs = listOf(
            TrainingLogEntity(1L, now - 3_600_000L, "BYBIT", "PERP", "MANUAL", true, "ok", json.encodeToString(metrics))
        )
        assertEquals(1, InsightsStats.buildTrainingTrend(logs, InsightsRange.H24, now).size)
        assertEquals(1, InsightsStats.extractCalibrationPoints(metrics).size)
    }

    @Test
    fun chartAxisNiceTicksAndSevenSlotGapMappingAreExact() {
        val ticks = ChartAxis.computeNiceTicks(101.2, 108.7, desiredCount = 5)
        assertTrue(ticks.size >= 3)
        assertTrue(ticks.all { it in 101.2..108.7 })
        assertTrue(ticks.zipWithNext().all { (a, b) -> a < b })

        val plotW = 730f
        val count = 30
        val stepX = ChartAxis.plotStepX(plotW, count)
        val newestCenter = ChartAxis.indexToCenterX(count - 1, stepX)
        // Remaining gap from newest center to right edge of plot equals exactly 7 * stepX
        assertEquals(7f * stepX, plotW - newestCenter, 1e-3f)
        assertEquals(15, ChartAxis.xToBarIndex(ChartAxis.indexToCenterX(5, stepX), 10, 40, stepX))
    }

    @Test
    fun allEightThemeAccentCombinationsMeetWcagContrastRatio() {
        for (dark in listOf(true, false)) {
            for (accent in AccentColor.entries) {
                val scheme = paletteFor(darkTheme = dark, accent = accent)
                assertTrue(
                    "onBackground/background contrast failed for dark=$dark accent=$accent",
                    contrastRatio(scheme.onBackground.toArgb(), scheme.background.toArgb()) >= 4.5
                )
                assertTrue(
                    "onSurface/surface contrast failed for dark=$dark accent=$accent",
                    contrastRatio(scheme.onSurface.toArgb(), scheme.surface.toArgb()) >= 4.5
                )
                assertTrue(
                    "onSurfaceVariant/surfaceVariant contrast failed for dark=$dark accent=$accent",
                    contrastRatio(scheme.onSurfaceVariant.toArgb(), scheme.surfaceVariant.toArgb()) >= 4.5
                )
                assertTrue(
                    "onPrimary/primary contrast failed for dark=$dark accent=$accent",
                    contrastRatio(scheme.onPrimary.toArgb(), scheme.primary.toArgb()) >= 4.5
                )
                assertTrue(
                    "primary/surface contrast failed for dark=$dark accent=$accent",
                    contrastRatio(scheme.primary.toArgb(), scheme.surface.toArgb()) >= 4.5
                )
            }
        }
    }
}
