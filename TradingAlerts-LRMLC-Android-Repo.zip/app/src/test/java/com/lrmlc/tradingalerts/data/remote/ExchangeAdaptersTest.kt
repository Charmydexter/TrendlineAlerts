package com.lrmlc.tradingalerts.data.remote

import com.lrmlc.tradingalerts.data.model.MarketType
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExchangeAdaptersTest {

    private val queue = RestRateLimiterQueue(OkHttpClient())
    private val bybit = BybitAdapter(queue)
    private val binance = BinanceAdapter(queue)

    @Test
    fun bybitKlinesReversesNewestFirstToChronological() {
        val payload = """
            {
              "retCode": 0,
              "retMsg": "OK",
              "result": {
                "list": [
                  ["1700000120000","102.0","103.5","101.5","103.0","500.0","51000"],
                  ["1700000060000","100.0","102.5","99.5","102.0","400.0","40500"]
                ]
              }
            }
        """.trimIndent()
        val candles = bybit.parseKlinesResponse(payload)
        assertEquals(2, candles.size)
        assertEquals(1700000060000L, candles[0].openTimeMs)
        assertEquals(1700000120000L, candles[1].openTimeMs)
        assertEquals(102.0, candles[0].close, 1e-9)
    }

    @Test
    fun bybitWebSocketParsesConfirmFlag() {
        val formingMsg = """
            {"topic":"kline.1.SOLUSDT","data":[{"start":1700000060000,"open":"150.1","high":"151.0","low":"149.9","close":"150.8","volume":"1200","confirm":false}]}
        """.trimIndent()
        val closedMsg = """
            {"topic":"kline.1.SOLUSDT","data":[{"start":1700000060000,"open":"150.1","high":"151.2","low":"149.9","close":"151.0","volume":"1500","confirm":true}]}
        """.trimIndent()
        val u1 = bybit.parseWebSocketMessage(formingMsg)
        val u2 = bybit.parseWebSocketMessage(closedMsg)
        assertEquals(1, u1.size)
        assertFalse(u1[0].isClosed)
        assertEquals("SOLUSDT", u2[0].symbol)
        assertTrue(u2[0].isClosed)
        assertEquals(151.0, u2[0].candle.close, 1e-9)
    }

    @Test
    fun binanceKlinesAndCombinedWebSocketParseCorrectly() {
        val restPayload = """
            [
              [1700000060000,"50.0","51.0","49.5","50.5","100.0",1700000119999,"5050",10,"50","2525","0"],
              [1700000120000,"50.5","52.0","50.2","51.8","150.0",1700000179999,"7700",15,"80","4100","0"]
            ]
        """.trimIndent()
        val candles = binance.parseKlinesResponse(restPayload)
        assertEquals(2, candles.size)
        assertEquals(51.8, candles[1].close, 1e-9)

        val wsPayload = """
            {
              "stream": "solusdt@kline_1m",
              "data": {
                "e": "kline",
                "s": "SOLUSDT",
                "k": {"t": 1700000120000, "o": "150.0", "h": "152.0", "l": "149.5", "c": "151.5", "v": "900.0", "x": true}
              }
            }
        """.trimIndent()
        val updates = binance.parseWebSocketMessage(wsPayload)
        assertEquals(1, updates.size)
        assertEquals("SOLUSDT", updates[0].symbol)
        assertTrue(updates[0].isClosed)
        assertEquals(151.5, updates[0].candle.close, 1e-9)
        assertTrue(binance.buildWebSocketUrl(MarketType.PERP, listOf("SOLUSDT")).startsWith("wss://fstream.binance.com"))
    }

    @Test
    fun malformedWebSocketMessagesNeverCrash() {
        assertTrue(bybit.parseWebSocketMessage("not json at all").isEmpty())
        assertTrue(bybit.parseWebSocketMessage("""{"op":"pong"}""").isEmpty())
        assertTrue(binance.parseWebSocketMessage("{bad").isEmpty())
        assertTrue(binance.parseWebSocketMessage("""{"result":null,"id":1}""").isEmpty())
    }
}
