package com.lrmlc.tradingalerts.data.local

import com.lrmlc.tradingalerts.data.model.Candle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DayChunkAndGapTest {

    @Test
    fun dayChunkEncodeMergeAndDecodePreservesOrderAndPrecision() {
        val dayStart = 20_000L * DayChunkCodec.MILLIS_PER_DAY
        val c1 = Candle(dayStart + 60_000L, 100.1234, 101.5, 99.8, 100.9, 1234.5)
        val c2 = Candle(dayStart + 180_000L, 100.9, 102.0, 100.4, 101.7, 987.25)

        val encoded1 = DayChunkCodec.encodeDay(20_000L, listOf(c2, c1))
        assertEquals(2, encoded1.candleCount)

        // Merge an overlapping bar (updated c1) + new bar c3
        val c1Updated = c1.copy(close = 101.0)
        val c3 = Candle(dayStart + 120_000L, 101.0, 101.2, 100.5, 100.9, 500.0)
        val merged = DayChunkCodec.mergeDay(20_000L, encoded1.blob, listOf(c1Updated, c3))
        assertEquals(3, merged.candleCount)

        val decoded = DayChunkCodec.decodeDay(20_000L, merged.blob)
        assertEquals(listOf(c1Updated, c3, c2), decoded)
    }

    @Test
    fun gapDetectorFindsExactMissingMinuteRanges() {
        val base = 1_700_000_040_000L // aligned to minute
        val candles = listOf(
            Candle(base, 10.0, 11.0, 9.0, 10.5, 1.0),
            Candle(base + 60_000L, 10.5, 11.0, 10.0, 10.8, 1.0),
            // missing minute +2 and +3
            Candle(base + 240_000L, 10.8, 11.2, 10.4, 11.0, 1.0)
            // missing minute +5
        )
        val gaps = GapDetector.findMissingRanges(base, base + 300_000L, candles)
        assertEquals(2, gaps.size)
        assertEquals(base + 120_000L, gaps[0].startOpenTimeMs)
        assertEquals(base + 180_000L, gaps[0].endOpenTimeMs)
        assertEquals(2, gaps[0].expectedBars)
        assertEquals(base + 300_000L, gaps[1].startOpenTimeMs)
        assertEquals(base + 300_000L, gaps[1].endOpenTimeMs)
        assertEquals(1, gaps[1].expectedBars)

        val incompleteDays = GapDetector.findIncompleteOrMissingDays(base, base + 300_000L, mapOf(DayChunkCodec.utcDayIndexOf(base) to 3))
        assertTrue(incompleteDays.isNotEmpty())
    }
}
