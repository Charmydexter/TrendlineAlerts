package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.repository.MasterSlots
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningEnhancerTest {

    private fun candles(n: Int, skipFrom: Int = -1, skipCount: Int = 0): List<Candle> {
        val out = ArrayList<Candle>()
        var t = 1_700_000_000_000L
        for (i in 0 until n) {
            if (i == skipFrom) t += skipCount * 60_000L
            out.add(Candle(t, 100.0, 101.0, 99.0, 100.0 + (i % 7) * 0.1, 10.0))
            t += 60_000L
        }
        return out
    }

    @Test
    fun maskZeroesOnlyDisabledOptionalGroups() {
        val f = DoubleArray(FeatureSpec.FEATURE_COUNT) { 1.0 }
        val m = FeatureSpec.applyMask(f, setOf(FeatureSpec.Group.CORE, FeatureSpec.Group.HTF))
        assertEquals(1.0, m[0], 0.0)
        assertEquals(1.0, m[82], 0.0)
        assertEquals(0.0, m[72], 0.0)
        assertEquals(0.0, m[77], 0.0)
        assertEquals(0.0, m[89], 0.0)
    }

    @Test
    fun recencyWeightHalvesAtHalfLifeAndIsFlatWhenOff() {
        val now = 100L * 86_400_000L
        val w = LearningEnhancer.recencyWeight(now - 14L * 86_400_000L, now, 14)
        assertEquals(0.5, w, 1e-9)
        assertEquals(1.0, LearningEnhancer.recencyWeight(0L, now, 0), 0.0)
        assertTrue(LearningEnhancer.recencyWeight(now - 1L * 86_400_000L, now, 7) > LearningEnhancer.recencyWeight(now - 20L * 86_400_000L, now, 7))
    }

    @Test
    fun gapGuardFlagsMoreThanTwoMissingCandlesOnly() {
        val ok = GapGuard(candles(50, skipFrom = 20, skipCount = 2))
        assertFalse(ok.hasBadGap(0, 49))
        val bad = GapGuard(candles(50, skipFrom = 20, skipCount = 3))
        assertTrue(bad.hasBadGap(0, 49))
        assertFalse(bad.hasBadGap(25, 49))
    }

    @Test
    fun masterSlotsKeepFiveAndEvictOldestRetired() {
        var s = AppSettings()
        var now = 1_000L
        val symbols = listOf("ETHUSDT", "SOLUSDT", "XRPUSDT", "ADAUSDT", "DOGEUSDT")
        var lastEvicted = emptyList<com.lrmlc.tradingalerts.data.model.MasterSlot>()
        for (sym in symbols) {
            now += 1_000L
            val (next, ev) = MasterSlots.switchMaster(s, sym, now, 10)
            s = next
            lastEvicted = ev
        }
        assertEquals(5, s.masterSlots.size)
        assertEquals("DOGEUSDT", s.marketContextAsset)
        // BTC was retired first, so it is the one evicted when the 6th distinct master arrives
        assertTrue(lastEvicted.any { it.symbol == "BTCUSDT" })
        assertEquals(1, s.masterSlots.count { it.retiredAtMs == 0L })
        // Re-selecting a stored master does not evict anything
        val (back, ev2) = MasterSlots.switchMaster(s, "ETHUSDT", now + 5_000L, 3)
        assertTrue(ev2.isEmpty())
        assertEquals("ETHUSDT", back.marketContextAsset)
    }

    @Test
    fun retiredMasterIsPhasedOutGradually() {
        val slot = com.lrmlc.tradingalerts.data.model.MasterSlot("BYBIT", "PERP", "ETHUSDT", retiredAtMs = 0L + 1, retiredDayCount = 28)
        val half = MasterSlots.keepDays(slot, 1 + MasterSlots.PHASE_OUT_MS / 2)
        assertEquals(14, half)
        assertEquals(0, MasterSlots.keepDays(slot, 1 + MasterSlots.PHASE_OUT_MS))
    }
}
