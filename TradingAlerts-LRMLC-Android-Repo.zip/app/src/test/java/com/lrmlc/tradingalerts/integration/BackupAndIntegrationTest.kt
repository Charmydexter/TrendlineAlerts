package com.lrmlc.tradingalerts.integration

import com.lrmlc.tradingalerts.backup.LrmlcBackupEnvelope
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.EngineConfig
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.engine.ConfluenceEngine
import com.lrmlc.tradingalerts.ml.FeatureBuilder
import com.lrmlc.tradingalerts.ml.FeatureSpec
import com.lrmlc.tradingalerts.ml.LabeledSample
import com.lrmlc.tradingalerts.ml.ModelExplainer
import com.lrmlc.tradingalerts.ml.TripleBarrierLabeler
import com.lrmlc.tradingalerts.ml.WalkForwardValidator
import com.lrmlc.tradingalerts.trade.SlTpManager
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import kotlin.math.sin

class BackupAndIntegrationTest {

    @Test
    fun backupEnvelopeGzipRoundTripAndBadFileRejection() {
        val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
        val env = LrmlcBackupEnvelope(
            exportedAtMs = 1_700_000_000_000L,
            includesCandles = false,
            settings = AppSettings(retentionDays = 60),
            watchlist = emptyList(),
            recycleBin = emptyList(),
            models = emptyList(),
            signals = emptyList(),
            trainingLogs = emptyList()
        )
        val out = ByteArrayOutputStream()
        GZIPOutputStream(out).use { it.write(json.encodeToString(env).toByteArray(Charsets.UTF_8)) }

        val restoredBytes = GZIPInputStream(ByteArrayInputStream(out.toByteArray())).readBytes()
        val decoded = json.decodeFromString<LrmlcBackupEnvelope>(restoredBytes.toString(Charsets.UTF_8))
        assertEquals("LRMLC_BACKUP", decoded.magic)
        assertEquals(60, decoded.settings.retentionDays)

        val badResult = runCatching {
            json.decodeFromString<LrmlcBackupEnvelope>("""{"corrupt":true}""")
        }
        assertTrue(badResult.isFailure)
    }

    @Test
    fun fullSyntheticPipelineRunsEndToEnd() {
        val baseTime = 1_700_000_000_000L
        // 1500 synthetic 1m bars with repeating compression channels and crisp breakouts
        val candles = MutableList(1500) { i ->
            val drift = (i / 250) * 0.4
            val phase = i % 100
            val close = when {
                phase in 75..80 -> 104.5 + drift
                phase in 81..86 -> 100.2 + drift
                phase in 87..92 -> 95.5 + drift
                else -> 100.0 + sin(i / 5.0) * 0.4 + drift
            }
            val open = close - 0.1
            val high = close + 0.45
            val low = close - 0.45
            val vol = if (phase in 75..92) 2200.0 + (phase * 30.0) else 900.0 + (i % 13) * 40.0
            Candle(baseTime + i * 60_000L, open, high, low, close, vol)
        }
        // Seed crisp anchors inside the 60-bar window before breakout at phase 75
        for (block in 0 until 14) {
            val base = block * 100
            if (base + 55 < candles.size) {
                candles[base + 20] = candles[base + 20].copy(high = 104.0, low = 96.0)
                candles[base + 45] = candles[base + 45].copy(high = 102.5, low = 97.5)
                candles[base + 46] = candles[base + 46].copy(high = 101.0, low = 99.0)
            }
        }

        val cfg = EngineConfig(
            windowLength = 60,
            minGap = 15,
            capitalUsd = 20.0,
            maxLossUsd = 2.5,
            takeProfitUsd = 0.50,
            labelHorizonBars = 20
        )
        val engine = ConfluenceEngine(cfg)
        val snaps = engine.evaluateAll(candles)

        val samples = ArrayList<LabeledSample>()
        var lastOutcome: Int? = null
        for (i in snaps.indices) {
            val s = snaps[i]
            val dir = s.candidateDirection ?: continue
            val sl = s.structuralSl ?: continue
            val tp = s.defaultTp ?: continue
            val feats = FeatureBuilder.buildFeatures(candles, snaps, i, MarketType.PERP, lastOutcome) ?: continue
            val barrier = TripleBarrierLabeler.labelCandidate(candles, i, dir, s.candle.close, sl, tp, cfg.labelHorizonBars, cfg.roundTripFeeRate)
            val lbl = barrier.label ?: continue
            lastOutcome = lbl
            val exitTime = candles.getOrNull(barrier.exitBarIndex)?.openTimeMs ?: s.candle.openTimeMs
            samples.add(LabeledSample(s.candle.openTimeMs, exitTime, "SOLUSDT", feats, lbl, barrier.netReturnPct, barrier.maePct, barrier.mfePct))
        }

        assertTrue("Expected synthetic dataset to produce candidate signals, got ${samples.size}", samples.size >= 6)

        val (weights, metrics) = WalkForwardValidator.validateAndSelectThreshold(
            chronologicalSamples = samples,
            featureCount = FeatureSpec.FEATURE_COUNT,
            horizonBars = cfg.labelHorizonBars,
            rewardToRisk = cfg.takeProfitUsd / cfg.maxLossUsd
        )
        assertTrue(metrics.threshold >= metrics.breakEvenThreshold)
        val explanation = ModelExplainer.explainValidationInPlainWords(metrics)
        assertTrue(explanation.isNotBlank())

        val winners = samples.filter { it.label == 1 }
        val stats = SlTpManager.computeStatsFromWinningExcursions(winners.map { it.maePct }, winners.map { it.mfePct })
        val lastSample = samples.last()
        val slTp = SlTpManager.resolveLevels(
            direction = com.lrmlc.tradingalerts.data.model.TradeDirection.LONG,
            entryPrice = 100.0,
            structuralSl = 99.0,
            config = cfg,
            stats = stats,
            autoSlEnabled = true,
            autoTpEnabled = true
        )
        assertTrue(slTp.appliedSl <= slTp.structuralSl)
        assertTrue(weights.predictProbability(lastSample.features) in 0.0..1.0)
    }
}
