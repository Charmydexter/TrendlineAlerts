package com.lrmlc.tradingalerts.data.remote

import kotlinx.coroutines.test.runTest
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RestRateLimiterQueueTest {

    @Test
    fun honors429RetryAfterAndSpacingWithoutTightLoop() = runTest {
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(429).addHeader("Retry-After", "1").setBody("rate limited"))
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"ok":true}"""))
        server.start()

        try {
            val sleeps = mutableListOf<Long>()
            var fakeNow = 10_000L
            val queue = RestRateLimiterQueue(
                client = OkHttpClient(),
                minSpacingMs = 350L,
                baseBackoffMs = 500L,
                maxRetries = 2,
                clockMs = { fakeNow },
                sleeper = { ms ->
                    sleeps.add(ms)
                    fakeNow += ms
                }
            )
            val res = queue.get(server.url("/test").toString())
            assertEquals(200, res.code)
            assertEquals("""{"ok":true}""", res.body)
            assertTrue("Expected Retry-After pause >= 1000ms, got $sleeps", sleeps.any { it >= 1000L })
        } finally {
            server.shutdown()
        }
    }

    @Test
    fun classifies451AsBlockedRegionImmediately() = runTest {
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(451).setBody("restricted"))
        server.start()

        try {
            val queue = RestRateLimiterQueue(OkHttpClient(), minSpacingMs = 0L, sleeper = {})
            var caught: ExchangeApiException? = null
            try {
                queue.get(server.url("/restricted").toString())
            } catch (e: ExchangeApiException) {
                caught = e
            }
            assertEquals(NetworkErrorKind.BLOCKED_REGION, caught?.kind)
        } finally {
            server.shutdown()
        }
    }
}
