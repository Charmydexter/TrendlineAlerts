package com.lrmlc.tradingalerts.data.remote

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.InstrumentInfo
import com.lrmlc.tradingalerts.data.model.MarketType
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runTest
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.Executors

class RestRateLimiterQueueTest {

    @Test
    fun honors429RetryAfterAndSpacingWithoutTightLoop() = runTest {
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(429).addHeader("Retry-After", "1").setBody("rate limited"))
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"ok":true}"""))
        server.start()

        try {
            val sleeps = mutableListOf<Long>()
            var fakeNow = 10_000L
            val queue = RestRateLimiterQueue(
                client = OkHttpClient(),
                minSpacingMs = 350L,
                baseBackoffMs = 500L,
                maxRetries = 2,
                clockMs = { fakeNow },
                sleeper = { ms ->
                    sleeps.add(ms)
                    fakeNow += ms
                }
            )
            val res = queue.get(server.url("/test").toString())
            assertEquals(200, res.code)
            assertEquals("""{"ok":true}""", res.body)
            assertTrue("Expected Retry-After pause >= 1000ms, got $sleeps", sleeps.any { it >= 1000L })
        } finally {
            server.shutdown()
        }
    }

    @Test
    fun classifies451AsBlockedRegionImmediately() = runTest {
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(451).setBody("restricted"))
        server.start()

        try {
            val queue = RestRateLimiterQueue(OkHttpClient(), minSpacingMs = 0L, sleeper = {})
            var caught: ExchangeApiException? = null
            try {
                queue.get(server.url("/restricted").toString())
            } catch (e: ExchangeApiException) {
                caught = e
            }
            assertEquals(NetworkErrorKind.BLOCKED_REGION, caught?.kind)
        } finally {
            server.shutdown()
        }
    }

    @Test
    fun executesHttpRequestOnIoDispatcherNotCallerMainThread() {
        val mainExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "test-main-thread") }
        val ioExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "test-io-thread") }
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"ok":true}"""))
        server.start()

        var executionThreadName: String? = null
        val client = OkHttpClient.Builder()
            .addInterceptor { chain ->
                executionThreadName = Thread.currentThread().name
                chain.proceed(chain.request())
            }
            .build()

        try {
            val queue = RestRateLimiterQueue(
                client = client,
                minSpacingMs = 0L,
                sleeper = {},
                ioDispatcher = ioExecutor.asCoroutineDispatcher()
            )
            val payload = runBlocking(mainExecutor.asCoroutineDispatcher()) {
                assertEquals("test-main-thread", Thread.currentThread().name)
                queue.get(server.url("/ping").toString())
            }
            assertEquals(200, payload.code)
            assertEquals("test-io-thread", executionThreadName)
            assertNotEquals("test-main-thread", executionThreadName)
        } finally {
            server.shutdown()
            mainExecutor.shutdownNow()
            ioExecutor.shutdownNow()
        }
    }

    @Test
    fun connectionTesterHandlesNullMessageExceptionsAndPassesRestPlusWebSocket() {
        val mainExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "test-main-thread") }
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"retCode":0,"result":{"timeSecond":"1700000000"}}"""))
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"retCode":0,"result":{"list":[["1700000060000","100","101","99","100.5","10","1005"]]}}"""))
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"retCode":0,"result":{"list":[{"symbol":"BTCUSDT","baseCoin":"BTC","quoteCoin":"USDT","status":"Trading","contractType":"LinearPerpetual","priceFilter":{"tickSize":"0.1"}}]}}"""))
        server.enqueue(MockResponse().withWebSocketUpgrade(object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.close(1000, "ok")
            }
        }))
        server.start()

        try {
            val client = OkHttpClient()
            val queue = RestRateLimiterQueue(client, minSpacingMs = 0L, sleeper = {})
            val baseHttp = server.url("").toString().trimEnd('/')
            val wsUrl = baseHttp.replace("http://", "ws://") + "/ws"
            val adapter = BybitAdapter(
                restQueue = queue,
                restBaseUrl = baseHttp,
                wsSpotBaseUrl = wsUrl,
                wsLinearBaseUrl = wsUrl
            )
            val tester = ConnectionTester(client)

            val report = runBlocking(mainExecutor.asCoroutineDispatcher()) {
                tester.runTest(adapter, MarketType.PERP, "BTCUSDT")
            }
            assertTrue("Expected all 4 connection steps to pass: ${report.steps}", report.allPassed)
            assertEquals(4, report.steps.size)

            val failingAdapter = object : ExchangeAdapter {
                override val exchangeId = ExchangeId.BYBIT
                override val maxPageLimit = 1000
                override val pingIntervalMs = 20_000L
                override suspend fun fetchServerTimeMs(marketType: MarketType): Pair<Long, Long> =
                    throw IllegalStateException() // message is null
                override suspend fun fetchUsdtInstruments(marketType: MarketType): Pair<List<InstrumentInfo>, Long> =
                    emptyList<InstrumentInfo>() to 1L
                override suspend fun fetchKlines1m(marketType: MarketType, symbol: String, limit: Int, endTimeMs: Long?, startTimeMs: Long?): Pair<List<Candle>, Long> =
                    emptyList<Candle>() to 1L
                override suspend fun fetch24hTickers(marketType: MarketType) = emptyMap<String, Ticker24hInfo>()
                override fun buildWebSocketUrl(marketType: MarketType, symbols: List<String>) = wsUrl
                override fun buildSubscribeMessages(marketType: MarketType, symbols: List<String>) = emptyList<String>()
                override fun buildPingMessage(): String? = null
                override fun parseWebSocketMessage(text: String) = emptyList<WebSocketKlineUpdate>()
            }
            val failReport = runBlocking { tester.runTest(failingAdapter, MarketType.PERP) }
            assertFalse(failReport.allPassed)
            assertEquals("IllegalStateException", failReport.steps[0].detail)
        } finally {
            server.shutdown()
            mainExecutor.shutdownNow()
        }
    }
}
