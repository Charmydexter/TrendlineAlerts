package com.lrmlc.tradingalerts.trade

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.EngineConfig
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.InstrumentInfo
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.data.repository.DefaultWatchlistResolver
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.service.PersistentNotificationFormatter
import com.lrmlc.tradingalerts.service.PositionedAssetBannerItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TradeAndNotificationTest {

    @Test
    fun slTpManagerEnforcesMaxLossCapAndStructuralSideAndMinTp() {
        val cfg = EngineConfig(capitalUsd = 20.0, maxLossUsd = 0.50, takeProfitUsd = 0.50)
        // Entry = 100.0 -> maxLossUsd 0.50 on $20 => max SL distance = 2.5% (SL >= 97.5 for LONG)
        // Structural SL = 99.0 (1% below entry)
        // Learned winners dipped 1.8% (80th pct MAE) and gained 4.0% (median MFE)
        val stats = SlTpStatsSummary(winningSampleCount = 20, mae80thPct = 0.018, mfeMedianPct = 0.04)

        val decision = SlTpManager.resolveLevels(
            direction = TradeDirection.LONG,
            entryPrice = 100.0,
            structuralSl = 99.0,
            config = cfg,
            stats = stats,
            autoSlEnabled = true,
            autoTpEnabled = true
        )
        assertTrue(decision.slAdjusted)
        assertEquals(98.2, decision.appliedSl, 1e-6) // widened to 1.8% (within 2.5% max loss cap)
        assertTrue(decision.appliedSl <= decision.structuralSl)
        assertTrue(decision.appliedSl >= 97.5)
        assertTrue(decision.tpAdjusted)
        assertEquals(104.0, decision.appliedTp, 1e-6)

        // If MAE is huge (e.g. 5%), SL MUST still be clamped at 2.5% maxLoss ($0.50)
        val hugeStats = SlTpStatsSummary(winningSampleCount = 20, mae80thPct = 0.05, mfeMedianPct = 0.01)
        val clamped = SlTpManager.resolveLevels(
            direction = TradeDirection.LONG,
            entryPrice = 100.0,
            structuralSl = 99.0,
            config = cfg,
            stats = hugeStats,
            autoSlEnabled = true,
            autoTpEnabled = true
        )
        assertEquals(97.5, clamped.appliedSl, 1e-6)
        assertEquals(102.5, clamped.appliedTp, 1e-6) // never below minimum TP ($0.50 => 2.5%)
    }

    @Test
    fun exitWarningFiresOncePerConditionAndRearmsWhenCleared() {
        val snapBase = ConfluenceBarSnapshot(
            barIndex = 250,
            candle = Candle(1_700_000_000_000L, 100.0, 100.5, 99.5, 100.0, 10.0),
            resistance = null, support = null, resVal = 101.0, supVal = 99.0, basis = 100.0, prevBasis = 100.0,
            hiLine = 101.0, loLine = 99.0, rawLong = false, rawShort = true, slDist = 2.5, tpDist = 2.5,
            longOk = false, shortOk = false, longArmedBefore = true, shortArmedBefore = true,
            longArmedAfter = true, shortArmedAfter = true, longFire = false, shortFire = false,
            candidateDirection = null, structuralSl = null, defaultTp = null,
            resUpdatesLast240 = 0, supUpdatesLast240 = 0, barsSinceLastRawLong = null, barsSinceLastRawShort = null,
            barsSinceLastSignal = null, recentRiskRejectionsLast60 = 0, consecutiveBarsOutside = 1,
            firstOutsideBarSinceResBirth = null, firstOutsideBarSinceSupBirth = null
        )

        // 1) Fires on unconfirmed rawShort for LONG trade
        val trig1 = ExitWarningEvaluator.evaluate(TradeDirection.LONG, snapBase, pReversal = 0.30, exitThreshold = 0.65, prevState = ExitWarningState())
        assertTrue(trig1.shouldWarn)

        // 2) Same condition still active next bar -> does NOT fire duplicate warning
        val trig2 = ExitWarningEvaluator.evaluate(TradeDirection.LONG, snapBase, pReversal = 0.30, exitThreshold = 0.65, prevState = trig1.nextState)
        assertFalse(trig2.shouldWarn)

        // 3) Condition clears -> re-arms
        val clearedSnap = snapBase.copy(rawShort = false)
        val trig3 = ExitWarningEvaluator.evaluate(TradeDirection.LONG, clearedSnap, pReversal = 0.30, exitThreshold = 0.65, prevState = trig2.nextState)
        assertFalse(trig3.shouldWarn)
        assertFalse(trig3.nextState.structureWarningFired)

        // 4) ML reversal triggers cleanly once re-armed
        val trig4 = ExitWarningEvaluator.evaluate(TradeDirection.LONG, clearedSnap, pReversal = 0.72, exitThreshold = 0.65, prevState = trig3.nextState)
        assertTrue(trig4.shouldWarn)
    }

    @Test
    fun persistentNotificationFormatterFormatsNewestFirstWithoutUsdt() {
        val emptyOn = PersistentNotificationFormatter.format(true, emptyList())
        assertTrue(emptyOn.title.contains("Monitoring ON"))
        val emptyOff = PersistentNotificationFormatter.format(false, emptyList())
        assertTrue(emptyOff.title.contains("Monitoring OFF"))

        val items = listOf(
            PositionedAssetBannerItem("WLDUSDT", TradeDirection.LONG, 3.2, 2.9, 100L),
            PositionedAssetBannerItem("HYPEUSDT", TradeDirection.SHORT, 22.0, 24.0, 200L),
            PositionedAssetBannerItem("XRPUSDT", TradeDirection.LONG, 0.65, 0.58, 300L),
            PositionedAssetBannerItem("SOLUSDT", TradeDirection.LONG, 153.95, 147.10, 400L)
        )
        val formatted = PersistentNotificationFormatter.format(true, items)
        assertTrue(formatted.title.contains("SOL"))
        assertTrue(formatted.title.contains("153.95"))
        assertTrue(formatted.title.contains("147.1"))
        assertFalse(formatted.title.contains("USDT"))
        assertEquals("👆 XRP, 👇 HYPE, 👆 WLD", formatted.body)
    }

    @Test
    fun defaultWatchlistResolverSkipsMissingSymbolsWithNote() {
        val available = listOf(
            InstrumentInfo(ExchangeId.BINANCE, MarketType.SPOT, "SOLUSDT", "SOL", "USDT"),
            InstrumentInfo(ExchangeId.BINANCE, MarketType.SPOT, "XRPUSDT", "XRP", "USDT")
            // GRAMUSDT intentionally absent
        )
        val res = DefaultWatchlistResolver.resolve(
            exchange = ExchangeId.BINANCE,
            marketType = MarketType.SPOT,
            availableInstruments = available,
            desiredBases = listOf("SOL", "GRAM", "XRP")
        )
        assertEquals(listOf("SOLUSDT", "XRPUSDT"), res.resolvedSymbols)
        assertEquals(1, res.unavailableNotes.size)
        assertTrue(res.unavailableNotes[0].contains("GRAM"))
        assertTrue(res.unavailableNotes[0].contains("Binance Spot"))
    }
}
