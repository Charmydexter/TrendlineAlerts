package com.lrmlc.tradingalerts.trade

import com.lrmlc.tradingalerts.data.local.ExitCellRuleEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.EngineConfig
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.InstrumentInfo
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.data.repository.DefaultWatchlistResolver
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.service.NotificationHelper
import com.lrmlc.tradingalerts.service.PersistentNotificationFormatter
import com.lrmlc.tradingalerts.service.PositionedAssetBannerItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TradeAndNotificationTest {

    @Test
    fun slTpManagerEnforcesMaxLossCapAndStructuralSideAndMinTp() {
        val cfg = EngineConfig(capitalUsd = 20.0, maxLossUsd = 0.50, takeProfitUsd = 0.50)
        val stats = SlTpStatsSummary(winningSampleCount = 20, mae80thPct = 0.018, mfeMedianPct = 0.04)

        val decision = SlTpManager.resolveLevels(
            direction = TradeDirection.LONG,
            entryPrice = 100.0,
            structuralSl = 99.0,
            config = cfg,
            stats = stats,
            autoSlEnabled = true,
            autoTpEnabled = true
        )
        assertTrue(decision.slAdjusted)
        assertEquals(98.2, decision.appliedSl, 1e-6)
        assertTrue(decision.appliedSl <= decision.structuralSl)
        assertTrue(decision.appliedSl >= 97.5)
        assertTrue(decision.tpAdjusted)
        assertEquals(104.0, decision.appliedTp, 1e-6)

        val hugeStats = SlTpStatsSummary(winningSampleCount = 20, mae80thPct = 0.05, mfeMedianPct = 0.01)
        val clamped = SlTpManager.resolveLevels(
            direction = TradeDirection.LONG,
            entryPrice = 100.0,
            structuralSl = 99.0,
            config = cfg,
            stats = hugeStats,
            autoSlEnabled = true,
            autoTpEnabled = true
        )
        assertEquals(97.5, clamped.appliedSl, 1e-6)
        assertEquals(102.5, clamped.appliedTp, 1e-6)
    }

    @Test
    fun barrierMetricsComputesDerivedPercentagesAndFlagsHighFee() {
        val lowFee = SlTpManager.computeBarrierMetrics(
            capitalUsd = 20.0,
            maxLossUsd = 0.50,
            takeProfitUsd = 0.50,
            roundTripFeeRate = 0.001
        )
        assertEquals(2.5, lowFee.stopDistancePct, 1e-6)
        assertEquals(2.5, lowFee.tpDistancePct, 1e-6)
        assertEquals(4.0, lowFee.feeAsPctOfBarrier, 1e-6)
        assertFalse(lowFee.feeExceeds10Pct)

        val highFee = SlTpManager.computeBarrierMetrics(
            capitalUsd = 100.0,
            maxLossUsd = 0.50,
            takeProfitUsd = 0.50,
            roundTripFeeRate = 0.001
        )
        assertEquals(0.5, highFee.stopDistancePct, 1e-6)
        assertEquals(0.5, highFee.tpDistancePct, 1e-6)
        assertEquals(20.0, highFee.feeAsPctOfBarrier, 1e-6)
        assertTrue(highFee.feeExceeds10Pct)
    }

    @Test
    fun exitWarningFiresOncePerConditionRearmsWhenClearedAndRespectsMaxTwoCap() {
        val snapBase = ConfluenceBarSnapshot(
            barIndex = 250,
            candle = Candle(1_700_000_000_000L, 100.0, 100.5, 99.5, 100.0, 10.0),
            resistance = null, support = null, resVal = 101.0, supVal = 99.0, basis = 100.0, prevBasis = 100.0,
            hiLine = 101.0, loLine = 99.0, rawLong = false, rawShort = true, slDist = 2.5, tpDist = 2.5,
            longOk = false, shortOk = false, longArmedBefore = true, shortArmedBefore = true,
            longArmedAfter = true, shortArmedAfter = true, longFire = false, shortFire = false,
            candidateDirection = null, structuralSl = null, defaultTp = null,
            resUpdatesInWindow = 0, supUpdatesInWindow = 0, barsSinceLastRawLong = null, barsSinceLastRawShort = null,
            barsSinceLastSignal = null, recentRiskRejectionsLast60 = 0, consecutiveBarsOutside = 1,
            firstOutsideBarSinceResBirth = null, firstOutsideBarSinceSupBirth = null
        )
        val enabledRule = ExitCellRuleEntity(
            exchange = "BYBIT",
            marketType = "PERP",
            ageBucket = 2,
            progressBucket = 1,
            mlEnabled = true,
            mlThreshold = 0.65,
            structEnabled = true,
            precision = 0.78,
            warnings = 40,
            avgSavedRisk = 0.4,
            updatedAtMs = 1L
        )

        fun run(rule: ExitCellRuleEntity?, p: Double, snap: ConfluenceBarSnapshot, prev: ExitWarningState, cell: String = "6-10|NEAR") =
            ExitWarningEvaluator.evaluate(
                direction = TradeDirection.LONG,
                snapshot = snap,
                pReversal = p,
                rule = rule,
                cellCode = cell,
                beyondTp = false,
                prevState = prev
            )

        // Silent when no proven rule exists
        assertFalse(run(null, 0.90, snapBase, ExitWarningState()).shouldWarn)

        // Fires on the first candle when persistN = 1
        val trig1 = run(enabledRule, 0.30, snapBase, ExitWarningState())
        assertTrue(trig1.shouldWarn)

        // No repeat while the condition stays on
        val trig2 = run(enabledRule, 0.30, snapBase, trig1.nextState)
        assertFalse(trig2.shouldWarn)

        // Condition gone for 1 candle (= persistN) re-arms; next trigger fires again, no fixed cap
        val clearedSnap = snapBase.copy(rawShort = false)
        val trig3 = run(enabledRule, 0.30, clearedSnap, trig2.nextState)
        assertFalse(trig3.shouldWarn)
        assertFalse(trig3.nextState.disarmed)
        val trig4 = run(enabledRule, 0.72, clearedSnap, trig3.nextState)
        assertTrue(trig4.shouldWarn)
        val trig5 = run(enabledRule, 0.20, clearedSnap, trig4.nextState)
        val trig6 = run(enabledRule, 0.85, clearedSnap, trig5.nextState)
        assertTrue("third warning is allowed (no fixed limit)", trig6.shouldWarn)

        // Needs persistN candles in a row
        val n2 = enabledRule.copy(persistN = 2, structEnabled = false)
        val s1 = run(n2, 0.80, clearedSnap, ExitWarningState())
        assertFalse(s1.shouldWarn)
        val s2 = run(n2, 0.80, clearedSnap, s1.nextState)
        assertTrue(s2.shouldWarn)

        // Moving into a different situation with its own rule may warn while still disarmed
        val moved = run(n2, 0.80, clearedSnap, s2.nextState, cell = "11-20|BEYOND")
        assertTrue(moved.shouldWarn)
    }

    @Test
    fun appSettingsDefaultsPreserveSlTpOffAndExitWarningsOn() {
        val defaults = AppSettings()
        assertFalse(defaults.notifySlHit)
        assertFalse(defaults.notifyTpHit)
        assertTrue(defaults.notifyExitMl)
        assertTrue(defaults.notifyExitStructure)
    }

    @Test
    fun exitNotificationFormatIncludesPhaseMinutesReturnAndProgress() {
        val body = NotificationHelper.formatExitWarningBody(
            direction = TradeDirection.LONG,
            symbol = "BTCUSDT",
            ageMinutes = 3,
            signedProgress = -0.40,
            unrealizedNetPct = -0.0085,
            reason = "Exit model reversal risk 76%"
        )
        assertTrue(body.contains("BTC"))
        assertTrue(body.contains("3 min in"))
        assertTrue(body.contains("40% of the way to SL"))
        assertTrue(body.contains("Reason:"))
    }

    @Test
    fun persistentNotificationFormatterFormatsNewestFirstWithoutUsdt() {
        val emptyOn = PersistentNotificationFormatter.format(true, emptyList())
        assertTrue(emptyOn.title.contains("Monitoring ON"))
        val emptyOff = PersistentNotificationFormatter.format(false, emptyList())
        assertTrue(emptyOff.title.contains("Monitoring OFF"))

        val items = listOf(
            PositionedAssetBannerItem("WLDUSDT", TradeDirection.LONG, 3.2, 2.9, 100L),
            PositionedAssetBannerItem("HYPEUSDT", TradeDirection.SHORT, 22.0, 24.0, 200L),
            PositionedAssetBannerItem("XRPUSDT", TradeDirection.LONG, 0.65, 0.58, 300L),
            PositionedAssetBannerItem("SOLUSDT", TradeDirection.LONG, 153.95, 147.10, 400L)
        )
        val formatted = PersistentNotificationFormatter.format(true, items)
        assertTrue(formatted.title.contains("SOL"))
        assertTrue(formatted.title.contains("153.95"))
        assertTrue(formatted.title.contains("147.1"))
        assertFalse(formatted.title.contains("USDT"))
        assertEquals("👆 XRP, 👇 HYPE, 👆 WLD", formatted.body)
    }

    @Test
    fun defaultWatchlistResolverSkipsMissingSymbolsWithNote() {
        val available = listOf(
            InstrumentInfo(ExchangeId.BINANCE, MarketType.SPOT, "SOLUSDT", "SOL", "USDT"),
            InstrumentInfo(ExchangeId.BINANCE, MarketType.SPOT, "XRPUSDT", "XRP", "USDT")
        )
        val res = DefaultWatchlistResolver.resolve(
            exchange = ExchangeId.BINANCE,
            marketType = MarketType.SPOT,
            availableInstruments = available,
            desiredBases = listOf("SOL", "GRAM", "XRP")
        )
        assertEquals(listOf("SOLUSDT", "XRPUSDT"), res.resolvedSymbols)
        assertEquals(1, res.unavailableNotes.size)
        assertTrue(res.unavailableNotes[0].contains("GRAM"))
        assertTrue(res.unavailableNotes[0].contains("Binance Spot"))
    }
}
