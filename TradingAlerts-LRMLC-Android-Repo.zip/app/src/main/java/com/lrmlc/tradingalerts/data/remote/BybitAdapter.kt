package com.lrmlc.tradingalerts.data.remote

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.InstrumentInfo
import com.lrmlc.tradingalerts.data.model.MarketType
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlin.math.abs

class BybitAdapter(
    private val restQueue: RestRateLimiterQueue,
    private val restBaseUrl: String = "https://api.bybit.com",
    private val wsSpotBaseUrl: String = "wss://stream.bybit.com/v5/public/spot",
    private val wsLinearBaseUrl: String = "wss://stream.bybit.com/v5/public/linear"
) : ExchangeAdapter {

    override val exchangeId: ExchangeId = ExchangeId.BYBIT
    override val maxPageLimit: Int = 1000
    override val pingIntervalMs: Long = 20_000L

    private val json = Json { ignoreUnknownKeys = true }

    private fun category(marketType: MarketType): String =
        if (marketType == MarketType.PERP) "linear" else "spot"

    override suspend fun fetchServerTimeMs(marketType: MarketType): Pair<Long, Long> {
        val resp = restQueue.get("$restBaseUrl/v5/market/time")
        return try {
            val root = json.parseToJsonElement(resp.body).jsonObject
            val retCode = root["retCode"]?.jsonPrimitive?.contentOrNull?.toIntOrNull()
            if (retCode != 0) {
                throw ExchangeApiException(
                    NetworkErrorKind.UPSTREAM_ERROR,
                    message = "Bybit time check error: ${root["retMsg"]?.jsonPrimitive?.contentOrNull ?: retCode}"
                )
            }
            val result = root["result"]?.jsonObject
            val timeSec = result?.get("timeSecond")?.jsonPrimitive?.longOrNull
            val timeNano = result?.get("timeNano")?.jsonPrimitive?.longOrNull
            val serverMs = when {
                timeNano != null -> timeNano / 1_000_000L
                timeSec != null -> timeSec * 1000L
                else -> System.currentTimeMillis()
            }
            serverMs to resp.latencyMs
        } catch (e: ExchangeApiException) {
            throw e
        } catch (e: Exception) {
            throw ExchangeApiException(NetworkErrorKind.MALFORMED_RESPONSE, message = "Invalid Bybit time response")
        }
    }

    override suspend fun fetchUsdtInstruments(marketType: MarketType): Pair<List<InstrumentInfo>, Long> {
        val cat = category(marketType)
        val out = ArrayList<InstrumentInfo>()
        var cursor: String? = null
        var totalLatency = 0L
        var page = 0

        do {
            val url = buildString {
                append("$restBaseUrl/v5/market/instruments-info?category=$cat&limit=1000")
                if (!cursor.isNullOrBlank()) append("&cursor=$cursor")
            }
            val resp = restQueue.get(url)
            totalLatency += resp.latencyMs
            val parsed = parseInstrumentsPage(resp.body, marketType)
            out.addAll(parsed.first)
            cursor = parsed.second
            page++
        } while (!cursor.isNullOrBlank() && page < 10)

        return out to totalLatency
    }

    internal fun parseInstrumentsPage(body: String, marketType: MarketType): Pair<List<InstrumentInfo>, String?> {
        return try {
            val root = json.parseToJsonElement(body).jsonObject
            val retCode = root["retCode"]?.jsonPrimitive?.contentOrNull?.toIntOrNull()
            if (retCode != 0) {
                throw ExchangeApiException(
                    NetworkErrorKind.UPSTREAM_ERROR,
                    message = "Bybit instruments error: ${root["retMsg"]?.jsonPrimitive?.contentOrNull ?: retCode}"
                )
            }
            val result = root["result"]?.jsonObject ?: return emptyList<InstrumentInfo>() to null
            val nextCursor = result["nextPageCursor"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
            val list = result["list"]?.jsonArray ?: return emptyList<InstrumentInfo>() to nextCursor
            val instruments = ArrayList<InstrumentInfo>(list.size)
            for (elem in list) {
                val obj = elem.jsonObject
                val status = obj["status"]?.jsonPrimitive?.contentOrNull ?: ""
                val quoteCoin = obj["quoteCoin"]?.jsonPrimitive?.contentOrNull ?: ""
                val baseCoin = obj["baseCoin"]?.jsonPrimitive?.contentOrNull ?: ""
                val symbol = obj["symbol"]?.jsonPrimitive?.contentOrNull ?: ""
                val contractType = obj["contractType"]?.jsonPrimitive?.contentOrNull
                if (status != "Trading" || quoteCoin != "USDT" || symbol.isBlank() || baseCoin.isBlank()) continue
                if (marketType == MarketType.PERP && contractType != null && contractType != "LinearPerpetual") continue

                val tickStr = obj["priceFilter"]?.jsonObject?.get("tickSize")?.jsonPrimitive?.contentOrNull
                val tick = tickStr?.toDoubleOrNull() ?: 0.0001
                val precision = decimalPlacesFromTick(tickStr)
                instruments.add(
                    InstrumentInfo(
                        exchange = ExchangeId.BYBIT,
                        marketType = marketType,
                        symbol = symbol,
                        baseAsset = baseCoin,
                        quoteAsset = quoteCoin,
                        pricePrecision = precision,
                        tickSize = tick
                    )
                )
            }
            instruments to nextCursor
        } catch (e: ExchangeApiException) {
            throw e
        } catch (e: Exception) {
            throw ExchangeApiException(NetworkErrorKind.MALFORMED_RESPONSE, message = "Malformed Bybit instruments response")
        }
    }

    override suspend fun fetchKlines1m(
        marketType: MarketType,
        symbol: String,
        limit: Int,
        endTimeMs: Long?,
        startTimeMs: Long?
    ): Pair<List<Candle>, Long> {
        val cat = category(marketType)
        val clampedLimit = limit.coerceIn(1, maxPageLimit)
        val url = buildString {
            append("$restBaseUrl/v5/market/kline?category=$cat&symbol=$symbol&interval=1&limit=$clampedLimit")
            if (endTimeMs != null) append("&end=$endTimeMs")
            if (startTimeMs != null) append("&start=$startTimeMs")
        }
        val resp = restQueue.get(url)
        val candles = parseKlinesResponse(resp.body)
        return candles to resp.latencyMs
    }

    internal fun parseKlinesResponse(body: String): List<Candle> {
        return try {
            val root = json.parseToJsonElement(body).jsonObject
            val retCode = root["retCode"]?.jsonPrimitive?.contentOrNull?.toIntOrNull()
            val retMsg = root["retMsg"]?.jsonPrimitive?.contentOrNull.orEmpty()
            if (retCode == 10001) {
                throw ExchangeApiException(NetworkErrorKind.INVALID_SYMBOL, message = "Symbol invalid or not listed: $retMsg")
            }
            if (retCode != 0) {
                throw ExchangeApiException(NetworkErrorKind.UPSTREAM_ERROR, message = "Bybit kline error $retCode: $retMsg")
            }
            val list = root["result"]?.jsonObject?.get("list")?.jsonArray ?: return emptyList()
            val candles = ArrayList<Candle>(list.size)
            for (rowElem in list) {
                val row = rowElem.jsonArray
                if (row.size < 6) continue
                val t = row[0].jsonPrimitive.contentOrNull?.toLongOrNull() ?: continue
                val o = row[1].jsonPrimitive.contentOrNull?.toDoubleOrNull() ?: continue
                val h = row[2].jsonPrimitive.contentOrNull?.toDoubleOrNull() ?: continue
                val l = row[3].jsonPrimitive.contentOrNull?.toDoubleOrNull() ?: continue
                val c = row[4].jsonPrimitive.contentOrNull?.toDoubleOrNull() ?: continue
                val v = row[5].jsonPrimitive.contentOrNull?.toDoubleOrNull() ?: 0.0
                if (o.isFinite() && h.isFinite() && l.isFinite() && c.isFinite() && v.isFinite()) {
                    candles.add(Candle(t, o, h, l, c, v))
                }
            }
            // Bybit returns newest-first -> sort ascending chronologically
            candles.sortBy { it.openTimeMs }
            candles
        } catch (e: ExchangeApiException) {
            throw e
        } catch (e: Exception) {
            throw ExchangeApiException(NetworkErrorKind.MALFORMED_RESPONSE, message = "Malformed Bybit kline payload")
        }
    }

    override suspend fun fetch24hTickers(marketType: MarketType): Map<String, Ticker24hInfo> {
        val cat = category(marketType)
        val resp = restQueue.get("$restBaseUrl/v5/market/tickers?category=$cat")
        return parseTickersResponse(resp.body)
    }

    internal fun parseTickersResponse(body: String): Map<String, Ticker24hInfo> {
        return try {
            val root = json.parseToJsonElement(body).jsonObject
            val retCode = root["retCode"]?.jsonPrimitive?.contentOrNull?.toIntOrNull()
            if (retCode != 0) return emptyMap()
            val list = root["result"]?.jsonObject?.get("list")?.jsonArray ?: return emptyMap()
            val map = HashMap<String, Ticker24hInfo>(list.size)
            for (elem in list) {
                val obj = elem.jsonObject
                val sym = obj["symbol"]?.jsonPrimitive?.contentOrNull ?: continue
                val last = obj["lastPrice"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: continue
                val pcnt = obj["price24hPcnt"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: 0.0
                map[sym] = Ticker24hInfo(sym, last, pcnt * 100.0)
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }

    override fun buildWebSocketUrl(marketType: MarketType, symbols: List<String>): String =
        if (marketType == MarketType.PERP) wsLinearBaseUrl else wsSpotBaseUrl

    override fun buildSubscribeMessages(marketType: MarketType, symbols: List<String>): List<String> {
        // Bybit recommends <= 10 args per subscribe frame
        return symbols
            .distinct()
            .chunked(10)
            .map { chunk ->
                val argsJson = chunk.joinToString(",") { "\"kline.1.$it\"" }
                """{"op":"subscribe","args":[$argsJson]}"""
            }
    }

    override fun buildPingMessage(): String = """{"op":"ping"}"""

    override fun parseWebSocketMessage(text: String): List<WebSocketKlineUpdate> {
        return try {
            val root = json.parseToJsonElement(text).jsonObject
            val topic = root["topic"]?.jsonPrimitive?.contentOrNull ?: return emptyList()
            if (!topic.startsWith("kline.1.")) return emptyList()
            val symbol = topic.removePrefix("kline.1.")
            val dataArr = root["data"]?.jsonArray ?: return emptyList()
            val updates = ArrayList<WebSocketKlineUpdate>(dataArr.size)
            for (elem in dataArr) {
                val obj = elem.jsonObject
                val start = obj["start"]?.jsonPrimitive?.longOrNull
                    ?: obj["start"]?.jsonPrimitive?.contentOrNull?.toLongOrNull()
                    ?: continue
                val o = obj["open"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()
                    ?: obj["open"]?.jsonPrimitive?.doubleOrNull ?: continue
                val h = obj["high"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()
                    ?: obj["high"]?.jsonPrimitive?.doubleOrNull ?: continue
                val l = obj["low"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()
                    ?: obj["low"]?.jsonPrimitive?.doubleOrNull ?: continue
                val c = obj["close"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()
                    ?: obj["close"]?.jsonPrimitive?.doubleOrNull ?: continue
                val v = obj["volume"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()
                    ?: obj["volume"]?.jsonPrimitive?.doubleOrNull ?: 0.0
                val confirm = obj["confirm"]?.jsonPrimitive?.booleanOrNull ?: false
                if (o.isFinite() && h.isFinite() && l.isFinite() && c.isFinite()) {
                    updates.add(
                        WebSocketKlineUpdate(
                            symbol = symbol,
                            candle = Candle(start, o, h, l, c, v),
                            isClosed = confirm
                        )
                    )
                }
            }
            updates
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun decimalPlacesFromTick(tickStr: String?): Int {
        if (tickStr == null || !tickStr.contains('.')) return 2
        val trimmed = tickStr.trimEnd('0')
        val idx = trimmed.indexOf('.')
        return if (idx < 0) 2 else (trimmed.length - idx - 1).coerceIn(1, 8)
    }
}
