package com.lrmlc.tradingalerts.ui

import android.graphics.Paint
import androidx.core.graphics.PaintCompat

/** Blast emoji for the "expects a run past TP" marker, or a plus sign when this phone cannot draw it. */
object RunOnGlyph {
    const val EMOJI = "\uD83D\uDCA5"
    const val FALLBACK = "+"

    @Volatile
    private var cached: String? = null

    fun resolve(): String {
        cached?.let { return it }
        val glyph = runCatching { if (PaintCompat.hasGlyph(Paint(), EMOJI)) EMOJI else FALLBACK }.getOrDefault(FALLBACK)
        cached = glyph
        return glyph
    }
}
