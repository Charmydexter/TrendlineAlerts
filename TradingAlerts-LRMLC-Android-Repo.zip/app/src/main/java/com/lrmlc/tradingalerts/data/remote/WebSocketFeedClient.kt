package com.lrmlc.tradingalerts.data.remote

import com.lrmlc.tradingalerts.data.model.MarketType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import kotlin.random.Random

sealed class WebSocketFeedEvent {
    data object Connected : WebSocketFeedEvent()
    data class ReconnectedAfterDrop(val downtimeMs: Long) : WebSocketFeedEvent()
    data class CandleUpdate(val update: WebSocketKlineUpdate) : WebSocketFeedEvent()
    data class Disconnected(val reason: String) : WebSocketFeedEvent()
}

enum class FeedConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING
}

class WebSocketFeedClient(
    private val okHttpClient: OkHttpClient,
    private val scope: CoroutineScope
) {
    private val _events = MutableSharedFlow<WebSocketFeedEvent>(extraBufferCapacity = 256)
    val events: SharedFlow<WebSocketFeedEvent> = _events.asSharedFlow()

    private val _state = MutableStateFlow(FeedConnectionState.DISCONNECTED)
    val state: StateFlow<FeedConnectionState> = _state.asStateFlow()

    private var activeWebSocket: WebSocket? = null
    private var connectionJob: Job? = null
    private var pingJob: Job? = null
    private var hasConnectedOnce = false
    private var lastDisconnectMs = 0L

    fun start(adapter: ExchangeAdapter, marketType: MarketType, symbols: List<String>) {
        stop()
        if (symbols.isEmpty()) return
        hasConnectedOnce = false
        connectionJob = scope.launch(Dispatchers.IO) {
            var attempt = 0
            while (isActive) {
                _state.value = if (attempt == 0) FeedConnectionState.CONNECTING else FeedConnectionState.RECONNECTING
                val disconnectSignal = kotlinx.coroutines.CompletableDeferred<String>()
                val url = adapter.buildWebSocketUrl(marketType, symbols)
                val req = Request.Builder().url(url).build()

                val ws = okHttpClient.newWebSocket(
                    req,
                    object : WebSocketListener() {
                        override fun onOpen(webSocket: WebSocket, response: Response) {
                            attempt = 0
                            _state.value = FeedConnectionState.CONNECTED
                            val subscribeFrames = adapter.buildSubscribeMessages(marketType, symbols)
                            subscribeFrames.forEach { webSocket.send(it) }

                            pingJob?.cancel()
                            val pingMsg = adapter.buildPingMessage()
                            if (pingMsg != null) {
                                pingJob = scope.launch(Dispatchers.IO) {
                                    while (isActive) {
                                        delay(adapter.pingIntervalMs)
                                        webSocket.send(pingMsg)
                                    }
                                }
                            }

                            if (hasConnectedOnce && lastDisconnectMs > 0L) {
                                _events.tryEmit(
                                    WebSocketFeedEvent.ReconnectedAfterDrop(
                                        (System.currentTimeMillis() - lastDisconnectMs).coerceAtLeast(0L)
                                    )
                                )
                            } else {
                                _events.tryEmit(WebSocketFeedEvent.Connected)
                            }
                            hasConnectedOnce = true
                        }

                        override fun onMessage(webSocket: WebSocket, text: String) {
                            val updates = adapter.parseWebSocketMessage(text)
                            for (u in updates) {
                                _events.tryEmit(WebSocketFeedEvent.CandleUpdate(u))
                            }
                        }

                        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                            pingJob?.cancel()
                            lastDisconnectMs = System.currentTimeMillis()
                            disconnectSignal.complete("Closed ($code): $reason")
                        }

                        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                            pingJob?.cancel()
                            lastDisconnectMs = System.currentTimeMillis()
                            disconnectSignal.complete(t.message ?: "WebSocket failure (HTTP ${response?.code ?: 0})")
                        }
                    }
                )
                activeWebSocket = ws

                val reason = disconnectSignal.await()
                _state.value = FeedConnectionState.RECONNECTING
                _events.tryEmit(WebSocketFeedEvent.Disconnected(reason))

                if (!isActive) break
                val backoffMs = ((2_000L shl attempt.coerceAtMost(5)).coerceAtMost(60_000L)) +
                    Random.nextLong(200L, 1_200L)
                attempt++
                delay(backoffMs)
            }
        }
    }

    fun stop() {
        connectionJob?.cancel()
        connectionJob = null
        pingJob?.cancel()
        pingJob = null
        activeWebSocket?.close(1000, "Client stopped")
        activeWebSocket = null
        _state.value = FeedConnectionState.DISCONNECTED
    }
}
