package com.lrmlc.tradingalerts.data.repository

import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import com.lrmlc.tradingalerts.data.local.GapDetector
import com.lrmlc.tradingalerts.data.local.SettingsRepository
import com.lrmlc.tradingalerts.data.local.SyncProgressDao
import com.lrmlc.tradingalerts.data.local.SyncProgressEntity
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.data.remote.ExchangeAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.ceil

data class DownloadProgressSnapshot(
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val currentSymbol: String? = null,
    val completedAssets: Int = 0,
    val totalAssets: Int = 0,
    val completedPages: Int = 0,
    val totalEstimatedPages: Int = 0,
    val etaSeconds: Long? = null,
    val statusMessage: String = "Idle",
    val lastError: String? = null
) {
    val progressFraction: Float
        get() = if (totalEstimatedPages <= 0) 0f
        else (completedPages.toFloat() / totalEstimatedPages.toFloat()).coerceIn(0f, 1f)
}

class HistorySyncManager(
    private val candleStore: CandleStoreRepository,
    private val syncProgressDao: SyncProgressDao,
    private val settingsRepository: SettingsRepository
) {
    companion object {
        const val FOUR_WEEKS_BARS = 28 * 24 * 60 // 40,320
        const val DEFAULT_WARMUP_BARS = 240
        const val DEFAULT_INITIAL_BARS = FOUR_WEEKS_BARS + DEFAULT_WARMUP_BARS // 40,560 (~41 pages)
    }

    private val _progress = MutableStateFlow(DownloadProgressSnapshot())
    val progress: StateFlow<DownloadProgressSnapshot> = _progress.asStateFlow()

    private val syncMutex = Mutex()
    @Volatile
    private var pauseRequested = false

    fun requestPause() {
        pauseRequested = true
        _progress.value = _progress.value.copy(
            isPaused = true,
            isRunning = false,
            statusMessage = "Download paused"
        )
    }

    /**
     * Downloads 4 weeks + warm-up newest-first backwards, one asset at a time,
     * persisting cursor progress after every 1000-bar page so it survives pause/kill/restart.
     */
    suspend fun syncInitialHistory(
        adapter: ExchangeAdapter,
        marketType: MarketType,
        symbols: List<String>,
        warmupBars: Int = DEFAULT_WARMUP_BARS
    ): Boolean = syncMutex.withLock {
        if (symbols.isEmpty()) {
            _progress.value = DownloadProgressSnapshot(statusMessage = "No assets in watchlist")
            return@withLock true
        }
        pauseRequested = false
        settingsRepository.setDownloadPaused(false)

        val totalBars = FOUR_WEEKS_BARS + warmupBars.coerceAtLeast(240)
        val pagesPerAsset = ceil(totalBars / adapter.maxPageLimit.toDouble()).toInt()
        val totalEstimatedPages = symbols.size * pagesPerAsset
        val nowMs = System.currentTimeMillis()
        val latestClosedMs = GapDetector.latestClosedMinuteOpenMs(nowMs)
        val targetStartMs = latestClosedMs - (totalBars.toLong() - 1L) * DayChunkCodec.MILLIS_PER_MINUTE

        var completedPages = 0
        var completedAssets = 0
        val startElapsedMs = System.currentTimeMillis()

        // Count already completed pages from persisted sync cursors
        val savedMap = symbols.associateWith { sym ->
            syncProgressDao.get(adapter.exchangeId.name, marketType.name, sym)
        }
        for (sym in symbols) {
            val saved = savedMap[sym]
            if (saved != null) {
                if (saved.completed) {
                    completedAssets++
                    completedPages += pagesPerAsset
                } else {
                    completedPages += saved.pagesFetched.coerceAtMost(pagesPerAsset)
                }
            }
        }

        _progress.value = DownloadProgressSnapshot(
            isRunning = true,
            isPaused = false,
            currentSymbol = symbols.firstOrNull()?.stripUsdtSuffix(),
            completedAssets = completedAssets,
            totalAssets = symbols.size,
            completedPages = completedPages,
            totalEstimatedPages = totalEstimatedPages,
            statusMessage = "Starting 4-week history sync..."
        )

        try {
            for (symbol in symbols) {
                if (pauseRequested) {
                    _progress.value = _progress.value.copy(
                        isRunning = false,
                        isPaused = true,
                        statusMessage = "Paused at ${symbol.stripUsdtSuffix()}"
                    )
                    return@withLock false
                }

                val existing = syncProgressDao.get(adapter.exchangeId.name, marketType.name, symbol)
                if (existing != null && existing.completed && existing.targetStartMs <= targetStartMs + DayChunkCodec.MILLIS_PER_DAY) {
                    // Already has 4-week base; fill only recent gap up to latestClosedMs
                    fillMissingGapsForAsset(adapter, marketType, symbol, existing.targetStartMs, latestClosedMs)
                    continue
                }

                var endCursorMs = if (existing != null && !existing.completed && existing.oldestFetchedMs > targetStartMs) {
                    existing.oldestFetchedMs - DayChunkCodec.MILLIS_PER_MINUTE
                } else {
                    latestClosedMs
                }
                var pagesForSymbol = existing?.pagesFetched ?: 0
                val effectiveTargetStart = existing?.targetStartMs?.coerceAtMost(targetStartMs) ?: targetStartMs

                while (endCursorMs >= effectiveTargetStart) {
                    if (pauseRequested) {
                        _progress.value = _progress.value.copy(
                            isRunning = false,
                            isPaused = true,
                            statusMessage = "Paused at ${symbol.stripUsdtSuffix()}"
                        )
                        return@withLock false
                    }

                    val (pageCandles, _) = adapter.fetchKlines1m(
                        marketType = marketType,
                        symbol = symbol,
                        limit = adapter.maxPageLimit,
                        endTimeMs = endCursorMs
                    )

                    if (pageCandles.isEmpty()) {
                        // Asset may have listed more recently than 4 weeks ago
                        syncProgressDao.upsert(
                            SyncProgressEntity(
                                exchange = adapter.exchangeId.name,
                                marketType = marketType.name,
                                symbol = symbol,
                                targetStartMs = effectiveTargetStart,
                                oldestFetchedMs = endCursorMs,
                                pagesFetched = pagesForSymbol,
                                completed = true,
                                lastError = null,
                                updatedAtMs = System.currentTimeMillis()
                            )
                        )
                        break
                    }

                    val closedCandles = pageCandles.filter { it.openTimeMs <= latestClosedMs }
                    if (closedCandles.isNotEmpty()) {
                        candleStore.appendCandles(adapter.exchangeId, marketType, symbol, closedCandles)
                    }

                    val oldestInPage = pageCandles.minOf { it.openTimeMs }
                    pagesForSymbol++
                    completedPages = (completedPages + 1).coerceAtMost(totalEstimatedPages)

                    val doneForSymbol = oldestInPage <= effectiveTargetStart || pageCandles.size < adapter.maxPageLimit / 2
                    syncProgressDao.upsert(
                        SyncProgressEntity(
                            exchange = adapter.exchangeId.name,
                            marketType = marketType.name,
                            symbol = symbol,
                            targetStartMs = effectiveTargetStart,
                            oldestFetchedMs = oldestInPage,
                            pagesFetched = pagesForSymbol,
                            completed = doneForSymbol,
                            lastError = null,
                            updatedAtMs = System.currentTimeMillis()
                        )
                    )

                    val elapsedMs = (System.currentTimeMillis() - startElapsedMs).coerceAtLeast(1L)
                    val remainingPages = (totalEstimatedPages - completedPages).coerceAtLeast(0)
                    val avgMsPerPage = if (completedPages > 0) elapsedMs.toDouble() / completedPages else 450.0
                    val etaSec = ((remainingPages * avgMsPerPage) / 1000.0).toLong()

                    _progress.value = DownloadProgressSnapshot(
                        isRunning = true,
                        isPaused = false,
                        currentSymbol = symbol.stripUsdtSuffix(),
                        completedAssets = completedAssets,
                        totalAssets = symbols.size,
                        completedPages = completedPages,
                        totalEstimatedPages = totalEstimatedPages,
                        etaSeconds = etaSec,
                        statusMessage = "Downloading ${symbol.stripUsdtSuffix()} (page $pagesForSymbol)"
                    )

                    if (doneForSymbol || oldestInPage >= endCursorMs) {
                        break
                    }
                    endCursorMs = oldestInPage - DayChunkCodec.MILLIS_PER_MINUTE
                }

                // Also fill any recent tail gap that elapsed while downloading earlier symbols
                fillMissingGapsForAsset(adapter, marketType, symbol, effectiveTargetStart, latestClosedMs)
                completedAssets++
            }

            _progress.value = DownloadProgressSnapshot(
                isRunning = false,
                isPaused = false,
                currentSymbol = null,
                completedAssets = symbols.size,
                totalAssets = symbols.size,
                completedPages = totalEstimatedPages,
                totalEstimatedPages = totalEstimatedPages,
                etaSeconds = 0L,
                statusMessage = "All ${symbols.size} assets synced"
            )
            true
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            _progress.value = _progress.value.copy(
                isRunning = false,
                lastError = e.message ?: "Download interrupted",
                statusMessage = "Download error: ${e.message ?: "retry available"}"
            )
            false
        }
    }

    /**
     * Fetches only missed minute ranges for each watchlist symbol (e.g. on reconnect or app start).
     */
    suspend fun fillGapsForWatchlist(
        adapter: ExchangeAdapter,
        marketType: MarketType,
        symbols: List<String>,
        lookbackDays: Int = 7
    ) = syncMutex.withLock {
        if (symbols.isEmpty()) return@withLock
        val nowMs = System.currentTimeMillis()
        val latestClosedMs = GapDetector.latestClosedMinuteOpenMs(nowMs)
        val lookbackStartMs = latestClosedMs - lookbackDays.toLong() * DayChunkCodec.MILLIS_PER_DAY
        for (sym in symbols) {
            fillMissingGapsForAsset(adapter, marketType, sym, lookbackStartMs, latestClosedMs)
        }
    }

    suspend fun fillMissingGapsForAsset(
        adapter: ExchangeAdapter,
        marketType: MarketType,
        symbol: String,
        startOpenTimeMs: Long,
        endOpenTimeMs: Long
    ) {
        val gaps = candleStore.detectGaps(adapter.exchangeId, marketType, symbol, startOpenTimeMs, endOpenTimeMs)
        if (gaps.isEmpty()) return

        for (gap in gaps) {
            var cursorEnd = gap.endOpenTimeMs
            var safety = 0
            while (cursorEnd >= gap.startOpenTimeMs && safety < 60) {
                safety++
                val (candles, _) = adapter.fetchKlines1m(
                    marketType = marketType,
                    symbol = symbol,
                    limit = adapter.maxPageLimit,
                    endTimeMs = cursorEnd
                )
                if (candles.isEmpty()) break
                val bounded = candles.filter { it.openTimeMs in gap.startOpenTimeMs..gap.endOpenTimeMs }
                if (bounded.isNotEmpty()) {
                    candleStore.appendCandles(adapter.exchangeId, marketType, symbol, bounded)
                }
                val oldest = candles.minOf { it.openTimeMs }
                if (oldest <= gap.startOpenTimeMs || oldest >= cursorEnd || candles.size < adapter.maxPageLimit / 2) {
                    break
                }
                cursorEnd = oldest - DayChunkCodec.MILLIS_PER_MINUTE
            }
        }
    }
}
