package com.lrmlc.tradingalerts.ml

import kotlinx.serialization.Serializable
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

@Serializable
data class StandardizationStats(
    val means: DoubleArray,
    val stds: DoubleArray
) {
    fun transform(raw: DoubleArray): DoubleArray {
        // Tolerates older stats that are shorter than a newer feature vector: extra features stay neutral (0).
        val out = DoubleArray(raw.size)
        val n = minOf(raw.size, means.size, stds.size)
        for (i in 0 until n) {
            val s = stds[i]
            out[i] = if (s > 1e-9) ((raw[i] - means[i]) / s).coerceIn(-8.0, 8.0) else 0.0
        }
        return out
    }

    companion object {
        fun fit(samples: List<DoubleArray>, featureCount: Int): StandardizationStats {
            val means = DoubleArray(featureCount)
            val stds = DoubleArray(featureCount) { 1.0 }
            if (samples.isEmpty()) return StandardizationStats(means, stds)

            val n = samples.size.toDouble()
            for (x in samples) {
                for (j in 0 until featureCount) {
                    means[j] += x[j]
                }
            }
            for (j in 0 until featureCount) means[j] /= n

            for (x in samples) {
                for (j in 0 until featureCount) {
                    val d = x[j] - means[j]
                    stds[j] += d * d
                }
            }
            for (j in 0 until featureCount) {
                // subtract initial 1.0 placeholder
                val variance = (stds[j] - 1.0) / n.coerceAtLeast(1.0)
                stds[j] = if (variance > 1e-12) sqrt(variance) else 1.0
            }
            return StandardizationStats(means, stds)
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is StandardizationStats) return false
        return means.contentEquals(other.means) && stds.contentEquals(other.stds)
    }

    override fun hashCode(): Int = 31 * means.contentHashCode() + stds.contentHashCode()
}

@Serializable
data class IsotonicCalibrator(
    val binUpperBounds: DoubleArray,
    val calibratedValues: DoubleArray
) {
    fun calibrate(rawProb: Double): Double {
        if (binUpperBounds.isEmpty() || calibratedValues.isEmpty()) return rawProb.coerceIn(0.0, 1.0)
        val p = rawProb.coerceIn(0.0, 1.0)
        for (i in binUpperBounds.indices) {
            if (p <= binUpperBounds[i]) {
                return calibratedValues[i].coerceIn(0.0, 1.0)
            }
        }
        return calibratedValues.last().coerceIn(0.0, 1.0)
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is IsotonicCalibrator) return false
        return binUpperBounds.contentEquals(other.binUpperBounds) &&
            calibratedValues.contentEquals(other.calibratedValues)
    }

    override fun hashCode(): Int =
        31 * binUpperBounds.contentHashCode() + calibratedValues.contentHashCode()

    companion object {
        private data class PavBlock(
            var sumY: Double,
            var count: Int,
            var minX: Double,
            var maxX: Double
        ) {
            val mean: Double get() = sumY / count.coerceAtLeast(1)
        }

        fun fitPoolAdjacentViolators(predictions: List<Pair<Double, Int>>): IsotonicCalibrator? {
            if (predictions.size < 10) return null
            val sorted = predictions.sortedBy { it.first }
            val blocks = ArrayList<PavBlock>(sorted.size)
            for ((x, y) in sorted) {
                blocks.add(PavBlock(y.toDouble(), 1, x, x))
                while (blocks.size >= 2) {
                    val last = blocks[blocks.lastIndex]
                    val prev = blocks[blocks.lastIndex - 1]
                    if (prev.mean >= last.mean) {
                        prev.sumY += last.sumY
                        prev.count += last.count
                        prev.maxX = maxOf(prev.maxX, last.maxX)
                        blocks.removeAt(blocks.lastIndex)
                    } else {
                        break
                    }
                }
            }
            if (blocks.isEmpty()) return null
            val uppers = DoubleArray(blocks.size)
            val vals = DoubleArray(blocks.size)
            for (i in blocks.indices) {
                uppers[i] = if (i == blocks.lastIndex) {
                    1.0
                } else {
                    0.5 * (blocks[i].maxX + blocks[i + 1].minX)
                }
                vals[i] = blocks[i].mean.coerceIn(0.001, 0.999)
            }
            return IsotonicCalibrator(uppers, vals)
        }
    }
}

@Serializable
data class LogisticRegressionWeights(
    val weights: DoubleArray,
    val bias: Double,
    val stats: StandardizationStats,
    val calibrator: IsotonicCalibrator? = null
) {
    fun predictRawProbability(rawFeatures: DoubleArray): Double {
        val z = stats.transform(rawFeatures)
        var logit = bias
        val n = minOf(weights.size, z.size)
        for (i in 0 until n) {
            logit += weights[i] * z[i]
        }
        return sigmoid(logit)
    }

    fun predictProbability(rawFeatures: DoubleArray): Double {
        val raw = predictRawProbability(rawFeatures)
        return calibrator?.calibrate(raw) ?: raw
    }

    fun explainTopDrivers(rawFeatures: DoubleArray, topK: Int = 3): List<FeatureContribution> {
        val z = stats.transform(rawFeatures)
        return weights.indices
            .map { idx ->
                val contrib = weights[idx] * z[idx]
                FeatureContribution(
                    featureIndex = idx,
                    standardizedValue = z[idx],
                    weight = weights[idx],
                    contribution = contrib
                )
            }
            .sortedByDescending { kotlin.math.abs(it.contribution) }
            .take(topK)
    }

    companion object {
        fun sigmoid(x: Double): Double {
            val clamped = x.coerceIn(-30.0, 30.0)
            return 1.0 / (1.0 + exp(-clamped))
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is LogisticRegressionWeights) return false
        return weights.contentEquals(other.weights) &&
            bias == other.bias &&
            stats == other.stats &&
            calibrator == other.calibrator
    }

    override fun hashCode(): Int {
        var result = weights.contentHashCode()
        result = 31 * result + bias.hashCode()
        result = 31 * result + stats.hashCode()
        result = 31 * result + (calibrator?.hashCode() ?: 0)
        return result
    }
}

@Serializable
data class FeatureContribution(
    val featureIndex: Int,
    val standardizedValue: Double,
    val weight: Double,
    val contribution: Double
)

data class LabeledSample(
    val timestampMs: Long,
    val exitTimeMs: Long,
    val symbol: String,
    val features: DoubleArray,
    val label: Int, // 0 or 1
    val netReturnPct: Double,
    val maePct: Double = 0.0,
    val mfePct: Double = 0.0,
    val sampleWeight: Double = 1.0,
    /** Recency decay x real-trade multiplier. Combined with the overlap weight by [OverlapWeightCalculator]. */
    val baseWeight: Double = 1.0,
    /** True for the user's own / other finished real trades (they carry double weight). */
    val isReal: Boolean = false
)

@Serializable
data class TrainingCheckpointState(
    val epoch: Int = 0,
    val batchIndex: Int = 0,
    val seed: Long = 42L,
    val shuffledOrder: IntArray = intArrayOf(),
    val weights: DoubleArray = doubleArrayOf(),
    val bias: Double = 0.0,
    val mWeights: DoubleArray = doubleArrayOf(),
    val vWeights: DoubleArray = doubleArrayOf(),
    val mBias: Double = 0.0,
    val vBias: Double = 0.0,
    val adamStep: Int = 0
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is TrainingCheckpointState) return false
        return epoch == other.epoch &&
            batchIndex == other.batchIndex &&
            seed == other.seed &&
            adamStep == other.adamStep &&
            bias == other.bias &&
            weights.contentEquals(other.weights)
    }

    override fun hashCode(): Int = 31 * epoch + batchIndex + adamStep
}

data class LogisticHyperParams(
    val epochs: Int = 25,
    val batchSize: Int = 32,
    val learningRate: Double = 0.03,
    val l2Lambda: Double = 0.02,
    val priorLambda: Double = 0.05,
    val beta1: Double = 0.9,
    val beta2: Double = 0.999,
    val adamEps: Double = 1e-8
)

object OverlapWeightCalculator {
    /**
     * Reduces the sample weight of overlapping trades on the same symbol or across watchlist.
     * Each sample gets weight 1 / concurrency, normalized so average weight is 1.0.
     */
    fun assignOverlapWeights(samples: List<LabeledSample>): List<LabeledSample> {
        if (samples.isEmpty()) return emptyList()
        val rawWeights = DoubleArray(samples.size)
        var sum = 0.0
        for (i in samples.indices) {
            val s = samples[i]
            var overlap = 0
            for (j in samples.indices) {
                val other = samples[j]
                if (other.timestampMs <= s.exitTimeMs && other.exitTimeMs >= s.timestampMs) {
                    overlap++
                }
            }
            val w = s.baseWeight.coerceAtLeast(1e-6) / overlap.coerceAtLeast(1).toDouble()
            rawWeights[i] = w
            sum += w
        }
        val mean = (sum / samples.size).coerceAtLeast(1e-9)
        return samples.mapIndexed { idx, s ->
            s.copy(sampleWeight = rawWeights[idx] / mean)
        }
    }
}

/**
 * Pure Kotlin L2-regularized Logistic Regression with Adam optimizer,
 * class balancing, overlap weights, optional hierarchical prior weights,
 * and deterministic batch-level checkpoint/resume support.
 */
object LogisticRegressionTrainer {

    fun trainWithCheckpoints(
        samples: List<LabeledSample>,
        stats: StandardizationStats,
        featureCount: Int,
        params: LogisticHyperParams = LogisticHyperParams(),
        priorWeights: DoubleArray? = null,
        initialWeights: LogisticRegressionWeights? = null,
        resumeState: TrainingCheckpointState? = null,
        seed: Long = 1337L,
        onCheckpoint: (TrainingCheckpointState) -> Unit = {}
    ): LogisticRegressionWeights {
        if (samples.isEmpty()) {
            return LogisticRegressionWeights(DoubleArray(featureCount), 0.0, stats)
        }

        // Compute class balance multipliers
        val posWeightSum = samples.filter { it.label == 1 }.sumOf { it.sampleWeight }.coerceAtLeast(1e-6)
        val negWeightSum = samples.filter { it.label == 0 }.sumOf { it.sampleWeight }.coerceAtLeast(1e-6)
        val totalW = posWeightSum + negWeightSum
        val posScale = totalW / (2.0 * posWeightSum)
        val negScale = totalW / (2.0 * negWeightSum)

        val standardized = Array(samples.size) { i -> stats.transform(samples[i].features) }

        var weights = resumeState?.weights?.takeIf { it.size == featureCount }?.copyOf()
            ?: initialWeights?.weights?.takeIf { it.size == featureCount }?.copyOf()
            ?: DoubleArray(featureCount)
        var bias = resumeState?.bias ?: initialWeights?.bias ?: 0.0

        var mW = resumeState?.mWeights?.takeIf { it.size == featureCount }?.copyOf() ?: DoubleArray(featureCount)
        var vW = resumeState?.vWeights?.takeIf { it.size == featureCount }?.copyOf() ?: DoubleArray(featureCount)
        var mB = resumeState?.mBias ?: 0.0
        var vB = resumeState?.vBias ?: 0.0
        var adamStep = resumeState?.adamStep ?: 0

        val startEpoch = resumeState?.epoch ?: 0
        val batchSize = params.batchSize.coerceIn(1, samples.size)
        val numBatches = (samples.size + batchSize - 1) / batchSize

        for (epoch in startEpoch until params.epochs) {
            val order = if (epoch == startEpoch && resumeState != null && resumeState.shuffledOrder.size == samples.size) {
                resumeState.shuffledOrder.copyOf()
            } else {
                deterministicShuffle(samples.size, seed + epoch * 7919L)
            }
            val startBatch = if (epoch == startEpoch && resumeState != null) resumeState.batchIndex else 0

            for (batchIdx in startBatch until numBatches) {
                val from = batchIdx * batchSize
                val to = min(samples.size, from + batchSize)
                val count = (to - from).toDouble().coerceAtLeast(1.0)

                val gradW = DoubleArray(featureCount)
                var gradB = 0.0

                for (pos in from until to) {
                    val idx = order[pos]
                    val x = standardized[idx]
                    val s = samples[idx]
                    val y = s.label.toDouble()
                    val cw = s.sampleWeight * (if (s.label == 1) posScale else negScale)

                    var z = bias
                    for (j in 0 until featureCount) {
                        z += weights[j] * x[j]
                    }
                    val p = LogisticRegressionWeights.sigmoid(z)
                    val err = (p - y) * cw
                    gradB += err
                    for (j in 0 until featureCount) {
                        gradW[j] += err * x[j]
                    }
                }

                gradB /= count
                for (j in 0 until featureCount) {
                    var reg = params.l2Lambda * weights[j]
                    if (priorWeights != null && j < priorWeights.size) {
                        reg += params.priorLambda * (weights[j] - priorWeights[j])
                    }
                    gradW[j] = (gradW[j] / count) + reg
                }

                adamStep++
                val b1Corr = 1.0 - powInt(params.beta1, adamStep)
                val b2Corr = 1.0 - powInt(params.beta2, adamStep)

                // Update bias
                mB = params.beta1 * mB + (1.0 - params.beta1) * gradB
                vB = params.beta2 * vB + (1.0 - params.beta2) * gradB * gradB
                val mBHat = mB / b1Corr
                val vBHat = vB / b2Corr
                bias -= params.learningRate * mBHat / (sqrt(vBHat) + params.adamEps)

                // Update weights
                for (j in 0 until featureCount) {
                    val g = gradW[j]
                    mW[j] = params.beta1 * mW[j] + (1.0 - params.beta1) * g
                    vW[j] = params.beta2 * vW[j] + (1.0 - params.beta2) * g * g
                    val mHat = mW[j] / b1Corr
                    val vHat = vW[j] / b2Corr
                    weights[j] -= params.learningRate * mHat / (sqrt(vHat) + params.adamEps)
                }

                // Checkpoint after each batch so interruption at any point resumes deterministically
                val nextBatch = batchIdx + 1
                val ckptEpoch = if (nextBatch >= numBatches) epoch + 1 else epoch
                val ckptBatch = if (nextBatch >= numBatches) 0 else nextBatch
                val ckptOrder = if (nextBatch >= numBatches) intArrayOf() else order
                onCheckpoint(
                    TrainingCheckpointState(
                        epoch = ckptEpoch,
                        batchIndex = ckptBatch,
                        seed = seed,
                        shuffledOrder = ckptOrder,
                        weights = weights.copyOf(),
                        bias = bias,
                        mWeights = mW.copyOf(),
                        vWeights = vW.copyOf(),
                        mBias = mB,
                        vBias = vB,
                        adamStep = adamStep
                    )
                )
            }
        }

        return LogisticRegressionWeights(weights, bias, stats)
    }

    fun computeGradientForTest(
        samples: List<LabeledSample>,
        stats: StandardizationStats,
        weights: DoubleArray,
        bias: Double,
        l2Lambda: Double = 0.02
    ): Pair<DoubleArray, Double> {
        val featureCount = weights.size
        val gradW = DoubleArray(featureCount)
        var gradB = 0.0
        val n = samples.size.toDouble().coerceAtLeast(1.0)
        for (s in samples) {
            val x = stats.transform(s.features)
            var z = bias
            for (j in 0 until featureCount) z += weights[j] * x[j]
            val p = LogisticRegressionWeights.sigmoid(z)
            val err = (p - s.label.toDouble()) * s.sampleWeight
            gradB += err
            for (j in 0 until featureCount) gradW[j] += err * x[j]
        }
        gradB /= n
        for (j in 0 until featureCount) {
            gradW[j] = (gradW[j] / n) + l2Lambda * weights[j]
        }
        return gradW to gradB
    }

    fun computeLossForTest(
        samples: List<LabeledSample>,
        stats: StandardizationStats,
        weights: DoubleArray,
        bias: Double,
        l2Lambda: Double = 0.02
    ): Double {
        val n = samples.size.toDouble().coerceAtLeast(1.0)
        var loss = 0.0
        for (s in samples) {
            val x = stats.transform(s.features)
            var z = bias
            for (j in weights.indices) z += weights[j] * x[j]
            val p = LogisticRegressionWeights.sigmoid(z).coerceIn(1e-12, 1.0 - 1e-12)
            val y = s.label.toDouble()
            loss += -(y * ln(p) + (1.0 - y) * ln(1.0 - p)) * s.sampleWeight
        }
        loss /= n
        var reg = 0.0
        for (w in weights) reg += w * w
        return loss + 0.5 * l2Lambda * reg
    }

    private fun deterministicShuffle(n: Int, seed: Long): IntArray {
        val arr = IntArray(n) { it }
        val rng = Random(seed)
        for (i in n - 1 downTo 1) {
            val j = rng.nextInt(i + 1)
            val tmp = arr[i]
            arr[i] = arr[j]
            arr[j] = tmp
        }
        return arr
    }

    private fun powInt(base: Double, exp: Int): Double {
        var result = 1.0
        var b = base
        var e = exp
        while (e > 0) {
            if ((e and 1) == 1) result *= b
            b *= b
            e = e ushr 1
        }
        return result
    }
}
