package com.lrmlc.tradingalerts.ui.alerts

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.RangePresets
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.service.PersistentNotificationFormatter
import com.lrmlc.tradingalerts.ui.home.formatCompactAge
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import com.lrmlc.tradingalerts.ui.theme.LrmlcShapes
import com.lrmlc.tradingalerts.ui.theme.cardBorderStroke
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class AlertFilter(val label: String) {
    ALL("All"),
    ACTIVE("Active"),
    CLOSED("Closed")
}

fun formatAlertStatusLabel(signal: SignalCandidateEntity): String {
    val pctStr = signal.netReturnPct?.let { String.format(Locale.US, "%+.2f%%", it * 100.0) }
    return when (signal.status) {
        "ACTIVE" -> when {
            signal.tpReachedTimeMs != null -> "Active - TP reached"
            signal.slReachedTimeMs != null -> "Active - SL reached"
            else -> "Active"
        }
        "CLOSED_TP" -> if (pctStr != null) "TP hit $pctStr" else "TP hit"
        "CLOSED_SL" -> if (pctStr != null) "SL hit $pctStr" else "SL hit"
        "CLOSED_OPPOSITE" -> if (pctStr != null) "Closed on opposite signal ($pctStr)" else "Closed on opposite signal"
        "CLOSED_MANUAL" -> if (pctStr != null) "Closed manually ($pctStr)" else "Closed manually"
        else -> signal.status
    }
}

private val absTimeFormatter = DateTimeFormatter.ofPattern("MMM d, HH:mm", Locale.US)

fun formatAlertTimestamp(timeMs: Long, nowMs: Long = System.currentTimeMillis()): String {
    val rel = formatCompactAge(nowMs - timeMs)
    val abs = Instant.ofEpochMilli(timeMs).atZone(ZoneId.systemDefault()).format(absTimeFormatter)
    return "$rel ago · $abs"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlertsScreen(
    settings: AppSettings,
    recentSignals: List<SignalCandidateEntity>,
    onOpenAlert: (symbol: String, signalId: String) -> Unit
) {
    var filter by remember { mutableStateOf(AlertFilter.ALL) }
    val acceptedSignals = remember(recentSignals, filter) {
        val base = recentSignals.filter { it.accepted }.sortedByDescending { it.signalTimeMs }
        when (filter) {
            AlertFilter.ALL -> base
            AlertFilter.ACTIVE -> base.filter { it.status == "ACTIVE" }
            AlertFilter.CLOSED -> base.filter { it.status != "ACTIVE" }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Alerts", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "${settings.exchange.displayName} ${settings.marketType.displayName} · Accepted signals history",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AlertFilter.entries.forEach { f ->
                    val selected = filter == f
                    FilterChip(
                        selected = selected,
                        onClick = { filter = f },
                        label = { Text(f.label) },
                        shape = LrmlcShapes.ButtonShape,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            if (acceptedSignals.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = LrmlcShapes.CardShape,
                        border = cardBorderStroke()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("No alerts in this view yet", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Accepted trade alerts stay listed here even after SL, TP, opposite signal, or manual close.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(acceptedSignals, key = { it.signalId }) { sig ->
                        AlertHistoryCard(
                            signal = sig,
                            onClick = { onOpenAlert(sig.symbol, sig.signalId) }
                        )
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}

@Composable
private fun AlertHistoryCard(
    signal: SignalCandidateEntity,
    onClick: () -> Unit
) {
    val isLong = signal.direction == "LONG"
    val dirColor = if (isLong) LrmlcColors.LongGreen else LrmlcColors.ShortRed
    val statusColor = when (signal.status) {
        "ACTIVE" -> MaterialTheme.colorScheme.primary
        "CLOSED_TP" -> LrmlcColors.LongGreen
        "CLOSED_SL" -> LrmlcColors.ShortRed
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val preset = RangePresets.byId(signal.presetId)
    val tnumStyle = TextStyle(fontFamily = FontFamily.Monospace, fontFeatureSettings = "tnum")
    val confText = if (!signal.modelWasTrained) {
        "Unfiltered"
    } else {
        val thr = ((signal.thresholdUsed ?: 0.0) * 100).toInt()
        "${((signal.pWin ?: 0.0) * 100).toInt()}% vs $thr%"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = LrmlcShapes.CardShape,
        border = cardBorderStroke()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = signal.symbol.stripUsdtSuffix(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(dirColor.copy(alpha = 0.16f))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = signal.direction,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = dirColor
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = preset.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Text(
                    text = formatAlertStatusLabel(signal),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = statusColor
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatAlertTimestamp(signal.signalTimeMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Conf $confText",
                    style = MaterialTheme.typography.labelSmall.merge(tnumStyle),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Entry", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        PersistentNotificationFormatter.formatPrice(signal.entryPrice),
                        style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Column {
                    Text("SL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        PersistentNotificationFormatter.formatPrice(signal.appliedSl),
                        style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                        fontWeight = FontWeight.SemiBold,
                        color = LrmlcColors.ShortRed
                    )
                }
                Column {
                    Text("TP", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        PersistentNotificationFormatter.formatPrice(signal.appliedTp),
                        style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                        fontWeight = FontWeight.SemiBold,
                        color = LrmlcColors.LongGreen
                    )
                }
            }

            signal.exitTimeMs?.let { exitMs ->
                val ret = signal.netReturnPct?.let { String.format(Locale.US, "%+.2f%% net", it * 100.0) } ?: "Closed"
                Text(
                    text = "Exited ${formatAlertTimestamp(exitMs)} · $ret",
                    style = MaterialTheme.typography.labelSmall.merge(tnumStyle),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
