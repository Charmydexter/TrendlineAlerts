package com.lrmlc.tradingalerts.ml

import kotlinx.serialization.Serializable

@Serializable
data class FeatureDefinition(
    val index: Int,
    val key: String,
    val title: String,
    val positiveExplanation: String,
    val negativeExplanation: String
)

object FeatureSpec {
    val DEFINITIONS: List<FeatureDefinition> = listOf(
        // Line geometry (0..11)
        FeatureDefinition(0, "res_slope_pct", "Resistance slope", "a steeper falling resistance line favored follow-through", "a steep falling resistance line weighed against the setup"),
        FeatureDefinition(1, "sup_slope_pct", "Support slope", "a stronger rising support line backed the move", "an overly steep rising support line reduced reliability"),
        FeatureDefinition(2, "channel_width_pct", "Channel width", "wider structure between the three lines helped", "a wide structure between the lines hurt performance"),
        FeatureDefinition(3, "res_bars_since_x1", "Age of resistance start", "an older resistance high anchor improved odds", "a stale resistance high anchor lowered odds"),
        FeatureDefinition(4, "res_bars_since_x2", "Age of resistance peak", "a fresher confirmed resistance peak helped", "distance from the confirmed resistance peak hurt"),
        FeatureDefinition(5, "sup_bars_since_x1", "Age of support start", "an older support low anchor improved odds", "a stale support low anchor lowered odds"),
        FeatureDefinition(6, "sup_bars_since_x2", "Age of support trough", "a fresher confirmed support trough helped", "distance from the confirmed support trough hurt"),
        FeatureDefinition(7, "res_anchor_spacing", "Resistance anchor span", "wider spacing between resistance anchors helped", "wide spacing between resistance anchors hurt"),
        FeatureDefinition(8, "sup_anchor_spacing", "Support anchor span", "wider spacing between support anchors helped", "wide spacing between support anchors hurt"),
        FeatureDefinition(9, "res_updates_win", "Resistance redraws ({W})", "frequent resistance updates signaled healthy structure", "frequent resistance redraws meant choppy structure"),
        FeatureDefinition(10, "sup_updates_win", "Support redraws ({W})", "frequent support updates signaled healthy structure", "frequent support redraws meant choppy structure"),
        FeatureDefinition(11, "line_convergence", "Line convergence", "converging trendlines preceded cleaner breakouts", "converging trendlines led to fakeouts"),

        // Position in structure (12..22)
        FeatureDefinition(12, "dist_low_hiline", "Clearance above top line", "stronger bar clearance above the top line helped", "over-extended clearance above the top line faded"),
        FeatureDefinition(13, "dist_high_loline", "Clearance below bottom line", "stronger bar clearance below the bottom line helped", "over-extended clearance below the bottom line bounced"),
        FeatureDefinition(14, "dist_close_hiline", "Close distance to top line", "higher close gap to the top line improved follow-through", "being stretched far from the top line hurt"),
        FeatureDefinition(15, "dist_close_loline", "Close distance to bottom line", "wider cushion to the bottom line improved survival", "being too far from the bottom line meant late entry"),
        FeatureDefinition(16, "dist_close_basis", "Distance from {W} average", "stronger separation from the {W} rolling average helped", "being overstretched from the {W} average pulled back"),
        FeatureDefinition(17, "outermost_hi_res", "Resistance as outer ceiling", "resistance acting as the outermost ceiling helped", "resistance being the outer ceiling capped upside"),
        FeatureDefinition(18, "outermost_lo_sup", "Support as outer floor", "support acting as the outermost floor helped", "support being the outer floor broke more often"),
        FeatureDefinition(19, "basis_slope_pct", "{W} average slope", "a rising {W} average supported continuation", "a rising {W} average opposed the setup"),
        FeatureDefinition(20, "struct_to_dollar_sl_ratio", "Structural vs max-$ stop ratio", "room between structural stop and dollar limit helped", "a tight structural stop compared with the max-dollar stop limit got clipped"),
        FeatureDefinition(21, "implied_rr", "Implied reward-to-risk", "a better reward-to-risk ratio improved expectancy", "tight reward-to-risk reduced net edge"),
        FeatureDefinition(22, "outermost_basis_edge", "{W} average as outer boundary", "the {W} average sitting at the outer boundary helped", "the {W} average sitting at the outer edge dragged price back"),

        // Gate & history (23..27)
        FeatureDefinition(23, "bars_since_opp_raw", "Time since opposite breakout", "longer time since the opposite condition helped", "a long lag since the opposite side signaled exhaustion"),
        FeatureDefinition(24, "bars_since_last_sig", "Time since last signal", "spacing between signals improved win rate", "long gaps without signals hurt momentum"),
        FeatureDefinition(25, "last_sig_outcome", "Previous signal outcome", "recent winning momentum carried over", "a prior winning signal often preceded mean reversion"),
        FeatureDefinition(26, "recent_risk_rejections", "Recent risk-filter blocks", "prior risk-blocked bars built pressure for a clean break", "repeated risk-filter blocks signaled noisy chop"),
        FeatureDefinition(27, "consec_bars_outside", "Consecutive bars outside lines", "sustained bars outside all three lines confirmed trend", "too many consecutive outside bars signaled an overextended move"),

        // Volume behavior from birth of resistance, support, and pair (28..55)
        FeatureDefinition(28, "res_vol_a1_med", "Resistance anchor 1 volume", "heavy volume at the resistance high anchor helped", "spike volume at the resistance high anchor hurt"),
        FeatureDefinition(29, "res_vol_a2_med", "Resistance anchor 2 volume", "strong volume at the second resistance peak helped", "fading volume at the second resistance peak worked better"),
        FeatureDefinition(30, "res_vol_a2_a1_ratio", "Resistance anchor volume ratio", "rising volume from anchor 1 to anchor 2 helped", "fading volume between resistance anchors worked better"),
        FeatureDefinition(31, "sup_vol_a1_med", "Support anchor 1 volume", "heavy volume at the support low anchor helped", "spike volume at the support low anchor hurt"),
        FeatureDefinition(32, "sup_vol_a2_med", "Support anchor 2 volume", "strong volume at the second support trough helped", "fading volume at the second support trough worked better"),
        FeatureDefinition(33, "sup_vol_a2_a1_ratio", "Support anchor volume ratio", "rising volume from anchor 1 to anchor 2 on support helped", "fading volume between support anchors worked better"),
        FeatureDefinition(34, "pair_vol_a2_a1_avg", "Combined anchor volume ratio", "stronger secondary anchor volume across both lines helped", "quieter secondary anchors across both lines worked better"),

        FeatureDefinition(35, "res_vol_since_vs_before", "Volume shift since resistance birth", "volume expanding after resistance birth confirmed conviction", "volume surging after resistance birth signaled churn"),
        FeatureDefinition(36, "sup_vol_since_vs_before", "Volume shift since support birth", "volume expanding after support birth confirmed conviction", "volume surging after support birth signaled churn"),
        FeatureDefinition(37, "pair_vol_since_vs_before", "Combined volume shift since birth", "higher overall volume after trendline birth helped", "lower overall volume after trendline birth worked better"),

        FeatureDefinition(38, "res_vol_slope_since_birth", "Volume trend since resistance birth", "steadily rising volume since resistance birth helped", "declining volume since resistance birth worked better"),
        FeatureDefinition(39, "sup_vol_slope_since_birth", "Volume trend since support birth", "steadily rising volume since support birth helped", "declining volume since support birth worked better"),
        FeatureDefinition(40, "pair_vol_slope_since_birth", "Combined volume trend since birth", "rising volume slope across the trendline pair helped", "falling volume slope across the pair worked better"),

        FeatureDefinition(41, "res_up_vol_share", "Up-bar volume share since resistance birth", "more volume on green bars since resistance birth helped", "heavy down-bar volume since resistance birth worked better"),
        FeatureDefinition(42, "sup_up_vol_share", "Up-bar volume share since support birth", "more volume on green bars since support birth helped", "heavy down-bar volume since support birth worked better"),
        FeatureDefinition(43, "pair_up_vol_share", "Combined up-bar volume share", "buyer-dominated volume since line births helped", "seller-dominated volume since line births worked better"),

        FeatureDefinition(44, "res_cum_vol_vs_med", "Cumulative volume since resistance birth", "higher total volume since resistance birth helped", "excess cumulative volume since resistance birth meant exhaustion"),
        FeatureDefinition(45, "sup_cum_vol_vs_med", "Cumulative volume since support birth", "higher total volume since support birth helped", "excess cumulative volume since support birth meant exhaustion"),
        FeatureDefinition(46, "pair_cum_vol_vs_med", "Combined cumulative volume since birth", "elevated cumulative participation since birth helped", "overheated cumulative volume since birth hurt"),

        FeatureDefinition(47, "res_sig_vol_vs_birth", "Signal-bar volume vs resistance birth avg", "a volume surge on the signal bar vs resistance birth helped", "an extreme signal-bar volume spike reversed"),
        FeatureDefinition(48, "res_last3_vol_vs_birth", "Last 3-bar volume vs resistance birth avg", "building 3-bar volume vs resistance birth helped", "elevated 3-bar volume vs resistance birth signaled climax"),
        FeatureDefinition(49, "sup_sig_vol_vs_birth", "Signal-bar volume vs support birth avg", "a volume surge on the signal bar vs support birth helped", "an extreme signal-bar volume spike vs support birth reversed"),
        FeatureDefinition(50, "sup_last3_vol_vs_birth", "Last 3-bar volume vs support birth avg", "building 3-bar volume vs support birth helped", "elevated 3-bar volume vs support birth signaled climax"),
        FeatureDefinition(51, "pair_sig_vol_vs_birth", "Signal-bar volume vs combined birth avg", "strong breakout volume compared with trendline birth helped", "a climax spike on the signal bar failed"),
        FeatureDefinition(52, "pair_last3_vol_vs_birth", "Last 3-bar volume vs combined birth avg", "steady 3-bar volume acceleration helped", "exhaustion over the last 3 bars hurt"),

        FeatureDefinition(53, "res_vol_birth_to_breakout", "Volume change from resistance birth to breakout", "volume expanding into the first breakout beyond all lines helped", "volume drying up or spiking abnormally into breakout hurt"),
        FeatureDefinition(54, "sup_vol_birth_to_breakout", "Volume change from support birth to breakout", "volume building from support birth to breakout helped", "erratic volume shift from support birth to breakout hurt"),
        FeatureDefinition(55, "pair_vol_birth_to_breakout", "Combined birth-to-breakout volume shift", "expanding participation between birth and breakout helped", "abrupt volume drop between birth and breakout hurt"),

        // Price behavior (56..64)
        FeatureDefinition(56, "bar_range_pct", "Signal candle range", "stronger signal bar expansion helped", "oversized signal candles tended to pull back"),
        FeatureDefinition(57, "body_to_range", "Body-to-range ratio", "decisive candle bodies outperformed long wicks", "full-bodied candles were prone to quick retests"),
        FeatureDefinition(58, "close_location", "Close position inside bar", "closing near the extreme of the candle helped", "closing at the extreme signaled short-term exhaustion"),
        FeatureDefinition(59, "ret_1", "1-minute return", "strong 1-minute impulse backed continuation", "sharp 1-minute spikes snapped back"),
        FeatureDefinition(60, "ret_5", "5-minute return", "steady 5-minute momentum helped", "extended 5-minute runs reversed"),
        FeatureDefinition(61, "ret_15", "15-minute return", "15-minute directional drift helped", "overextended 15-minute moves faded"),
        FeatureDefinition(62, "ret_60", "1-hour return", "1-hour trend alignment improved odds", "chasing a stretched 1-hour move hurt"),
        FeatureDefinition(63, "realized_vol_60", "1-hour realized volatility", "healthy volatility helped reach take profit", "excessive chop and volatility triggered stops"),
        FeatureDefinition(64, "vol_vs_median_win", "Volume vs {W} median", "above-median volume confirmed the signal", "overheated volume spikes failed more often"),

        // Context (65..70)
        FeatureDefinition(65, "hour_sin", "Time of day (sin)", "this UTC session hour performed better", "this UTC session hour underperformed"),
        FeatureDefinition(66, "hour_cos", "Time of day (cos)", "session timing favored continuation", "session timing favored mean reversion"),
        FeatureDefinition(67, "weekday_sin", "Day of week (sin)", "mid-week liquidity helped", "this day of week showed weaker follow-through"),
        FeatureDefinition(68, "weekday_cos", "Day of week (cos)", "this part of the week performed better", "weekend/off-peak conditions hurt"),
        FeatureDefinition(69, "signal_direction", "Signal direction (Long vs Short)", "long setups outperformed in recent data", "short setups outperformed in recent data"),
        FeatureDefinition(70, "market_type", "Market type (Perp vs Spot)", "perpetual futures liquidity helped", "spot market structure performed better"),

        // Market context group (71..75) - master asset (Bitcoin by default); neutral (0) for the master itself
        FeatureDefinition(71, "mc_master_ret_15", "Master asset 15-minute move", "a rising master asset backed the setup", "a falling master asset weighed on the setup"),
        FeatureDefinition(72, "mc_master_ret_60", "Master asset 1-hour move", "master asset 1-hour trend alignment helped", "master asset 1-hour trend opposed the setup"),
        FeatureDefinition(73, "mc_master_vol_60", "Master asset volatility", "a lively master asset market helped", "a turbulent master asset market hurt"),
        FeatureDefinition(74, "mc_rel_strength_60", "Strength vs master asset (1h)", "outperforming the master asset over the last hour helped", "lagging the master asset over the last hour hurt"),
        FeatureDefinition(75, "mc_corr_60", "Correlation with master asset", "closely following the master asset helped", "moving independently of the master asset hurt"),

        // Volatility mood group (76..80)
        FeatureDefinition(76, "vm_range_5", "Recent candle size (5m)", "bigger recent candles helped follow-through", "oversized recent candles faded"),
        FeatureDefinition(77, "vm_range_30", "Recent candle size (30m)", "healthy medium-term candle size helped", "inflated medium-term candle size hurt"),
        FeatureDefinition(78, "vm_vol_vs_day", "Volatility vs last day", "volatility above its daily norm helped", "unusually high volatility versus the last day hurt"),
        FeatureDefinition(79, "vm_range_trend", "Range tightening or widening", "widening price range helped", "tightening price range hurt"),
        FeatureDefinition(80, "vm_volume_vs_day", "Volume vs last day", "unusually active volume versus the last day helped", "unusually heavy volume versus the last day hurt"),

        // Bigger-picture group (81..88) - 5m and 15m candles built from 1-minute data
        FeatureDefinition(81, "htf_ret_5m_1", "Last 5-minute candle move", "the latest 5-minute candle supported the setup", "the latest 5-minute candle opposed the setup"),
        FeatureDefinition(82, "htf_ret_5m_3", "Three 5-minute candles move", "a steady 5-minute trend helped", "an extended 5-minute trend faded"),
        FeatureDefinition(83, "htf_ret_15m_1", "Last 15-minute candle move", "the latest 15-minute candle supported the setup", "the latest 15-minute candle opposed the setup"),
        FeatureDefinition(84, "htf_ret_15m_3", "Three 15-minute candles move", "a steady 15-minute trend helped", "an extended 15-minute trend faded"),
        FeatureDefinition(85, "htf_dist_15m_avg", "Distance to 15-minute average", "separation from the 15-minute average helped", "being stretched from the 15-minute average hurt"),
        FeatureDefinition(86, "htf_dist_hour_high", "Distance to last-hour high", "room below the last-hour high helped", "being pinned under the last-hour high hurt"),
        FeatureDefinition(87, "htf_dist_hour_low", "Distance to last-hour low", "room above the last-hour low helped", "sitting on the last-hour low hurt"),
        FeatureDefinition(88, "htf_rsi_5m", "5-minute RSI", "5-minute momentum (RSI) backed the setup", "stretched 5-minute RSI reversed"),

        // Futures group (89..90) - perpetual markets only
        FeatureDefinition(89, "fut_funding_rate", "Funding rate", "the funding rate backed the setup", "crowded funding worked against the setup"),
        FeatureDefinition(90, "fut_oi_change_1h", "Open interest change (1h)", "rising open interest confirmed the move", "open interest swings signaled churn")
    )

    /** Learned feature groups. CORE is always on; the others are proven first and dropped if they do not help. */
    enum class Group(val label: String, val firstIndex: Int, val lastIndex: Int) {
        CORE("Core", 0, 70),
        MARKET("Market context", 71, 75),
        VOLATILITY("Volatility mood", 76, 80),
        HTF("Bigger-picture view", 81, 88),
        FUTURES("Futures (funding / open interest)", 89, 90);

        val indices: IntRange get() = firstIndex..lastIndex
    }

    val OPTIONAL_GROUPS: List<Group> = listOf(Group.MARKET, Group.VOLATILITY, Group.HTF, Group.FUTURES)
    const val CORE_FEATURE_COUNT = 71

    fun parseGroups(names: List<String>?): Set<Group> {
        val out = HashSet<Group>()
        out.add(Group.CORE)
        names?.forEach { n -> Group.values().firstOrNull { it.name == n }?.let { out.add(it) } }
        return out
    }

    /** Zeroes every optional group that is not enabled. Returns the same array when nothing needs masking. */
    fun applyMask(features: DoubleArray, enabled: Set<Group>): DoubleArray {
        var needsCopy = false
        for (g in OPTIONAL_GROUPS) {
            if (g !in enabled) { needsCopy = true; break }
        }
        if (!needsCopy) return features
        val out = features.copyOf()
        for (g in OPTIONAL_GROUPS) {
            if (g in enabled) continue
            for (i in g.indices) if (i < out.size) out[i] = 0.0
        }
        return out
    }

    /** Pads an older, shorter stored feature vector with neutral zeros for newer features. */
    fun padToCurrent(features: DoubleArray): DoubleArray =
        if (features.size >= DEFINITIONS.size) features else features.copyOf(DEFINITIONS.size)

    val FEATURE_COUNT: Int = DEFINITIONS.size
    val KEY_TO_DEF: Map<String, FeatureDefinition> = DEFINITIONS.associateBy { it.key }

    fun formatText(template: String, windowLabel: String = "4h"): String =
        template.replace("{W}", windowLabel)
}
