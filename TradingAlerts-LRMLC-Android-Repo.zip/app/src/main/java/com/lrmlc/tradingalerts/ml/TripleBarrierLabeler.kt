package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.TimeoutLabelMode
import com.lrmlc.tradingalerts.data.model.TradeDirection
import kotlin.math.max

enum class BarrierOutcome {
    TP_HIT,
    SL_HIT,
    TIMEOUT_PROFIT,
    TIMEOUT_LOSS,
    UNRESOLVED
}

data class TripleBarrierResult(
    val outcome: BarrierOutcome,
    val label: Int?, // 1 win, 0 loss, null if excluded or unresolved
    val exitBarIndex: Int,
    val exitPrice: Double,
    val netReturnPct: Double,
    val maePct: Double, // >= 0 adverse excursion %
    val mfePct: Double  // >= 0 favorable excursion %
)

object TripleBarrierLabeler {

    fun labelCandidate(
        candles: List<Candle>,
        signalBarIndex: Int,
        direction: TradeDirection,
        entryPrice: Double,
        slPrice: Double,
        tpPrice: Double,
        horizonBars: Int = 60,
        roundTripFeeRate: Double = 0.001,
        timeoutLabelMode: TimeoutLabelMode = TimeoutLabelMode.SIGN_OF_NET_AFTER_FEES
    ): TripleBarrierResult {
        if (signalBarIndex !in candles.indices || entryPrice <= 0.0) {
            return TripleBarrierResult(BarrierOutcome.UNRESOLVED, null, signalBarIndex, entryPrice, 0.0, 0.0, 0.0)
        }
        val availableFuture = candles.size - 1 - signalBarIndex
        if (availableFuture <= 0) {
            return TripleBarrierResult(BarrierOutcome.UNRESOLVED, null, signalBarIndex, entryPrice, 0.0, 0.0, 0.0)
        }

        val maxStep = minOf(horizonBars.coerceAtLeast(1), availableFuture)
        var maePct = 0.0
        var mfePct = 0.0

        for (step in 1..maxStep) {
            val idx = signalBarIndex + step
            val bar = candles[idx]
            when (direction) {
                TradeDirection.LONG -> {
                    val adv = ((entryPrice - bar.low) / entryPrice).coerceAtLeast(0.0)
                    val fav = ((bar.high - entryPrice) / entryPrice).coerceAtLeast(0.0)
                    maePct = max(maePct, adv)
                    mfePct = max(mfePct, fav)

                    val hitSl = bar.low <= slPrice
                    val hitTp = bar.high >= tpPrice
                    // Conservative rule: if both are touched in the same candle, assume SL hit first
                    if (hitSl) {
                        val rawRet = (slPrice - entryPrice) / entryPrice
                        return TripleBarrierResult(
                            outcome = BarrierOutcome.SL_HIT,
                            label = 0,
                            exitBarIndex = idx,
                            exitPrice = slPrice,
                            netReturnPct = rawRet - roundTripFeeRate,
                            maePct = maePct,
                            mfePct = mfePct
                        )
                    }
                    if (hitTp) {
                        val rawRet = (tpPrice - entryPrice) / entryPrice
                        return TripleBarrierResult(
                            outcome = BarrierOutcome.TP_HIT,
                            label = 1,
                            exitBarIndex = idx,
                            exitPrice = tpPrice,
                            netReturnPct = rawRet - roundTripFeeRate,
                            maePct = maePct,
                            mfePct = mfePct
                        )
                    }
                }

                TradeDirection.SHORT -> {
                    val adv = ((bar.high - entryPrice) / entryPrice).coerceAtLeast(0.0)
                    val fav = ((entryPrice - bar.low) / entryPrice).coerceAtLeast(0.0)
                    maePct = max(maePct, adv)
                    mfePct = max(mfePct, fav)

                    val hitSl = bar.high >= slPrice
                    val hitTp = bar.low <= tpPrice
                    if (hitSl) {
                        val rawRet = (entryPrice - slPrice) / entryPrice
                        return TripleBarrierResult(
                            outcome = BarrierOutcome.SL_HIT,
                            label = 0,
                            exitBarIndex = idx,
                            exitPrice = slPrice,
                            netReturnPct = rawRet - roundTripFeeRate,
                            maePct = maePct,
                            mfePct = mfePct
                        )
                    }
                    if (hitTp) {
                        val rawRet = (entryPrice - tpPrice) / entryPrice
                        return TripleBarrierResult(
                            outcome = BarrierOutcome.TP_HIT,
                            label = 1,
                            exitBarIndex = idx,
                            exitPrice = tpPrice,
                            netReturnPct = rawRet - roundTripFeeRate,
                            maePct = maePct,
                            mfePct = mfePct
                        )
                    }
                }
            }
        }

        // Horizon reached without hitting SL or TP
        if (availableFuture < horizonBars) {
            return TripleBarrierResult(
                outcome = BarrierOutcome.UNRESOLVED,
                label = null,
                exitBarIndex = signalBarIndex + maxStep,
                exitPrice = candles[signalBarIndex + maxStep].close,
                netReturnPct = 0.0,
                maePct = maePct,
                mfePct = mfePct
            )
        }

        val endIdx = signalBarIndex + horizonBars
        val endPrice = candles[endIdx].close
        val rawRet = when (direction) {
            TradeDirection.LONG -> (endPrice - entryPrice) / entryPrice
            TradeDirection.SHORT -> (entryPrice - endPrice) / entryPrice
        }
        val netRet = rawRet - roundTripFeeRate
        val outcome = if (netRet > 0.0) BarrierOutcome.TIMEOUT_PROFIT else BarrierOutcome.TIMEOUT_LOSS
        val label = when (timeoutLabelMode) {
            TimeoutLabelMode.SIGN_OF_NET_AFTER_FEES -> if (netRet > 0.0) 1 else 0
            TimeoutLabelMode.EXCLUDE -> null
        }

        return TripleBarrierResult(
            outcome = outcome,
            label = label,
            exitBarIndex = endIdx,
            exitPrice = endPrice,
            netReturnPct = netRet,
            maePct = maePct,
            mfePct = mfePct
        )
    }
}
