package com.lrmlc.tradingalerts.service

import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import java.util.Locale

data class PositionedAssetBannerItem(
    val symbol: String,
    val direction: TradeDirection?,
    val tpPrice: Double?,
    val slPrice: Double?,
    val updatedAtMs: Long
)

data class PersistentNotificationContent(
    val title: String,
    val body: String
)

object PersistentNotificationFormatter {

    fun format(
        monitoringOn: Boolean,
        positionedAssets: List<PositionedAssetBannerItem>
    ): PersistentNotificationContent {
        if (positionedAssets.isEmpty()) {
            return if (monitoringOn) {
                PersistentNotificationContent(
                    title = "⚪ Monitoring ON",
                    body = "Watching watchlist 1m candles"
                )
            } else {
                PersistentNotificationContent(
                    title = "⚫ Monitoring OFF",
                    body = "Background monitoring is paused"
                )
            }
        }

        val ordered = positionedAssets.sortedByDescending { it.updatedAtMs }
        val primary = ordered.first()
        val primaryDirEmoji = primary.direction?.emoji ?: "●"
        val primarySym = primary.symbol.stripUsdtSuffix()
        val tpStr = primary.tpPrice?.let { formatPrice(it) } ?: "—"
        val slStr = primary.slPrice?.let { formatPrice(it) } ?: "—"
        val title = "$primaryDirEmoji $primarySym · TP $tpStr · SL $slStr"

        val older = ordered.drop(1)
        val body = if (older.isEmpty()) {
            if (monitoringOn) "⚪ Monitoring ON · 1 open position" else "1 open position"
        } else {
            older.joinToString(", ") { item ->
                val emoji = item.direction?.emoji ?: "●"
                "$emoji ${item.symbol.stripUsdtSuffix()}"
            }
        }

        return PersistentNotificationContent(title = title, body = body)
    }

    fun formatPrice(price: Double): String {
        val absP = kotlin.math.abs(price)
        return when {
            absP >= 1000.0 -> String.format(Locale.US, "%.2f", price)
            absP >= 1.0 -> String.format(Locale.US, "%.4f", price).trimEnd('0').trimEnd('.')
            absP >= 0.01 -> String.format(Locale.US, "%.5f", price).trimEnd('0').trimEnd('.')
            else -> String.format(Locale.US, "%.6f", price).trimEnd('0').trimEnd('.')
        }.let { if (it.endsWith('.')) it.dropLast(1) else it }
    }
}
