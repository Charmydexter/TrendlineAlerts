package com.lrmlc.tradingalerts.trade

import com.lrmlc.tradingalerts.data.model.EngineConfig
import com.lrmlc.tradingalerts.data.model.TradeDirection
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

data class BarrierMetrics(
    val stopPct: Double,
    val tpPct: Double,
    val feeAsPctOfStopBarrier: Double,
    val feeAsPctOfTpBarrier: Double,
    val maxFeePctOfBarrier: Double,
    val isHighFeeWarning: Boolean
)

data class SlTpStatsSummary(
    val winningSampleCount: Int,
    val mae80thPct: Double,
    val mfeMedianPct: Double
)

data class SlTpDecision(
    val structuralSl: Double,
    val defaultTp: Double,
    val appliedSl: Double,
    val appliedTp: Double,
    val slAdjusted: Boolean,
    val tpAdjusted: Boolean,
    val slReason: String,
    val tpReason: String
)

object SlTpManager {

    fun computeBarrierMetrics(
        capitalUsd: Double,
        maxLossUsd: Double,
        takeProfitUsd: Double,
        roundTripFeeRate: Double
    ): BarrierMetrics {
        val safeCapital = capitalUsd.coerceAtLeast(0.01)
        val stopPct = (maxLossUsd.coerceAtLeast(0.0) / safeCapital) * 100.0
        val tpPct = (takeProfitUsd.coerceAtLeast(0.0) / safeCapital) * 100.0
        val feePct = roundTripFeeRate.coerceAtLeast(0.0) * 100.0
        val feeStopShare = if (stopPct > 1e-9) (feePct / stopPct) * 100.0 else 100.0
        val feeTpShare = if (tpPct > 1e-9) (feePct / tpPct) * 100.0 else 100.0
        val maxShare = max(feeStopShare, feeTpShare)
        return BarrierMetrics(
            stopPct = stopPct,
            tpPct = tpPct,
            feeAsPctOfStopBarrier = feeStopShare,
            feeAsPctOfTpBarrier = feeTpShare,
            maxFeePctOfBarrier = maxShare,
            isHighFeeWarning = maxShare > 10.0
        )
    }

    fun computeStatsFromWinningExcursions(
        winningMaePcts: List<Double>,
        winningMfePcts: List<Double>
    ): SlTpStatsSummary? {
        if (winningMaePcts.size < 5 || winningMfePcts.size < 5) return null
        val sortedMae = winningMaePcts.filter { it.isFinite() && it >= 0.0 }.sorted()
        val sortedMfe = winningMfePcts.filter { it.isFinite() && it >= 0.0 }.sorted()
        if (sortedMae.size < 5 || sortedMfe.size < 5) return null

        val mae80 = percentile(sortedMae, 0.80)
        val mfe50 = percentile(sortedMfe, 0.50)
        return SlTpStatsSummary(
            winningSampleCount = sortedMae.size,
            mae80thPct = mae80,
            mfeMedianPct = mfe50
        )
    }

    fun resolveLevels(
        direction: TradeDirection,
        entryPrice: Double,
        structuralSl: Double,
        config: EngineConfig,
        stats: SlTpStatsSummary?,
        autoSlEnabled: Boolean,
        autoTpEnabled: Boolean
    ): SlTpDecision {
        val safeCapital = config.capitalUsd.coerceAtLeast(0.01)
        val maxSlDist = config.maxLossUsd * entryPrice / safeCapital
        val minTpDist = config.takeProfitUsd * entryPrice / safeCapital

        val defaultTp = when (direction) {
            TradeDirection.LONG -> entryPrice + minTpDist
            TradeDirection.SHORT -> entryPrice - minTpDist
        }

        var appliedSl = structuralSl
        var slAdjusted = false
        var slReason = "Structural trendline stop (default)."

        if (autoSlEnabled && stats != null && stats.winningSampleCount >= 5) {
            val learnedMaeDist = entryPrice * stats.mae80thPct
            val currentStructDist = when (direction) {
                TradeDirection.LONG -> (entryPrice - structuralSl).coerceAtLeast(0.0)
                TradeDirection.SHORT -> (structuralSl - entryPrice).coerceAtLeast(0.0)
            }
            if (learnedMaeDist > currentStructDist && learnedMaeDist > 0.0) {
                val clampedDist = min(learnedMaeDist, maxSlDist)
                val candidateSl = when (direction) {
                    TradeDirection.LONG -> min(structuralSl, entryPrice - clampedDist)
                    TradeDirection.SHORT -> max(structuralSl, entryPrice + clampedDist)
                }
                val widenedEnough = when (direction) {
                    TradeDirection.LONG -> candidateSl < structuralSl - 1e-12
                    TradeDirection.SHORT -> candidateSl > structuralSl + 1e-12
                }
                if (widenedEnough) {
                    appliedSl = candidateSl
                    slAdjusted = true
                    val structPct = (currentStructDist / entryPrice) * 100.0
                    val learnedPct = (clampedDist / entryPrice) * 100.0
                    slReason = String.format(
                        Locale.US,
                        "Stop widened from %.2f%% to %.2f%% because 80%% of past winning trades dipped up to %.2f%% before recovering (capped at $%.2f max loss).",
                        structPct,
                        learnedPct,
                        stats.mae80thPct * 100.0,
                        config.maxLossUsd
                    )
                }
            }
        }

        appliedSl = when (direction) {
            TradeDirection.LONG -> min(structuralSl, max(appliedSl, entryPrice - maxSlDist))
            TradeDirection.SHORT -> max(structuralSl, min(appliedSl, entryPrice + maxSlDist))
        }

        var appliedTp = defaultTp
        var tpAdjusted = false
        var tpReason = String.format(Locale.US, "Minimum $%.2f take profit target.", config.takeProfitUsd)

        if (autoTpEnabled && stats != null && stats.winningSampleCount >= 5) {
            val learnedMfeDist = entryPrice * stats.mfeMedianPct
            if (learnedMfeDist > minTpDist * 1.05) {
                appliedTp = when (direction) {
                    TradeDirection.LONG -> entryPrice + learnedMfeDist
                    TradeDirection.SHORT -> entryPrice - learnedMfeDist
                }
                tpAdjusted = true
                tpReason = String.format(
                    Locale.US,
                    "Take profit raised to %.2f%% (median winning excursion across %d past winners, above $%.2f minimum).",
                    stats.mfeMedianPct * 100.0,
                    stats.winningSampleCount,
                    config.takeProfitUsd
                )
            }
        }

        return SlTpDecision(
            structuralSl = structuralSl,
            defaultTp = defaultTp,
            appliedSl = appliedSl,
            appliedTp = appliedTp,
            slAdjusted = slAdjusted,
            tpAdjusted = tpAdjusted,
            slReason = slReason,
            tpReason = tpReason
        )
    }

    private fun percentile(sorted: List<Double>, p: Double): Double {
        if (sorted.isEmpty()) return 0.0
        if (sorted.size == 1) return sorted[0]
        val rank = p.coerceIn(0.0, 1.0) * (sorted.size - 1)
        val lo = rank.toInt()
        val hi = min(sorted.size - 1, lo + 1)
        val frac = rank - lo
        return sorted[lo] * (1.0 - frac) + sorted[hi] * frac
    }
}
