package com.lrmlc.tradingalerts.engine

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.EngineConfig
import com.lrmlc.tradingalerts.data.model.RangePreset
import com.lrmlc.tradingalerts.data.model.TradeDirection
import kotlin.math.max
import kotlin.math.min

data class TrendlineAnchorPair(
    val x1: Int,
    val y1: Double,
    val x2: Int,
    val y2: Double,
    val birthBar: Int
) {
    fun extrapolateAt(barIndex: Int): Double {
        val dx = (x2 - x1).toDouble()
        if (dx == 0.0) return y2
        return y2 + ((y2 - y1) / dx) * (barIndex - x2).toDouble()
    }

    val slopePerBar: Double
        get() {
            val dx = (x2 - x1).toDouble()
            return if (dx == 0.0) 0.0 else (y2 - y1) / dx
        }
}

data class ConfluenceBarSnapshot(
    val barIndex: Int,
    val candle: Candle,
    val resistance: TrendlineAnchorPair?,
    val support: TrendlineAnchorPair?,
    val resVal: Double?,
    val supVal: Double?,
    val basis: Double?,
    val prevBasis: Double?,
    val hiLine: Double?,
    val loLine: Double?,
    val rawLong: Boolean,
    val rawShort: Boolean,
    val slDist: Double,
    val tpDist: Double,
    val longOk: Boolean,
    val shortOk: Boolean,
    val longArmedBefore: Boolean,
    val shortArmedBefore: Boolean,
    val longArmedAfter: Boolean,
    val shortArmedAfter: Boolean,
    val longFire: Boolean,
    val shortFire: Boolean,
    val candidateDirection: TradeDirection?,
    val structuralSl: Double?,
    val defaultTp: Double?,
    val resUpdatesInWindow: Int,
    val supUpdatesInWindow: Int,
    val barsSinceLastRawLong: Int?,
    val barsSinceLastRawShort: Int?,
    val barsSinceLastSignal: Int?,
    val recentRiskRejectionsLast60: Int,
    val consecutiveBarsOutside: Int,
    val firstOutsideBarSinceResBirth: Int?,
    val firstOutsideBarSinceSupBirth: Int?
)

/**
 * Deterministic bar-by-bar port of the Triple Confluence Pine Script v6 indicator:
 * "Trendlines + Gated Signals + SL/TP".
 */
class ConfluenceEngine(
    private val config: EngineConfig = EngineConfig(),
    private val preset: RangePreset? = null
) {
    @Suppress("DEPRECATION")
    val windowBars: Int = (preset?.windowBars ?: config.windowLength).coerceAtLeast(20)

    @Suppress("DEPRECATION")
    val minGapBars: Int = (preset?.minGapBars ?: config.minGap).coerceAtLeast(1)

    /**
     * Evaluates a chronologically ordered list of closed 1-minute candles.
     */
    fun evaluateAll(candles: List<Candle>): List<ConfluenceBarSnapshot> {
        if (candles.isEmpty()) return emptyList()

        val winLen = windowBars
        val minGap = minGapBars

        val result = ArrayList<ConfluenceBarSnapshot>(candles.size)
        var currentRes: TrendlineAnchorPair? = null
        var currentSup: TrendlineAnchorPair? = null

        var longArmed = true
        var shortArmed = true

        var rollingOhlc4Sum = 0.0
        var prevBasis: Double? = null

        val resUpdateBars = ArrayDeque<Int>()
        val supUpdateBars = ArrayDeque<Int>()
        val riskRejectionBars = ArrayDeque<Int>()

        var lastRawLongBar: Int? = null
        var lastRawShortBar: Int? = null
        var lastSignalBar: Int? = null
        var consecutiveOutside = 0

        var firstOutsideSinceResBirth: Int? = null
        var firstOutsideSinceSupBirth: Int? = null

        for (barIndex in candles.indices) {
            val bar = candles[barIndex]
            rollingOhlc4Sum += bar.ohlc4
            if (barIndex >= winLen) {
                rollingOhlc4Sum -= candles[barIndex - winLen].ohlc4
            }
            val basis: Double? = if (barIndex >= winLen - 1) rollingOhlc4Sum / winLen.toDouble() else null

            // 1) Trendline state (computed every bar once winLen bars exist)
            if (barIndex >= winLen - 1) {
                // Resistance: older point = window high (on equal highs keep most recent, i=0 is newest)
                var h1 = -1.0e18
                var hi1 = 0
                for (i in 0 until winLen) {
                    val h = candles[barIndex - i].high
                    if (h > h1) {
                        h1 = h
                        hi1 = i
                    }
                }
                // Newer point: highest CONFIRMED peak at least minGap bars after window high.
                // Bar 0 is never eligible; bar i counts only when high[i] > high[i - 1].
                var h2 = -1.0e18
                var hi2 = -1
                if (hi1 - minGap >= 1) {
                    for (i in 1..(hi1 - minGap)) {
                        val h = candles[barIndex - i].high
                        val hNext = candles[barIndex - (i - 1)].high
                        if (h > hNext && h > h2) {
                            h2 = h
                            hi2 = i
                        }
                    }
                }
                if (hi2 >= 0) {
                    val newX1 = barIndex - hi1
                    val newX2 = barIndex - hi2
                    val changed = currentRes == null ||
                        currentRes.x1 != newX1 || currentRes.y1 != h1 ||
                        currentRes.x2 != newX2 || currentRes.y2 != h2
                    if (changed) {
                        resUpdateBars.addLast(barIndex)
                        firstOutsideSinceResBirth = null
                        currentRes = TrendlineAnchorPair(
                            x1 = newX1,
                            y1 = h1,
                            x2 = newX2,
                            y2 = h2,
                            birthBar = barIndex
                        )
                    }
                }

                // Support (exact mirror): older point = window low
                var l1 = 1.0e18
                var li1 = 0
                for (i in 0 until winLen) {
                    val l = candles[barIndex - i].low
                    if (l < l1) {
                        l1 = l
                        li1 = i
                    }
                }
                var l2 = 1.0e18
                var li2 = -1
                if (li1 - minGap >= 1) {
                    for (i in 1..(li1 - minGap)) {
                        val l = candles[barIndex - i].low
                        val lNext = candles[barIndex - (i - 1)].low
                        if (l < lNext && l < l2) {
                            l2 = l
                            li2 = i
                        }
                    }
                }
                if (li2 >= 0) {
                    val newX1 = barIndex - li1
                    val newX2 = barIndex - li2
                    val changed = currentSup == null ||
                        currentSup.x1 != newX1 || currentSup.y1 != l1 ||
                        currentSup.x2 != newX2 || currentSup.y2 != l2
                    if (changed) {
                        supUpdateBars.addLast(barIndex)
                        firstOutsideSinceSupBirth = null
                        currentSup = TrendlineAnchorPair(
                            x1 = newX1,
                            y1 = l1,
                            x2 = newX2,
                            y2 = l2,
                            birthBar = barIndex
                        )
                    }
                }
            }

            while (resUpdateBars.isNotEmpty() && resUpdateBars.first() <= barIndex - winLen) {
                resUpdateBars.removeFirst()
            }
            while (supUpdateBars.isNotEmpty() && supUpdateBars.first() <= barIndex - winLen) {
                supUpdateBars.removeFirst()
            }
            while (riskRejectionBars.isNotEmpty() && riskRejectionBars.first() <= barIndex - 60) {
                riskRejectionBars.removeFirst()
            }

            val resVal = currentRes?.extrapolateAt(barIndex)
            val supVal = currentSup?.extrapolateAt(barIndex)

            val haveAll = resVal != null && supVal != null && basis != null
            val hiLine = if (haveAll) max(basis!!, max(resVal!!, supVal!!)) else null
            val loLine = if (haveAll) min(basis!!, min(resVal!!, supVal!!)) else null

            val rawLong = haveAll && bar.low > hiLine!!
            val rawShort = haveAll && bar.high < loLine!!

            if (rawLong || rawShort) {
                consecutiveOutside++
                if (currentRes != null && firstOutsideSinceResBirth == null) {
                    firstOutsideSinceResBirth = barIndex
                }
                if (currentSup != null && firstOutsideSinceSupBirth == null) {
                    firstOutsideSinceSupBirth = barIndex
                }
            } else {
                consecutiveOutside = 0
            }

            val safeCapital = config.capitalUsd.coerceAtLeast(0.01)
            val slDist = config.maxLossUsd * bar.close / safeCapital
            val tpDist = config.takeProfitUsd * bar.close / safeCapital

            val longOk = haveAll && (bar.close - slDist) < loLine!!
            val shortOk = haveAll && (bar.close + slDist) > hiLine!!

            val longArmedBefore = longArmed
            val shortArmedBefore = shortArmed

            val longFire = rawLong && longArmed && longOk
            val shortFire = rawShort && shortArmed && shortOk

            if ((rawLong && longArmed && !longOk) || (rawShort && shortArmed && !shortOk)) {
                riskRejectionBars.addLast(barIndex)
            }

            if (longFire) longArmed = false
            if (shortFire) shortArmed = false
            if (rawShort) longArmed = true
            if (rawLong) shortArmed = true

            val candidateDir = when {
                longFire -> TradeDirection.LONG
                shortFire -> TradeDirection.SHORT
                else -> null
            }
            val structuralSl = when (candidateDir) {
                TradeDirection.LONG -> loLine
                TradeDirection.SHORT -> hiLine
                null -> null
            }
            val defaultTp = when (candidateDir) {
                TradeDirection.LONG -> bar.close + tpDist
                TradeDirection.SHORT -> bar.close - tpDist
                null -> null
            }

            result.add(
                ConfluenceBarSnapshot(
                    barIndex = barIndex,
                    candle = bar,
                    resistance = currentRes,
                    support = currentSup,
                    resVal = resVal,
                    supVal = supVal,
                    basis = basis,
                    prevBasis = prevBasis,
                    hiLine = hiLine,
                    loLine = loLine,
                    rawLong = rawLong,
                    rawShort = rawShort,
                    slDist = slDist,
                    tpDist = tpDist,
                    longOk = longOk,
                    shortOk = shortOk,
                    longArmedBefore = longArmedBefore,
                    shortArmedBefore = shortArmedBefore,
                    longArmedAfter = longArmed,
                    shortArmedAfter = shortArmed,
                    longFire = longFire,
                    shortFire = shortFire,
                    candidateDirection = candidateDir,
                    structuralSl = structuralSl,
                    defaultTp = defaultTp,
                    resUpdatesInWindow = resUpdateBars.size,
                    supUpdatesInWindow = supUpdateBars.size,
                    barsSinceLastRawLong = lastRawLongBar?.let { barIndex - it },
                    barsSinceLastRawShort = lastRawShortBar?.let { barIndex - it },
                    barsSinceLastSignal = lastSignalBar?.let { barIndex - it },
                    recentRiskRejectionsLast60 = riskRejectionBars.size,
                    consecutiveBarsOutside = consecutiveOutside,
                    firstOutsideBarSinceResBirth = firstOutsideSinceResBirth,
                    firstOutsideBarSinceSupBirth = firstOutsideSinceSupBirth
                )
            )

            if (rawLong) lastRawLongBar = barIndex
            if (rawShort) lastRawShortBar = barIndex
            if (longFire || shortFire) lastSignalBar = barIndex
            prevBasis = basis
        }

        return result
    }
}
