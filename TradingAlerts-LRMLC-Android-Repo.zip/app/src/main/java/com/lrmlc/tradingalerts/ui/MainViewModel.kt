package com.lrmlc.tradingalerts.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.lrmlc.tradingalerts.backup.ImportPreview
import com.lrmlc.tradingalerts.data.local.AssetStorageSummary
import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import com.lrmlc.tradingalerts.data.local.MlModelEntity
import com.lrmlc.tradingalerts.data.local.RecycleBinEntity
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.TrainingJobEntity
import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ChartStyle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.InstrumentInfo
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.ThresholdMode
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.data.remote.ConnectionTestReport
import com.lrmlc.tradingalerts.data.repository.DefaultWatchlistResolution
import com.lrmlc.tradingalerts.data.repository.DownloadProgressSnapshot
import com.lrmlc.tradingalerts.di.AppContainer
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.engine.ConfluenceEngine
import com.lrmlc.tradingalerts.ml.TrainingJobType
import com.lrmlc.tradingalerts.ml.TrainingStatusSnapshot
import com.lrmlc.tradingalerts.ml.TrainingWorker
import com.lrmlc.tradingalerts.service.MonitoringForegroundService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChartScreenState(
    val symbol: String = "",
    val candles: List<Candle> = emptyList(),
    val snapshots: List<ConfluenceBarSnapshot> = emptyList(),
    val signals: List<SignalCandidateEntity> = emptyList(),
    val activeTrade: SignalCandidateEntity? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    private val container: AppContainer,
    private val appContext: Context
) : ViewModel() {

    val settings: StateFlow<AppSettings> = container.settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val downloadProgress: StateFlow<DownloadProgressSnapshot> = container.historySyncManager.progress
    val trainingStatus: StateFlow<TrainingStatusSnapshot> = container.trainingOrchestrator.status
    val serviceRunning: StateFlow<Boolean> = MonitoringForegroundService.isServiceRunning
    val formingCandles: StateFlow<Map<String, Candle>> = container.liveFormingCandles.formingBySymbol

    val watchlist: StateFlow<List<WatchlistEntity>> = settings
        .flatMapLatest { s -> container.watchlistRepository.observeWatchlist(s.exchange, s.marketType) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recycleBin: StateFlow<List<RecycleBinEntity>> = settings
        .flatMapLatest { s -> container.watchlistRepository.observeRecycleBin(s.exchange, s.marketType) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeModels: StateFlow<List<MlModelEntity>> = settings
        .flatMapLatest { s -> container.database.mlModelDao().observeActiveModels(s.exchange.name, s.marketType.name) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentSignals: StateFlow<List<SignalCandidateEntity>> = settings
        .flatMapLatest { s -> container.database.signalCandidateDao().observeRecentSignals(s.exchange.name, s.marketType.name) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trainingLogs: StateFlow<List<TrainingLogEntity>> = settings
        .flatMapLatest { s -> container.database.trainingLogDao().observeLogs(s.exchange.name, s.marketType.name) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trainingJobs: StateFlow<List<TrainingJobEntity>> = container.database.trainingJobDao().observeRecentJobs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _connectionReport = MutableStateFlow<ConnectionTestReport?>(null)
    val connectionReport: StateFlow<ConnectionTestReport?> = _connectionReport.asStateFlow()

    private val _connectionTesting = MutableStateFlow(false)
    val connectionTesting: StateFlow<Boolean> = _connectionTesting.asStateFlow()

    private val _availableInstruments = MutableStateFlow<List<InstrumentInfo>>(emptyList())
    val availableInstruments: StateFlow<List<InstrumentInfo>> = _availableInstruments.asStateFlow()

    private val _defaultResolution = MutableStateFlow<DefaultWatchlistResolution?>(null)
    val defaultResolution: StateFlow<DefaultWatchlistResolution?> = _defaultResolution.asStateFlow()

    private val _storageSummary = MutableStateFlow<List<AssetStorageSummary>>(emptyList())
    val storageSummary: StateFlow<List<AssetStorageSummary>> = _storageSummary.asStateFlow()

    private val _uiBannerMessage = MutableStateFlow<String?>(null)
    val uiBannerMessage: StateFlow<String?> = _uiBannerMessage.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _chartState = MutableStateFlow(ChartScreenState())
    val chartState: StateFlow<ChartScreenState> = _chartState.asStateFlow()

    private val _importPreview = MutableStateFlow<ImportPreview?>(null)
    val importPreview: StateFlow<ImportPreview?> = _importPreview.asStateFlow()

    private var syncJob: Job? = null

    fun clearBannerMessage() {
        _uiBannerMessage.value = null
    }

    fun runConnectionTest() {
        viewModelScope.launch {
            _connectionTesting.value = true
            val s = container.settingsRepository.getSettings()
            val adapter = container.adapterFor(s.exchange)
            val report = container.connectionTester.runTest(adapter, s.marketType)
            _connectionReport.value = report
            _connectionTesting.value = false
        }
    }

    fun loadInstrumentsAndResolveDefaults() {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            val adapter = container.adapterFor(s.exchange)
            runCatching {
                val (instruments, _) = adapter.fetchUsdtInstruments(s.marketType)
                _availableInstruments.value = instruments
                val res = container.watchlistRepository.initializeDefaultsIfEmpty(s.exchange, s.marketType, instruments)
                _defaultResolution.value = res
            }.onFailure { e ->
                _uiBannerMessage.value = e.message ?: "Failed to load instrument list"
            }
        }
    }

    fun fetchInstrumentsForSearch() {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            val adapter = container.adapterFor(s.exchange)
            runCatching {
                val (instruments, _) = adapter.fetchUsdtInstruments(s.marketType)
                _availableInstruments.value = instruments
            }.onFailure { e ->
                _uiBannerMessage.value = e.message ?: "Could not fetch symbols"
            }
        }
    }

    fun startInitialHistoryAndTraining() {
        syncJob?.cancel()
        syncJob = viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            val adapter = container.adapterFor(s.exchange)
            val symbols = container.watchlistRepository.getWatchlist(s.exchange, s.marketType).map { it.symbol }
            val completed = container.historySyncManager.syncInitialHistory(
                adapter = adapter,
                marketType = s.marketType,
                symbols = symbols,
                warmupBars = s.engineConfig.windowLength
            )
            if (completed) {
                val job = container.trainingOrchestrator.enqueueJob(TrainingJobType.INITIAL, s.exchange, s.marketType)
                TrainingWorker.enqueueOneTime(appContext, job.jobId)
            }
        }
    }

    fun pauseHistoryDownload() {
        container.historySyncManager.requestPause()
        syncJob?.cancel()
    }

    fun resumeHistoryDownload() {
        startInitialHistoryAndTraining()
    }

    fun completeOnboarding(enableBackgroundMonitoring: Boolean) {
        viewModelScope.launch {
            container.settingsRepository.updateSettings {
                it.copy(
                    onboardingCompleted = true,
                    keepMonitoringInBackground = enableBackgroundMonitoring
                )
            }
            if (enableBackgroundMonitoring) {
                MonitoringForegroundService.start(appContext)
            }
        }
    }

    fun refreshWatchlist() {
        viewModelScope.launch {
            _isRefreshing.value = true
            val s = container.settingsRepository.getSettings()
            val adapter = container.adapterFor(s.exchange)
            runCatching {
                val tickers = adapter.fetch24hTickers(s.marketType)
                val list = container.watchlistRepository.getWatchlist(s.exchange, s.marketType)
                for (item in list) {
                    val t = tickers[item.symbol]
                    if (t != null) {
                        container.watchlistRepository.updateMarketSnapshot(
                            exchange = s.exchange,
                            marketType = s.marketType,
                            symbol = item.symbol,
                            lastPrice = t.lastPrice,
                            change24hPct = t.change24hPct,
                            lastCandleReceivedMs = null
                        )
                    }
                }
                container.historySyncManager.fillGapsForWatchlist(
                    adapter = adapter,
                    marketType = s.marketType,
                    symbols = list.map { it.symbol },
                    lookbackDays = 1
                )
            }.onFailure { e ->
                _uiBannerMessage.value = e.message ?: "Refresh failed"
            }
            _isRefreshing.value = false
        }
    }

    fun addAsset(symbol: String) {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            when (val res = container.watchlistRepository.addAsset(s.exchange, s.marketType, symbol)) {
                is com.lrmlc.tradingalerts.data.repository.WatchlistMutationResult.Error -> {
                    _uiBannerMessage.value = res.message
                }
                com.lrmlc.tradingalerts.data.repository.WatchlistMutationResult.Success -> {
                    // Fill missing history/gap for newly added asset
                    startInitialHistoryAndTraining()
                }
            }
        }
    }

    fun removeAsset(symbol: String) {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            container.watchlistRepository.removeAsset(s.exchange, s.marketType, symbol)
            container.notificationHelper.refreshPersistentNotification(s.exchange, s.marketType, s.keepMonitoringInBackground)
        }
    }

    fun restoreFromBin(symbol: String) {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            when (val res = container.watchlistRepository.restoreFromBin(s.exchange, s.marketType, symbol)) {
                is com.lrmlc.tradingalerts.data.repository.WatchlistMutationResult.Error -> _uiBannerMessage.value = res.message
                com.lrmlc.tradingalerts.data.repository.WatchlistMutationResult.Success -> startInitialHistoryAndTraining()
            }
        }
    }

    fun permanentlyDeleteFromBin(symbol: String) {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            container.watchlistRepository.permanentlyDeleteFromBin(s.exchange, s.marketType, symbol)
            refreshStorageSummary()
        }
    }

    fun setInPosition(symbol: String, inPosition: Boolean) {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            container.watchlistRepository.setInPosition(s.exchange, s.marketType, symbol, inPosition)
            if (!inPosition) {
                val active = container.database.signalCandidateDao()
                    .getActiveTradeForSymbol(s.exchange.name, s.marketType.name, symbol)
                if (active != null) {
                    container.database.signalCandidateDao().upsert(
                        active.copy(status = "CLOSED_MANUAL", exitTimeMs = System.currentTimeMillis())
                    )
                    container.watchlistRepository.updateMarketSnapshot(
                        exchange = s.exchange,
                        marketType = s.marketType,
                        symbol = symbol,
                        lastPrice = null,
                        change24hPct = null,
                        lastCandleReceivedMs = null,
                        activeDirection = null,
                        activeConfidence = null,
                        updateActiveFields = true
                    )
                }
            }
            container.notificationHelper.refreshPersistentNotification(s.exchange, s.marketType, s.keepMonitoringInBackground)
        }
    }

    fun setMuted(symbol: String, muted: Boolean) {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            container.watchlistRepository.setMuted(s.exchange, s.marketType, symbol, muted)
        }
    }

    fun openChart(symbol: String) {
        viewModelScope.launch {
            _chartState.value = ChartScreenState(symbol = symbol, isLoading = true)
            val s = container.settingsRepository.getSettings()
            runCatching {
                withContext(Dispatchers.Default) {
                    val now = System.currentTimeMillis()
                    val lookbackMs = (s.engineConfig.windowLength + 720L) * DayChunkCodec.MILLIS_PER_MINUTE
                    var candles = container.candleStore.loadCandles(s.exchange, s.marketType, symbol, now - lookbackMs, now)
                    if (candles.isEmpty()) {
                        val adapter = container.adapterFor(s.exchange)
                        val (fetched, _) = adapter.fetchKlines1m(s.marketType, symbol, limit = 500)
                        if (fetched.isNotEmpty()) {
                            container.candleStore.appendCandles(s.exchange, s.marketType, symbol, fetched)
                            candles = fetched
                        }
                    }
                    val engine = ConfluenceEngine(s.engineConfig)
                    val snapshots = engine.evaluateAll(candles)
                    val signals = container.database.signalCandidateDao()
                        .getAllForMarket(s.exchange.name, s.marketType.name)
                        .filter { it.symbol == symbol }
                        .sortedByDescending { it.signalTimeMs }
                    val active = signals.firstOrNull { it.status == "ACTIVE" }
                    ChartScreenState(
                        symbol = symbol,
                        candles = candles,
                        snapshots = snapshots,
                        signals = signals,
                        activeTrade = active,
                        isLoading = false
                    )
                }
            }.onSuccess { state ->
                _chartState.value = state
            }.onFailure { err ->
                _chartState.value = ChartScreenState(symbol = symbol, isLoading = false, errorMessage = err.message ?: "Failed to load chart")
            }
        }
    }

    fun updateManualSlTp(signalId: String, newSl: Double, newTp: Double) {
        viewModelScope.launch {
            val existing = container.database.signalCandidateDao().getById(signalId) ?: return@launch
            val updated = existing.copy(
                appliedSl = newSl,
                appliedTp = newTp,
                manualOverride = true,
                slAdjustmentNote = "Manual override by user.",
                tpAdjustmentNote = "Manual override by user."
            )
            container.database.signalCandidateDao().upsert(updated)
            openChart(existing.symbol)
            val s = container.settingsRepository.getSettings()
            container.notificationHelper.refreshPersistentNotification(s.exchange, s.marketType, s.keepMonitoringInBackground)
        }
    }

    fun resetSlTpToDefault(signalId: String) {
        viewModelScope.launch {
            val existing = container.database.signalCandidateDao().getById(signalId) ?: return@launch
            val updated = existing.copy(
                appliedSl = existing.structuralSl,
                appliedTp = existing.defaultTp,
                manualOverride = false,
                slAdjustmentNote = "Reset to structural trendline stop.",
                tpAdjustmentNote = "Reset to minimum take profit."
            )
            container.database.signalCandidateDao().upsert(updated)
            openChart(existing.symbol)
            val s = container.settingsRepository.getSettings()
            container.notificationHelper.refreshPersistentNotification(s.exchange, s.marketType, s.keepMonitoringInBackground)
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch {
            val prev = container.settingsRepository.getSettings()
            container.settingsRepository.updateSettings(transform)
            val next = container.settingsRepository.getSettings()

            if (prev.keepMonitoringInBackground != next.keepMonitoringInBackground) {
                if (next.keepMonitoringInBackground) {
                    MonitoringForegroundService.start(appContext)
                } else {
                    MonitoringForegroundService.stop(appContext)
                }
            }
            if (prev.exchange != next.exchange || prev.marketType != next.marketType) {
                // Switch market/exchange cleanly: resolve default watchlist if empty and sync only missing data
                loadInstrumentsAndResolveDefaults()
                refreshStorageSummary()
            }
        }
    }

    fun triggerTraining(type: TrainingJobType = TrainingJobType.MANUAL) {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            val job = container.trainingOrchestrator.enqueueJob(type, s.exchange, s.marketType)
            TrainingWorker.enqueueOneTime(appContext, job.jobId)
        }
    }

    fun pauseTraining() {
        container.trainingOrchestrator.requestPause()
    }

    fun resumeTraining() {
        viewModelScope.launch {
            val job = container.database.trainingJobDao().getNextResumableJob()
            if (job != null) {
                TrainingWorker.enqueueOneTime(appContext, job.jobId)
            } else {
                triggerTraining(TrainingJobType.MANUAL)
            }
        }
    }

    fun refreshStorageSummary() {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            _storageSummary.value = container.candleStore.getStorageSummary(s.exchange, s.marketType)
        }
    }

    fun clearAssetStorage(symbol: String) {
        viewModelScope.launch {
            val s = container.settingsRepository.getSettings()
            container.candleStore.deleteAssetCandles(s.exchange, s.marketType, symbol)
            container.database.syncProgressDao().deleteForSymbol(s.exchange.name, s.marketType.name, symbol)
            refreshStorageSummary()
        }
    }

    fun exportBackup(uri: Uri, includeCandles: Boolean) {
        viewModelScope.launch {
            runCatching {
                appContext.contentResolver.openOutputStream(uri)?.use { os ->
                    container.backupManager.exportToStream(os, includeCandles)
                } ?: throw IllegalStateException("Could not open output file")
            }.onSuccess {
                _uiBannerMessage.value = "Backup exported successfully."
            }.onFailure { e ->
                _uiBannerMessage.value = "Export failed: ${e.message}"
            }
        }
    }

    fun inspectImportUri(uri: Uri) {
        viewModelScope.launch {
            runCatching {
                appContext.contentResolver.openInputStream(uri)?.use { ins ->
                    container.backupManager.parseAndValidate(ins)
                } ?: throw IllegalStateException("Could not read selected file")
            }.onSuccess { preview ->
                _importPreview.value = preview
            }.onFailure { e ->
                _uiBannerMessage.value = "Invalid backup file: ${e.message}"
            }
        }
    }

    fun confirmImport() {
        val preview = _importPreview.value ?: return
        viewModelScope.launch {
            runCatching {
                container.backupManager.applyImport(preview, mergeInsteadOfReplace = true)
            }.onSuccess {
                _importPreview.value = null
                _uiBannerMessage.value = "Backup imported safely."
                refreshStorageSummary()
            }.onFailure { e ->
                _importPreview.value = null
                _uiBannerMessage.value = "Import failed safely (existing data untouched): ${e.message}"
            }
        }
    }

    fun dismissImportPreview() {
        _importPreview.value = null
    }

    class Factory(
        private val container: AppContainer,
        private val appContext: Context
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(container, appContext) as T
        }
    }
}
