package com.lrmlc.tradingalerts.ui.chart

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow

object ChartAxis {

    const val RIGHT_GAP_SLOTS = 7f

    private val timeOnlyFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.US)
    private val dateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd HH:mm", Locale.US)

    /**
     * Step width in pixels so that the newest visible bar center is at (count - 0.5) * stepX,
     * leaving exactly 7 * stepX empty slots on the right edge of the plot [U18].
     */
    fun plotStepX(plotWidth: Float, visibleCount: Int): Float {
        if (plotWidth <= 0f || visibleCount <= 0) return 0f
        return plotWidth / (visibleCount - 0.5f + RIGHT_GAP_SLOTS)
    }

    /**
     * X coordinate of candle center for [relIndex] = barIndex - startIdx.
     */
    fun indexToCenterX(relIndex: Int, stepX: Float): Float = (relIndex + 0.5f) * stepX

    /**
     * Inverse mapping from plot X coordinate to candle index in [startIdx, endIdx).
     */
    fun xToBarIndex(x: Float, startIdx: Int, endIdx: Int, stepX: Float): Int {
        val count = endIdx - startIdx
        if (count <= 0 || stepX <= 0f) return startIdx
        val rel = floor(x / stepX).toInt().coerceIn(0, count - 1)
        return startIdx + rel
    }

    /**
     * Returns 4..7 nice round tick values strictly within [minVal, maxVal].
     */
    fun computeNiceTicks(minVal: Double, maxVal: Double, desiredCount: Int = 5): List<Double> {
        if (!minVal.isFinite() || !maxVal.isFinite() || maxVal <= minVal) {
            return if (minVal.isFinite()) listOf(minVal) else emptyList()
        }
        val targetCount = desiredCount.coerceIn(3, 8)
        val range = maxVal - minVal
        val rawStep = range / (targetCount - 1).coerceAtLeast(1)
        var step = niceStep(rawStep)
        var ticks = collectTicks(minVal, maxVal, step)
        var attempts = 0
        while (ticks.size < 3 && attempts < 4) {
            step = niceStep(step * 0.45)
            ticks = collectTicks(minVal, maxVal, step)
            attempts++
        }
        if (ticks.size > 7) {
            step = niceStep(step * 1.9)
            val reduced = collectTicks(minVal, maxVal, step)
            if (reduced.size >= 3) ticks = reduced
        }
        return ticks
    }

    private fun niceStep(rough: Double): Double {
        if (rough <= 0.0 || !rough.isFinite()) return 1.0
        val exp = floor(log10(rough))
        val mag = 10.0.pow(exp)
        val frac = rough / mag
        val niceFrac = when {
            frac <= 1.0 -> 1.0
            frac <= 2.0 -> 2.0
            frac <= 2.5 -> 2.5
            frac <= 5.0 -> 5.0
            else -> 10.0
        }
        return niceFrac * mag
    }

    private fun collectTicks(minVal: Double, maxVal: Double, step: Double): List<Double> {
        if (step <= 0.0 || !step.isFinite()) return emptyList()
        val first = ceil(minVal / step - 1e-9) * step
        val out = ArrayList<Double>()
        var cur = first
        var guard = 0
        while (cur <= maxVal + step * 1e-6 && guard < 32) {
            val clean = if (abs(cur) < step * 1e-9) 0.0 else cur
            if (clean >= minVal - 1e-9 && clean <= maxVal + 1e-9) {
                out.add(clean.coerceIn(minVal, maxVal))
            }
            cur += step
            guard++
        }
        return out
    }

    fun formatAxisPrice(price: Double, precisionDigits: Int? = null): String {
        val decimals = precisionDigits ?: when {
            price >= 10_000 -> 1
            price >= 100 -> 2
            price >= 1 -> 3
            price >= 0.05 -> 4
            else -> 5
        }
        return String.format(Locale.US, "%.${decimals.coerceIn(0, 6)}f", price)
    }

    fun formatAxisTime(timeMs: Long, showDate: Boolean, zoneId: ZoneId = ZoneId.systemDefault()): String {
        val zdt = Instant.ofEpochMilli(timeMs).atZone(zoneId)
        return (if (showDate) dateTimeFormatter else timeOnlyFormatter).format(zdt)
    }
}
