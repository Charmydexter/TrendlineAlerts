package com.lrmlc.tradingalerts.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lrmlc.tradingalerts.data.model.AccentColor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

object LrmlcColors {
    // Dark palette with faint blue tint [U19]
    val CharcoalBase = Color(0xFF12151B)
    val CharcoalSurface = Color(0xFF1A1E26)
    val CharcoalElevated = Color(0xFF222733)
    val CharcoalBorder = Color(0xFF2C3342)
    val DarkOnSurface = Color(0xFFF3F6FA)
    val DarkOnSurfaceVariant = Color(0xFFA8B0C0)
    val DarkOnPrimary = Color(0xFF0D1117)

    // Light palette [U19]
    val LightBg = Color(0xFFF4F6FA)
    val LightSurface = Color(0xFFFFFFFF)
    val LightElevated = Color(0xFFE9EDF5)
    val LightBorder = Color(0xFFD5DBE7)
    val LightOnSurface = Color(0xFF111827)
    val LightOnSurfaceVariant = Color(0xFF4A5264)

    // Accents (Dark / Light) [U19]
    val AccentBlueDark = Color(0xFF4C8DFF)
    val AccentBlueLight = Color(0xFF2F6FE4)
    val AccentTealDark = Color(0xFF2DD4BF)
    val AccentTealLight = Color(0xFF0B7F75)
    val AccentVioletDark = Color(0xFF8B7CFF)
    val AccentVioletLight = Color(0xFF6A5AE0)
    val AccentAmberDark = Color(0xFFF5B83D)
    val AccentAmberLight = Color(0xFF9A6700)

    // Fixed semantic colors [U19]
    val LongGreen = Color(0xFF22C55E)
    val ShortRed = Color(0xFFEF4444)
    val NeutralGrey = Color(0xFF9CA3AF)

    val ResistanceFuchsia = Color(0xFFE879F9)
    val SupportLime = Color(0xFF84CC16)
    val BasisBlue = Color(0xFF3B82F6)
    val WarningAmber = Color(0xFFF59E0B)
}

object LrmlcShapes {
    val CardShape = RoundedCornerShape(16.dp)
    val ButtonShape = RoundedCornerShape(12.dp)
    val PanelShape = RoundedCornerShape(12.dp)
}

private val LrmlcTypography = Typography(
    titleLarge = TextStyle(
        fontSize = 21.sp,
        lineHeight = 26.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-0.2).sp
    ),
    titleMedium = TextStyle(
        fontSize = 16.sp,
        lineHeight = 22.sp,
        fontWeight = FontWeight.SemiBold
    ),
    labelMedium = TextStyle(
        fontSize = 12.sp,
        lineHeight = 16.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.8.sp
    ),
    labelSmall = TextStyle(
        fontSize = 11.sp,
        lineHeight = 14.sp,
        fontWeight = FontWeight.Medium
    )
)

fun accentColorValue(accent: AccentColor, darkTheme: Boolean): Color = when (accent) {
    AccentColor.BLUE -> if (darkTheme) LrmlcColors.AccentBlueDark else LrmlcColors.AccentBlueLight
    AccentColor.TEAL -> if (darkTheme) LrmlcColors.AccentTealDark else LrmlcColors.AccentTealLight
    AccentColor.VIOLET -> if (darkTheme) LrmlcColors.AccentVioletDark else LrmlcColors.AccentVioletLight
    AccentColor.AMBER -> if (darkTheme) LrmlcColors.AccentAmberDark else LrmlcColors.AccentAmberLight
}

fun paletteFor(darkTheme: Boolean, accent: AccentColor): ColorScheme {
    val primary = accentColorValue(accent, darkTheme)
    return if (darkTheme) {
        darkColorScheme(
            primary = primary,
            onPrimary = LrmlcColors.DarkOnPrimary,
            primaryContainer = primary.copy(alpha = 0.16f),
            onPrimaryContainer = primary,
            secondary = LrmlcColors.BasisBlue,
            onSecondary = Color.White,
            tertiary = LrmlcColors.LongGreen,
            onTertiary = LrmlcColors.DarkOnPrimary,
            background = LrmlcColors.CharcoalBase,
            onBackground = LrmlcColors.DarkOnSurface,
            surface = LrmlcColors.CharcoalSurface,
            onSurface = LrmlcColors.DarkOnSurface,
            surfaceVariant = LrmlcColors.CharcoalElevated,
            onSurfaceVariant = LrmlcColors.DarkOnSurfaceVariant,
            outline = LrmlcColors.CharcoalBorder,
            error = LrmlcColors.ShortRed,
            onError = Color.White
        )
    } else {
        lightColorScheme(
            primary = primary,
            onPrimary = Color.White,
            primaryContainer = primary.copy(alpha = 0.12f),
            onPrimaryContainer = primary,
            secondary = LrmlcColors.BasisBlue,
            onSecondary = Color.White,
            tertiary = LrmlcColors.LongGreen,
            onTertiary = Color.White,
            background = LrmlcColors.LightBg,
            onBackground = LrmlcColors.LightOnSurface,
            surface = LrmlcColors.LightSurface,
            onSurface = LrmlcColors.LightOnSurface,
            surfaceVariant = LrmlcColors.LightElevated,
            onSurfaceVariant = LrmlcColors.LightOnSurfaceVariant,
            outline = LrmlcColors.LightBorder,
            error = LrmlcColors.ShortRed,
            onError = Color.White
        )
    }
}

fun relativeLuminance(argb: Int): Double {
    fun linear(channel: Int): Double {
        val c = channel / 255.0
        return if (c <= 0.04045) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4)
    }
    val r = (argb ushr 16) and 0xFF
    val g = (argb ushr 8) and 0xFF
    val b = argb and 0xFF
    return 0.2126 * linear(r) + 0.7152 * linear(g) + 0.0722 * linear(b)
}

fun contrastRatio(fgArgb: Int, bgArgb: Int): Double {
    val l1 = relativeLuminance(fgArgb)
    val l2 = relativeLuminance(bgArgb)
    val lighter = max(l1, l2)
    val darker = min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)
}

fun contrastRatio(fg: Color, bg: Color): Double = contrastRatio(fg.toArgb(), bg.toArgb())

@Composable
fun cardBorderStroke(): BorderStroke = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)

@Composable
fun SectionHeaderLabel(
    text: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .height(14.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(MaterialTheme.colorScheme.primary)
        )
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun LrmlcTheme(
    darkTheme: Boolean = true,
    accentColor: AccentColor = AccentColor.BLUE,
    content: @Composable () -> Unit
) {
    val colorScheme = paletteFor(darkTheme = darkTheme, accent = accentColor)
    MaterialTheme(
        colorScheme = colorScheme,
        typography = LrmlcTypography
    ) {
        Surface(
            color = colorScheme.background,
            contentColor = colorScheme.onBackground
        ) {
            content()
        }
    }
}
