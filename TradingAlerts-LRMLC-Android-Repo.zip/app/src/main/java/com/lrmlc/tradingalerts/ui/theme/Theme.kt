package com.lrmlc.tradingalerts.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

object LrmlcColors {
    val CharcoalBase = Color(0xFF212121)
    val CharcoalSurface = Color(0xFF2A2A2A)
    val CharcoalElevated = Color(0xFF333333)
    val CharcoalBorder = Color(0xFF3E3E3E)

    val LightBg = Color(0xFFF6F7F9)
    val LightSurface = Color(0xFFFFFFFF)
    val LightElevated = Color(0xFFECEFF4)

    val LongGreen = Color(0xFF22C55E)
    val ShortRed = Color(0xFFEF4444)
    val NeutralGrey = Color(0xFF9CA3AF)

    val ResistanceFuchsia = Color(0xFFE879F9)
    val SupportLime = Color(0xFF84CC16)
    val BasisBlue = Color(0xFF3B82F6)
    val WarningAmber = Color(0xFFF59E0B)
}

private val DarkPalette = darkColorScheme(
    primary = Color(0xFFE5E7EB),
    onPrimary = Color(0xFF181818),
    secondary = LrmlcColors.BasisBlue,
    onSecondary = Color.White,
    tertiary = LrmlcColors.LongGreen,
    background = LrmlcColors.CharcoalBase,
    onBackground = Color.White,
    surface = LrmlcColors.CharcoalSurface,
    onSurface = Color.White,
    surfaceVariant = LrmlcColors.CharcoalElevated,
    onSurfaceVariant = Color(0xFFD1D5DB),
    outline = LrmlcColors.CharcoalBorder,
    error = LrmlcColors.ShortRed
)

private val LightPalette = lightColorScheme(
    primary = Color(0xFF212121),
    onPrimary = Color.White,
    secondary = LrmlcColors.BasisBlue,
    onSecondary = Color.White,
    tertiary = LrmlcColors.LongGreen,
    background = LrmlcColors.LightBg,
    onBackground = Color(0xFF111827),
    surface = LrmlcColors.LightSurface,
    onSurface = Color(0xFF111827),
    surfaceVariant = LrmlcColors.LightElevated,
    onSurfaceVariant = Color(0xFF4B5563),
    outline = Color(0xFFD1D5DB),
    error = LrmlcColors.ShortRed
)

@Composable
fun LrmlcTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val scheme = if (darkTheme) DarkPalette else LightPalette
    MaterialTheme(colorScheme = scheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = scheme.background,
            contentColor = scheme.onBackground,
            content = content
        )
    }
}
