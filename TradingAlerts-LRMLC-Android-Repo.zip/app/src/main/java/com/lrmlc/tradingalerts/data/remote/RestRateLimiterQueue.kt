package com.lrmlc.tradingalerts.data.remote

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlin.math.min
import kotlin.random.Random

enum class NetworkErrorKind {
    OFFLINE,
    BLOCKED_REGION,
    RATE_LIMITED,
    INVALID_SYMBOL,
    MALFORMED_RESPONSE,
    UPSTREAM_ERROR
}

class ExchangeApiException(
    val kind: NetworkErrorKind,
    val httpCode: Int? = null,
    override val message: String
) : IOException(message)

/**
 * Single global REST queue enforcing sequential requests, minimum inter-request spacing,
 * Retry-After/rate-limit header respect, and whole-queue exponential backoff on 429/418/403.
 */
class RestRateLimiterQueue(
    private val client: OkHttpClient,
    private val minSpacingMs: Long = 350L,
    private val baseBackoffMs: Long = 2_500L,
    private val maxBackoffMs: Long = 60_000L,
    private val maxRetries: Int = 3,
    private val clockMs: () -> Long = { System.currentTimeMillis() },
    private val sleeper: suspend (Long) -> Unit = { ms -> delay(ms) },
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    private val queueMutex = Mutex()
    private var lastRequestEndMs: Long = 0L
    private var pausedUntilMs: Long = 0L

    data class HttpResponsePayload(
        val code: Int,
        val body: String,
        val latencyMs: Long
    )

    suspend fun get(url: String): HttpResponsePayload = withContext(ioDispatcher) {
        queueMutex.withLock {
            var attempt = 0
            var lastException: ExchangeApiException? = null

            while (attempt <= maxRetries) {
                val now = clockMs()
                val waitForPause = (pausedUntilMs - now).coerceAtLeast(0L)
                val waitForSpacing = ((lastRequestEndMs + minSpacingMs) - (now + waitForPause)).coerceAtLeast(0L)
                val totalWait = waitForPause + waitForSpacing
                if (totalWait > 0L) {
                    sleeper(totalWait)
                }

                val req = Request.Builder()
                    .url(url)
                    .header("Accept", "application/json")
                    .header("User-Agent", "TradingAlertsLRMLC/1.0")
                    .get()
                    .build()

                val startNs = System.nanoTime()
                var shouldRetry = false
                try {
                    val payload: HttpResponsePayload? = client.newCall(req).execute().use { response ->
                    val latencyMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                    lastRequestEndMs = clockMs()
                    val code = response.code
                    val bodyStr = response.body?.string().orEmpty()

                    when {
                        code in 200..299 -> {
                            inspectSoftRateLimitHeaders(response)
                            HttpResponsePayload(code, bodyStr, latencyMs)
                        }
                        code == 429 || code == 418 || code == 403 -> {
                            val retryAfterMs = parseRetryAfterMs(response)
                            val kind = if (code == 403 && retryAfterMs == null && bodyStr.contains("region", ignoreCase = true)) {
                                NetworkErrorKind.BLOCKED_REGION
                            } else if (code == 403 && attempt >= maxRetries) {
                                NetworkErrorKind.BLOCKED_REGION
                            } else {
                                NetworkErrorKind.RATE_LIMITED
                            }
                            val backoff = computeBackoffMs(attempt, retryAfterMs)
                            pausedUntilMs = maxOf(pausedUntilMs, clockMs() + backoff)
                            lastException = ExchangeApiException(
                                kind = kind,
                                httpCode = code,
                                message = when (kind) {
                                    NetworkErrorKind.BLOCKED_REGION ->
                                        "Access blocked by exchange or region restrictions (HTTP $code)."
                                    NetworkErrorKind.RATE_LIMITED ->
                                        "Rate limited by exchange (HTTP $code). Queue paused for ${backoff}ms."
                                    else -> "HTTP $code"
                                }
                            )
                            if (attempt >= maxRetries) throw lastException!!
                            shouldRetry = true
                            null
                        }
                        code == 451 -> {
                            throw ExchangeApiException(
                                kind = NetworkErrorKind.BLOCKED_REGION,
                                httpCode = 451,
                                message = "Blocked in your region by the exchange (HTTP 451)."
                            )
                        }
                        code == 400 || code == 404 -> {
                            throw ExchangeApiException(
                                kind = NetworkErrorKind.INVALID_SYMBOL,
                                httpCode = code,
                                message = "Invalid symbol or request parameters (HTTP $code)."
                            )
                        }
                        else -> {
                            val retryAfterMs = parseRetryAfterMs(response)
                            lastException = ExchangeApiException(
                                kind = NetworkErrorKind.UPSTREAM_ERROR,
                                httpCode = code,
                                message = "Exchange returned HTTP $code."
                            )
                            if (code in 500..599 && attempt < maxRetries) {
                                val backoff = computeBackoffMs(attempt, retryAfterMs)
                                pausedUntilMs = maxOf(pausedUntilMs, clockMs() + backoff)
                                shouldRetry = true
                                null
                            } else {
                                throw lastException!!
                            }
                        }
                    }
                }
                if (payload != null) {
                    return@withLock payload
                }
                if (shouldRetry) {
                    attempt++
                    continue
                }
            } catch (e: ExchangeApiException) {
                if (e.kind == NetworkErrorKind.BLOCKED_REGION || e.kind == NetworkErrorKind.INVALID_SYMBOL) {
                    throw e
                }
                lastException = e
                if (attempt >= maxRetries) throw e
                attempt++
            } catch (e: UnknownHostException) {
                lastRequestEndMs = clockMs()
                throw ExchangeApiException(
                    kind = NetworkErrorKind.OFFLINE,
                    message = "Device appears offline or DNS failed (${e.message ?: "no host"})."
                )
            } catch (e: SocketTimeoutException) {
                lastRequestEndMs = clockMs()
                lastException = ExchangeApiException(
                    kind = NetworkErrorKind.OFFLINE,
                    message = "Connection timed out contacting the exchange."
                )
                if (attempt >= maxRetries) throw lastException!!
                val backoff = computeBackoffMs(attempt, null)
                pausedUntilMs = maxOf(pausedUntilMs, clockMs() + backoff)
                attempt++
                } catch (ce: CancellationException) {
                    throw ce
                } catch (e: IOException) {
                    lastRequestEndMs = clockMs()
                    throw ExchangeApiException(
                        kind = NetworkErrorKind.OFFLINE,
                        message = "Network error: ${e.message ?: "connection failed"}"
                    )
                }
            }
            throw lastException ?: ExchangeApiException(NetworkErrorKind.UPSTREAM_ERROR, message = "Request failed")
        }
    }

    private fun inspectSoftRateLimitHeaders(response: Response) {
        val bapiRemaining = response.header("X-Bapi-Limit-Status")?.toIntOrNull()
        val bapiResetMs = response.header("X-Bapi-Limit-Reset-Timestamp")?.toLongOrNull()
        if (bapiRemaining != null && bapiRemaining <= 2 && bapiResetMs != null) {
            val now = clockMs()
            if (bapiResetMs > now) {
                pausedUntilMs = maxOf(pausedUntilMs, min(bapiResetMs, now + 10_000L))
            }
        }
        val mbxWeight = response.header("X-MBX-USED-WEIGHT-1M")?.toIntOrNull()
        if (mbxWeight != null && mbxWeight >= 1000) {
            pausedUntilMs = maxOf(pausedUntilMs, clockMs() + 2_000L)
        }
    }

    private fun parseRetryAfterMs(response: Response): Long? {
        val header = response.header("Retry-After")?.trim() ?: return null
        val seconds = header.toLongOrNull() ?: return null
        return (seconds * 1000L).coerceIn(500L, maxBackoffMs)
    }

    private fun computeBackoffMs(attempt: Int, retryAfterMs: Long?): Long {
        val exp = (baseBackoffMs shl attempt.coerceAtMost(5)).coerceAtMost(maxBackoffMs)
        val jitter = Random.nextLong(100L, 650L)
        val computed = (exp + jitter).coerceAtMost(maxBackoffMs)
        return if (retryAfterMs != null) maxOf(computed, retryAfterMs) else computed
    }
}
