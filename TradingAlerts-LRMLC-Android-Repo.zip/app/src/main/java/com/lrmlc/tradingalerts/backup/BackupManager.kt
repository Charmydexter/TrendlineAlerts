package com.lrmlc.tradingalerts.backup

import android.util.Base64
import androidx.room.withTransaction
import com.lrmlc.tradingalerts.data.local.AppDatabase
import com.lrmlc.tradingalerts.data.local.CandleDayChunkEntity
import com.lrmlc.tradingalerts.data.local.MlModelEntity
import com.lrmlc.tradingalerts.data.local.RecycleBinEntity
import com.lrmlc.tradingalerts.data.local.SettingsRepository
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

@Serializable
data class BackupWatchlistItem(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val displayOrder: Int,
    val inPosition: Boolean,
    val inPositionUpdatedAtMs: Long,
    val muted: Boolean,
    val addedAtMs: Long
)

@Serializable
data class BackupRecycleBinItem(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val removedAtMs: Long
)

@Serializable
data class BackupMlModelItem(
    val modelKey: String,
    val modelKind: String,
    val exchange: String,
    val marketType: String,
    val symbol: String?,
    val version: Int,
    val trainedAtMs: Long,
    val sampleCount: Int,
    val threshold: Double,
    val brierScore: Double,
    val winRate: Double,
    val profitFactor: Double,
    val netExpectancy: Double,
    val maxDrawdown: Double,
    val modelJson: String,
    val isActive: Boolean
)

@Serializable
data class BackupSignalItem(
    val signalId: String,
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val direction: String,
    val signalTimeMs: Long,
    val barIndex: Int,
    val entryPrice: Double,
    val structuralSl: Double,
    val defaultTp: Double,
    val appliedSl: Double,
    val appliedTp: Double,
    val slAdjustmentNote: String?,
    val tpAdjustmentNote: String?,
    val manualOverride: Boolean,
    val pWin: Double?,
    val thresholdUsed: Double?,
    val modelWasTrained: Boolean,
    val accepted: Boolean,
    val status: String,
    val exitTimeMs: Long?,
    val exitPrice: Double?,
    val netReturnPct: Double?,
    val maePct: Double?,
    val mfePct: Double?,
    val label: Int?,
    val featuresJson: String,
    val topReasonsJson: String,
    val notified: Boolean
)

@Serializable
data class BackupTrainingLogItem(
    val timestampMs: Long,
    val exchange: String,
    val marketType: String,
    val jobType: String,
    val promoted: Boolean,
    val summary: String,
    val metricsJson: String
)

@Serializable
data class BackupCandleChunkItem(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val utcDayIndex: Long,
    val candleCount: Int,
    val minOpenTimeMs: Long,
    val maxOpenTimeMs: Long,
    val blobBase64: String
)

@Serializable
data class LrmlcBackupEnvelope(
    val magic: String = "LRMLC_BACKUP",
    val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
    val exportedAtMs: Long,
    val includesCandles: Boolean,
    val settings: AppSettings,
    val watchlist: List<BackupWatchlistItem>,
    val recycleBin: List<BackupRecycleBinItem>,
    val models: List<BackupMlModelItem>,
    val signals: List<BackupSignalItem>,
    val trainingLogs: List<BackupTrainingLogItem>,
    val candleChunks: List<BackupCandleChunkItem> = emptyList()
) {
    companion object {
        const val CURRENT_SCHEMA_VERSION = 1
    }
}

data class ImportPreview(
    val schemaVersion: Int,
    val exportedAtMs: Long,
    val watchlistCount: Int,
    val recycleBinCount: Int,
    val modelCount: Int,
    val signalCount: Int,
    val trainingLogCount: Int,
    val candleChunkCount: Int,
    val envelope: LrmlcBackupEnvelope
)

class BackupManager(
    private val db: AppDatabase,
    private val settingsRepository: SettingsRepository
) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    companion object {
        private const val MAX_DECOMPRESSED_BYTES = 128 * 1024 * 1024 // 128 MB zip-bomb safety cap
    }

    suspend fun buildEnvelope(includeCandles: Boolean): LrmlcBackupEnvelope = withContext(Dispatchers.IO) {
        val settings = settingsRepository.getSettings()
        val watchlist = db.watchlistDao().exportAll().map {
            BackupWatchlistItem(
                exchange = it.exchange,
                marketType = it.marketType,
                symbol = it.symbol,
                displayOrder = it.displayOrder,
                inPosition = it.inPosition,
                inPositionUpdatedAtMs = it.inPositionUpdatedAtMs,
                muted = it.muted,
                addedAtMs = it.addedAtMs
            )
        }
        val recycleBin = db.recycleBinDao().exportAll().map {
            BackupRecycleBinItem(it.exchange, it.marketType, it.symbol, it.removedAtMs)
        }
        val models = db.mlModelDao().exportAll().map {
            BackupMlModelItem(
                modelKey = it.modelKey,
                modelKind = it.modelKind,
                exchange = it.exchange,
                marketType = it.marketType,
                symbol = it.symbol,
                version = it.version,
                trainedAtMs = it.trainedAtMs,
                sampleCount = it.sampleCount,
                threshold = it.threshold,
                brierScore = it.brierScore,
                winRate = it.winRate,
                profitFactor = it.profitFactor,
                netExpectancy = it.netExpectancy,
                maxDrawdown = it.maxDrawdown,
                modelJson = it.modelJson,
                isActive = it.isActive
            )
        }
        val signals = db.signalCandidateDao().exportAll().map {
            BackupSignalItem(
                signalId = it.signalId,
                exchange = it.exchange,
                marketType = it.marketType,
                symbol = it.symbol,
                direction = it.direction,
                signalTimeMs = it.signalTimeMs,
                barIndex = it.barIndex,
                entryPrice = it.entryPrice,
                structuralSl = it.structuralSl,
                defaultTp = it.defaultTp,
                appliedSl = it.appliedSl,
                appliedTp = it.appliedTp,
                slAdjustmentNote = it.slAdjustmentNote,
                tpAdjustmentNote = it.tpAdjustmentNote,
                manualOverride = it.manualOverride,
                pWin = it.pWin,
                thresholdUsed = it.thresholdUsed,
                modelWasTrained = it.modelWasTrained,
                accepted = it.accepted,
                status = it.status,
                exitTimeMs = it.exitTimeMs,
                exitPrice = it.exitPrice,
                netReturnPct = it.netReturnPct,
                maePct = it.maePct,
                mfePct = it.mfePct,
                label = it.label,
                featuresJson = it.featuresJson,
                topReasonsJson = it.topReasonsJson,
                notified = it.notified
            )
        }
        val logs = db.trainingLogDao().exportAll().map {
            BackupTrainingLogItem(it.timestampMs, it.exchange, it.marketType, it.jobType, it.promoted, it.summary, it.metricsJson)
        }
        val chunks = if (includeCandles) {
            db.candleChunkDao().exportAllChunks().map {
                BackupCandleChunkItem(
                    exchange = it.exchange,
                    marketType = it.marketType,
                    symbol = it.symbol,
                    utcDayIndex = it.utcDayIndex,
                    candleCount = it.candleCount,
                    minOpenTimeMs = it.minOpenTimeMs,
                    maxOpenTimeMs = it.maxOpenTimeMs,
                    blobBase64 = java.util.Base64.getEncoder().encodeToString(it.blob)
                )
            }
        } else {
            emptyList()
        }

        LrmlcBackupEnvelope(
            exportedAtMs = System.currentTimeMillis(),
            includesCandles = includeCandles,
            settings = settings,
            watchlist = watchlist,
            recycleBin = recycleBin,
            models = models,
            signals = signals,
            trainingLogs = logs,
            candleChunks = chunks
        )
    }

    suspend fun exportToStream(outputStream: OutputStream, includeCandles: Boolean): LrmlcBackupEnvelope =
        withContext(Dispatchers.IO) {
            val envelope = buildEnvelope(includeCandles)
            val jsonText = json.encodeToString(envelope)
            GZIPOutputStream(outputStream).use { gzip ->
                gzip.write(jsonText.toByteArray(Charsets.UTF_8))
                gzip.finish()
            }
            envelope
        }

    suspend fun parseAndValidate(inputStream: InputStream): ImportPreview = withContext(Dispatchers.IO) {
        val rawBytes = inputStream.readBytes()
        val decompressed = decompressIfGzipped(rawBytes)
        val text = decompressed.toString(Charsets.UTF_8)
        val decoded = runCatching { json.decodeFromString<LrmlcBackupEnvelope>(text) }
            .getOrElse { throw IllegalArgumentException("Invalid backup file format: ${it.message}") }

        if (decoded.magic != "LRMLC_BACKUP") {
            throw IllegalArgumentException("Unrecognized backup header.")
        }
        if (decoded.schemaVersion <= 0 || decoded.schemaVersion > LrmlcBackupEnvelope.CURRENT_SCHEMA_VERSION) {
            throw IllegalArgumentException("Unsupported backup schema version ${decoded.schemaVersion}.")
        }
        val migrated = migrateIfNeeded(decoded)
        // Validate base64 blobs before previewing
        for (chunk in migrated.candleChunks) {
            val decodedBytes = decodeBase64Compat(chunk.blobBase64)
            if (decodedBytes.isEmpty()) {
                throw IllegalArgumentException("Corrupted candle chunk payload for ${chunk.symbol}.")
            }
        }

        ImportPreview(
            schemaVersion = migrated.schemaVersion,
            exportedAtMs = migrated.exportedAtMs,
            watchlistCount = migrated.watchlist.size,
            recycleBinCount = migrated.recycleBin.size,
            modelCount = migrated.models.size,
            signalCount = migrated.signals.size,
            trainingLogCount = migrated.trainingLogs.size,
            candleChunkCount = migrated.candleChunks.size,
            envelope = migrated
        )
    }

    suspend fun applyImport(preview: ImportPreview, mergeInsteadOfReplace: Boolean = true) =
        withContext(Dispatchers.IO) {
            val env = preview.envelope
            db.withTransaction {
                if (env.watchlist.isNotEmpty()) {
                    val items = env.watchlist.map {
                        WatchlistEntity(
                            exchange = it.exchange,
                            marketType = it.marketType,
                            symbol = it.symbol,
                            displayOrder = it.displayOrder,
                            inPosition = it.inPosition,
                            inPositionUpdatedAtMs = it.inPositionUpdatedAtMs,
                            muted = it.muted,
                            addedAtMs = it.addedAtMs
                        )
                    }
                    db.watchlistDao().upsertAll(items)
                }
                if (env.recycleBin.isNotEmpty()) {
                    db.recycleBinDao().upsertAll(
                        env.recycleBin.map {
                            RecycleBinEntity(it.exchange, it.marketType, it.symbol, it.removedAtMs)
                        }
                    )
                }
                if (env.models.isNotEmpty()) {
                    db.mlModelDao().upsertAll(
                        env.models.map {
                            MlModelEntity(
                                modelKey = it.modelKey,
                                modelKind = it.modelKind,
                                exchange = it.exchange,
                                marketType = it.marketType,
                                symbol = it.symbol,
                                version = it.version,
                                trainedAtMs = it.trainedAtMs,
                                sampleCount = it.sampleCount,
                                threshold = it.threshold,
                                brierScore = it.brierScore,
                                winRate = it.winRate,
                                profitFactor = it.profitFactor,
                                netExpectancy = it.netExpectancy,
                                maxDrawdown = it.maxDrawdown,
                                modelJson = it.modelJson,
                                isActive = it.isActive
                            )
                        }
                    )
                }
                if (env.signals.isNotEmpty()) {
                    db.signalCandidateDao().upsertAll(
                        env.signals.map {
                            SignalCandidateEntity(
                                signalId = it.signalId,
                                exchange = it.exchange,
                                marketType = it.marketType,
                                symbol = it.symbol,
                                direction = it.direction,
                                signalTimeMs = it.signalTimeMs,
                                barIndex = it.barIndex,
                                entryPrice = it.entryPrice,
                                structuralSl = it.structuralSl,
                                defaultTp = it.defaultTp,
                                appliedSl = it.appliedSl,
                                appliedTp = it.appliedTp,
                                slAdjustmentNote = it.slAdjustmentNote,
                                tpAdjustmentNote = it.tpAdjustmentNote,
                                manualOverride = it.manualOverride,
                                pWin = it.pWin,
                                thresholdUsed = it.thresholdUsed,
                                modelWasTrained = it.modelWasTrained,
                                accepted = it.accepted,
                                status = it.status,
                                exitTimeMs = it.exitTimeMs,
                                exitPrice = it.exitPrice,
                                netReturnPct = it.netReturnPct,
                                maePct = it.maePct,
                                mfePct = it.mfePct,
                                label = it.label,
                                featuresJson = it.featuresJson,
                                topReasonsJson = it.topReasonsJson,
                                notified = it.notified
                            )
                        }
                    )
                }
                if (!mergeInsteadOfReplace || env.trainingLogs.isNotEmpty()) {
                    db.trainingLogDao().insertAll(
                        env.trainingLogs.map {
                            TrainingLogEntity(
                                timestampMs = it.timestampMs,
                                exchange = it.exchange,
                                marketType = it.marketType,
                                jobType = it.jobType,
                                promoted = it.promoted,
                                summary = it.summary,
                                metricsJson = it.metricsJson
                            )
                        }
                    )
                }
                if (env.candleChunks.isNotEmpty()) {
                    val chunks = env.candleChunks.map { c ->
                        val bytes = decodeBase64Compat(c.blobBase64)
                        CandleDayChunkEntity(
                            exchange = c.exchange,
                            marketType = c.marketType,
                            symbol = c.symbol,
                            utcDayIndex = c.utcDayIndex,
                            candleCount = c.candleCount,
                            minOpenTimeMs = c.minOpenTimeMs,
                            maxOpenTimeMs = c.maxOpenTimeMs,
                            byteSize = bytes.size,
                            blob = bytes
                        )
                    }
                    db.candleChunkDao().upsertChunks(chunks)
                }
            }
            settingsRepository.setSettings(env.settings)
        }

    private fun migrateIfNeeded(env: LrmlcBackupEnvelope): LrmlcBackupEnvelope {
        // Version 1 is current; future versions migrate step-by-step here
        return env
    }

    private fun decompressIfGzipped(bytes: ByteArray): ByteArray {
        val isGzip = bytes.size >= 2 && bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()
        if (!isGzip) return bytes
        GZIPInputStream(ByteArrayInputStream(bytes)).use { gzip ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            var total = 0
            while (true) {
                val n = gzip.read(buf)
                if (n <= 0) break
                total += n
                if (total > MAX_DECOMPRESSED_BYTES) {
                    throw IllegalArgumentException("Backup file exceeds maximum safe decompressed size.")
                }
                out.write(buf, 0, n)
            }
            return out.toByteArray()
        }
    }

    private fun decodeBase64Compat(str: String): ByteArray {
        return try {
            java.util.Base64.getDecoder().decode(str)
        } catch (_: IllegalArgumentException) {
            Base64.decode(str, Base64.DEFAULT)
        }
    }
}
