package com.lrmlc.tradingalerts.data.repository

import com.lrmlc.tradingalerts.data.local.AssetStorageSummary
import com.lrmlc.tradingalerts.data.local.CandleChunkDao
import com.lrmlc.tradingalerts.data.local.CandleDayChunkEntity
import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import com.lrmlc.tradingalerts.data.local.GapDetector
import com.lrmlc.tradingalerts.data.local.TimeGap
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class CandleStoreRepository(
    private val chunkDao: CandleChunkDao
) {
    private val writeMutex = Mutex()

    suspend fun appendCandles(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        candles: List<Candle>
    ) = withContext(Dispatchers.IO) {
        if (candles.isEmpty()) return@withContext
        val byDay = candles.groupBy { DayChunkCodec.utcDayIndexOf(it.openTimeMs) }
        writeMutex.withLock {
            val entities = ArrayList<CandleDayChunkEntity>(byDay.size)
            for ((dayIdx, dayCandles) in byDay) {
                val existing = chunkDao.getChunk(exchange.name, marketType.name, symbol, dayIdx)
                val encoded = DayChunkCodec.mergeDay(dayIdx, existing?.blob, dayCandles)
                entities.add(
                    CandleDayChunkEntity(
                        exchange = exchange.name,
                        marketType = marketType.name,
                        symbol = symbol,
                        utcDayIndex = dayIdx,
                        candleCount = encoded.candleCount,
                        minOpenTimeMs = encoded.minOpenTimeMs,
                        maxOpenTimeMs = encoded.maxOpenTimeMs,
                        byteSize = encoded.blob.size,
                        blob = encoded.blob
                    )
                )
            }
            chunkDao.upsertChunks(entities)
        }
    }

    suspend fun loadCandles(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        startOpenTimeMs: Long,
        endOpenTimeMs: Long
    ): List<Candle> = withContext(Dispatchers.IO) {
        if (endOpenTimeMs < startOpenTimeMs) return@withContext emptyList()
        val startDay = DayChunkCodec.utcDayIndexOf(startOpenTimeMs)
        val endDay = DayChunkCodec.utcDayIndexOf(endOpenTimeMs)
        val chunks = chunkDao.getChunksInRange(exchange.name, marketType.name, symbol, startDay, endDay)
        if (chunks.isEmpty()) return@withContext emptyList()
        val out = ArrayList<Candle>(chunks.sumOf { it.candleCount })
        for (chunk in chunks) {
            val decoded = DayChunkCodec.decodeDay(chunk.utcDayIndex, chunk.blob)
            for (c in decoded) {
                if (c.openTimeMs in startOpenTimeMs..endOpenTimeMs) {
                    out.add(c)
                }
            }
        }
        out.sortBy { it.openTimeMs }
        out
    }

    suspend fun loadAllCandles(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String
    ): List<Candle> = withContext(Dispatchers.IO) {
        val chunks = chunkDao.getAllChunksForAsset(exchange.name, marketType.name, symbol)
        if (chunks.isEmpty()) return@withContext emptyList()
        val out = ArrayList<Candle>(chunks.sumOf { it.candleCount })
        for (chunk in chunks) {
            out.addAll(DayChunkCodec.decodeDay(chunk.utcDayIndex, chunk.blob))
        }
        out.sortBy { it.openTimeMs }
        out
    }

    suspend fun detectGaps(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        startOpenTimeMs: Long,
        endOpenTimeMs: Long
    ): List<TimeGap> = withContext(Dispatchers.IO) {
        val alignedStart = GapDetector.floorToMinute(startOpenTimeMs)
        val alignedEnd = GapDetector.floorToMinute(endOpenTimeMs)
        if (alignedEnd < alignedStart) return@withContext emptyList()

        val startDay = DayChunkCodec.utcDayIndexOf(alignedStart)
        val endDay = DayChunkCodec.utcDayIndexOf(alignedEnd)
        val dayCountList = chunkDao.getDayCounts(exchange.name, marketType.name, symbol, startDay, endDay)
        val dayCounts = dayCountList.associate { it.utcDayIndex to it.candleCount }
        val incompleteDays = GapDetector.findIncompleteOrMissingDays(alignedStart, alignedEnd, dayCounts)
        if (incompleteDays.isEmpty()) return@withContext emptyList()

        val stored = loadCandles(exchange, marketType, symbol, alignedStart, alignedEnd)
        GapDetector.findMissingRanges(alignedStart, alignedEnd, stored)
    }

    suspend fun trimOlderThanRetention(retentionDays: Int, nowMs: Long = System.currentTimeMillis()): Int =
        withContext(Dispatchers.IO) {
            val clamped = retentionDays.coerceIn(7, 90)
            val minAllowedMs = nowMs - clamped * DayChunkCodec.MILLIS_PER_DAY
            val minAllowedDay = DayChunkCodec.utcDayIndexOf(minAllowedMs)
            writeMutex.withLock {
                chunkDao.trimOlderThan(minAllowedDay)
            }
        }

    suspend fun getStorageSummary(exchange: ExchangeId, marketType: MarketType): List<AssetStorageSummary> =
        withContext(Dispatchers.IO) {
            chunkDao.getStorageSummary(exchange.name, marketType.name)
        }

    /**
     * "EXCHANGE|MARKET|SYMBOL" keys of master (market-context) assets whose history must survive a watchlist
     * removal. Updated by MarketContextManager whenever the master slots change.
     */
    @Volatile
    var protectedKeys: Set<String> = emptySet()

    fun isProtected(exchange: ExchangeId, marketType: MarketType, symbol: String): Boolean =
        protectedKeys.contains("${exchange.name}|${marketType.name}|$symbol")

    /** Deletes an asset's candles. Master-asset history is skipped unless [force] is set. */
    suspend fun deleteAssetCandles(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        force: Boolean = false
    ) = withContext(Dispatchers.IO) {
        if (!force && isProtected(exchange, marketType, symbol)) return@withContext
        writeMutex.withLock {
            chunkDao.deleteAllForAsset(exchange.name, marketType.name, symbol)
        }
    }

    /** Deletes the oldest day-chunks of one asset (everything before [beforeDay]). */
    suspend fun deleteAssetBeforeDay(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        beforeDay: Long
    ) = withContext(Dispatchers.IO) {
        writeMutex.withLock {
            chunkDao.deleteAssetBeforeDay(exchange.name, marketType.name, symbol, beforeDay)
        }
    }

    suspend fun countStoredDays(exchange: ExchangeId, marketType: MarketType, symbol: String): Int =
        withContext(Dispatchers.IO) {
            chunkDao.getDayCounts(exchange.name, marketType.name, symbol, 0L, Long.MAX_VALUE / 4).size
        }
}
