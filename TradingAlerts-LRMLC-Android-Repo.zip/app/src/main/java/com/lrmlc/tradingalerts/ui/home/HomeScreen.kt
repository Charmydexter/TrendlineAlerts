package com.lrmlc.tradingalerts.ui.home

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.lrmlc.tradingalerts.R
import com.lrmlc.tradingalerts.data.local.MlModelEntity
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.DefaultWatchlist
import com.lrmlc.tradingalerts.data.model.InstrumentInfo
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.data.repository.DownloadProgressSnapshot
import com.lrmlc.tradingalerts.ml.TrainingStatusSnapshot
import com.lrmlc.tradingalerts.service.PersistentNotificationFormatter
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import com.lrmlc.tradingalerts.ui.theme.LrmlcShapes
import com.lrmlc.tradingalerts.ui.theme.cardBorderStroke
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs

private val AvatarPalette = listOf(
    Color(0xFF4C8DFF),
    Color(0xFF2DD4BF),
    Color(0xFF8B7CFF),
    Color(0xFFF5B83D),
    Color(0xFF22C55E),
    Color(0xFFEC4899)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    settings: AppSettings,
    watchlist: List<WatchlistEntity>,
    formingCandles: Map<String, Candle>,
    activeModels: List<MlModelEntity>,
    activeTradeBySymbol: Map<String, SignalCandidateEntity>,
    lastAlertBySymbol: Map<String, SignalCandidateEntity>,
    recentSignals: List<SignalCandidateEntity>,
    downloadProgress: DownloadProgressSnapshot,
    trainingStatus: TrainingStatusSnapshot,
    serviceRunning: Boolean,
    isRefreshing: Boolean,
    availableInstruments: List<InstrumentInfo>,
    bannerMessage: String?,
    onRefresh: () -> Unit,
    onOpenChart: (String) -> Unit,
    onToggleInPosition: (String, Boolean) -> Unit,
    onOpenAddSearch: () -> Unit,
    onAddAsset: (String) -> Unit,
    onDismissBanner: () -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var confirmCloseSymbol by remember { mutableStateOf<String?>(null) }

    // Single screen-level 1s ticker for header feed status & outcome ages [U21]
    val nowMs by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(1_000L)
            value = System.currentTimeMillis()
        }
    }
    val feedStatus = remember(watchlist, nowMs) { computeFeedStatus(watchlist, nowMs) }
    val sortedWatchlist = remember(watchlist, recentSignals) {
        sortWatchlistByRecentAlert(watchlist, recentSignals)
    }
    val sortedKey = remember(sortedWatchlist) { sortedWatchlist.map { it.symbol } }
    val listState = rememberLazyListState()
    LaunchedEffect(sortedKey) {
        if (listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0 && sortedWatchlist.isNotEmpty()) {
            listState.scrollToItem(0)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(R.drawable.ic_brand_logo),
                                contentDescription = "Trading Alerts LRMLC mark",
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text("Trading Alerts (LRMLC)", style = MaterialTheme.typography.titleLarge)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val feedDot = when {
                                    feedStatus.isOk -> LrmlcColors.LongGreen
                                    feedStatus.isStale -> LrmlcColors.WarningAmber
                                    else -> LrmlcColors.NeutralGrey
                                }
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(feedDot)
                                )
                                Text(
                                    "${settings.exchange.displayName} ${settings.marketType.displayName} · ${watchlist.size}/${DefaultWatchlist.MAX_WATCHLIST_SIZE} · ${feedStatus.label}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh watchlist")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            if (watchlist.size < DefaultWatchlist.MAX_WATCHLIST_SIZE) {
                FloatingActionButton(
                    onClick = {
                        onOpenAddSearch()
                        showAddDialog = true
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = LrmlcShapes.ButtonShape
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add asset to watchlist")
                }
            }
        }
    ) { innerPadding ->
        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = onRefresh,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "status_banner") {
                    StatusBannerCard(
                        activeModels = activeModels,
                        downloadProgress = downloadProgress,
                        trainingStatus = trainingStatus,
                        serviceRunning = serviceRunning,
                        bannerMessage = bannerMessage,
                        onDismissBanner = onDismissBanner
                    )
                }

                if (sortedWatchlist.isEmpty()) {
                    item(key = "empty_watchlist") {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = LrmlcShapes.CardShape,
                            border = cardBorderStroke()
                        ) {
                            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("No watchlist assets yet", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Tap + to add any USDT pair on ${settings.exchange.displayName} ${settings.marketType.displayName}.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                items(sortedWatchlist, key = { "${it.exchange}_${it.marketType}_${it.symbol}" }) { item ->
                    val forming = formingCandles[item.symbol]
                    val activeTrade = activeTradeBySymbol[item.symbol]
                    val lastAlert = lastAlertBySymbol[item.symbol]
                    WatchlistRowCard(
                        item = item,
                        livePrice = forming?.close ?: item.lastPrice,
                        activeTrade = activeTrade,
                        lastAlert = lastAlert,
                        nowMs = nowMs,
                        modifier = Modifier.animateItem(),
                        onClick = { onOpenChart(item.symbol) },
                        onToggleInPosition = { newInPos ->
                            if (!newInPos && activeTrade != null) {
                                confirmCloseSymbol = item.symbol
                            } else {
                                onToggleInPosition(item.symbol, newInPos)
                            }
                        }
                    )
                }
                item(key = "bottom_spacer") { Spacer(Modifier.height(72.dp)) }
            }
        }
    }

    confirmCloseSymbol?.let { sym ->
        AlertDialog(
            onDismissRequest = { confirmCloseSymbol = null },
            title = { Text("Turn Off In Position (${sym.stripUsdtSuffix()})?") },
            text = { Text("This will mark the alert as closed manually.") },
            confirmButton = {
                Button(
                    onClick = {
                        confirmCloseSymbol = null
                        onToggleInPosition(sym, false)
                    },
                    shape = LrmlcShapes.ButtonShape
                ) { Text("Close Alert") }
            },
            dismissButton = {
                TextButton(onClick = { confirmCloseSymbol = null }) { Text("Cancel") }
            }
        )
    }

    if (showAddDialog) {
        val currentSet = remember(watchlist) { watchlist.map { it.symbol }.toHashSet() }
        val filtered = remember(availableInstruments, searchQuery, currentSet) {
            val q = searchQuery.trim().uppercase()
            availableInstruments
                .filter { !currentSet.contains(it.symbol) }
                .filter { q.isBlank() || it.baseAsset.contains(q) || it.symbol.contains(q) }
                .take(40)
        }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add USDT Asset (${watchlist.size}/${DefaultWatchlist.MAX_WATCHLIST_SIZE})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search symbol (e.g. BTC, ETH, AVAX)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    LazyColumn(modifier = Modifier.height(260.dp)) {
                        items(filtered, key = { it.symbol }) { inst ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onAddAsset(inst.symbol)
                                        showAddDialog = false
                                    }
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(inst.baseAsset, fontWeight = FontWeight.SemiBold)
                                Text(inst.marketType.displayName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun StatusBannerCard(
    activeModels: List<MlModelEntity>,
    downloadProgress: DownloadProgressSnapshot,
    trainingStatus: TrainingStatusSnapshot,
    serviceRunning: Boolean,
    bannerMessage: String?,
    onDismissBanner: () -> Unit
) {
    val globalModel = activeModels.firstOrNull { it.modelKind == "GLOBAL" }
    Card(
        modifier = Modifier.animateContentSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = LrmlcShapes.CardShape,
        border = cardBorderStroke()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (globalModel != null) {
                        "Model: Active (${globalModel.sampleCount} samples · ≥${(globalModel.threshold * 100).toInt()}%)"
                    } else {
                        "Unfiltered – model not trained yet"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = if (serviceRunning) "Live ON" else "Live OFF",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (serviceRunning) LrmlcColors.LongGreen else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (downloadProgress.isRunning) {
                Text(downloadProgress.statusMessage, style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(progress = { downloadProgress.progressFraction }, modifier = Modifier.fillMaxWidth())
            }
            if (trainingStatus.isRunning) {
                Text(trainingStatus.stageMessage, style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(progress = { trainingStatus.progressPct / 100f }, modifier = Modifier.fillMaxWidth())
            }
            bannerMessage?.let { msg ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(msg, style = MaterialTheme.typography.bodySmall, color = LrmlcColors.WarningAmber, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismissBanner) { Text("OK") }
                }
            }
        }
    }
}

@Composable
private fun WatchlistRowCard(
    item: WatchlistEntity,
    livePrice: Double?,
    activeTrade: SignalCandidateEntity?,
    lastAlert: SignalCandidateEntity?,
    nowMs: Long,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onToggleInPosition: (Boolean) -> Unit
) {
    val cleanSymbol = item.symbol.stripUsdtSuffix()
    val hasActive = activeTrade != null || item.activeDirection == "LONG" || item.activeDirection == "SHORT"
    val activeDir = activeTrade?.direction ?: item.activeDirection
    val dotColor = when (activeDir) {
        "LONG" -> LrmlcColors.LongGreen
        "SHORT" -> LrmlcColors.ShortRed
        else -> LrmlcColors.NeutralGrey
    }
    val statusDesc = when (activeDir) {
        "LONG" -> "Active Long signal"
        "SHORT" -> "Active Short signal"
        else -> "No active signal"
    }
    val avatarColor = AvatarPalette[abs(item.symbol.hashCode()) % AvatarPalette.size]
    val slTp = formatSlTpLine(activeTrade)
    val tnumStyle = TextStyle(fontFamily = FontFamily.Monospace, fontFeatureSettings = "tnum")

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = LrmlcShapes.CardShape,
        border = cardBorderStroke()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (hasActive || item.inPosition) {
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(54.dp)
                        .background(MaterialTheme.colorScheme.primary)
                )
            }
            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Hash-tinted circular symbol avatar + small status dot
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(avatarColor.copy(alpha = 0.16f))
                        .semantics { contentDescription = statusDesc },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = cleanSymbol.take(2),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = avatarColor
                    )
                    if (hasActive) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(dotColor)
                        )
                    }
                }
                Spacer(Modifier.width(11.dp))

                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = cleanSymbol,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (activeDir == "LONG" || activeDir == "SHORT") {
                            val conf = activeTrade?.pWin ?: item.activeConfidence
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(dotColor.copy(alpha = 0.16f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = if (activeDir == "LONG") Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                    contentDescription = activeDir,
                                    tint = dotColor,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = activeDir + (conf?.let { " ${(it * 100).toInt()}%" } ?: ""),
                                    style = MaterialTheme.typography.labelSmall.merge(tnumStyle),
                                    color = dotColor,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        } else if (lastAlert != null) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = formatOutcomeChipText(lastAlert, nowMs),
                                    style = MaterialTheme.typography.labelSmall.merge(tnumStyle),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    // Second line strictly reserved for active SL/TP or '--' [U21]
                    if (!slTp.isActive) {
                        Text(
                            text = slTp.combinedText,
                            style = MaterialTheme.typography.labelSmall.merge(tnumStyle),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    } else {
                        val mutedColor = MaterialTheme.colorScheme.onSurfaceVariant
                        Text(
                            text = buildAnnotatedString {
                                withStyle(SpanStyle(color = mutedColor)) { append("SL ") }
                                withStyle(SpanStyle(color = LrmlcColors.ShortRed, fontWeight = FontWeight.SemiBold)) { append(slTp.slText) }
                                withStyle(SpanStyle(color = mutedColor)) { append(" · TP ") }
                                withStyle(SpanStyle(color = LrmlcColors.LongGreen, fontWeight = FontWeight.SemiBold)) { append(slTp.tpText) }
                            },
                            style = MaterialTheme.typography.labelSmall.merge(tnumStyle),
                            maxLines = 1
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(end = 10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(
                        text = livePrice?.let { PersistentNotificationFormatter.formatPrice(it) } ?: "--",
                        style = MaterialTheme.typography.bodyLarge.merge(tnumStyle),
                        fontWeight = FontWeight.Bold
                    )
                    item.change24hPct?.let { pct ->
                        val chgColor = if (pct >= 0) LrmlcColors.LongGreen else LrmlcColors.ShortRed
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(chgColor.copy(alpha = 0.14f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = String.format(Locale.US, "%+.2f%%", pct),
                                style = MaterialTheme.typography.labelSmall.merge(tnumStyle),
                                fontWeight = FontWeight.SemiBold,
                                color = chgColor
                            )
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Pos", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Switch(
                        checked = item.inPosition,
                        onCheckedChange = onToggleInPosition
                    )
                }
            }
        }
    }
}
