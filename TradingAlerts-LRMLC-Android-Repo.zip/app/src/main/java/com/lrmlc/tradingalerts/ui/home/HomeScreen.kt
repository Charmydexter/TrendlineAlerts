package com.lrmlc.tradingalerts.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lrmlc.tradingalerts.R
import com.lrmlc.tradingalerts.data.local.MlModelEntity
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.DefaultWatchlist
import com.lrmlc.tradingalerts.data.model.InstrumentInfo
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.data.repository.DownloadProgressSnapshot
import com.lrmlc.tradingalerts.ml.TrainingStatusSnapshot
import com.lrmlc.tradingalerts.service.PersistentNotificationFormatter
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    settings: AppSettings,
    watchlist: List<WatchlistEntity>,
    formingCandles: Map<String, Candle>,
    activeModels: List<MlModelEntity>,
    downloadProgress: DownloadProgressSnapshot,
    trainingStatus: TrainingStatusSnapshot,
    serviceRunning: Boolean,
    isRefreshing: Boolean,
    availableInstruments: List<InstrumentInfo>,
    bannerMessage: String?,
    onRefresh: () -> Unit,
    onOpenChart: (String) -> Unit,
    onToggleInPosition: (String, Boolean) -> Unit,
    onOpenAddSearch: () -> Unit,
    onAddAsset: (String) -> Unit,
    onDismissBanner: () -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(LrmlcColors.CharcoalBase),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(R.drawable.ic_brand_logo),
                                contentDescription = "Trading Alerts LRMLC mark",
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text("Trading Alerts (LRMLC)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "${settings.exchange.displayName} ${settings.marketType.displayName} · ${watchlist.size}/${DefaultWatchlist.MAX_WATCHLIST_SIZE}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh watchlist")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            if (watchlist.size < DefaultWatchlist.MAX_WATCHLIST_SIZE) {
                FloatingActionButton(
                    onClick = {
                        onOpenAddSearch()
                        showAddDialog = true
                    }
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add asset to watchlist")
                }
            }
        }
    ) { innerPadding ->
        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = onRefresh,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    StatusBannerCard(
                        activeModels = activeModels,
                        downloadProgress = downloadProgress,
                        trainingStatus = trainingStatus,
                        serviceRunning = serviceRunning,
                        bannerMessage = bannerMessage,
                        onDismissBanner = onDismissBanner
                    )
                }

                if (watchlist.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("No watchlist assets yet", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Tap + to add any USDT pair on ${settings.exchange.displayName} ${settings.marketType.displayName}.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                items(watchlist, key = { "${it.exchange}_${it.marketType}_${it.symbol}" }) { item ->
                    val forming = formingCandles[item.symbol]
                    WatchlistRowCard(
                        item = item,
                        livePrice = forming?.close ?: item.lastPrice,
                        onClick = { onOpenChart(item.symbol) },
                        onToggleInPosition = { onToggleInPosition(item.symbol, it) }
                    )
                }
                item { Spacer(Modifier.height(72.dp)) }
            }
        }
    }

    if (showAddDialog) {
        val currentSet = remember(watchlist) { watchlist.map { it.symbol }.toHashSet() }
        val filtered = remember(availableInstruments, searchQuery, currentSet) {
            val q = searchQuery.trim().uppercase()
            availableInstruments
                .filter { !currentSet.contains(it.symbol) }
                .filter { q.isBlank() || it.baseAsset.contains(q) || it.symbol.contains(q) }
                .take(40)
        }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add USDT Asset (${watchlist.size}/${DefaultWatchlist.MAX_WATCHLIST_SIZE})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search symbol (e.g. BTC, ETH, AVAX)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    LazyColumn(modifier = Modifier.height(260.dp)) {
                        items(filtered, key = { it.symbol }) { inst ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onAddAsset(inst.symbol)
                                        showAddDialog = false
                                    }
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(inst.baseAsset, fontWeight = FontWeight.SemiBold)
                                Text(inst.marketType.displayName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun StatusBannerCard(
    activeModels: List<MlModelEntity>,
    downloadProgress: DownloadProgressSnapshot,
    trainingStatus: TrainingStatusSnapshot,
    serviceRunning: Boolean,
    bannerMessage: String?,
    onDismissBanner: () -> Unit
) {
    val globalModel = activeModels.firstOrNull { it.modelKind == "GLOBAL" }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (globalModel != null) {
                        "Model: Active (${globalModel.sampleCount} samples · ≥${(globalModel.threshold * 100).toInt()}%)"
                    } else {
                        "Unfiltered – model not trained yet"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = if (serviceRunning) "Live ON" else "Live OFF",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (serviceRunning) LrmlcColors.LongGreen else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (downloadProgress.isRunning) {
                Text(downloadProgress.statusMessage, style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(progress = { downloadProgress.progressFraction }, modifier = Modifier.fillMaxWidth())
            }
            if (trainingStatus.isRunning) {
                Text(trainingStatus.stageMessage, style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(progress = { trainingStatus.progressPct / 100f }, modifier = Modifier.fillMaxWidth())
            }
            bannerMessage?.let { msg ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(msg, style = MaterialTheme.typography.bodySmall, color = LrmlcColors.WarningAmber, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismissBanner) { Text("OK") }
                }
            }
        }
    }
}

@Composable
private fun WatchlistRowCard(
    item: WatchlistEntity,
    livePrice: Double?,
    onClick: () -> Unit,
    onToggleInPosition: (Boolean) -> Unit
) {
    val dotColor = when (item.activeDirection) {
        "LONG" -> LrmlcColors.LongGreen
        "SHORT" -> LrmlcColors.ShortRed
        else -> LrmlcColors.NeutralGrey
    }
    val statusDesc = when (item.activeDirection) {
        "LONG" -> "Active Long signal"
        "SHORT" -> "Active Short signal"
        else -> "No active signal"
    }
    val cleanSymbol = item.symbol.stripUsdtSuffix()
    val ageSec = if (item.lastCandleReceivedMs > 0L) {
        ((System.currentTimeMillis() - item.lastCandleReceivedMs) / 1000L).coerceAtLeast(0L)
    } else null

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Far-left status dot before name
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(dotColor)
                    .semantics { contentDescription = statusDesc }
            )
            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = cleanSymbol,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (item.activeDirection == "LONG" || item.activeDirection == "SHORT") {
                        Icon(
                            imageVector = if (item.activeDirection == "LONG") Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = item.activeDirection,
                            tint = dotColor,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = item.activeDirection + (item.activeConfidence?.let { " ${(it * 100).toInt()}%" } ?: ""),
                            style = MaterialTheme.typography.labelSmall,
                            color = dotColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                val healthText = when {
                    ageSec == null -> "No closed candle yet"
                    ageSec < 90L -> "Feed OK · ${ageSec}s ago"
                    else -> "Stale · ${ageSec / 60}m ago"
                }
                Text(
                    text = healthText,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (ageSec != null && ageSec < 90L) MaterialTheme.colorScheme.onSurfaceVariant else LrmlcColors.WarningAmber
                )
            }

            Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(end = 12.dp)) {
                Text(
                    text = livePrice?.let { PersistentNotificationFormatter.formatPrice(it) } ?: "—",
                    style = MaterialTheme.typography.bodyLarge,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium
                )
                item.change24hPct?.let { pct ->
                    Text(
                        text = String.format(Locale.US, "%+.2f%%", pct),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (pct >= 0) LrmlcColors.LongGreen else LrmlcColors.ShortRed
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Pos", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Switch(
                    checked = item.inPosition,
                    onCheckedChange = onToggleInPosition
                )
            }
        }
    }
}
