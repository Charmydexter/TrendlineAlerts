package com.lrmlc.tradingalerts.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CandleDayChunkEntity::class,
        WatchlistEntity::class,
        RecycleBinEntity::class,
        SignalCandidateEntity::class,
        MlModelEntity::class,
        TrainingJobEntity::class,
        TrainingLogEntity::class,
        ExitWarningStateEntity::class,
        SyncProgressEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun candleChunkDao(): CandleChunkDao
    abstract fun watchlistDao(): WatchlistDao
    abstract fun recycleBinDao(): RecycleBinDao
    abstract fun signalCandidateDao(): SignalCandidateDao
    abstract fun mlModelDao(): MlModelDao
    abstract fun trainingJobDao(): TrainingJobDao
    abstract fun trainingLogDao(): TrainingLogDao
    abstract fun exitWarningStateDao(): ExitWarningStateDao
    abstract fun syncProgressDao(): SyncProgressDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "lrmlc_trading_alerts.db"
            )
                .fallbackToDestructiveMigrationOnDowngrade()
                .build()
    }
}
