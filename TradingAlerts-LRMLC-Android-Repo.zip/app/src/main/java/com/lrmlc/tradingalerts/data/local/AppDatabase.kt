package com.lrmlc.tradingalerts.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        CandleDayChunkEntity::class,
        WatchlistEntity::class,
        RecycleBinEntity::class,
        SignalCandidateEntity::class,
        MlModelEntity::class,
        TrainingJobEntity::class,
        TrainingLogEntity::class,
        ExitWarningStateEntity::class,
        ExitCellRuleEntity::class,
        AssetPresetSelectionEntity::class,
        SyncProgressEntity::class
    ],
    version = 5,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun candleChunkDao(): CandleChunkDao
    abstract fun watchlistDao(): WatchlistDao
    abstract fun recycleBinDao(): RecycleBinDao
    abstract fun signalCandidateDao(): SignalCandidateDao
    abstract fun mlModelDao(): MlModelDao
    abstract fun trainingJobDao(): TrainingJobDao
    abstract fun trainingLogDao(): TrainingLogDao
    abstract fun exitWarningStateDao(): ExitWarningStateDao
    abstract fun exitCellRuleDao(): ExitCellRuleDao
    abstract fun assetPresetSelectionDao(): AssetPresetSelectionDao
    abstract fun syncProgressDao(): SyncProgressDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `exitWarningCount` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `firstExitWarningTimeMs` INTEGER")
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `firstExitWarningPrice` REAL")
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `firstExitWarningHelped` INTEGER")
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `exitWarningCell` TEXT")
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `presetId` TEXT NOT NULL DEFAULT 'R240'")
                db.execSQL("ALTER TABLE `training_logs` ADD COLUMN `reportJson` TEXT")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `exit_cell_rules` (" +
                        "`exchange` TEXT NOT NULL, " +
                        "`marketType` TEXT NOT NULL, " +
                        "`ageBucket` INTEGER NOT NULL, " +
                        "`progressBucket` INTEGER NOT NULL, " +
                        "`mlEnabled` INTEGER NOT NULL, " +
                        "`mlThreshold` REAL NOT NULL, " +
                        "`structEnabled` INTEGER NOT NULL, " +
                        "`precision` REAL NOT NULL, " +
                        "`warnings` INTEGER NOT NULL, " +
                        "`avgSavedRisk` REAL NOT NULL, " +
                        "`updatedAtMs` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`exchange`, `marketType`, `ageBucket`, `progressBucket`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `asset_preset_selection` (" +
                        "`exchange` TEXT NOT NULL, " +
                        "`marketType` TEXT NOT NULL, " +
                        "`symbol` TEXT NOT NULL, " +
                        "`presetId` TEXT NOT NULL, " +
                        "`lcbExpectancy` REAL NOT NULL, " +
                        "`trades` INTEGER NOT NULL, " +
                        "`updatedAtMs` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`exchange`, `marketType`, `symbol`))"
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `tpReachedTimeMs` INTEGER")
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `slReachedTimeMs` INTEGER")
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `maxBeyondTpPct` REAL")
            }
        }

        /** Exit warnings v2: 20 situations, new features. Old exit rules/models/state are thrown away. */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("DELETE FROM `exit_cell_rules`")
                db.execSQL("DELETE FROM `exit_warning_states`")
                db.execSQL("DELETE FROM `ml_models` WHERE `modelKind` = 'EXIT'")
                db.execSQL("ALTER TABLE `exit_cell_rules` ADD COLUMN `persistN` INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE `exit_warning_states` ADD COLUMN `streak` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `exit_warning_states` ADD COLUMN `goneCount` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `exit_warning_states` ADD COLUMN `lastWarnCell` TEXT")
            }
        }

        /** Job 3: run-past-TP marker saved with the trade. */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `runOnProb` REAL")
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `runOnMarker` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `signal_candidates` ADD COLUMN `runOnShownTimeMs` INTEGER")
            }
        }

        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "lrmlc_trading_alerts.db"
            )
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                .fallbackToDestructiveMigrationOnDowngrade()
                .build()
    }
}
