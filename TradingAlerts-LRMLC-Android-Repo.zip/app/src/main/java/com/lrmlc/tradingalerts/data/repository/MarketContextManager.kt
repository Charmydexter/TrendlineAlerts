package com.lrmlc.tradingalerts.data.repository

import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import com.lrmlc.tradingalerts.data.local.FuturesMetricsStore
import com.lrmlc.tradingalerts.data.local.GapDetector
import com.lrmlc.tradingalerts.data.local.SettingsRepository
import com.lrmlc.tradingalerts.data.local.WatchlistDao
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.DEFAULT_MASTER_ASSET
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MAX_MASTER_SLOTS
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.MasterSlot
import com.lrmlc.tradingalerts.data.model.ensureUsdtSymbol
import com.lrmlc.tradingalerts.data.remote.ExchangeAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.ceil

/** Pure slot bookkeeping for the single Master (market-context) asset. Up to 5 datasets are kept in the backend. */
object MasterSlots {

    /** An old master's history is phased out over this long (oldest days first). */
    const val PHASE_OUT_MS = 14L * 24L * 3600_000L

    private fun matches(s: MasterSlot, exchange: String, market: String, symbol: String) =
        s.exchange == exchange && s.marketType == market && s.symbol == symbol

    fun keyOf(s: MasterSlot) = "${s.exchange}|${s.marketType}|${s.symbol}"

    fun activeSymbol(settings: AppSettings): String =
        settings.marketContextAsset.ifBlank { DEFAULT_MASTER_ASSET }.ensureUsdtSymbol()

    /**
     * Makes sure the active master has an un-retired slot and that no other slot claims to be active
     * (e.g. after an exchange or market switch). Returns the (possibly unchanged) settings.
     */
    fun normalize(settings: AppSettings, nowMs: Long): AppSettings {
        val ex = settings.exchange.name
        val mk = settings.marketType.name
        val sym = activeSymbol(settings)
        var slots = settings.masterSlots.map {
            if (it.retiredAtMs == 0L && !matches(it, ex, mk, sym)) it.copy(retiredAtMs = nowMs) else it
        }
        val existing = slots.firstOrNull { matches(it, ex, mk, sym) }
        slots = when {
            existing == null -> slots + MasterSlot(ex, mk, sym)
            existing.retiredAtMs != 0L -> slots.map { if (matches(it, ex, mk, sym)) it.copy(retiredAtMs = 0L, retiredDayCount = 0) else it }
            else -> slots
        }
        return if (slots == settings.masterSlots && sym == settings.marketContextAsset) settings
        else settings.copy(marketContextAsset = sym, masterSlots = slots)
    }

    /**
     * Switches the active master. The old master's slot is retired (its data is then phased out gradually).
     * If all [MAX_MASTER_SLOTS] slots would be exceeded by a master that is not already stored, the slot that
     * has been retired the longest is evicted; its data must be deleted by the caller (returned list).
     */
    fun switchMaster(
        settings: AppSettings,
        newSymbolRaw: String,
        nowMs: Long,
        oldDayCount: Int
    ): Pair<AppSettings, List<MasterSlot>> {
        val ex = settings.exchange.name
        val mk = settings.marketType.name
        val newSym = newSymbolRaw.ensureUsdtSymbol()
        val base = normalize(settings, nowMs)
        val oldSym = activeSymbol(base)
        if (newSym == oldSym) return base to emptyList()

        var slots = base.masterSlots.map {
            if (matches(it, ex, mk, oldSym) && it.retiredAtMs == 0L) it.copy(retiredAtMs = nowMs, retiredDayCount = oldDayCount.coerceAtLeast(0)) else it
        }
        val existing = slots.firstOrNull { matches(it, ex, mk, newSym) }
        slots = if (existing != null) {
            slots.map { if (matches(it, ex, mk, newSym)) it.copy(retiredAtMs = 0L, retiredDayCount = 0) else it }
        } else {
            slots + MasterSlot(ex, mk, newSym)
        }
        val evicted = ArrayList<MasterSlot>()
        while (slots.size > MAX_MASTER_SLOTS) {
            val victim = slots.filter { it.retiredAtMs > 0L }.minByOrNull { it.retiredAtMs } ?: break
            slots = slots - victim
            evicted.add(victim)
        }
        return base.copy(marketContextAsset = newSym, masterSlots = slots) to evicted
    }

    /** How many newest days of a retired slot should still be kept at [nowMs]; 0 means fully phased out. */
    fun keepDays(slot: MasterSlot, nowMs: Long): Int {
        if (slot.retiredAtMs <= 0L) return Int.MAX_VALUE
        val progress = ((nowMs - slot.retiredAtMs).toDouble() / PHASE_OUT_MS).coerceIn(0.0, 1.0)
        if (progress >= 1.0) return 0
        return ceil(slot.retiredDayCount * (1.0 - progress)).toInt().coerceAtLeast(1)
    }
}

sealed class MasterChangeResult {
    data class Applied(val symbol: String) : MasterChangeResult()
    data class Unchanged(val symbol: String) : MasterChangeResult()
    data class NotFound(val symbol: String) : MasterChangeResult()
    object Invalid : MasterChangeResult()
}

/**
 * Keeps the Master (market-context) asset's 1-minute history current in the background - even when it is not on
 * the watchlist - phases out old masters, and quietly fetches futures metrics (funding / open interest).
 */
class MarketContextManager(
    private val candleStore: CandleStoreRepository,
    private val settingsRepository: SettingsRepository,
    private val watchlistDao: WatchlistDao,
    private val historySyncManager: HistorySyncManager,
    private val futuresStore: FuturesMetricsStore
) {
    private val masterSyncMutex = Mutex()
    private val slotMutex = Mutex()

    companion object {
        const val MASTER_BACKFILL_DAYS = 29
        const val FUTURES_RESYNC_MS = 25L * 60_000L
        const val FUTURES_PAUSE_BETWEEN_SYMBOLS_MS = 1_200L
    }

    private fun publishProtected(settings: AppSettings) {
        candleStore.protectedKeys = settings.masterSlots.map { MasterSlots.keyOf(it) }.toSet()
    }

    suspend fun masterSymbol(): String = MasterSlots.activeSymbol(settingsRepository.getSettings())

    /** Registers the active master slot (idempotent) and refreshes the delete-protection set. */
    suspend fun ensureSlots() = slotMutex.withLock {
        val now = System.currentTimeMillis()
        val cur = settingsRepository.getSettings()
        val normalized = MasterSlots.normalize(cur, now)
        if (normalized != cur) settingsRepository.updateSettings { MasterSlots.normalize(it, now) }
        publishProtected(normalized)
    }

    /** Validates and applies a new master. Old data is kept and phased out; extra slots beyond five are evicted. */
    suspend fun changeMaster(rawSymbol: String, adapter: ExchangeAdapter): MasterChangeResult {
        val cleaned = rawSymbol.trim().uppercase().filter { it.isLetterOrDigit() }
        if (cleaned.length < 2) return MasterChangeResult.Invalid
        val newSym = cleaned.ensureUsdtSymbol()
        val cur = settingsRepository.getSettings()
        if (newSym == MasterSlots.activeSymbol(cur)) {
            ensureSlots()
            return MasterChangeResult.Unchanged(newSym)
        }
        val found = try {
            adapter.fetchKlines1m(cur.marketType, newSym, limit = 5).first.isNotEmpty()
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            false
        }
        if (!found) return MasterChangeResult.NotFound(newSym)

        var evicted: List<MasterSlot> = emptyList()
        slotMutex.withLock {
            val settings = settingsRepository.getSettings()
            val oldSym = MasterSlots.activeSymbol(settings)
            val oldDays = candleStore.countStoredDays(settings.exchange, settings.marketType, oldSym)
            val now = System.currentTimeMillis()
            val (next, ev) = MasterSlots.switchMaster(settings, newSym, now, oldDays)
            evicted = ev
            settingsRepository.setSettings(next)
            publishProtected(next)
        }
        // Evicted slots are removed immediately, unless the coin is also on the watchlist.
        for (slot in evicted) deleteSlotData(slot)
        return MasterChangeResult.Applied(newSym)
    }

    private suspend fun isOnWatchlist(slot: MasterSlot): Boolean =
        watchlistDao.getAsset(slot.exchange, slot.marketType, slot.symbol) != null

    private suspend fun deleteSlotData(slot: MasterSlot) {
        if (isOnWatchlist(slot)) return
        val ex = runCatching { ExchangeId.valueOf(slot.exchange) }.getOrNull() ?: return
        val mk = runCatching { MarketType.valueOf(slot.marketType) }.getOrNull() ?: return
        candleStore.deleteAssetCandles(ex, mk, slot.symbol, force = true)
    }

    /** Gradually deletes retired masters (oldest days first) and drops slots that are fully gone. */
    suspend fun pruneRetired(nowMs: Long = System.currentTimeMillis()) = slotMutex.withLock {
        val settings = settingsRepository.getSettings()
        val remaining = ArrayList<MasterSlot>()
        for (slot in settings.masterSlots) {
            if (slot.retiredAtMs <= 0L) {
                remaining.add(slot)
                continue
            }
            val ex = runCatching { ExchangeId.valueOf(slot.exchange) }.getOrNull()
            val mk = runCatching { MarketType.valueOf(slot.marketType) }.getOrNull()
            if (ex == null || mk == null) continue // unusable slot: drop it
            if (isOnWatchlist(slot)) continue // data now belongs to the watchlist; just release the slot
            val keep = MasterSlots.keepDays(slot, nowMs)
            if (keep <= 0) {
                candleStore.deleteAssetCandles(ex, mk, slot.symbol, force = true)
                continue
            }
            val cutoffDay = DayChunkCodec.utcDayIndexOf(nowMs) - keep + 1L
            candleStore.deleteAssetBeforeDay(ex, mk, slot.symbol, cutoffDay)
            remaining.add(slot)
        }
        if (remaining != settings.masterSlots) {
            settingsRepository.updateSettings { it.copy(masterSlots = remaining) }
        }
        publishProtected(settings.copy(masterSlots = remaining))
    }

    private suspend fun masterIsOnWatchlist(settings: AppSettings): Boolean =
        watchlistDao.getAsset(settings.exchange.name, settings.marketType.name, MasterSlots.activeSymbol(settings)) != null

    /** Quiet background backfill of ~4 weeks of the master's 1-minute candles (no progress UI). */
    suspend fun syncMasterHistory(adapter: ExchangeAdapter) = withContext(Dispatchers.IO) {
        masterSyncMutex.withLock {
            val settings = settingsRepository.getSettings()
            if (masterIsOnWatchlist(settings)) return@withLock // watchlist sync already covers it
            val master = MasterSlots.activeSymbol(settings)
            val latestClosed = GapDetector.latestClosedMinuteOpenMs(System.currentTimeMillis())
            val start = latestClosed - MASTER_BACKFILL_DAYS.toLong() * DayChunkCodec.MILLIS_PER_DAY
            try {
                historySyncManager.fillMissingGapsForAsset(adapter, settings.marketType, master, start, latestClosed)
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
                // quiet by design; retried on the next cycle
            }
        }
    }

    /** Appends the newest closed 1-minute candles of the master when it is not already streamed via the watchlist. */
    suspend fun refreshMasterTail(adapter: ExchangeAdapter) = withContext(Dispatchers.IO) {
        val settings = settingsRepository.getSettings()
        if (masterIsOnWatchlist(settings)) return@withContext
        val master = MasterSlots.activeSymbol(settings)
        try {
            val latestClosed = GapDetector.latestClosedMinuteOpenMs(System.currentTimeMillis())
            val (candles, _) = adapter.fetchKlines1m(settings.marketType, master, limit = 10)
            val closed = candles.filter { it.openTimeMs <= latestClosed }
            if (closed.isNotEmpty()) candleStore.appendCandles(adapter.exchangeId, settings.marketType, master, closed)
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
        }
    }

    /** Slowly fetches funding / open interest for perpetual watchlist symbols (public data). */
    suspend fun syncFutures(
        adapter: ExchangeAdapter,
        marketType: MarketType,
        symbols: List<String>,
        deadlineMs: Long = Long.MAX_VALUE
    ) = withContext(Dispatchers.IO) {
        if (marketType != MarketType.PERP) return@withContext
        val ex = adapter.exchangeId.name
        for (sym in symbols) {
            val now = System.currentTimeMillis()
            if (now >= deadlineMs) break
            if (now - futuresStore.lastSyncedAt(ex, sym) < FUTURES_RESYNC_MS) continue
            val newest = futuresStore.newestOiTimestamp(ex, sym)
            val since = if (newest > 0L) newest - 2L * 3600_000L else now - 29L * 24L * 3600_000L
            try {
                val batch = adapter.fetchFuturesMetrics(marketType, sym, since)
                futuresStore.merge(ex, sym, batch.funding, batch.openInterest, now)
                futuresStore.markSynced(ex, sym, now)
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
            }
            delay(FUTURES_PAUSE_BETWEEN_SYMBOLS_MS)
        }
    }
}
