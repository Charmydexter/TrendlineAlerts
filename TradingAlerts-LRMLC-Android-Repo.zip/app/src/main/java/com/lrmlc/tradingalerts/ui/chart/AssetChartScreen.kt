package com.lrmlc.tradingalerts.ui.chart

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ChartStyle
import com.lrmlc.tradingalerts.data.model.RangePresets
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.service.PersistentNotificationFormatter
import com.lrmlc.tradingalerts.ui.ChartScreenState
import com.lrmlc.tradingalerts.ui.alerts.formatAlertStatusLabel
import com.lrmlc.tradingalerts.ui.alerts.formatAlertTimestamp
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import com.lrmlc.tradingalerts.ui.theme.LrmlcShapes
import com.lrmlc.tradingalerts.ui.theme.cardBorderStroke
import kotlinx.serialization.json.Json
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssetChartScreen(
    chartState: ChartScreenState,
    watchlistItem: WatchlistEntity?,
    formingCandle: Candle?,
    settings: AppSettings,
    onBack: () -> Unit,
    onToggleInPosition: (Boolean) -> Unit,
    onToggleMute: (Boolean) -> Unit,
    onUpdateManualSlTp: (signalId: String, newSl: Double, newTp: Double) -> Unit,
    onResetDefaultSlTp: (signalId: String) -> Unit
) {
    var selectedZoomBars by remember(chartState.symbol, chartState.preset.id) {
        mutableIntStateOf(chartState.preset.windowBars)
    }
    var showEditSlTpDialog by remember { mutableStateOf(false) }
    var confirmManualClose by remember { mutableStateOf(false) }

    val mergedCandles = remember(chartState.candles, formingCandle) {
        if (formingCandle == null || chartState.candles.isEmpty()) {
            chartState.candles
        } else {
            val last = chartState.candles.last()
            if (formingCandle.openTimeMs == last.openTimeMs) {
                chartState.candles.dropLast(1) + formingCandle
            } else if (formingCandle.openTimeMs > last.openTimeMs) {
                chartState.candles + formingCandle
            } else {
                chartState.candles
            }
        }
    }

    val signalMarkers = remember(mergedCandles, chartState.signals) {
        val timeToIdx = mergedCandles.mapIndexed { idx, c -> c.openTimeMs to idx }.toMap()
        chartState.signals.mapNotNull { sig ->
            val idx = timeToIdx[sig.signalTimeMs] ?: return@mapNotNull null
            ChartSignalMarker(
                barIndex = idx,
                direction = TradeDirection.valueOf(sig.direction),
                accepted = sig.accepted
            )
        }
    }

    val displaySignal = remember(chartState.focusedSignal, chartState.activeTrade, chartState.signals) {
        chartState.focusedSignal
            ?: chartState.activeTrade
            ?: chartState.signals.firstOrNull { it.accepted }
    }
    val isDisplayClosed = displaySignal != null && displaySignal.status != "ACTIVE"

    val exitMarker = remember(mergedCandles, displaySignal) {
        val exitMs = displaySignal?.exitTimeMs
        if (exitMs != null && isDisplayClosed && mergedCandles.isNotEmpty()) {
            val idx = mergedCandles.indexOfLast { it.openTimeMs <= exitMs }.takeIf { it >= 0 } ?: mergedCandles.lastIndex
            val price = when (displaySignal.status) {
                "CLOSED_TP" -> displaySignal.appliedTp
                "CLOSED_SL" -> displaySignal.appliedSl
                else -> mergedCandles[idx].close
            }
            idx to price
        } else null
    }

    val currentPrice = mergedCandles.lastOrNull()?.close
    val cleanSym = chartState.symbol.stripUsdtSuffix()
    val json = remember { Json { ignoreUnknownKeys = true } }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Column {
                        Text("$cleanSym · 1m", style = MaterialTheme.typography.titleLarge)
                        Text(
                            if (settings.chartStyle == ChartStyle.HEIKIN_ASHI) "Heikin Ashi · Res(Fuchsia) Sup(Lime) Avg(Blue)"
                            else "Candles · Res(Fuchsia) Sup(Lime) Avg(Blue)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { onToggleMute(!(watchlistItem?.muted ?: false)) }) {
                        Icon(
                            imageVector = if (watchlistItem?.muted == true) Icons.Default.NotificationsOff else Icons.Default.Notifications,
                            contentDescription = "Mute alerts for $cleanSym"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (chartState.isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            chartState.errorMessage?.let {
                Text(it, color = LrmlcColors.ShortRed, style = MaterialTheme.typography.bodyMedium)
            }

            // Preset info chip + In-pos toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "Range ${chartState.preset.label} · gap ${chartState.preset.minGapBars} · auto",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("In pos", style = MaterialTheme.typography.labelMedium)
                    Switch(
                        checked = watchlistItem?.inPosition ?: false,
                        onCheckedChange = { checked ->
                            if (!checked && chartState.activeTrade != null) {
                                confirmManualClose = true
                            } else {
                                onToggleInPosition(checked)
                            }
                        }
                    )
                }
            }

            // Chart zoom view presets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RangePresets.ALL.forEach { p ->
                    val selected = selectedZoomBars == p.windowBars
                    FilterChip(
                        selected = selected,
                        onClick = { selectedZoomBars = p.windowBars },
                        label = { Text(p.label) },
                        shape = LrmlcShapes.ButtonShape,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            // Custom Compose Canvas Chart with axes & 7-bar right gap
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = LrmlcShapes.CardShape,
                border = cardBorderStroke()
            ) {
                CandlestickChart(
                    candles = mergedCandles,
                    snapshots = chartState.snapshots,
                    visibleBarsDefault = selectedZoomBars,
                    chartStyle = settings.chartStyle,
                    signalMarkers = signalMarkers,
                    activeSlPrice = displaySignal?.appliedSl,
                    activeTpPrice = displaySignal?.appliedTp,
                    activeEntryPrice = displaySignal?.entryPrice,
                    tpReached = displaySignal?.tpReachedTimeMs != null,
                    runOnMarker = displaySignal?.runOnMarker == true,
                    runOnGlyph = com.lrmlc.tradingalerts.ui.RunOnGlyph.resolve(),
                    levelsFaded = isDisplayClosed,
                    exitMarkerBarIndex = exitMarker?.first,
                    exitMarkerPrice = exitMarker?.second,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                        .padding(8.dp)
                )
            }

            // Closed alert status banner [U13]
            if (displaySignal != null && isDisplayClosed) {
                val exitPrice = exitMarker?.second ?: displaySignal.entryPrice
                val retStr = displaySignal.netReturnPct?.let { String.format(Locale.US, "%+.2f%% net", it * 100.0) } ?: "closed"
                val exitTimeStr = displaySignal.exitTimeMs?.let { formatAlertTimestamp(it) } ?: ""
                val bannerColor = when (displaySignal.status) {
                    "CLOSED_TP" -> LrmlcColors.LongGreen
                    "CLOSED_SL" -> LrmlcColors.ShortRed
                    else -> LrmlcColors.WarningAmber
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(LrmlcShapes.PanelShape)
                        .background(bannerColor.copy(alpha = 0.14f))
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = "Closed: ${formatAlertStatusLabel(displaySignal)} at ${PersistentNotificationFormatter.formatPrice(exitPrice)}, $retStr${if (exitTimeStr.isNotEmpty()) ", $exitTimeStr" else ""}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = bannerColor
                    )
                }
            }

            // Persistent Alert Detail Strip (focused, active, or most recent accepted) [U13]
            displaySignal?.let { sig ->
                AlertDetailStrip(
                    signal = sig,
                    currentPrice = currentPrice,
                    onEditSlTp = { showEditSlTpDialog = true },
                    onResetDefaults = { onResetDefaultSlTp(sig.signalId) }
                )
            }

            // Latest signal explanations
            val explainTarget = displaySignal ?: chartState.signals.firstOrNull()
            if (explainTarget != null) {
                val reasons = remember(explainTarget.topReasonsJson) {
                    runCatching { json.decodeFromString<List<String>>(explainTarget.topReasonsJson) }.getOrDefault(emptyList())
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = LrmlcShapes.CardShape,
                    border = cardBorderStroke()
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "Signal Explanation (${explainTarget.direction})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (reasons.isEmpty()) {
                            Text("Confluence rule-based setup recorded.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            reasons.forEach { r ->
                                Text("• $r", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmManualClose) {
        AlertDialog(
            onDismissRequest = { confirmManualClose = false },
            title = { Text("Turn Off In Position?") },
            text = { Text("This will mark the alert as closed manually.") },
            confirmButton = {
                Button(
                    onClick = {
                        confirmManualClose = false
                        onToggleInPosition(false)
                    },
                    shape = LrmlcShapes.ButtonShape
                ) { Text("Close Alert") }
            },
            dismissButton = {
                TextButton(onClick = { confirmManualClose = false }) { Text("Cancel") }
            }
        )
    }

    val active = chartState.activeTrade
    if (showEditSlTpDialog && active != null && active.status == "ACTIVE") {
        var slText by remember(active.appliedSl) { mutableStateOf(active.appliedSl.toString()) }
        var tpText by remember(active.appliedTp) { mutableStateOf(active.appliedTp.toString()) }
        AlertDialog(
            onDismissRequest = { showEditSlTpDialog = false },
            title = { Text("Manual SL / TP Override") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = slText, onValueChange = { slText = it }, label = { Text("Stop Loss") }, singleLine = true)
                    OutlinedTextField(value = tpText, onValueChange = { tpText = it }, label = { Text("Take Profit") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val slVal = slText.toDoubleOrNull()
                        val tpVal = tpText.toDoubleOrNull()
                        if (slVal != null && tpVal != null && slVal > 0 && tpVal > 0) {
                            onUpdateManualSlTp(active.signalId, slVal, tpVal)
                            showEditSlTpDialog = false
                        }
                    },
                    shape = LrmlcShapes.ButtonShape
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showEditSlTpDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun AlertDetailStrip(
    signal: SignalCandidateEntity,
    currentPrice: Double?,
    onEditSlTp: () -> Unit,
    onResetDefaults: () -> Unit
) {
    val dir = TradeDirection.valueOf(signal.direction)
    val dirColor = if (dir == TradeDirection.LONG) LrmlcColors.LongGreen else LrmlcColors.ShortRed
    val price = currentPrice ?: signal.entryPrice
    val distTpPct = if (price > 0) ((signal.appliedTp - price) / price) * 100.0 * (if (dir == TradeDirection.LONG) 1.0 else -1.0) else 0.0
    val distSlPct = if (price > 0) ((price - signal.appliedSl) / price) * 100.0 * (if (dir == TradeDirection.LONG) 1.0 else -1.0) else 0.0
    val isActive = signal.status == "ACTIVE"
    val tnumStyle = TextStyle(fontFamily = FontFamily.Monospace, fontFeatureSettings = "tnum")

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = LrmlcShapes.CardShape,
        border = cardBorderStroke()
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${dir.emoji} ${formatAlertStatusLabel(signal)} ${dir.label}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = dirColor
                )
                Text(
                    text = if (!signal.modelWasTrained) "Unfiltered – model not trained yet"
                    else "Conf ${(signal.pWin?.times(100)?.toInt() ?: 0)}%",
                    style = MaterialTheme.typography.labelLarge.merge(tnumStyle),
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                PriceColumn("Entry", PersistentNotificationFormatter.formatPrice(signal.entryPrice))
                PriceColumn("Current", PersistentNotificationFormatter.formatPrice(price))
                PriceColumn("TP", "${PersistentNotificationFormatter.formatPrice(signal.appliedTp)} (${String.format(Locale.US, "%+.2f%%", distTpPct)})", LrmlcColors.SupportLime)
                PriceColumn("SL", "${PersistentNotificationFormatter.formatPrice(signal.appliedSl)} (${String.format(Locale.US, "%.2f%%", distSlPct)})", LrmlcColors.ShortRed)
            }

            if (isActive) {
                val hhmm = java.time.format.DateTimeFormatter.ofPattern("HH:mm")
                val zone = java.time.ZoneId.systemDefault()
                signal.tpReachedTimeMs?.let { t ->
                    val beyond = (signal.maxBeyondTpPct ?: 0.0) * 100.0
                    Text(
                        text = "TP reached ${hhmm.format(java.time.Instant.ofEpochMilli(t).atZone(zone))} " +
                            "(${String.format(Locale.US, "%+.2f%%", beyond)} beyond TP)",
                        style = MaterialTheme.typography.bodySmall,
                        color = LrmlcColors.LongGreen
                    )
                }
                if (signal.runOnMarker) {
                    val pctSure = ((signal.runOnProb ?: 0.0) * 100).toInt()
                    Text(
                        text = "Model expects a run past TP ($pctSure% sure, reliable at this stage)",
                        style = MaterialTheme.typography.bodySmall,
                        color = LrmlcColors.LongGreen
                    )
                }
                signal.slReachedTimeMs?.let { t ->
                    Text(
                        text = "SL reached ${hhmm.format(java.time.Instant.ofEpochMilli(t).atZone(zone))} \u2013 trade still open",
                        style = MaterialTheme.typography.bodySmall,
                        color = LrmlcColors.ShortRed
                    )
                }
            }

            signal.slAdjustmentNote?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            signal.tpAdjustmentNote?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (isActive) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onEditSlTp, shape = LrmlcShapes.ButtonShape) { Text("Override SL / TP") }
                    if (signal.manualOverride || signal.appliedSl != signal.structuralSl || signal.appliedTp != signal.defaultTp) {
                        TextButton(onClick = onResetDefaults) { Text("Reset to Defaults") }
                    }
                }
            }
        }
    }
}

@Composable
private fun PriceColumn(
    label: String,
    value: String,
    valueColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface
) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.merge(TextStyle(fontFamily = FontFamily.Monospace, fontFeatureSettings = "tnum")),
            fontWeight = FontWeight.SemiBold,
            color = valueColor
        )
    }
}
