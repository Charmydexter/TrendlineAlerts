package com.lrmlc.tradingalerts.ui.chart

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ChartStyle
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.service.PersistentNotificationFormatter
import com.lrmlc.tradingalerts.ui.ChartScreenState
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import kotlinx.serialization.json.Json
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssetChartScreen(
    chartState: ChartScreenState,
    watchlistItem: WatchlistEntity?,
    formingCandle: Candle?,
    settings: AppSettings,
    onBack: () -> Unit,
    onToggleInPosition: (Boolean) -> Unit,
    onToggleMute: (Boolean) -> Unit,
    onUpdateManualSlTp: (signalId: String, newSl: Double, newTp: Double) -> Unit,
    onResetDefaultSlTp: (signalId: String) -> Unit
) {
    var selectedRangeBars by remember { mutableIntStateOf(240) }
    var showEditSlTpDialog by remember { mutableStateOf(false) }

    val mergedCandles = remember(chartState.candles, formingCandle) {
        if (formingCandle == null || chartState.candles.isEmpty()) {
            chartState.candles
        } else {
            val last = chartState.candles.last()
            if (formingCandle.openTimeMs == last.openTimeMs) {
                chartState.candles.dropLast(1) + formingCandle
            } else if (formingCandle.openTimeMs > last.openTimeMs) {
                chartState.candles + formingCandle
            } else {
                chartState.candles
            }
        }
    }

    val signalMarkers = remember(mergedCandles, chartState.signals) {
        val timeToIdx = mergedCandles.mapIndexed { idx, c -> c.openTimeMs to idx }.toMap()
        chartState.signals.mapNotNull { sig ->
            val idx = timeToIdx[sig.signalTimeMs] ?: return@mapNotNull null
            ChartSignalMarker(
                barIndex = idx,
                direction = TradeDirection.valueOf(sig.direction),
                accepted = sig.accepted
            )
        }
    }

    val currentPrice = mergedCandles.lastOrNull()?.close
    val cleanSym = chartState.symbol.stripUsdtSuffix()
    val json = remember { Json { ignoreUnknownKeys = true } }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Column {
                        Text("$cleanSym · 1m", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            if (settings.chartStyle == ChartStyle.HEIKIN_ASHI) "Heikin Ashi · Res(Fuchsia) Sup(Lime) Avg(Blue)"
                            else "Candles · Res(Fuchsia) Sup(Lime) Avg(Blue)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { onToggleMute(!(watchlistItem?.muted ?: false)) }) {
                        Icon(
                            imageVector = if (watchlistItem?.muted == true) Icons.Default.NotificationsOff else Icons.Default.Notifications,
                            contentDescription = "Mute alerts for $cleanSym"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (chartState.isLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            chartState.errorMessage?.let {
                Text(it, color = LrmlcColors.ShortRed, style = MaterialTheme.typography.bodyMedium)
            }

            // Range tabs: 240 (4h), 60 (1h), 30 (30m)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(240 to "4h (240)", 60 to "1h (60)", 30 to "30m (30)").forEach { (bars, label) ->
                    FilterChip(
                        selected = selectedRangeBars == bars,
                        onClick = { selectedRangeBars = bars },
                        label = { Text(label) }
                    )
                }
                Spacer(Modifier.weight(1f))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("In pos", style = MaterialTheme.typography.labelMedium)
                    Switch(
                        checked = watchlistItem?.inPosition ?: false,
                        onCheckedChange = onToggleInPosition
                    )
                }
            }

            // Custom Compose Canvas Chart
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                CandlestickChart(
                    candles = mergedCandles,
                    snapshots = chartState.snapshots,
                    visibleBarsDefault = selectedRangeBars,
                    chartStyle = settings.chartStyle,
                    signalMarkers = signalMarkers,
                    activeSlPrice = chartState.activeTrade?.appliedSl,
                    activeTpPrice = chartState.activeTrade?.appliedTp,
                    activeEntryPrice = chartState.activeTrade?.entryPrice,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(330.dp)
                        .padding(6.dp)
                )
            }

            // Active trade strip below chart (shown only when a trade is open from last signal)
            chartState.activeTrade?.let { trade ->
                ActiveTradeStrip(
                    trade = trade,
                    currentPrice = currentPrice,
                    onEditSlTp = { showEditSlTpDialog = true },
                    onResetDefaults = { onResetDefaultSlTp(trade.signalId) }
                )
            }

            // Latest signal explanations
            val latestSig = chartState.signals.firstOrNull()
            if (latestSig != null) {
                val reasons = remember(latestSig.topReasonsJson) {
                    runCatching { json.decodeFromString<List<String>>(latestSig.topReasonsJson) }.getOrDefault(emptyList())
                }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "Latest Signal Explanation (${latestSig.direction})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (reasons.isEmpty()) {
                            Text("Confluence rule-based setup recorded.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            reasons.forEach { r ->
                                Text("• $r", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }

    val active = chartState.activeTrade
    if (showEditSlTpDialog && active != null) {
        var slText by remember(active.appliedSl) { mutableStateOf(active.appliedSl.toString()) }
        var tpText by remember(active.appliedTp) { mutableStateOf(active.appliedTp.toString()) }
        AlertDialog(
            onDismissRequest = { showEditSlTpDialog = false },
            title = { Text("Manual SL / TP Override") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = slText, onValueChange = { slText = it }, label = { Text("Stop Loss") }, singleLine = true)
                    OutlinedTextField(value = tpText, onValueChange = { tpText = it }, label = { Text("Take Profit") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val slVal = slText.toDoubleOrNull()
                    val tpVal = tpText.toDoubleOrNull()
                    if (slVal != null && tpVal != null && slVal > 0 && tpVal > 0) {
                        onUpdateManualSlTp(active.signalId, slVal, tpVal)
                        showEditSlTpDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showEditSlTpDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ActiveTradeStrip(
    trade: SignalCandidateEntity,
    currentPrice: Double?,
    onEditSlTp: () -> Unit,
    onResetDefaults: () -> Unit
) {
    val dir = TradeDirection.valueOf(trade.direction)
    val dirColor = if (dir == TradeDirection.LONG) LrmlcColors.LongGreen else LrmlcColors.ShortRed
    val price = currentPrice ?: trade.entryPrice
    val distTpPct = if (price > 0) ((trade.appliedTp - price) / price) * 100.0 * (if (dir == TradeDirection.LONG) 1.0 else -1.0) else 0.0
    val distSlPct = if (price > 0) ((price - trade.appliedSl) / price) * 100.0 * (if (dir == TradeDirection.LONG) 1.0 else -1.0) else 0.0

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${dir.emoji} Active ${dir.label}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = dirColor
                )
                Text(
                    text = if (!trade.modelWasTrained) "Unfiltered – model not trained yet"
                    else "Confidence ${(trade.pWin?.times(100)?.toInt() ?: 0)}%",
                    style = MaterialTheme.typography.labelLarge
                )
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                PriceColumn("Entry", PersistentNotificationFormatter.formatPrice(trade.entryPrice))
                PriceColumn("Current", PersistentNotificationFormatter.formatPrice(price))
                PriceColumn("TP", "${PersistentNotificationFormatter.formatPrice(trade.appliedTp)} (${String.format(Locale.US, "%+.2f%%", distTpPct)})", LrmlcColors.SupportLime)
                PriceColumn("SL", "${PersistentNotificationFormatter.formatPrice(trade.appliedSl)} (${String.format(Locale.US, "%.2f%%", distSlPct)})", LrmlcColors.ShortRed)
            }

            trade.slAdjustmentNote?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            trade.tpAdjustmentNote?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onEditSlTp) { Text("Override SL / TP") }
                if (trade.manualOverride || trade.appliedSl != trade.structuralSl || trade.appliedTp != trade.defaultTp) {
                    TextButton(onClick = onResetDefaults) { Text("Reset to Defaults") }
                }
            }
        }
    }
}

@Composable
private fun PriceColumn(
    label: String,
    value: String,
    valueColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface
) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, color = valueColor)
    }
}
