package com.lrmlc.tradingalerts.ui.insights

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lrmlc.tradingalerts.data.local.ExitCellRuleEntity
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import com.lrmlc.tradingalerts.ml.CalibrationBucket
import com.lrmlc.tradingalerts.ml.ExitFeatureSpec
import com.lrmlc.tradingalerts.ml.ValidationMetrics
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import com.lrmlc.tradingalerts.ui.theme.LrmlcShapes
import com.lrmlc.tradingalerts.ui.theme.SectionHeaderLabel
import com.lrmlc.tradingalerts.ui.theme.cardBorderStroke
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

@Composable
fun InsightsInfographicsHeader(
    metrics: ValidationMetrics?,
    recentSignals: List<SignalCandidateEntity>,
    trainingLogs: List<TrainingLogEntity>,
    selectedRange: InsightsRange,
    onSelectRange: (InsightsRange) -> Unit
) {
    val kpis = remember(metrics) { InsightsStats.extractKpis(metrics) }
    val calibration = remember(metrics) { InsightsStats.extractCalibrationPoints(metrics) }
    val trendPoints = remember(trainingLogs, selectedRange) {
        InsightsStats.buildTrainingTrend(trainingLogs, selectedRange)
    }
    val outcomes = remember(recentSignals, selectedRange) {
        InsightsStats.buildAlertOutcomes(recentSignals, selectedRange)
    }
    var trendShowWinRate by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Range chips (24h / 7d / 30d, default 7d)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionHeaderLabel("Performance Overview")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                InsightsRange.entries.forEach { r ->
                    val selected = selectedRange == r
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectRange(r) },
                        label = { Text(r.label, style = MaterialTheme.typography.labelSmall) },
                        shape = LrmlcShapes.ButtonShape,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }

        // Scrollable KPI tiles row
        KpiTilesRow(kpis)

        // Win-rate gauge
        WinRateGaugeCard(kpis)

        // Calibration scatter chart
        CalibrationChartCard(calibration)

        // Training trend chart
        TrainingTrendCard(
            points = trendPoints,
            range = selectedRange,
            showWinRate = trendShowWinRate,
            onToggleMode = { trendShowWinRate = !trendShowWinRate }
        )

        // Alert outcomes & cumulative net return
        AlertOutcomesCard(outcomes = outcomes, range = selectedRange)
    }
}

@Composable
private fun KpiTilesRow(kpis: InsightsKpiSummary) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (!kpis.hasMetrics) {
            KpiTile("Win Rate", "--", "No model yet", LrmlcColors.NeutralGrey)
            KpiTile("Net Expectancy", "--", "Per trade", LrmlcColors.NeutralGrey)
            KpiTile("Profit Factor", "--", "Gross W / L", LrmlcColors.NeutralGrey)
            KpiTile("OOS Trades", "0 / 0", "At threshold", LrmlcColors.NeutralGrey)
            KpiTile("Brier Score", "--", "vs baseline", LrmlcColors.NeutralGrey)
        } else {
            val winColor = when {
                kpis.winRate >= kpis.breakEven + 0.02 -> LrmlcColors.LongGreen
                kpis.winRate >= kpis.breakEven -> LrmlcColors.WarningAmber
                else -> LrmlcColors.ShortRed
            }
            KpiTile(
                label = "Win Rate",
                value = String.format(Locale.US, "%.1f%%", kpis.winRate * 100.0),
                sub = String.format(
                    Locale.US,
                    "95%% CI %.0f–%.0f%% · BE %.0f%%",
                    kpis.ciLow * 100.0,
                    kpis.ciHigh * 100.0,
                    kpis.breakEven * 100.0
                ),
                statusColor = winColor
            )
            val expColor = when {
                kpis.netExpectancyPct > 0.0005 -> LrmlcColors.LongGreen
                kpis.netExpectancyPct >= 0.0 -> LrmlcColors.WarningAmber
                else -> LrmlcColors.ShortRed
            }
            KpiTile(
                label = "Net Expectancy",
                value = String.format(Locale.US, "%+.2f%%", kpis.netExpectancyPct * 100.0),
                sub = "Per trade after fees",
                statusColor = expColor
            )
            val pfColor = when {
                kpis.profitFactor >= 1.2 -> LrmlcColors.LongGreen
                kpis.profitFactor >= 1.0 -> LrmlcColors.WarningAmber
                else -> LrmlcColors.ShortRed
            }
            KpiTile(
                label = "Profit Factor",
                value = String.format(Locale.US, "%.2f", kpis.profitFactor),
                sub = "Gross profit / loss",
                statusColor = pfColor
            )
            val tradesColor = when {
                kpis.tradesTaken >= 150 -> LrmlcColors.LongGreen
                kpis.tradesTaken >= 30 -> LrmlcColors.WarningAmber
                else -> LrmlcColors.ShortRed
            }
            KpiTile(
                label = "Trades / OOS",
                value = "${kpis.tradesTaken} / ${kpis.totalOutOfSample}",
                sub = if (kpis.tradesTaken < 150) "Small sample (<150)" else "At threshold",
                statusColor = tradesColor
            )
            val brierColor = when {
                kpis.brierScore < kpis.baselineBrier - 0.005 -> LrmlcColors.LongGreen
                kpis.brierScore <= kpis.baselineBrier -> LrmlcColors.WarningAmber
                else -> LrmlcColors.ShortRed
            }
            KpiTile(
                label = "Brier vs Base",
                value = String.format(Locale.US, "%.3f", kpis.brierScore),
                sub = String.format(Locale.US, "Baseline %.3f (lower better)", kpis.baselineBrier),
                statusColor = brierColor
            )
        }
    }
}

@Composable
private fun KpiTile(label: String, value: String, sub: String, statusColor: Color) {
    val tnumStyle = TextStyle(fontFamily = FontFamily.Monospace, fontFeatureSettings = "tnum")
    Card(
        modifier = Modifier.width(156.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = LrmlcShapes.CardShape,
        border = cardBorderStroke()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(statusColor))
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.merge(tnumStyle),
                fontWeight = FontWeight.Bold,
                color = statusColor
            )
            Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
private fun WinRateGaugeCard(kpis: InsightsKpiSummary) {
    val accent = MaterialTheme.colorScheme.primary
    val trackBg = MaterialTheme.colorScheme.surfaceVariant
    val onSurface = MaterialTheme.colorScheme.onSurface
    val textMeasurer = rememberTextMeasurer()
    val labelStyle = TextStyle(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = LrmlcShapes.CardShape,
        border = cardBorderStroke()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Win Rate vs Break-Even", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            if (!kpis.hasMetrics || kpis.tradesTaken <= 0) {
                Text("Not enough data yet", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val desc = "Win rate ${(kpis.winRate * 100).toInt()} percent vs break-even ${(kpis.breakEven * 100).toInt()} percent"
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .semantics { contentDescription = desc }
                ) {
                    val barY = 18f
                    val barH = 14f
                    drawRoundRect(
                        color = trackBg,
                        topLeft = Offset(0f, barY),
                        size = Size(size.width, barH),
                        cornerRadius = CornerRadius(7f, 7f)
                    )
                    val ciStart = (kpis.ciLow.toFloat().coerceIn(0f, 1f)) * size.width
                    val ciEnd = (kpis.ciHigh.toFloat().coerceIn(0f, 1f)) * size.width
                    drawRoundRect(
                        color = accent.copy(alpha = 0.30f),
                        topLeft = Offset(ciStart, barY),
                        size = Size((ciEnd - ciStart).coerceAtLeast(4f), barH),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                    val beX = (kpis.breakEven.toFloat().coerceIn(0f, 1f)) * size.width
                    drawLine(
                        color = LrmlcColors.WarningAmber,
                        start = Offset(beX, barY - 6f),
                        end = Offset(beX, barY + barH + 6f),
                        strokeWidth = 3f
                    )
                    val winX = (kpis.winRate.toFloat().coerceIn(0f, 1f)) * size.width
                    val dotColor = if (kpis.winRate >= kpis.breakEven) LrmlcColors.LongGreen else LrmlcColors.ShortRed
                    drawCircle(color = dotColor, radius = 8f, center = Offset(winX, barY + barH / 2f))
                    drawCircle(color = onSurface, radius = 3f, center = Offset(winX, barY + barH / 2f))

                    listOf(0 to "0%", 50 to "50%", 100 to "100%").forEach { (pct, txt) ->
                        val layout = textMeasurer.measure(txt, labelStyle)
                        val x = when (pct) {
                            0 -> 0f
                            100 -> (size.width - layout.size.width).coerceAtLeast(0f)
                            else -> (size.width * (pct / 100f) - layout.size.width / 2f)
                        }
                        drawText(layout, topLeft = Offset(x, barY + barH + 6f))
                    }
                }
                Text(
                    text = String.format(
                        Locale.US,
                        "Win %.1f%% (95%% band %.0f–%.0f%%) · Amber tick marks fee-aware break-even %.1f%%.",
                        kpis.winRate * 100.0,
                        kpis.ciLow * 100.0,
                        kpis.ciHigh * 100.0,
                        kpis.breakEven * 100.0
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun CalibrationChartCard(buckets: List<CalibrationBucket>) {
    val accent = MaterialTheme.colorScheme.primary
    val outlineColor = MaterialTheme.colorScheme.outline
    val labelStyle = TextStyle(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    val textMeasurer = rememberTextMeasurer()

    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = LrmlcShapes.CardShape,
        border = cardBorderStroke()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Probability Calibration", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            if (buckets.isEmpty()) {
                Text("Not enough data yet", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val maxSamples = (buckets.maxOfOrNull { it.sampleCount } ?: 1).coerceAtLeast(1)
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .semantics { contentDescription = "Calibration plot comparing predicted probability against actual win rate" }
                ) {
                    val leftPad = 36f
                    val bottomPad = 24f
                    val topPad = 10f
                    val rightPad = 12f
                    val plotW = (size.width - leftPad - rightPad).coerceAtLeast(10f)
                    val plotH = (size.height - topPad - bottomPad).coerceAtLeast(10f)

                    drawRect(
                        color = outlineColor.copy(alpha = 0.45f),
                        topLeft = Offset(leftPad, topPad),
                        size = Size(plotW, plotH),
                        style = Stroke(width = 1f)
                    )
                    // Diagonal perfect calibration line
                    drawLine(
                        color = LrmlcColors.NeutralGrey.copy(alpha = 0.65f),
                        start = Offset(leftPad, topPad + plotH),
                        end = Offset(leftPad + plotW, topPad),
                        strokeWidth = 2f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f))
                    )
                    listOf(0f, 0.5f, 1f).forEach { tick ->
                        val y = topPad + plotH * (1f - tick)
                        val x = leftPad + plotW * tick
                        drawLine(outlineColor.copy(alpha = 0.25f), Offset(leftPad, y), Offset(leftPad + plotW, y), 1f)
                        val lbl = "${(tick * 100).toInt()}%"
                        val layY = textMeasurer.measure(lbl, labelStyle)
                        drawText(layY, topLeft = Offset((leftPad - layY.size.width - 4f).coerceAtLeast(0f), y - layY.size.height / 2f))
                        val layX = textMeasurer.measure(lbl, labelStyle)
                        drawText(layX, topLeft = Offset((x - layX.size.width / 2f).coerceIn(leftPad, size.width - layX.size.width), topPad + plotH + 4f))
                    }
                    buckets.forEach { b ->
                        val cx = leftPad + b.predictedAvg.toFloat().coerceIn(0f, 1f) * plotW
                        val cy = topPad + (1f - b.actualWinRate.toFloat().coerceIn(0f, 1f)) * plotH
                        val radius = 5f + 8f * (b.sampleCount.toFloat() / maxSamples.toFloat())
                        val dotColor = if (b.actualWinRate + 0.02 >= b.predictedAvg) LrmlcColors.LongGreen else accent
                        drawCircle(color = dotColor.copy(alpha = 0.85f), radius = radius, center = Offset(cx, cy))
                    }
                }
                Text(
                    "Dots below the diagonal mean the model is overconfident.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun TrainingTrendCard(
    points: List<TrainingTrendPoint>,
    range: InsightsRange,
    showWinRate: Boolean,
    onToggleMode: () -> Unit
) {
    val accent = MaterialTheme.colorScheme.primary
    val outlineColor = MaterialTheme.colorScheme.outline
    val labelStyle = TextStyle(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    val textMeasurer = rememberTextMeasurer()

    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = LrmlcShapes.CardShape,
        border = cardBorderStroke()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Training Trend (${range.label})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                TextButton(onClick = onToggleMode) {
                    Text(if (showWinRate) "Show Expectancy" else "Show Win Rate", style = MaterialTheme.typography.labelSmall)
                }
            }
            if (points.size < 2) {
                Text("Not enough data yet", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val values = points.map { if (showWinRate) it.winRate * 100.0 else it.expectancyPct * 100.0 }
                val rawMin = values.minOrNull() ?: 0.0
                val rawMax = values.maxOrNull() ?: 1.0
                val minV = if (showWinRate) min(rawMin - 5.0, 40.0) else min(rawMin, 0.0) - 0.05
                val maxV = if (showWinRate) max(rawMax + 5.0, 65.0) else max(rawMax, 0.0) + 0.05
                val span = (maxV - minV).coerceAtLeast(1e-4)

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .semantics { contentDescription = "Training run trend across ${points.size} runs" }
                ) {
                    val leftPad = 42f
                    val vPad = 14f
                    val plotW = (size.width - leftPad - 10f).coerceAtLeast(10f)
                    val plotH = (size.height - vPad * 2f).coerceAtLeast(10f)

                    fun yFor(v: Double): Float {
                        val norm = ((v - minV) / span).toFloat().coerceIn(0f, 1f)
                        return vPad + plotH * (1f - norm)
                    }

                    if (!showWinRate && minV <= 0.0 && maxV >= 0.0) {
                        val zeroY = yFor(0.0)
                        drawLine(
                            color = LrmlcColors.NeutralGrey.copy(alpha = 0.6f),
                            start = Offset(leftPad, zeroY),
                            end = Offset(leftPad + plotW, zeroY),
                            strokeWidth = 1.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                        )
                    }
                    drawRect(outlineColor.copy(alpha = 0.35f), Offset(leftPad, vPad), Size(plotW, plotH), style = Stroke(1f))

                    val maxLbl = String.format(Locale.US, "%.1f%%", maxV)
                    val minLbl = String.format(Locale.US, "%.1f%%", minV)
                    drawText(textMeasurer.measure(maxLbl, labelStyle), topLeft = Offset(0f, vPad - 4f))
                    drawText(textMeasurer.measure(minLbl, labelStyle), topLeft = Offset(0f, vPad + plotH - 10f))

                    val path = Path()
                    val coords = ArrayList<Offset>(points.size)
                    points.forEachIndexed { idx, _ ->
                        val x = leftPad + (idx.toFloat() / (points.size - 1).coerceAtLeast(1)) * plotW
                        val y = yFor(values[idx])
                        val pt = Offset(x, y)
                        coords.add(pt)
                        if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, color = accent, style = Stroke(width = 3f))
                    coords.forEachIndexed { idx, pt ->
                        val promoted = points[idx].promoted
                        drawCircle(
                            color = if (promoted) LrmlcColors.LongGreen else outlineColor,
                            radius = if (promoted) 6f else 4f,
                            center = pt
                        )
                    }
                }
                Text(
                    "Tracks ${if (showWinRate) "win rate" else "net expectancy"} across ${points.size} runs; green dots mark promoted models.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun AlertOutcomesCard(outcomes: AlertOutcomesBreakdown, range: InsightsRange) {
    val accent = MaterialTheme.colorScheme.primary
    val outlineColor = MaterialTheme.colorScheme.outline
    val labelStyle = TextStyle(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    val textMeasurer = rememberTextMeasurer()

    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = LrmlcShapes.CardShape,
        border = cardBorderStroke()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Alert Outcomes (${range.label})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            if (outcomes.totalCount == 0) {
                Text("Not enough data yet", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val total = outcomes.totalCount.toFloat().coerceAtLeast(1f)
                val segments = listOf(
                    outcomes.tpCount to LrmlcColors.LongGreen,
                    outcomes.slCount to LrmlcColors.ShortRed,
                    outcomes.oppositeCount to LrmlcColors.WarningAmber,
                    outcomes.manualCount to LrmlcColors.NeutralGrey,
                    outcomes.activeCount to accent
                )
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(20.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .semantics { contentDescription = "Alert outcomes breakdown stacked bar" }
                ) {
                    var x = 0f
                    segments.forEach { (count, color) ->
                        if (count > 0) {
                            val w = (count / total) * size.width
                            drawRect(color = color, topLeft = Offset(x, 0f), size = Size(w, size.height))
                            x += w
                        }
                    }
                }
                Text(
                    "TP ${outcomes.tpCount} · SL ${outcomes.slCount} · Opp ${outcomes.oppositeCount} · Manual ${outcomes.manualCount} · Active ${outcomes.activeCount}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                val curve = outcomes.cumulativeReturnsPct
                if (curve.size >= 2) {
                    val pctValues = curve.map { it * 100.0 }
                    val minV = min(0.0, pctValues.minOrNull() ?: 0.0) - 0.1
                    val maxV = max(0.0, pctValues.maxOrNull() ?: 0.0) + 0.1
                    val span = (maxV - minV).coerceAtLeast(1e-4)
                    val endColor = if (pctValues.last() >= 0.0) LrmlcColors.LongGreen else LrmlcColors.ShortRed

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .semantics { contentDescription = "Cumulative net return curve of resolved alerts" }
                    ) {
                        val leftPad = 42f
                        val vPad = 10f
                        val plotW = (size.width - leftPad - 8f).coerceAtLeast(10f)
                        val plotH = (size.height - vPad * 2f).coerceAtLeast(10f)
                        fun yFor(v: Double): Float = vPad + plotH * (1f - ((v - minV) / span).toFloat().coerceIn(0f, 1f))

                        val zeroY = yFor(0.0)
                        drawLine(
                            outlineColor,
                            Offset(leftPad, zeroY),
                            Offset(leftPad + plotW, zeroY),
                            strokeWidth = 1.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                        )
                        drawText(textMeasurer.measure(String.format(Locale.US, "%+.1f%%", pctValues.last()), labelStyle), topLeft = Offset(0f, vPad))

                        val path = Path()
                        pctValues.forEachIndexed { i, v ->
                            val x = leftPad + (i.toFloat() / (pctValues.size - 1).coerceAtLeast(1)) * plotW
                            val y = yFor(v)
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        drawPath(path, color = endColor, style = Stroke(width = 3f))
                    }
                    Text(
                        String.format(
                            Locale.US,
                            "Cumulative net return across %d resolved alerts: %+.2f%%.",
                            curve.size,
                            pctValues.last()
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        "Needs at least 2 resolved accepted alerts in ${range.label} for cumulative return curve.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun ExitPhaseCellGrid(rules: List<ExitCellRuleEntity>) {
    val ruleMap = remember(rules) {
        rules.associateBy { it.ageBucket to it.progressBucket }
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Spacer(modifier = Modifier.width(52.dp))
            ExitFeatureSpec.PROGRESS_BUCKET_LABELS.forEach { label ->
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        ExitFeatureSpec.AGE_BUCKET_LABELS.forEachIndexed { ageIdx, ageLabel ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = ageLabel,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(52.dp)
                )
                for (progIdx in 0..2) {
                    val r = ruleMap[ageIdx to progIdx]
                    val enabled = r != null && (r.mlEnabled || r.structEnabled)
                    val bg = if (enabled) {
                        LrmlcColors.LongGreen.copy(alpha = 0.16f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                    val fg = if (enabled) LrmlcColors.LongGreen else MaterialTheme.colorScheme.onSurfaceVariant
                    val text = if (enabled && r != null) {
                        val mode = buildString {
                            if (r.mlEnabled) append("${(r.mlThreshold * 100).toInt()}%")
                            if (r.structEnabled) append(if (isNotEmpty()) "+S" else "Struct")
                        }
                        "$mode · ${(r.precision * 100).toInt()}%"
                    } else {
                        "Silent"
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(bg)
                            .padding(horizontal = 4.dp, vertical = 5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = text, style = MaterialTheme.typography.labelSmall, color = fg, maxLines = 1)
                    }
                }
            }
        }
    }
}
