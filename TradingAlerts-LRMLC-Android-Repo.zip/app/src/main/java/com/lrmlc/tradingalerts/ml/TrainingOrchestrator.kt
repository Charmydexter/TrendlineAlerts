package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import com.lrmlc.tradingalerts.data.local.MlModelDao
import com.lrmlc.tradingalerts.data.local.MlModelEntity
import com.lrmlc.tradingalerts.data.local.SettingsRepository
import com.lrmlc.tradingalerts.data.local.SignalCandidateDao
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.TrainingJobDao
import com.lrmlc.tradingalerts.data.local.TrainingJobEntity
import com.lrmlc.tradingalerts.data.local.TrainingLogDao
import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import com.lrmlc.tradingalerts.data.local.WatchlistDao
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.data.repository.CandleStoreRepository
import com.lrmlc.tradingalerts.engine.ConfluenceEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

enum class TrainingJobType(val label: String) {
    INITIAL("Initial 4-Week Training"),
    DAILY("Daily Incremental Update"),
    THREE_DAY("3-Day Rolling Refit"),
    WEEKLY("Weekly Full Refit"),
    MANUAL("Manual Full Training")
}

@Serializable
data class FullJobCheckpoint(
    val globalCheckpoint: TrainingCheckpointState? = null,
    val currentAssetSymbol: String? = null,
    val assetCheckpoint: TrainingCheckpointState? = null,
    val exitCheckpoint: TrainingCheckpointState? = null
)

data class TrainingStatusSnapshot(
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val progressPct: Int = 0,
    val stageMessage: String = "Idle",
    val lastError: String? = null
)

class TrainingOrchestrator(
    private val candleStore: CandleStoreRepository,
    private val watchlistDao: WatchlistDao,
    private val signalDao: SignalCandidateDao,
    private val mlModelDao: MlModelDao,
    private val trainingJobDao: TrainingJobDao,
    private val trainingLogDao: TrainingLogDao,
    private val settingsRepository: SettingsRepository
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val _status = MutableStateFlow(TrainingStatusSnapshot())
    val status: StateFlow<TrainingStatusSnapshot> = _status.asStateFlow()

    @Volatile
    private var pauseRequested = false

    fun requestPause() {
        pauseRequested = true
        _status.value = _status.value.copy(
            isPaused = true,
            isRunning = false,
            stageMessage = "Training paused at checkpoint"
        )
    }

    suspend fun enqueueJob(
        jobType: TrainingJobType,
        exchange: ExchangeId,
        marketType: MarketType
    ): TrainingJobEntity {
        val now = System.currentTimeMillis()
        val job = TrainingJobEntity(
            jobId = UUID.randomUUID().toString(),
            jobType = jobType.name,
            exchange = exchange.name,
            marketType = marketType.name,
            stage = "COLLECTING_SAMPLES",
            datasetCursor = 0,
            epoch = 0,
            batchIndex = 0,
            randomSeed = now,
            checkpointJson = json.encodeToString(FullJobCheckpoint()),
            status = "PENDING",
            progressPct = 0,
            statusMessage = "Queued: ${jobType.label}",
            createdAtMs = now,
            updatedAtMs = now
        )
        trainingJobDao.upsert(job)
        return job
    }

    suspend fun runNextOrSpecificJob(jobId: String? = null): Boolean = withContext(Dispatchers.Default) {
        pauseRequested = false
        val job = (if (jobId != null) trainingJobDao.getJob(jobId) else trainingJobDao.getNextResumableJob())
            ?: return@withContext true

        val exchange = ExchangeId.valueOf(job.exchange)
        val marketType = MarketType.valueOf(job.marketType)
        val jobType = TrainingJobType.valueOf(job.jobType)
        val settings = settingsRepository.getSettings()

        var currentJob = job.copy(status = "RUNNING", updatedAtMs = System.currentTimeMillis())
        trainingJobDao.upsert(currentJob)
        _status.value = TrainingStatusSnapshot(
            isRunning = true,
            isPaused = false,
            progressPct = currentJob.progressPct,
            stageMessage = currentJob.statusMessage
        )

        try {
            val watchlist = watchlistDao.getWatchlist(exchange.name, marketType.name)
            val symbols = watchlist.map { it.symbol }
            if (symbols.isEmpty()) {
                val done = currentJob.copy(
                    status = "COMPLETED",
                    stage = "COMPLETED",
                    progressPct = 100,
                    statusMessage = "No watchlist assets to train on",
                    updatedAtMs = System.currentTimeMillis()
                )
                trainingJobDao.upsert(done)
                _status.value = TrainingStatusSnapshot(progressPct = 100, stageMessage = done.statusMessage)
                return@withContext true
            }

            // Stage 1: Collect labeled samples from candle history + logged shadow/realized signals
            val lookbackDays = when (jobType) {
                TrainingJobType.DAILY -> 3 // fast update with recent history + newest day
                TrainingJobType.THREE_DAY -> 10
                TrainingJobType.INITIAL, TrainingJobType.WEEKLY, TrainingJobType.MANUAL -> settings.retentionDays
            }
            val nowMs = System.currentTimeMillis()
            val windowStartMs = nowMs - lookbackDays.toLong() * DayChunkCodec.MILLIS_PER_DAY

            val allSamples = ArrayList<LabeledSample>()
            val samplesBySymbol = HashMap<String, List<LabeledSample>>()
            val exitStateSamples = ArrayList<LabeledSample>()
            val allHistoricalCandidates = ArrayList<SignalCandidateEntity>()

            for ((idx, sym) in symbols.withIndex()) {
                if (pauseRequested) {
                    savePaused(currentJob, "Paused while collecting features for $sym")
                    return@withContext false
                }
                val pct = ((idx + 1) * 35) / symbols.size.coerceAtLeast(1)
                updateProgress(currentJob.copy(stage = "COLLECTING_SAMPLES", datasetCursor = idx, progressPct = pct, statusMessage = "Extracting signals & features (${idx + 1}/${symbols.size})"))

                val candles = candleStore.loadCandles(exchange, marketType, sym, windowStartMs, nowMs)
                if (candles.size < settings.engineConfig.windowLength + 10) continue

                val extracted = extractSamplesFromCandles(
                    exchange = exchange,
                    marketType = marketType,
                    symbol = sym,
                    candles = candles,
                    settings = settings
                )
                allSamples.addAll(extracted.signalSamples)
                samplesBySymbol[sym] = extracted.signalSamples
                exitStateSamples.addAll(extracted.exitSamples)
                allHistoricalCandidates.addAll(extracted.candidateEntities)
            }

            // Also include any live/shadow trades logged in Room that already resolved
            val allExistingInDb = signalDao.getAllForMarket(exchange.name, marketType.name)
            val logged = allExistingInDb.filter { it.label != null }
            val existingIds = allExistingInDb.map { it.signalId }.toHashSet()
            val newLoggedEntities = allHistoricalCandidates.filter { !existingIds.contains(it.signalId) }
            if (newLoggedEntities.isNotEmpty() && jobType == TrainingJobType.INITIAL) {
                // Persist historical shadow records so MAE/MFE stats & Insights are immediately populated
                signalDao.upsertAll(newLoggedEntities.takeLast(500))
            }

            // Merge live resolved signals not already covered by candle scan
            for (sig in logged) {
                val feats = runCatching { json.decodeFromString<DoubleArray>(sig.featuresJson) }.getOrNull()
                if (feats != null && feats.size == FeatureSpec.FEATURE_COUNT && sig.label != null) {
                    val sample = LabeledSample(
                        timestampMs = sig.signalTimeMs,
                        exitTimeMs = sig.exitTimeMs ?: (sig.signalTimeMs + settings.engineConfig.labelHorizonBars * 60_000L),
                        symbol = sig.symbol,
                        features = feats,
                        label = sig.label,
                        netReturnPct = sig.netReturnPct ?: 0.0,
                        maePct = sig.maePct ?: 0.0,
                        mfePct = sig.mfePct ?: 0.0
                    )
                    if (allSamples.none { it.symbol == sig.symbol && it.timestampMs == sig.signalTimeMs }) {
                        allSamples.add(sample)
                        samplesBySymbol[sig.symbol] = (samplesBySymbol[sig.symbol].orEmpty()) + sample
                    }
                }
            }

            if (allSamples.size < 15) {
                val msg = "Only ${allSamples.size} labeled setups found so far; waiting for more history before activating ML filter."
                trainingLogDao.insert(
                    TrainingLogEntity(
                        timestampMs = System.currentTimeMillis(),
                        exchange = exchange.name,
                        marketType = marketType.name,
                        jobType = jobType.name,
                        promoted = false,
                        summary = msg,
                        metricsJson = "{}"
                    )
                )
                val done = currentJob.copy(status = "COMPLETED", stage = "COMPLETED", progressPct = 100, statusMessage = msg, updatedAtMs = System.currentTimeMillis())
                trainingJobDao.upsert(done)
                _status.value = TrainingStatusSnapshot(progressPct = 100, stageMessage = msg)
                return@withContext true
            }

            var ckpt = runCatching { json.decodeFromString<FullJobCheckpoint>(currentJob.checkpointJson) }
                .getOrDefault(FullJobCheckpoint())

            // Stage 2: Global model walk-forward validation & checkpointed fit
            updateProgress(currentJob.copy(stage = "TRAINING_GLOBAL", progressPct = 45, statusMessage = "Validating & training global ${marketType.displayName} model (${allSamples.size} setups)"))
            val sortedGlobal = allSamples.sortedBy { it.timestampMs }
            val rr = (settings.engineConfig.takeProfitUsd / settings.engineConfig.maxLossUsd.coerceAtLeast(0.01))
            val globalStats = StandardizationStats.fit(sortedGlobal.map { it.features }, FeatureSpec.FEATURE_COUNT)
            val weightedGlobal = OverlapWeightCalculator.assignOverlapWeights(sortedGlobal)

            var lastCheckpointWriteMs = System.currentTimeMillis()
            val trainedGlobalWeights = LogisticRegressionTrainer.trainWithCheckpoints(
                samples = weightedGlobal,
                stats = globalStats,
                featureCount = FeatureSpec.FEATURE_COUNT,
                params = LogisticHyperParams(epochs = if (jobType == TrainingJobType.DAILY) 12 else 25),
                resumeState = ckpt.globalCheckpoint,
                seed = currentJob.randomSeed,
                onCheckpoint = { state ->
                    val now = System.currentTimeMillis()
                    if (now - lastCheckpointWriteMs >= 2500L || state.batchIndex == 0) {
                        lastCheckpointWriteMs = now
                        ckpt = ckpt.copy(globalCheckpoint = state)
                        currentJob = currentJob.copy(
                            stage = "TRAINING_GLOBAL",
                            epoch = state.epoch,
                            batchIndex = state.batchIndex,
                            checkpointJson = json.encodeToString(ckpt),
                            progressPct = (45 + (state.epoch * 20) / 25).coerceIn(45, 65),
                            updatedAtMs = now
                        )
                        // Blocking room checkpoint inside Default dispatcher
                        kotlinx.coroutines.runBlocking { trainingJobDao.upsert(currentJob) }
                    }
                    if (pauseRequested) throw CancellationException("Paused by user")
                }
            )

            val (_, globalMetrics) = WalkForwardValidator.validateAndSelectThreshold(
                chronologicalSamples = sortedGlobal,
                featureCount = FeatureSpec.FEATURE_COUNT,
                horizonBars = settings.engineConfig.labelHorizonBars,
                rewardToRisk = rr
            )

            // Promotion check for global model
            val globalKey = "GLOBAL_${exchange.name}_${marketType.name}"
            val existingGlobal = mlModelDao.getActiveModel(globalKey)
            val existingGlobalBundle = existingGlobal?.let {
                runCatching { json.decodeFromString<SerializedModelBundle>(it.modelJson) }.getOrNull()
            }
            val recentWindow = sortedGlobal.takeLast((sortedGlobal.size / 3).coerceAtLeast(15))
            val recentNewPreds = recentWindow.map { trainedGlobalWeights.predictProbability(it.features) to it }
            val recentNewMetrics = WalkForwardValidator.evaluatePredictions(recentNewPreds, globalMetrics.breakEvenThreshold, globalMetrics.threshold)
            val recentOldMetrics = existingGlobalBundle?.let { old ->
                val oldPreds = recentWindow.map { old.weights.predictProbability(it.features) to it }
                WalkForwardValidator.evaluatePredictions(oldPreds, old.metrics.breakEvenThreshold, old.metrics.threshold)
            }

            val (promoteGlobal, promoReason) = WalkForwardValidator.shouldPromote(
                newMetrics = globalMetrics,
                existingActiveMetrics = existingGlobalBundle?.metrics,
                newModelOnRecent = recentNewMetrics,
                activeModelOnRecent = recentOldMetrics
            )

            val activeGlobalWeights: LogisticRegressionWeights = if (promoteGlobal) {
                val bundle = SerializedModelBundle(trainedGlobalWeights, globalMetrics)
                mlModelDao.atomicSwapActive(
                    MlModelEntity(
                        modelKey = globalKey,
                        modelKind = "GLOBAL",
                        exchange = exchange.name,
                        marketType = marketType.name,
                        symbol = null,
                        version = (existingGlobal?.version ?: 0) + 1,
                        trainedAtMs = System.currentTimeMillis(),
                        sampleCount = sortedGlobal.size,
                        threshold = globalMetrics.threshold,
                        brierScore = globalMetrics.brierScore,
                        winRate = globalMetrics.winRate,
                        profitFactor = globalMetrics.profitFactor,
                        netExpectancy = globalMetrics.netExpectancyPct,
                        maxDrawdown = globalMetrics.maxDrawdownPct,
                        modelJson = json.encodeToString(bundle),
                        isActive = true
                    )
                )
                trainedGlobalWeights
            } else {
                existingGlobalBundle?.weights ?: trainedGlobalWeights
            }

            // Stage 3: Per-asset hierarchical models (pulled toward global weights)
            updateProgress(currentJob.copy(stage = "TRAINING_PER_ASSET", progressPct = 70, statusMessage = "Training per-asset hierarchical models..."))
            var assetModelsUpdated = 0
            for ((sym, assetSamples) in samplesBySymbol) {
                if (pauseRequested) {
                    savePaused(currentJob, "Paused during per-asset training ($sym)")
                    return@withContext false
                }
                if (assetSamples.size < settings.minSamplesForPerAssetModel) continue
                val (assetWeights, assetMetrics) = WalkForwardValidator.validateAndSelectThreshold(
                    chronologicalSamples = assetSamples,
                    featureCount = FeatureSpec.FEATURE_COUNT,
                    horizonBars = settings.engineConfig.labelHorizonBars,
                    rewardToRisk = rr,
                    priorWeights = activeGlobalWeights.weights
                )
                val assetKey = "ASSET_${exchange.name}_${marketType.name}_$sym"
                val prevAsset = mlModelDao.getActiveModel(assetKey)
                val prevAssetBundle = prevAsset?.let {
                    runCatching { json.decodeFromString<SerializedModelBundle>(it.modelJson) }.getOrNull()
                }
                val (promoteAsset, _) = WalkForwardValidator.shouldPromote(assetMetrics, prevAssetBundle?.metrics)
                if (promoteAsset) {
                    mlModelDao.atomicSwapActive(
                        MlModelEntity(
                            modelKey = assetKey,
                            modelKind = "PER_ASSET",
                            exchange = exchange.name,
                            marketType = marketType.name,
                            symbol = sym,
                            version = (prevAsset?.version ?: 0) + 1,
                            trainedAtMs = System.currentTimeMillis(),
                            sampleCount = assetSamples.size,
                            threshold = assetMetrics.threshold,
                            brierScore = assetMetrics.brierScore,
                            winRate = assetMetrics.winRate,
                            profitFactor = assetMetrics.profitFactor,
                            netExpectancy = assetMetrics.netExpectancyPct,
                            maxDrawdown = assetMetrics.maxDrawdownPct,
                            modelJson = json.encodeToString(SerializedModelBundle(assetWeights, assetMetrics)),
                            isActive = true
                        )
                    )
                    assetModelsUpdated++
                }
            }

            // Stage 4: Exit warning logistic regression model
            updateProgress(currentJob.copy(stage = "TRAINING_EXIT", progressPct = 88, statusMessage = "Training exit-reversal warning model..."))
            if (exitStateSamples.size >= 20) {
                val (exitWeights, exitThresh) = ExitWarningFeatureBuilder.trainExitModel(exitStateSamples)
                val exitKey = "EXIT_${exchange.name}_${marketType.name}"
                val prevExit = mlModelDao.getActiveModel(exitKey)
                val exitMetrics = ValidationMetrics(
                    threshold = exitThresh,
                    breakEvenThreshold = 0.5,
                    tradesTaken = exitStateSamples.size,
                    totalOutOfSample = exitStateSamples.size,
                    winRate = exitStateSamples.count { it.label == 1 }.toDouble() / exitStateSamples.size,
                    netExpectancyPct = 0.0,
                    profitFactor = 1.0,
                    maxDrawdownPct = 0.0,
                    brierScore = 0.2,
                    baselineExpectancyPct = 0.0,
                    baselineWinRate = 0.5,
                    calibrationBuckets = emptyList()
                )
                mlModelDao.atomicSwapActive(
                    MlModelEntity(
                        modelKey = exitKey,
                        modelKind = "EXIT",
                        exchange = exchange.name,
                        marketType = marketType.name,
                        symbol = null,
                        version = (prevExit?.version ?: 0) + 1,
                        trainedAtMs = System.currentTimeMillis(),
                        sampleCount = exitStateSamples.size,
                        threshold = exitThresh,
                        brierScore = 0.2,
                        winRate = exitMetrics.winRate,
                        profitFactor = 1.0,
                        netExpectancy = 0.0,
                        maxDrawdown = 0.0,
                        modelJson = json.encodeToString(SerializedModelBundle(exitWeights, exitMetrics)),
                        isActive = true
                    )
                )
            }

            val finalSummary = "$promoReason Updated $assetModelsUpdated per-asset model(s) across ${sortedGlobal.size} setups."
            trainingLogDao.insert(
                TrainingLogEntity(
                    timestampMs = System.currentTimeMillis(),
                    exchange = exchange.name,
                    marketType = marketType.name,
                    jobType = jobType.name,
                    promoted = promoteGlobal,
                    summary = finalSummary,
                    metricsJson = json.encodeToString(globalMetrics)
                )
            )

            val completed = currentJob.copy(
                stage = "COMPLETED",
                status = "COMPLETED",
                progressPct = 100,
                statusMessage = finalSummary,
                updatedAtMs = System.currentTimeMillis()
            )
            trainingJobDao.upsert(completed)
            _status.value = TrainingStatusSnapshot(
                isRunning = false,
                isPaused = false,
                progressPct = 100,
                stageMessage = finalSummary
            )
            true
        } catch (ce: CancellationException) {
            if (pauseRequested) {
                savePaused(currentJob, "Training paused cleanly at checkpoint")
                false
            } else {
                throw ce
            }
        } catch (e: Exception) {
            val failed = currentJob.copy(
                status = "FAILED",
                statusMessage = e.message ?: "Training failed",
                updatedAtMs = System.currentTimeMillis()
            )
            trainingJobDao.upsert(failed)
            _status.value = TrainingStatusSnapshot(
                isRunning = false,
                lastError = e.message ?: "Training failed",
                stageMessage = failed.statusMessage
            )
            false
        }
    }

    private suspend fun updateProgress(job: TrainingJobEntity) {
        val updated = job.copy(updatedAtMs = System.currentTimeMillis())
        trainingJobDao.upsert(updated)
        _status.value = _status.value.copy(
            isRunning = true,
            isPaused = false,
            progressPct = updated.progressPct,
            stageMessage = updated.statusMessage
        )
    }

    private suspend fun savePaused(job: TrainingJobEntity, msg: String) {
        trainingJobDao.upsert(job.copy(status = "PAUSED", statusMessage = msg, updatedAtMs = System.currentTimeMillis()))
        _status.value = _status.value.copy(isRunning = false, isPaused = true, stageMessage = msg)
    }

    private data class ExtractedAssetData(
        val signalSamples: List<LabeledSample>,
        val exitSamples: List<LabeledSample>,
        val candidateEntities: List<SignalCandidateEntity>
    )

    private fun extractSamplesFromCandles(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        candles: List<Candle>,
        settings: AppSettings
    ): ExtractedAssetData {
        val config = settings.engineConfig
        val engine = ConfluenceEngine(config)
        val snapshots = engine.evaluateAll(candles)

        val signalSamples = ArrayList<LabeledSample>()
        val exitSamples = ArrayList<LabeledSample>()
        val entities = ArrayList<SignalCandidateEntity>()
        var lastOutcome: Int? = null

        for (i in snapshots.indices) {
            val snap = snapshots[i]
            val dir = snap.candidateDirection ?: continue
            val sl = snap.structuralSl ?: continue
            val tp = snap.defaultTp ?: continue

            val features = FeatureBuilder.buildFeatures(
                candles = candles,
                snapshots = snapshots,
                barIndex = i,
                marketType = marketType,
                lastSignalOutcome = lastOutcome
            ) ?: continue

            val barrier = TripleBarrierLabeler.labelCandidate(
                candles = candles,
                signalBarIndex = i,
                direction = dir,
                entryPrice = snap.candle.close,
                slPrice = sl,
                tpPrice = tp,
                horizonBars = config.labelHorizonBars,
                roundTripFeeRate = config.roundTripFeeRate,
                timeoutLabelMode = config.timeoutLabelMode
            )

            val label = barrier.label ?: continue
            lastOutcome = label
            val exitBarTime = candles.getOrNull(barrier.exitBarIndex)?.openTimeMs
                ?: (snap.candle.openTimeMs + config.labelHorizonBars * 60_000L)

            signalSamples.add(
                LabeledSample(
                    timestampMs = snap.candle.openTimeMs,
                    exitTimeMs = exitBarTime,
                    symbol = symbol,
                    features = features,
                    label = label,
                    netReturnPct = barrier.netReturnPct,
                    maePct = barrier.maePct,
                    mfePct = barrier.mfePct
                )
            )

            // Sample bar-by-bar states inside this trade for Exit-Warning model
            val endStep = barrier.exitBarIndex.coerceAtMost(candles.lastIndex)
            val exitLabel = if (barrier.outcome == BarrierOutcome.SL_HIT || barrier.outcome == BarrierOutcome.TIMEOUT_LOSS) 1 else 0
            val stride = ((endStep - i) / 4).coerceAtLeast(1)
            var b = i + 1
            while (b < endStep) {
                val exitFeats = ExitWarningFeatureBuilder.buildStateFeatures(
                    candles = candles,
                    snapshots = snapshots,
                    currentBarIndex = b,
                    entryBarIndex = i,
                    direction = dir,
                    entryPrice = snap.candle.close,
                    slPrice = sl,
                    tpPrice = tp
                )
                if (exitFeats != null) {
                    exitSamples.add(
                        LabeledSample(
                            timestampMs = candles[b].openTimeMs,
                            exitTimeMs = exitBarTime,
                            symbol = symbol,
                            features = exitFeats,
                            label = exitLabel,
                            netReturnPct = barrier.netReturnPct
                        )
                    )
                }
                b += stride
            }

            entities.add(
                SignalCandidateEntity(
                    signalId = "${exchange.name}_${marketType.name}_${symbol}_${snap.candle.openTimeMs}",
                    exchange = exchange.name,
                    marketType = marketType.name,
                    symbol = symbol,
                    direction = dir.name,
                    signalTimeMs = snap.candle.openTimeMs,
                    barIndex = i,
                    entryPrice = snap.candle.close,
                    structuralSl = sl,
                    defaultTp = tp,
                    appliedSl = sl,
                    appliedTp = tp,
                    slAdjustmentNote = null,
                    tpAdjustmentNote = null,
                    pWin = null,
                    thresholdUsed = null,
                    modelWasTrained = false,
                    accepted = false,
                    status = "SHADOW",
                    exitTimeMs = exitBarTime,
                    exitPrice = barrier.exitPrice,
                    netReturnPct = barrier.netReturnPct,
                    maePct = barrier.maePct,
                    mfePct = barrier.mfePct,
                    label = label,
                    featuresJson = json.encodeToString(features),
                    topReasonsJson = "[]",
                    notified = true
                )
            )
        }
        return ExtractedAssetData(signalSamples, exitSamples, entities)
    }
}
