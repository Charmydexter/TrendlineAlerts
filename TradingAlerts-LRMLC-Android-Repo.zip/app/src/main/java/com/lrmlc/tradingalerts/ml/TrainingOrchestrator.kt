package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.local.AssetPresetSelectionDao
import com.lrmlc.tradingalerts.data.local.AssetPresetSelectionEntity
import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import com.lrmlc.tradingalerts.data.local.ExitCellRuleDao
import com.lrmlc.tradingalerts.data.local.MlModelDao
import com.lrmlc.tradingalerts.data.local.MlModelEntity
import com.lrmlc.tradingalerts.data.local.SettingsRepository
import com.lrmlc.tradingalerts.data.local.SignalCandidateDao
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.TrainingJobDao
import com.lrmlc.tradingalerts.data.local.TrainingJobEntity
import com.lrmlc.tradingalerts.data.local.TrainingLogDao
import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import com.lrmlc.tradingalerts.data.local.WatchlistDao
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.RangePreset
import com.lrmlc.tradingalerts.data.model.RangePresets
import com.lrmlc.tradingalerts.data.model.ThresholdMode
import com.lrmlc.tradingalerts.data.repository.CandleStoreRepository
import com.lrmlc.tradingalerts.engine.ConfluenceEngine
import com.lrmlc.tradingalerts.trade.SlTpManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID
import kotlin.math.abs

enum class TrainingJobType(val label: String) {
    INITIAL("Initial 4-Week Training"),
    DAILY("Daily Incremental Update"),
    THREE_DAY("3-Day Rolling Refit"),
    WEEKLY("Weekly Full Refit"),
    MANUAL("Manual Full Training")
}

@Serializable
data class FullJobCheckpoint(
    val globalCheckpoint: TrainingCheckpointState? = null,
    val currentPresetIndex: Int = 0,
    val currentAssetSymbol: String? = null,
    val assetCheckpoint: TrainingCheckpointState? = null,
    val exitCheckpoint: TrainingCheckpointState? = null
)

data class TrainingStatusSnapshot(
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val progressPct: Int = 0,
    val stageMessage: String = "Idle",
    val lastError: String? = null
)

class TrainingOrchestrator(
    private val candleStore: CandleStoreRepository,
    private val watchlistDao: WatchlistDao,
    private val signalDao: SignalCandidateDao,
    private val mlModelDao: MlModelDao,
    private val trainingJobDao: TrainingJobDao,
    private val trainingLogDao: TrainingLogDao,
    private val exitCellRuleDao: ExitCellRuleDao,
    private val assetPresetSelectionDao: AssetPresetSelectionDao,
    private val settingsRepository: SettingsRepository
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val _status = MutableStateFlow(TrainingStatusSnapshot())
    val status: StateFlow<TrainingStatusSnapshot> = _status.asStateFlow()

    @Volatile
    private var pauseRequested = false

    fun requestPause() {
        pauseRequested = true
        _status.value = _status.value.copy(
            isPaused = true,
            isRunning = false,
            stageMessage = "Training paused at checkpoint"
        )
    }

    suspend fun enqueueJob(
        jobType: TrainingJobType,
        exchange: ExchangeId,
        marketType: MarketType
    ): TrainingJobEntity {
        val now = System.currentTimeMillis()
        val job = TrainingJobEntity(
            jobId = UUID.randomUUID().toString(),
            jobType = jobType.name,
            exchange = exchange.name,
            marketType = marketType.name,
            stage = "COLLECTING_SAMPLES",
            datasetCursor = 0,
            epoch = 0,
            batchIndex = 0,
            randomSeed = now,
            checkpointJson = json.encodeToString(FullJobCheckpoint()),
            status = "PENDING",
            progressPct = 0,
            statusMessage = "Queued: ${jobType.label}",
            createdAtMs = now,
            updatedAtMs = now
        )
        trainingJobDao.upsert(job)
        return job
    }

    suspend fun runNextOrSpecificJob(jobId: String? = null): Boolean = withContext(Dispatchers.Default) {
        pauseRequested = false
        val job = (if (jobId != null) trainingJobDao.getJob(jobId) else trainingJobDao.getNextResumableJob())
            ?: return@withContext true

        val exchange = ExchangeId.valueOf(job.exchange)
        val marketType = MarketType.valueOf(job.marketType)
        val jobType = TrainingJobType.valueOf(job.jobType)
        val settings = settingsRepository.getSettings()
        val config = settings.engineConfig
        val startedAtMs = System.currentTimeMillis()

        var currentJob = job.copy(status = "RUNNING", updatedAtMs = startedAtMs)
        trainingJobDao.upsert(currentJob)
        _status.value = TrainingStatusSnapshot(
            isRunning = true,
            isPaused = false,
            progressPct = currentJob.progressPct,
            stageMessage = currentJob.statusMessage
        )

        try {
            val watchlist = watchlistDao.getWatchlist(exchange.name, marketType.name)
            val symbols = watchlist.map { it.symbol }
            if (symbols.isEmpty()) {
                val done = currentJob.copy(
                    status = "COMPLETED",
                    stage = "COMPLETED",
                    progressPct = 100,
                    statusMessage = "No watchlist assets to train on",
                    updatedAtMs = System.currentTimeMillis()
                )
                trainingJobDao.upsert(done)
                _status.value = TrainingStatusSnapshot(progressPct = 100, stageMessage = done.statusMessage)
                return@withContext true
            }

            val lookbackDays = when (jobType) {
                TrainingJobType.DAILY -> 3
                TrainingJobType.THREE_DAY -> 10
                TrainingJobType.INITIAL, TrainingJobType.WEEKLY, TrainingJobType.MANUAL -> settings.retentionDays
            }
            val nowMs = System.currentTimeMillis()
            val windowStartMs = nowMs - lookbackDays.toLong() * DayChunkCodec.MILLIS_PER_DAY
            val longestWarmup = RangePresets.R240.windowBars

            val candlesBySymbol = LinkedHashMap<String, List<Candle>>()
            val commonEvalStartMsBySymbol = HashMap<String, Long>()
            for ((idx, sym) in symbols.withIndex()) {
                if (pauseRequested) {
                    savePaused(currentJob, "Paused while loading candles for $sym")
                    return@withContext false
                }
                val pct = ((idx + 1) * 15) / symbols.size.coerceAtLeast(1)
                updateProgress(
                    currentJob.copy(
                        stage = "COLLECTING_SAMPLES",
                        datasetCursor = idx,
                        progressPct = pct,
                        statusMessage = "Loading candle history (${idx + 1}/${symbols.size})"
                    )
                )
                val candles = candleStore.loadCandles(exchange, marketType, sym, windowStartMs, nowMs)
                if (candles.size >= longestWarmup + 10) {
                    candlesBySymbol[sym] = candles
                    commonEvalStartMsBySymbol[sym] = candles[longestWarmup].openTimeMs
                }
            }

            val allExistingInDb = signalDao.getAllForMarket(exchange.name, marketType.name)
            val existingIds = allExistingInDb.map { it.signalId }.toHashSet()
            val prevLog = trainingLogDao.getLatestForMarket(exchange.name, marketType.name)
            val manualThreshEval = if (settings.thresholdMode == ThresholdMode.MANUAL) settings.manualThreshold else null
            val rr = config.takeProfitUsd / config.maxLossUsd.coerceAtLeast(0.01)
            val epochs = if (jobType == TrainingJobType.DAILY) 12 else 25

            var ckpt = runCatching { json.decodeFromString<FullJobCheckpoint>(currentJob.checkpointJson) }
                .getOrDefault(FullJobCheckpoint())

            data class PresetTrainingOutput(
                val preset: RangePreset,
                val samples: List<LabeledSample>,
                val samplesBySymbol: Map<String, List<LabeledSample>>,
                val timeoutCount: Int,
                val eval: PresetCandidateEval,
                val activeWeights: LogisticRegressionWeights,
                val activeMetrics: ValidationMetrics,
                val promoted: Boolean,
                val promotionReason: String,
                val candidateHoldoutMetrics: ValidationMetrics?,
                val activeHoldoutMetrics: ValidationMetrics?
            )

            val presetOutputs = ArrayList<PresetTrainingOutput>(RangePresets.ALL.size)
            val allHistoricalCandidates = ArrayList<SignalCandidateEntity>()

            for ((presetIdx, preset) in RangePresets.ALL.withIndex()) {
                if (pauseRequested) {
                    savePaused(currentJob, "Paused before preset ${preset.label}")
                    return@withContext false
                }
                val basePct = 15 + presetIdx * 13
                updateProgress(
                    currentJob.copy(
                        stage = "TRAINING_GLOBAL",
                        progressPct = basePct,
                        statusMessage = "Preset ${presetIdx + 1}/${RangePresets.ALL.size} (${preset.label}): extracting & validating"
                    )
                )

                val presetSamples = ArrayList<LabeledSample>()
                val presetSamplesBySym = HashMap<String, List<LabeledSample>>()
                var timeoutCount = 0

                for ((sym, candles) in candlesBySymbol) {
                    val minCommonMs = commonEvalStartMsBySymbol[sym] ?: continue
                    val extracted = extractSignalSamplesForPreset(
                        exchange = exchange,
                        marketType = marketType,
                        symbol = sym,
                        candles = candles,
                        settings = settings,
                        preset = preset,
                        minTimestampMs = minCommonMs
                    )
                    presetSamples.addAll(extracted.signalSamples)
                    presetSamplesBySym[sym] = extracted.signalSamples
                    timeoutCount += extracted.timeoutCount
                    if (preset.id == RangePresets.DEFAULT.id) {
                        allHistoricalCandidates.addAll(extracted.candidateEntities)
                    }
                }

                // Merge live/shadow resolved DB signals tagged with this preset
                for (sig in allExistingInDb) {
                    if (sig.label == null || sig.presetId != preset.id) continue
                    val feats = runCatching { json.decodeFromString<DoubleArray>(sig.featuresJson) }.getOrNull()
                    if (feats != null && feats.size == FeatureSpec.FEATURE_COUNT) {
                        val sample = LabeledSample(
                            timestampMs = sig.signalTimeMs,
                            exitTimeMs = sig.exitTimeMs ?: (sig.signalTimeMs + config.labelHorizonBars * 60_000L),
                            symbol = sig.symbol,
                            features = feats,
                            label = sig.label,
                            netReturnPct = sig.netReturnPct ?: 0.0,
                            maePct = sig.maePct ?: 0.0,
                            mfePct = sig.mfePct ?: 0.0
                        )
                        if (presetSamples.none { it.symbol == sig.symbol && it.timestampMs == sig.signalTimeMs }) {
                            presetSamples.add(sample)
                            presetSamplesBySym[sig.symbol] = presetSamplesBySym[sig.symbol].orEmpty() + sample
                        }
                    }
                }

                val sortedPreset = presetSamples.sortedBy { it.timestampMs }
                if (sortedPreset.size < 15) continue

                val globalStats = StandardizationStats.fit(sortedPreset.map { it.features }, FeatureSpec.FEATURE_COUNT)
                val weightedGlobal = OverlapWeightCalculator.assignOverlapWeights(sortedPreset)
                var lastCheckpointWriteMs = System.currentTimeMillis()
                val resumeGlobal = if (ckpt.currentPresetIndex == presetIdx) ckpt.globalCheckpoint else null

                val rawTrainedWeights = LogisticRegressionTrainer.trainWithCheckpoints(
                    samples = weightedGlobal,
                    stats = globalStats,
                    featureCount = FeatureSpec.FEATURE_COUNT,
                    params = LogisticHyperParams(epochs = epochs),
                    resumeState = resumeGlobal,
                    seed = currentJob.randomSeed + presetIdx * 31L,
                    onCheckpoint = { state ->
                        val now = System.currentTimeMillis()
                        if (now - lastCheckpointWriteMs >= 2500L || state.batchIndex == 0) {
                            lastCheckpointWriteMs = now
                            ckpt = ckpt.copy(currentPresetIndex = presetIdx, globalCheckpoint = state)
                            currentJob = currentJob.copy(
                                stage = "TRAINING_GLOBAL",
                                epoch = state.epoch,
                                batchIndex = state.batchIndex,
                                checkpointJson = json.encodeToString(ckpt),
                                progressPct = (basePct + (state.epoch * 12) / epochs).coerceIn(basePct, basePct + 12),
                                updatedAtMs = now
                            )
                            kotlinx.coroutines.runBlocking { trainingJobDao.upsert(currentJob) }
                        }
                        if (pauseRequested) throw CancellationException("Paused by user")
                    }
                )

                val wfResult = WalkForwardValidator.validateWithOosPredictions(
                    chronologicalSamples = sortedPreset,
                    featureCount = FeatureSpec.FEATURE_COUNT,
                    horizonBars = config.labelHorizonBars,
                    rewardToRisk = rr,
                    params = LogisticHyperParams(epochs = epochs),
                    manualThreshold = manualThreshEval
                )
                // Keep calibrated production model from WalkForwardValidator if it improved Brier
                val prodWeights = rawTrainedWeights.copy(calibrator = wfResult.model.calibrator)

                // True purged hold-out check for model promotion [U6]
                val globalKey = "GLOBAL_${exchange.name}_${marketType.name}_${preset.id}"
                val legacyGlobalKey = if (preset.id == RangePresets.DEFAULT.id) {
                    "GLOBAL_${exchange.name}_${marketType.name}"
                } else null
                val existingGlobal = mlModelDao.getActiveModel(globalKey)
                    ?: legacyGlobalKey?.let { mlModelDao.getActiveModel(it) }
                val existingGlobalBundle = existingGlobal?.let {
                    runCatching { json.decodeFromString<SerializedModelBundle>(it.modelJson) }.getOrNull()
                }

                val holdoutStartIdx = ((sortedPreset.size * 2) / 3).coerceIn(1, (sortedPreset.size - 1).coerceAtLeast(1))
                val holdoutSamples = sortedPreset.subList(holdoutStartIdx, sortedPreset.size)
                val holdoutStartMs = holdoutSamples.first().timestampMs
                val purgeGapMs = config.labelHorizonBars.coerceAtLeast(1) * DayChunkCodec.MILLIS_PER_MINUTE
                val preHoldoutTrain = sortedPreset.subList(0, holdoutStartIdx).filter {
                    it.exitTimeMs + purgeGapMs < holdoutStartMs
                }

                var candHoldoutMetrics: ValidationMetrics? = null
                var activeHoldoutMetrics: ValidationMetrics? = null

                val (promoteGlobal, promoReason) = if (preHoldoutTrain.size >= 25 && holdoutSamples.size >= WalkForwardValidator.MIN_HOLDOUT_TRADES) {
                    val (holdoutCandModel, holdoutCandValidation) = WalkForwardValidator.validateAndSelectThreshold(
                        chronologicalSamples = preHoldoutTrain,
                        featureCount = FeatureSpec.FEATURE_COUNT,
                        horizonBars = config.labelHorizonBars,
                        rewardToRisk = rr,
                        params = LogisticHyperParams(epochs = epochs),
                        manualThreshold = manualThreshEval
                    )
                    val candHoldoutPreds = holdoutSamples.map { holdoutCandModel.predictProbability(it.features) to it }
                    val cMetrics = WalkForwardValidator.evaluatePredictions(
                        preds = candHoldoutPreds,
                        breakEvenThreshold = holdoutCandValidation.breakEvenThreshold,
                        chosenThreshold = holdoutCandValidation.threshold
                    )
                    candHoldoutMetrics = cMetrics
                    val aMetrics = existingGlobalBundle?.let { old ->
                        val oldPreds = holdoutSamples.map { old.weights.predictProbability(it.features) to it }
                        WalkForwardValidator.evaluatePredictions(oldPreds, old.metrics.breakEvenThreshold, old.metrics.threshold)
                    }
                    activeHoldoutMetrics = aMetrics
                    WalkForwardValidator.shouldPromote(
                        newMetrics = wfResult.metrics,
                        existingActiveMetrics = existingGlobalBundle?.metrics,
                        newModelOnRecent = cMetrics,
                        activeModelOnRecent = aMetrics,
                        nowMs = nowMs,
                        lastPromotedAtMs = existingGlobal?.trainedAtMs ?: 0L,
                        lastPromotedSampleCount = existingGlobal?.sampleCount ?: 0,
                        currentSampleCount = sortedPreset.size
                    )
                } else {
                    WalkForwardValidator.shouldPromote(
                        newMetrics = wfResult.metrics,
                        existingActiveMetrics = existingGlobalBundle?.metrics,
                        nowMs = nowMs,
                        lastPromotedAtMs = existingGlobal?.trainedAtMs ?: 0L,
                        lastPromotedSampleCount = existingGlobal?.sampleCount ?: 0,
                        currentSampleCount = sortedPreset.size
                    )
                }

                val finalActiveWeights: LogisticRegressionWeights
                val finalActiveMetrics: ValidationMetrics
                if (promoteGlobal) {
                    val bundle = SerializedModelBundle(prodWeights, wfResult.metrics)
                    mlModelDao.atomicSwapActive(
                        MlModelEntity(
                            modelKey = globalKey,
                            modelKind = "GLOBAL",
                            exchange = exchange.name,
                            marketType = marketType.name,
                            symbol = null,
                            version = (existingGlobal?.version ?: 0) + 1,
                            trainedAtMs = nowMs,
                            sampleCount = sortedPreset.size,
                            threshold = wfResult.metrics.threshold,
                            brierScore = wfResult.metrics.brierScore,
                            winRate = wfResult.metrics.winRate,
                            profitFactor = wfResult.metrics.profitFactor,
                            netExpectancy = wfResult.metrics.netExpectancyPct,
                            maxDrawdown = wfResult.metrics.maxDrawdownPct,
                            modelJson = json.encodeToString(bundle),
                            isActive = true
                        )
                    )
                    if (legacyGlobalKey != null) {
                        mlModelDao.deactivateKey(legacyGlobalKey)
                    }
                    finalActiveWeights = prodWeights
                    finalActiveMetrics = wfResult.metrics
                } else {
                    finalActiveWeights = existingGlobalBundle?.weights ?: prodWeights
                    finalActiveMetrics = existingGlobalBundle?.metrics ?: wfResult.metrics
                }

                presetOutputs.add(
                    PresetTrainingOutput(
                        preset = preset,
                        samples = sortedPreset,
                        samplesBySymbol = presetSamplesBySym,
                        timeoutCount = timeoutCount,
                        eval = PresetCandidateEval(preset, wfResult.metrics, wfResult.oosPredictions),
                        activeWeights = finalActiveWeights,
                        activeMetrics = finalActiveMetrics,
                        promoted = promoteGlobal,
                        promotionReason = promoReason,
                        candidateHoldoutMetrics = candHoldoutMetrics,
                        activeHoldoutMetrics = activeHoldoutMetrics
                    )
                )
            }

            // Persist initial historical shadows cleanly if INITIAL run
            val newLoggedEntities = allHistoricalCandidates.filter { !existingIds.contains(it.signalId) }
            if (newLoggedEntities.isNotEmpty() && jobType == TrainingJobType.INITIAL) {
                signalDao.upsertAll(newLoggedEntities.takeLast(500))
            }

            if (presetOutputs.isEmpty()) {
                val msg = "Not enough labeled setups across presets yet; waiting for more candle history."
                val endNow = System.currentTimeMillis()
                trainingLogDao.insert(
                    TrainingLogEntity(
                        timestampMs = endNow,
                        exchange = exchange.name,
                        marketType = marketType.name,
                        jobType = jobType.name,
                        promoted = false,
                        summary = msg,
                        metricsJson = "{}",
                        reportJson = null
                    )
                )
                val done = currentJob.copy(status = "COMPLETED", stage = "COMPLETED", progressPct = 100, statusMessage = msg, updatedAtMs = endNow)
                trainingJobDao.upsert(done)
                _status.value = TrainingStatusSnapshot(progressPct = 100, stageMessage = msg)
                return@withContext true
            }

            // Select pooled-best and per-asset preset [U20]
            val evals = presetOutputs.map { it.eval }
            val pooledBestPreset = PresetSelector.selectPooledBest(evals)
            val existingSelections = assetPresetSelectionDao.getSelections(exchange.name, marketType.name)
                .associateBy { it.symbol }

            val outputById = presetOutputs.associateBy { it.preset.id }
            val selectedBySymbol = HashMap<String, AssetPresetChoice>()
            val newSelectionEntities = ArrayList<AssetPresetSelectionEntity>()

            for (sym in symbols) {
                val counts = RangePresets.ALL.associate { p ->
                    p.id to (outputById[p.id]?.samplesBySymbol?.get(sym)?.size ?: 0)
                }
                val choice = PresetSelector.selectPresetForAsset(
                    symbol = sym,
                    assetSampleCounts = counts,
                    evals = evals,
                    pooledBestPreset = pooledBestPreset,
                    previousPresetId = existingSelections[sym]?.presetId,
                    minSamplesForPerAsset = settings.minSamplesForPerAssetModel
                )
                selectedBySymbol[sym] = choice
                newSelectionEntities.add(
                    AssetPresetSelectionEntity(
                        exchange = exchange.name,
                        marketType = marketType.name,
                        symbol = sym,
                        presetId = choice.selectedPreset.id,
                        lcbExpectancy = choice.lcbExpectancy,
                        trades = choice.trades,
                        updatedAtMs = nowMs
                    )
                )
            }
            if (newSelectionEntities.isNotEmpty()) {
                assetPresetSelectionDao.upsertAll(newSelectionEntities)
            }

            // Stage 3: Per-asset hierarchical models for each asset's selected preset [U20]
            updateProgress(
                currentJob.copy(
                    stage = "TRAINING_PER_ASSET",
                    progressPct = 72,
                    statusMessage = "Training per-asset hierarchical models..."
                )
            )
            var assetModelsUpdated = 0
            val perAssetReportRows = ArrayList<ReportPerAssetRow>()

            for (sym in symbols) {
                if (pauseRequested) {
                    savePaused(currentJob, "Paused during per-asset training ($sym)")
                    return@withContext false
                }
                val choice = selectedBySymbol[sym] ?: continue
                val presetOut = outputById[choice.selectedPreset.id] ?: continue
                val assetSamples = presetOut.samplesBySymbol[sym].orEmpty()
                if (assetSamples.size < settings.minSamplesForPerAssetModel) continue

                val (assetWeights, assetMetrics) = WalkForwardValidator.validateAndSelectThreshold(
                    chronologicalSamples = assetSamples,
                    featureCount = FeatureSpec.FEATURE_COUNT,
                    horizonBars = config.labelHorizonBars,
                    rewardToRisk = rr,
                    priorWeights = presetOut.activeWeights.weights,
                    manualThreshold = manualThreshEval
                )
                val assetKey = "ASSET_${exchange.name}_${marketType.name}_${sym}_${choice.selectedPreset.id}"
                val prevAsset = mlModelDao.getActiveModel(assetKey)
                val prevAssetBundle = prevAsset?.let {
                    runCatching { json.decodeFromString<SerializedModelBundle>(it.modelJson) }.getOrNull()
                }
                val (promoteAsset, _) = WalkForwardValidator.shouldPromote(
                    newMetrics = assetMetrics,
                    existingActiveMetrics = prevAssetBundle?.metrics,
                    nowMs = nowMs,
                    lastPromotedAtMs = prevAsset?.trainedAtMs ?: 0L,
                    lastPromotedSampleCount = prevAsset?.sampleCount ?: 0,
                    currentSampleCount = assetSamples.size
                )
                if (promoteAsset) {
                    mlModelDao.atomicSwapActive(
                        MlModelEntity(
                            modelKey = assetKey,
                            modelKind = "PER_ASSET",
                            exchange = exchange.name,
                            marketType = marketType.name,
                            symbol = sym,
                            version = (prevAsset?.version ?: 0) + 1,
                            trainedAtMs = nowMs,
                            sampleCount = assetSamples.size,
                            threshold = assetMetrics.threshold,
                            brierScore = assetMetrics.brierScore,
                            winRate = assetMetrics.winRate,
                            profitFactor = assetMetrics.profitFactor,
                            netExpectancy = assetMetrics.netExpectancyPct,
                            maxDrawdown = assetMetrics.maxDrawdownPct,
                            modelJson = json.encodeToString(SerializedModelBundle(assetWeights, assetMetrics)),
                            isActive = true
                        )
                    )
                    assetModelsUpdated++
                }
                val m = if (promoteAsset) assetMetrics else (prevAssetBundle?.metrics ?: assetMetrics)
                perAssetReportRows.add(
                    ReportPerAssetRow(
                        symbol = sym,
                        presetId = choice.selectedPreset.id,
                        samples = assetSamples.size,
                        threshold = m.threshold,
                        winRate = m.winRate,
                        netExpectancyPct = m.netExpectancyPct,
                        profitFactor = m.profitFactor,
                        updatedOrKept = if (promoteAsset) "Updated" else "Kept"
                    )
                )
            }

            // Stage 4: Phase-aware exit warning model + 5x3 OOS phase rules [U22]
            updateProgress(
                currentJob.copy(
                    stage = "TRAINING_EXIT",
                    progressPct = 88,
                    statusMessage = "Learning phase-aware exit warning rules..."
                )
            )
            val exitPresetOut = outputById[pooledBestPreset.id] ?: presetOutputs.last()
            val exitStateSamples = ArrayList<ExitStateSample>()
            for ((sym, candles) in candlesBySymbol) {
                val chosenPreset = selectedBySymbol[sym]?.selectedPreset ?: pooledBestPreset
                val activeGlobalForSym = outputById[chosenPreset.id]?.activeWeights ?: exitPresetOut.activeWeights
                val minCommonMs = commonEvalStartMsBySymbol[sym] ?: continue
                exitStateSamples.addAll(
                    extractExitSamplesForSymbol(
                        candles = candles,
                        marketType = marketType,
                        settings = settings,
                        preset = chosenPreset,
                        signalModel = activeGlobalForSym,
                        minTimestampMs = minCommonMs,
                        symbol = sym
                    )
                )
            }

            val exitResult = ExitWarningFeatureBuilder.trainAndEvaluatePhaseRules(
                samples = exitStateSamples,
                exchange = exchange.name,
                marketType = marketType.name,
                horizonBars = config.labelHorizonBars,
                nowMs = nowMs
            )
            exitCellRuleDao.replaceForMarket(exchange.name, marketType.name, exitResult.rules)

            if (exitStateSamples.size >= 30) {
                val exitKey = "EXIT_${exchange.name}_${marketType.name}"
                val prevExit = mlModelDao.getActiveModel(exitKey)
                val posExitRate = exitStateSamples.count { it.sample.label == 1 }.toDouble() / exitStateSamples.size
                val exitMetrics = ValidationMetrics(
                    threshold = exitResult.overallThreshold,
                    breakEvenThreshold = ExitWarningFeatureBuilder.MIN_BASE_PRECISION,
                    tradesTaken = exitResult.rules.sumOf { it.warnings },
                    totalOutOfSample = exitStateSamples.size,
                    winRate = exitResult.rules.filter { it.mlEnabled || it.structEnabled }
                        .takeIf { it.isNotEmpty() }
                        ?.map { it.precision }?.average() ?: 0.0,
                    netExpectancyPct = 0.0,
                    profitFactor = 1.0,
                    maxDrawdownPct = 0.0,
                    brierScore = 0.2,
                    baselineExpectancyPct = 0.0,
                    baselineWinRate = posExitRate,
                    calibrationBuckets = emptyList()
                )
                mlModelDao.atomicSwapActive(
                    MlModelEntity(
                        modelKey = exitKey,
                        modelKind = "EXIT",
                        exchange = exchange.name,
                        marketType = marketType.name,
                        symbol = null,
                        version = (prevExit?.version ?: 0) + 1,
                        trainedAtMs = nowMs,
                        sampleCount = exitStateSamples.size,
                        threshold = exitResult.overallThreshold,
                        brierScore = 0.2,
                        winRate = exitMetrics.winRate,
                        profitFactor = 1.0,
                        netExpectancy = 0.0,
                        maxDrawdown = 0.0,
                        modelJson = json.encodeToString(SerializedModelBundle(exitResult.weights, exitMetrics)),
                        isActive = true
                    )
                )
            }

            val endNowMs = System.currentTimeMillis()
            val primaryOut = outputById[pooledBestPreset.id] ?: presetOutputs.last()
            val anyPromoted = presetOutputs.any { it.promoted }
            val primaryPromoReason = primaryOut.promotionReason

            val barrierMetrics = SlTpManager.computeBarrierMetrics(
                capitalUsd = config.capitalUsd,
                maxLossUsd = config.maxLossUsd,
                takeProfitUsd = config.takeProfitUsd,
                roundTripFeeRate = config.roundTripFeeRate
            )

            val pooledSummaries = presetOutputs.map { po ->
                val takenReturns = po.eval.oosPredictions
                    .filter { it.first >= po.eval.metrics.threshold }
                    .map { it.second.netReturnPct }
                PooledPresetSummary(
                    presetId = po.preset.id,
                    label = po.preset.label,
                    windowBars = po.preset.windowBars,
                    minGapBars = po.preset.minGapBars,
                    trades = po.eval.metrics.tradesTaken,
                    winRate = po.eval.metrics.winRate,
                    expectancyPct = po.eval.metrics.netExpectancyPct,
                    lcbExpectancyPct = PresetSelector.computeLcbExpectancy(takenReturns),
                    threshold = po.eval.metrics.threshold,
                    brierScore = po.eval.metrics.brierScore
                )
            }

            val sinceMs = prevLog?.timestampMs ?: 0L
            val sinceSignals = allExistingInDb.filter { it.signalTimeMs > sinceMs }
            val acceptedSince = sinceSignals.filter { it.accepted }
            val resolvedAccepted = acceptedSince.filter { it.status.startsWith("CLOSED_") }
            val shadowSince = sinceSignals.filter { !it.accepted && it.label != null }
            val liveOutcomes = ReportLiveOutcomes(
                acceptedAlerts = acceptedSince.size,
                resolvedTp = resolvedAccepted.count { it.status == "CLOSED_TP" },
                resolvedSl = resolvedAccepted.count { it.status == "CLOSED_SL" },
                resolvedOpposite = resolvedAccepted.count { it.status == "CLOSED_OPPOSITE" },
                resolvedManual = resolvedAccepted.count { it.status == "CLOSED_MANUAL" },
                winRate = if (resolvedAccepted.isNotEmpty()) {
                    resolvedAccepted.count { it.label == 1 }.toDouble() / resolvedAccepted.size
                } else null,
                shadowCount = shadowSince.size,
                shadowWinRate = if (shadowSince.isNotEmpty()) {
                    shadowSince.count { it.label == 1 }.toDouble() / shadowSince.size
                } else null
            )

            val activeWeightsForExplain = primaryOut.activeWeights
            val winShare = if (primaryOut.samples.isNotEmpty()) {
                primaryOut.samples.count { it.label == 1 }.toDouble() / primaryOut.samples.size
            } else 0.0

            val reportData = TrainingReportData(
                jobType = jobType.name,
                startedAtMs = startedAtMs,
                endedAtMs = endNowMs,
                durationMs = (endNowMs - startedAtMs).coerceAtLeast(0L),
                exchange = exchange.name,
                marketType = marketType.name,
                capitalUsd = config.capitalUsd,
                maxLossUsd = config.maxLossUsd,
                takeProfitUsd = config.takeProfitUsd,
                roundTripFeeRate = config.roundTripFeeRate,
                labelHorizonBars = config.labelHorizonBars,
                windowLength = primaryOut.preset.windowBars,
                minGap = primaryOut.preset.minGapBars,
                thresholdMode = settings.thresholdMode.name,
                manualThreshold = settings.manualThreshold,
                minSamplesForPerAssetModel = settings.minSamplesForPerAssetModel,
                retentionDays = settings.retentionDays,
                stopDistancePct = barrierMetrics.stopPct,
                tpDistancePct = barrierMetrics.tpPct,
                feeAsPctOfBarrier = barrierMetrics.maxFeePctOfBarrier,
                rangePresetsSummary = "30m/3 | 1h/7 | 2h/15 | 4h/30",
                activeRangeLabel = pooledBestPreset.label,
                symbolCount = primaryOut.samplesBySymbol.count { it.value.isNotEmpty() },
                symbols = primaryOut.samplesBySymbol.filter { it.value.isNotEmpty() }.keys.sorted(),
                samplesPerSymbol = primaryOut.samplesBySymbol.mapValues { it.value.size },
                totalSetups = primaryOut.samples.size,
                dataWindowStartMs = primaryOut.samples.firstOrNull()?.timestampMs ?: windowStartMs,
                dataWindowEndMs = primaryOut.samples.lastOrNull()?.timestampMs ?: endNowMs,
                winLabelShare = winShare,
                timeoutCount = primaryOut.timeoutCount,
                globalMetrics = primaryOut.eval.metrics,
                promoted = anyPromoted,
                promotionReason = primaryPromoReason,
                candidateHoldoutMetrics = primaryOut.candidateHoldoutMetrics,
                activeHoldoutMetrics = primaryOut.activeHoldoutMetrics,
                perAssetRows = perAssetReportRows.sortedByDescending { it.samples }.take(30),
                pooledPresetSummaries = pooledSummaries,
                assetPresetSelections = selectedBySymbol.values.sortedBy { it.symbol }.map { ch ->
                    ReportAssetPresetRow(
                        symbol = ch.symbol,
                        presetId = ch.selectedPreset.id,
                        presetLabel = ch.selectedPreset.label,
                        trades = ch.trades,
                        lcbExpectancyPct = if (ch.lcbExpectancy.isFinite()) ch.lcbExpectancy else 0.0
                    )
                },
                pooledBestPresetId = pooledBestPreset.id,
                topPositiveFactors = ModelExplainer.topLearnedFactors(
                    weights = activeWeightsForExplain,
                    positive = true,
                    limit = 5,
                    windowLabel = pooledBestPreset.label
                ),
                topNegativeFactors = ModelExplainer.topLearnedFactors(
                    weights = activeWeightsForExplain,
                    positive = false,
                    limit = 5,
                    windowLabel = pooledBestPreset.label
                ),
                exitRuleSummary = exitResult.summary.reportLine,
                liveOutcomes = liveOutcomes
            )

            val finalSummary = "$primaryPromoReason Pooled best: ${pooledBestPreset.label}. Updated $assetModelsUpdated per-asset model(s) across ${primaryOut.samples.size} setups. ${exitResult.summary.reportLine}"
            trainingLogDao.insert(
                TrainingLogEntity(
                    timestampMs = endNowMs,
                    exchange = exchange.name,
                    marketType = marketType.name,
                    jobType = jobType.name,
                    promoted = anyPromoted,
                    summary = finalSummary,
                    metricsJson = json.encodeToString(primaryOut.eval.metrics),
                    reportJson = json.encodeToString(reportData)
                )
            )

            val completed = currentJob.copy(
                stage = "COMPLETED",
                status = "COMPLETED",
                progressPct = 100,
                statusMessage = finalSummary,
                updatedAtMs = endNowMs
            )
            trainingJobDao.upsert(completed)
            _status.value = TrainingStatusSnapshot(
                isRunning = false,
                isPaused = false,
                progressPct = 100,
                stageMessage = finalSummary
            )
            true
        } catch (ce: CancellationException) {
            if (pauseRequested) {
                savePaused(currentJob, "Training paused cleanly at checkpoint")
                false
            } else {
                throw ce
            }
        } catch (e: Exception) {
            val failed = currentJob.copy(
                status = "FAILED",
                statusMessage = e.message ?: "Training failed",
                updatedAtMs = System.currentTimeMillis()
            )
            trainingJobDao.upsert(failed)
            _status.value = TrainingStatusSnapshot(
                isRunning = false,
                lastError = e.message ?: "Training failed",
                stageMessage = failed.statusMessage
            )
            false
        }
    }

    private suspend fun updateProgress(job: TrainingJobEntity) {
        val updated = job.copy(updatedAtMs = System.currentTimeMillis())
        trainingJobDao.upsert(updated)
        _status.value = _status.value.copy(
            isRunning = true,
            isPaused = false,
            progressPct = updated.progressPct,
            stageMessage = updated.statusMessage
        )
    }

    private suspend fun savePaused(job: TrainingJobEntity, msg: String) {
        trainingJobDao.upsert(job.copy(status = "PAUSED", statusMessage = msg, updatedAtMs = System.currentTimeMillis()))
        _status.value = _status.value.copy(isRunning = false, isPaused = true, stageMessage = msg)
    }

    private data class ExtractedSignalData(
        val signalSamples: List<LabeledSample>,
        val candidateEntities: List<SignalCandidateEntity>,
        val timeoutCount: Int
    )

    private fun extractSignalSamplesForPreset(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        candles: List<Candle>,
        settings: AppSettings,
        preset: RangePreset,
        minTimestampMs: Long
    ): ExtractedSignalData {
        val config = settings.engineConfig
        val engine = ConfluenceEngine(config, preset)
        val snapshots = engine.evaluateAll(candles)

        val signalSamples = ArrayList<LabeledSample>()
        val entities = ArrayList<SignalCandidateEntity>()
        var lastOutcome: Int? = null
        var timeouts = 0

        for (i in snapshots.indices) {
            val snap = snapshots[i]
            if (snap.candle.openTimeMs < minTimestampMs) continue
            val dir = snap.candidateDirection ?: continue
            val sl = snap.structuralSl ?: continue
            val tp = snap.defaultTp ?: continue

            val features = FeatureBuilder.buildFeatures(
                candles = candles,
                snapshots = snapshots,
                barIndex = i,
                marketType = marketType,
                lastSignalOutcome = lastOutcome,
                windowBars = preset.windowBars
            ) ?: continue

            val barrier = TripleBarrierLabeler.labelCandidate(
                candles = candles,
                signalBarIndex = i,
                direction = dir,
                entryPrice = snap.candle.close,
                slPrice = sl,
                tpPrice = tp,
                horizonBars = config.labelHorizonBars,
                roundTripFeeRate = config.roundTripFeeRate,
                timeoutLabelMode = config.timeoutLabelMode
            )
            if (barrier.outcome == BarrierOutcome.TIMEOUT_PROFIT || barrier.outcome == BarrierOutcome.TIMEOUT_LOSS) {
                timeouts++
            }
            val label = barrier.label ?: continue
            lastOutcome = label
            val exitBarTime = candles.getOrNull(barrier.exitBarIndex)?.openTimeMs
                ?: (snap.candle.openTimeMs + config.labelHorizonBars * 60_000L)

            signalSamples.add(
                LabeledSample(
                    timestampMs = snap.candle.openTimeMs,
                    exitTimeMs = exitBarTime,
                    symbol = symbol,
                    features = features,
                    label = label,
                    netReturnPct = barrier.netReturnPct,
                    maePct = barrier.maePct,
                    mfePct = barrier.mfePct
                )
            )

            entities.add(
                SignalCandidateEntity(
                    signalId = "${exchange.name}_${marketType.name}_${symbol}_${snap.candle.openTimeMs}",
                    exchange = exchange.name,
                    marketType = marketType.name,
                    symbol = symbol,
                    direction = dir.name,
                    signalTimeMs = snap.candle.openTimeMs,
                    barIndex = i,
                    entryPrice = snap.candle.close,
                    structuralSl = sl,
                    defaultTp = tp,
                    appliedSl = sl,
                    appliedTp = tp,
                    slAdjustmentNote = null,
                    tpAdjustmentNote = null,
                    pWin = null,
                    thresholdUsed = null,
                    modelWasTrained = false,
                    accepted = false,
                    status = "SHADOW",
                    exitTimeMs = exitBarTime,
                    exitPrice = barrier.exitPrice,
                    netReturnPct = barrier.netReturnPct,
                    maePct = barrier.maePct,
                    mfePct = barrier.mfePct,
                    label = label,
                    featuresJson = json.encodeToString(features),
                    topReasonsJson = "[]",
                    notified = true,
                    presetId = preset.id
                )
            )
        }
        return ExtractedSignalData(signalSamples, entities, timeouts)
    }

    private fun extractExitSamplesForSymbol(
        candles: List<Candle>,
        marketType: MarketType,
        settings: AppSettings,
        preset: RangePreset,
        signalModel: LogisticRegressionWeights,
        minTimestampMs: Long,
        symbol: String
    ): List<ExitStateSample> {
        val config = settings.engineConfig
        val engine = ConfluenceEngine(config, preset)
        val snapshots = engine.evaluateAll(candles)
        val out = ArrayList<ExitStateSample>()
        var lastOutcome: Int? = null

        for (i in snapshots.indices) {
            val snap = snapshots[i]
            if (snap.candle.openTimeMs < minTimestampMs) continue
            val dir = snap.candidateDirection ?: continue
            val sl = snap.structuralSl ?: continue
            val tp = snap.defaultTp ?: continue

            val entryFeats = FeatureBuilder.buildFeatures(
                candles = candles,
                snapshots = snapshots,
                barIndex = i,
                marketType = marketType,
                lastSignalOutcome = lastOutcome,
                windowBars = preset.windowBars
            ) ?: continue

            val barrier = TripleBarrierLabeler.labelCandidate(
                candles = candles,
                signalBarIndex = i,
                direction = dir,
                entryPrice = snap.candle.close,
                slPrice = sl,
                tpPrice = tp,
                horizonBars = config.labelHorizonBars,
                roundTripFeeRate = config.roundTripFeeRate,
                timeoutLabelMode = config.timeoutLabelMode
            )
            val label = barrier.label ?: continue
            lastOutcome = label

            val entryPrice = snap.candle.close.coerceAtLeast(1e-9)
            val stopDistPct = (abs(entryPrice - sl) / entryPrice).coerceAtLeast(1e-6)
            val entryPWin = signalModel.predictProbability(entryFeats)
            val exitBarTime = candles.getOrNull(barrier.exitBarIndex)?.openTimeMs
                ?: (snap.candle.openTimeMs + config.labelHorizonBars * 60_000L)

            val endStep = barrier.exitBarIndex.coerceAtMost(candles.lastIndex)
            val stride = ((endStep - i) / 6).coerceAtLeast(1)
            var b = i + 1
            while (b < endStep) {
                val close = candles[b].close
                val rawUnrealized = when (dir) {
                    com.lrmlc.tradingalerts.data.model.TradeDirection.LONG -> (close - entryPrice) / entryPrice
                    com.lrmlc.tradingalerts.data.model.TradeDirection.SHORT -> (entryPrice - close) / entryPrice
                }
                val unrealizedNet = rawUnrealized - config.roundTripFeeRate
                val exitLabel = ExitWarningFeatureBuilder.computeExitLabel(
                    outcome = barrier.outcome,
                    unrealizedNetPct = unrealizedNet,
                    finalNetPct = barrier.netReturnPct,
                    stopDistPct = stopDistPct
                )
                val exitFeats = ExitWarningFeatureBuilder.buildStateFeatures(
                    candles = candles,
                    snapshots = snapshots,
                    currentBarIndex = b,
                    entryBarIndex = i,
                    direction = dir,
                    entryPrice = entryPrice,
                    slPrice = sl,
                    tpPrice = tp,
                    entryPWin = entryPWin
                )
                if (exitFeats != null) {
                    val age = ExitWarningFeatureBuilder.computeAgeBars(b, i)
                    val progress = ExitWarningFeatureBuilder.computeSignedProgress(dir, close, entryPrice, sl, tp)
                    val savedRisk = (unrealizedNet - barrier.netReturnPct) / stopDistPct
                    out.add(
                        ExitStateSample(
                            entryTimeMs = snap.candle.openTimeMs,
                            sample = LabeledSample(
                                timestampMs = candles[b].openTimeMs,
                                exitTimeMs = exitBarTime,
                                symbol = symbol,
                                features = exitFeats,
                                label = exitLabel,
                                netReturnPct = unrealizedNet - barrier.netReturnPct
                            ),
                            ageBucket = ExitWarningFeatureBuilder.ageBucketFor(age),
                            progressBucket = ExitWarningFeatureBuilder.progressBucketFor(progress),
                            structTriggered = ExitWarningFeatureBuilder.isOppositeStructureTriggered(dir, snapshots[b]),
                            savedRisk = savedRisk
                        )
                    )
                }
                b += stride
            }
        }
        return out
    }
}
