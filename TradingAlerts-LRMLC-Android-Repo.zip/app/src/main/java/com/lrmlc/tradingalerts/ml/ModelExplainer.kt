package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.trade.SlTpStatsSummary
import kotlinx.serialization.Serializable
import java.util.Locale
import kotlin.math.abs

@Serializable
data class ReadableFactor(
    val title: String,
    val sentence: String,
    val strength: Double,
    val isPositive: Boolean
)

object ModelExplainer {

    fun topLearnedFactors(
        weights: LogisticRegressionWeights,
        positive: Boolean,
        limit: Int = 5
    ): List<ReadableFactor> {
        return FeatureSpec.DEFINITIONS
            .mapNotNull { def ->
                val w = weights.weights.getOrNull(def.index) ?: return@mapNotNull null
                if (positive && w <= 0.01) return@mapNotNull null
                if (!positive && w >= -0.01) return@mapNotNull null
                ReadableFactor(
                    title = def.title,
                    sentence = if (positive) {
                        "Signals worked better when ${def.positiveExplanation}."
                    } else {
                        "Signals struggled when ${def.negativeExplanation}."
                    },
                    strength = abs(w),
                    isPositive = positive
                )
            }
            .sortedByDescending { it.strength }
            .take(limit)
    }

    fun explainSignalDrivers(
        weights: LogisticRegressionWeights,
        rawFeatures: DoubleArray,
        pWin: Double,
        metrics: ValidationMetrics?
    ): List<String> {
        val drivers = weights.explainTopDrivers(rawFeatures, topK = 3)
        val lines = ArrayList<String>(4)
        for (d in drivers) {
            val def = FeatureSpec.DEFINITIONS.getOrNull(d.featureIndex) ?: continue
            val phrase = if (d.contribution >= 0) def.positiveExplanation else def.negativeExplanation
            val signWord = if (d.contribution >= 0) "Supports trade" else "Caution"
            lines.add("$signWord: $phrase.")
        }
        val calSentence = calibrationSentenceForConfidence(pWin, metrics)
        if (calSentence != null) lines.add(calSentence)
        return lines
    }

    fun calibrationSentenceForConfidence(pWin: Double, metrics: ValidationMetrics?): String? {
        val pct = (pWin * 100.0).toInt()
        if (metrics == null || metrics.calibrationBuckets.isEmpty()) {
            return "The model scores this setup at $pct% confidence."
        }
        val bucket = metrics.calibrationBuckets.minByOrNull { abs(it.predictedAvg - pWin) } ?: return null
        val bucketCenter = (bucket.predictedAvg * 100.0).toInt()
        val actualPct = (bucket.actualWinRate * 100.0).toInt()
        return "The model trusts this signal $pct%; historically, signals scored around $bucketCenter% won about $actualPct% of the time (${bucket.sampleCount} samples)."
    }

    fun explainValidationInPlainWords(metrics: ValidationMetrics): String {
        val winPct = String.format(Locale.US, "%.1f%%", metrics.winRate * 100.0)
        val baseWin = String.format(Locale.US, "%.1f%%", metrics.baselineWinRate * 100.0)
        val exp = String.format(Locale.US, "%+.3f%%", metrics.netExpectancyPct * 100.0)
        val baseExp = String.format(Locale.US, "%+.3f%%", metrics.baselineExpectancyPct * 100.0)
        val thresh = String.format(Locale.US, "%.0f%%", metrics.threshold * 100.0)
        return "At a $thresh confidence filter, the model kept ${metrics.tradesTaken} of ${metrics.totalOutOfSample} out-of-sample setups, lifting win rate from $baseWin to $winPct and average net return per trade from $baseExp to $exp (profit factor ${String.format(Locale.US, "%.2f", metrics.profitFactor)})."
    }

    fun explainSlTpAdaptation(summary: SlTpStatsSummary?): String {
        if (summary == null || summary.winningSampleCount < 5) {
            return "Using default structural stop loss and minimum take profit until enough winning trades are recorded."
        }
        val mae80 = String.format(Locale.US, "%.2f%%", summary.mae80thPct * 100.0)
        val mfe50 = String.format(Locale.US, "%.2f%%", summary.mfeMedianPct * 100.0)
        return "Based on ${summary.winningSampleCount} past winners, 80% stayed within $mae80 adverse excursion and half reached $mfe50 favorable move."
    }
}
