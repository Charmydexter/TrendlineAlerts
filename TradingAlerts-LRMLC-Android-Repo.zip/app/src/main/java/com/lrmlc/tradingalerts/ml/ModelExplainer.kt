package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.trade.SlTpStatsSummary
import kotlinx.serialization.Serializable
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

@Serializable
data class ReadableFactor(
    val title: String,
    val sentence: String,
    val strength: Double,
    val isPositive: Boolean
)

object ModelExplainer {

    fun wilsonInterval(wins: Int, n: Int, z: Double = 1.96): Pair<Double, Double> {
        if (n <= 0) return 0.0 to 0.0
        val p = wins.coerceIn(0, n).toDouble() / n.toDouble()
        val z2 = z * z
        val denom = 1.0 + z2 / n
        val center = (p + z2 / (2.0 * n)) / denom
        val margin = (z * sqrt((p * (1.0 - p) + z2 / (4.0 * n)) / n)) / denom
        return (center - margin).coerceIn(0.0, 1.0) to (center + margin).coerceIn(0.0, 1.0)
    }

    fun baselineBrier(baseWinRate: Double): Double {
        val p = baseWinRate.coerceIn(0.0, 1.0)
        return p * (1.0 - p)
    }

    fun topLearnedFactors(
        weights: LogisticRegressionWeights,
        positive: Boolean,
        limit: Int = 5,
        windowLabel: String = "4h"
    ): List<ReadableFactor> {
        return FeatureSpec.DEFINITIONS
            .mapNotNull { def ->
                val w = weights.weights.getOrNull(def.index) ?: return@mapNotNull null
                if (positive && w <= 0.01) return@mapNotNull null
                if (!positive && w >= -0.01) return@mapNotNull null
                val formattedTitle = FeatureSpec.formatText(def.title, windowLabel)
                val formattedBody = if (positive) {
                    "Signals worked better when ${FeatureSpec.formatText(def.positiveExplanation, windowLabel)}."
                } else {
                    "Signals struggled when ${FeatureSpec.formatText(def.negativeExplanation, windowLabel)}."
                }
                ReadableFactor(
                    title = formattedTitle,
                    sentence = formattedBody,
                    strength = abs(w),
                    isPositive = positive
                )
            }
            .sortedByDescending { it.strength }
            .take(limit)
    }

    fun explainSignalDrivers(
        weights: LogisticRegressionWeights,
        rawFeatures: DoubleArray,
        pWin: Double,
        metrics: ValidationMetrics?,
        windowLabel: String = "4h"
    ): List<String> {
        val drivers = weights.explainTopDrivers(rawFeatures, topK = 3)
        val lines = ArrayList<String>(4)
        for (d in drivers) {
            val def = FeatureSpec.DEFINITIONS.getOrNull(d.featureIndex) ?: continue
            val rawPhrase = if (d.contribution >= 0) def.positiveExplanation else def.negativeExplanation
            val phrase = FeatureSpec.formatText(rawPhrase, windowLabel)
            val signWord = if (d.contribution >= 0) "Supports trade" else "Caution"
            lines.add("$signWord: $phrase.")
        }
        val calSentence = calibrationSentenceForConfidence(pWin, metrics)
        if (calSentence != null) lines.add(calSentence)
        return lines
    }

    fun calibrationSentenceForConfidence(pWin: Double, metrics: ValidationMetrics?): String? {
        val pct = (pWin * 100.0).toInt()
        if (metrics == null || metrics.calibrationBuckets.isEmpty()) {
            return "The model scores this setup at $pct% confidence."
        }
        val bucket = metrics.calibrationBuckets.minByOrNull { abs(it.predictedAvg - pWin) } ?: return null
        val bucketCenter = (bucket.predictedAvg * 100.0).toInt()
        val actualPct = (bucket.actualWinRate * 100.0).toInt()
        return "The model trusts this signal $pct%; historically, signals scored around $bucketCenter% won about $actualPct% of the time (${bucket.sampleCount} samples)."
    }

    fun explainValidationInPlainWords(metrics: ValidationMetrics): String {
        val wins = (metrics.winRate * metrics.tradesTaken).toInt().coerceIn(0, metrics.tradesTaken)
        val (ciLo, ciHi) = wilsonInterval(wins, metrics.tradesTaken)
        val winPct = String.format(Locale.US, "%.0f%%", metrics.winRate * 100.0)
        val ciStr = String.format(Locale.US, "%.0f-%.0f%%", ciLo * 100.0, ciHi * 100.0)
        val baseWin = String.format(Locale.US, "%.1f%%", metrics.baselineWinRate * 100.0)
        val bePct = String.format(Locale.US, "%.1f%%", metrics.breakEvenThreshold * 100.0)
        val exp = String.format(Locale.US, "%+.3f%%", metrics.netExpectancyPct * 100.0)
        val baseExp = String.format(Locale.US, "%+.3f%%", metrics.baselineExpectancyPct * 100.0)
        val thresh = String.format(Locale.US, "%.0f%%", metrics.threshold * 100.0)
        val optimisticSuffix = if (metrics.metricsAreOptimistic) {
            " Note: optimistic (threshold tuned on same data)."
        } else {
            ""
        }
        return "At a $thresh confidence filter (fee-aware break-even $bePct), the model kept ${metrics.tradesTaken} of ${metrics.totalOutOfSample} out-of-sample setups: win rate $winPct ($ciStr, ${metrics.tradesTaken} trades vs $baseWin base), net expectancy $exp (vs $baseExp base), profit factor ${String.format(Locale.US, "%.2f", metrics.profitFactor)}.$optimisticSuffix"
    }

    fun explainSlTpAdaptation(summary: SlTpStatsSummary?): String {
        if (summary == null || summary.winningSampleCount < 5) {
            return "Using default structural stop loss and minimum take profit until enough winning trades are recorded."
        }
        val mae80 = String.format(Locale.US, "%.2f%%", summary.mae80thPct * 100.0)
        val mfe50 = String.format(Locale.US, "%.2f%%", summary.mfeMedianPct * 100.0)
        return "Based on ${summary.winningSampleCount} past winners, 80% stayed within $mae80 adverse excursion and half reached $mfe50 favorable move."
    }
}
