package com.lrmlc.tradingalerts.trade

import com.lrmlc.tradingalerts.data.local.AssetPresetSelectionDao
import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import com.lrmlc.tradingalerts.data.local.ExitCellRuleDao
import com.lrmlc.tradingalerts.data.local.ExitWarningStateDao
import com.lrmlc.tradingalerts.data.local.ExitWarningStateEntity
import com.lrmlc.tradingalerts.data.local.FuturesMetricsStore
import com.lrmlc.tradingalerts.data.local.MlModelDao
import com.lrmlc.tradingalerts.data.local.SettingsRepository
import com.lrmlc.tradingalerts.data.local.SignalCandidateDao
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.WatchlistDao
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.RangePreset
import com.lrmlc.tradingalerts.data.model.RangePresets
import com.lrmlc.tradingalerts.data.model.ThresholdMode
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.data.repository.CandleStoreRepository
import com.lrmlc.tradingalerts.data.repository.MasterSlots
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.engine.ConfluenceEngine
import com.lrmlc.tradingalerts.ml.ExitFeatureSpec
import com.lrmlc.tradingalerts.ml.ExitWarningFeatureBuilder
import com.lrmlc.tradingalerts.ml.FeatureBuilder
import com.lrmlc.tradingalerts.ml.FeatureSpec
import com.lrmlc.tradingalerts.ml.ModelExplainer
import com.lrmlc.tradingalerts.ml.RunOnBundle
import com.lrmlc.tradingalerts.ml.RunOnFeatureBuilder
import com.lrmlc.tradingalerts.ml.RunOnSpec
import com.lrmlc.tradingalerts.ml.RunOnTrainer
import com.lrmlc.tradingalerts.ml.SerializedModelBundle
import com.lrmlc.tradingalerts.ml.TripleBarrierLabeler
import com.lrmlc.tradingalerts.service.NotificationHelper
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.math.max

class TradeLifecycleManager(
    private val candleStore: CandleStoreRepository,
    private val watchlistDao: WatchlistDao,
    private val signalDao: SignalCandidateDao,
    private val mlModelDao: MlModelDao,
    private val exitWarningStateDao: ExitWarningStateDao,
    private val exitCellRuleDao: ExitCellRuleDao,
    private val assetPresetSelectionDao: AssetPresetSelectionDao,
    private val settingsRepository: SettingsRepository,
    private val notificationHelper: NotificationHelper? = null,
    private val futuresStore: FuturesMetricsStore? = null
) {
    private val json = Json { ignoreUnknownKeys = true }

    companion object {
        fun computeExitWarningHelped(
            direction: TradeDirection,
            entryPrice: Double,
            firstWarnPrice: Double,
            feeRate: Double,
            finalNetReturnPct: Double
        ): Boolean {
            if (entryPrice <= 0.0) return false
            val rawAtWarn = when (direction) {
                TradeDirection.LONG -> (firstWarnPrice - entryPrice) / entryPrice
                TradeDirection.SHORT -> (entryPrice - firstWarnPrice) / entryPrice
            }
            val netAtWarn = rawAtWarn - feeRate
            return netAtWarn > finalNetReturnPct + 1e-9
        }
    }

    /**
     * Evaluates newly closed 1-minute candle(s) for [symbol] in chronological order.
     */
    suspend fun processClosedCandle(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        closedCandle: Candle
    ) {
        val settings = settingsRepository.getSettings()
        val config = settings.engineConfig
        // 1,500 bars: also covers the 1-day volatility baseline of the learned context features
        val windowLookbackMs = maxOf(RangePresets.R240.windowBars + 360L, 1_500L) * DayChunkCodec.MILLIS_PER_MINUTE
        val candles = candleStore.loadCandles(
            exchange = exchange,
            marketType = marketType,
            symbol = symbol,
            startOpenTimeMs = closedCandle.openTimeMs - windowLookbackMs,
            endOpenTimeMs = closedCandle.openTimeMs
        )
        if (candles.isEmpty()) return

        // 1) Update open active trade & unresolved shadow trades against the newly closed candle
        reconcileOpenTradesAndShadows(exchange, marketType, symbol, closedCandle, candles, settings)

        // 2) Resolve this asset's selected range preset & run ConfluenceEngine
        val selectedPreset = resolvePresetForSymbol(exchange, marketType, symbol)
        val engine = ConfluenceEngine(config, selectedPreset)
        val snapshots = engine.evaluateAll(candles)
        val lastIdx = snapshots.lastIndex
        if (lastIdx < 0) return
        val lastSnap = snapshots[lastIdx]

        // Update watchlist row live stats
        val existingWatch = watchlistDao.getAsset(exchange.name, marketType.name, symbol)
        val activeTradeNow = signalDao.getActiveTradeForSymbol(exchange.name, marketType.name, symbol)
        if (existingWatch != null) {
            watchlistDao.upsert(
                existingWatch.copy(
                    lastPrice = closedCandle.close,
                    lastCandleReceivedMs = System.currentTimeMillis(),
                    activeDirection = activeTradeNow?.direction,
                    activeConfidence = activeTradeNow?.pWin
                )
            )
        }

        // 3) Check phase-aware exit warnings for any active position
        if (existingWatch?.inPosition == true && activeTradeNow != null) {
            evaluateAndNotifyExitWarning(
                exchange = exchange,
                marketType = marketType,
                symbol = symbol,
                activeTrade = activeTradeNow,
                candles = candles,
                snapshots = snapshots,
                currentIdx = lastIdx,
                muted = existingWatch.muted,
                settings = settings
            )
        }

        // 3b) Run-past-TP marker (only shown where the model proved itself on unseen trades)
        if (existingWatch?.inPosition == true && activeTradeNow != null) {
            runCatching {
                evaluateRunOn(
                    exchange = exchange,
                    marketType = marketType,
                    symbol = symbol,
                    activeTradeId = activeTradeNow.signalId,
                    candles = candles,
                    snapshots = snapshots,
                    currentIdx = lastIdx,
                    muted = existingWatch.muted,
                    settings = settings
                )
            }
        }

        // 4) Check if the closed bar fired a candidate signal
        val dir = lastSnap.candidateDirection ?: return
        val structuralSl = lastSnap.structuralSl ?: return
        val signalId = "${exchange.name}_${marketType.name}_${symbol}_${closedCandle.openTimeMs}"
        if (signalDao.getById(signalId) != null) return // duplicate guard

        val recentSignals = signalDao.getAllForMarket(exchange.name, marketType.name)
            .filter { it.symbol == symbol && it.label != null }
        val lastOutcome = recentSignals.lastOrNull()?.label
        val masterSymbol = MasterSlots.activeSymbol(settings)
        val masterCandles = if (symbol == masterSymbol) null else candleStore.loadCandles(
            exchange = exchange,
            marketType = marketType,
            symbol = masterSymbol,
            startOpenTimeMs = closedCandle.openTimeMs - windowLookbackMs,
            endOpenTimeMs = closedCandle.openTimeMs
        ).takeIf { it.size >= 120 }
        val features = FeatureBuilder.buildFeatures(
            candles = candles,
            snapshots = snapshots,
            barIndex = lastIdx,
            marketType = marketType,
            lastSignalOutcome = lastOutcome,
            windowBars = selectedPreset.windowBars,
            masterCandles = masterCandles,
            isMasterAsset = symbol == masterSymbol,
            futures = if (marketType == MarketType.PERP) futuresStore?.pointAt(exchange.name, symbol, closedCandle.openTimeMs) else null
        ) ?: return

        val (bundle, usedModelNote) = loadBestSignalModel(exchange, marketType, symbol, selectedPreset, settings)
        val modelTrained = bundle != null
        // Only feature groups that proved useful for this model are visible to it
        val scoredFeatures = bundle?.maskFeatures(features) ?: features
        val pWin = bundle?.weights?.predictProbability(scoredFeatures)
        val threshold = when {
            bundle == null -> 0.0
            settings.thresholdMode == ThresholdMode.MANUAL -> settings.manualThreshold
            else -> bundle.metrics.threshold
        }
        val accepted = !modelTrained || (pWin != null && pWin >= threshold)

        val winningForSymbol = recentSignals.filter { it.label == 1 && it.maePct != null && it.mfePct != null }
        val slTpStats = SlTpManager.computeStatsFromWinningExcursions(
            winningMaePcts = winningForSymbol.mapNotNull { it.maePct },
            winningMfePcts = winningForSymbol.mapNotNull { it.mfePct }
        )
        val slTp = SlTpManager.resolveLevels(
            direction = dir,
            entryPrice = closedCandle.close,
            structuralSl = structuralSl,
            config = config,
            stats = slTpStats,
            autoSlEnabled = settings.autoSlEnabled,
            autoTpEnabled = settings.autoTpEnabled
        )

        val reasons = if (bundle != null && pWin != null) {
            ModelExplainer.explainSignalDrivers(
                weights = bundle.weights,
                rawFeatures = scoredFeatures,
                pWin = pWin,
                metrics = bundle.metrics,
                windowLabel = selectedPreset.label
            )
        } else {
            listOf("Unfiltered – model not trained yet. Signal uses structural confluence rules.")
        }

        val entity = SignalCandidateEntity(
            signalId = signalId,
            exchange = exchange.name,
            marketType = marketType.name,
            symbol = symbol,
            direction = dir.name,
            signalTimeMs = closedCandle.openTimeMs,
            barIndex = lastIdx,
            entryPrice = closedCandle.close,
            structuralSl = slTp.structuralSl,
            defaultTp = slTp.defaultTp,
            appliedSl = slTp.appliedSl,
            appliedTp = slTp.appliedTp,
            slAdjustmentNote = if (slTp.slAdjusted) slTp.slReason else usedModelNote,
            tpAdjustmentNote = if (slTp.tpAdjusted) slTp.tpReason else null,
            pWin = pWin,
            thresholdUsed = if (modelTrained) threshold else null,
            modelWasTrained = modelTrained,
            accepted = accepted,
            status = if (accepted) "ACTIVE" else "SHADOW",
            featuresJson = json.encodeToString(features),
            topReasonsJson = json.encodeToString(reasons),
            notified = false,
            presetId = selectedPreset.id
        )

        if (accepted) {
            if (activeTradeNow != null) {
                closeTradeOnOppositeSignal(activeTradeNow, closedCandle, config.roundTripFeeRate)
            }
            signalDao.upsert(entity)
            watchlistDao.setInPosition(
                exchange.name,
                marketType.name,
                symbol,
                inPosition = true,
                updatedAtMs = System.currentTimeMillis()
            )
            watchlistDao.getAsset(exchange.name, marketType.name, symbol)?.let { w ->
                watchlistDao.upsert(
                    w.copy(
                        inPosition = true,
                        inPositionUpdatedAtMs = System.currentTimeMillis(),
                        activeDirection = dir.name,
                        activeConfidence = pWin,
                        lastPrice = closedCandle.close
                    )
                )
            }
            exitWarningStateDao.upsert(ExitWarningStateEntity(exchange.name, marketType.name, symbol))

            if (existingWatch?.muted != true) {
                notificationHelper?.notifySignal(entity, settings)
                signalDao.markNotified(entity.signalId)
            }
            notificationHelper?.refreshPersistentNotification(exchange, marketType, settings.keepMonitoringInBackground)
        } else {
            signalDao.upsert(entity)
            if (settings.notifyFilteredSignals && existingWatch?.muted != true) {
                notificationHelper?.notifyFilteredSignal(entity, settings)
            }
        }
    }

    private suspend fun resolvePresetForSymbol(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String
    ): RangePreset {
        val assetSel = assetPresetSelectionDao.getSelection(exchange.name, marketType.name, symbol)
        if (assetSel != null) return RangePresets.byId(assetSel.presetId)

        val activeModels = mlModelDao.getActiveModelsForMarket(exchange.name, marketType.name)
        val bestGlobal = activeModels
            .filter { it.modelKind == "GLOBAL" }
            .maxByOrNull { it.netExpectancy }
        val inferredId = bestGlobal?.modelKey?.substringAfterLast('_')
            ?.takeIf { key -> RangePresets.ALL.any { it.id == key } }
        return RangePresets.byId(inferredId)
    }

    private suspend fun reconcileOpenTradesAndShadows(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        closedCandle: Candle,
        recentCandles: List<Candle>,
        settings: AppSettings
    ) {
        val config = settings.engineConfig
        val allOpen = signalDao.getAllForMarket(exchange.name, marketType.name)
            .filter { it.symbol == symbol && (it.status == "ACTIVE" || it.status == "SHADOW") && it.signalTimeMs < closedCandle.openTimeMs }

        for (trade in allOpen) {
            val dir = TradeDirection.valueOf(trade.direction)
            val hitSl = when (dir) {
                TradeDirection.LONG -> closedCandle.low <= trade.appliedSl
                TradeDirection.SHORT -> closedCandle.high >= trade.appliedSl
            }
            val hitTp = when (dir) {
                TradeDirection.LONG -> closedCandle.high >= trade.appliedTp
                TradeDirection.SHORT -> closedCandle.low <= trade.appliedTp
            }

            val tradeCandles = recentCandles.filter { it.openTimeMs > trade.signalTimeMs && it.openTimeMs <= closedCandle.openTimeMs }
            var maxMae = trade.maePct ?: 0.0
            var maxMfe = trade.mfePct ?: 0.0
            for (c in tradeCandles) {
                val adv = when (dir) {
                    TradeDirection.LONG -> ((trade.entryPrice - c.low) / trade.entryPrice).coerceAtLeast(0.0)
                    TradeDirection.SHORT -> ((c.high - trade.entryPrice) / trade.entryPrice).coerceAtLeast(0.0)
                }
                val fav = when (dir) {
                    TradeDirection.LONG -> ((c.high - trade.entryPrice) / trade.entryPrice).coerceAtLeast(0.0)
                    TradeDirection.SHORT -> ((trade.entryPrice - c.low) / trade.entryPrice).coerceAtLeast(0.0)
                }
                maxMae = max(maxMae, adv)
                maxMfe = max(maxMfe, fav)
            }

            val isShadow = trade.status == "SHADOW"
            // Job 1: real (ACTIVE) trades only close on a touch when the matching auto-close switch is on.
            // Shadow trades always end at TP/SL exactly as before.
            val closeOnSl = hitSl && (isShadow || settings.autoCloseOnSl)
            val closeOnTp = hitTp && !hitSl && (isShadow || settings.autoCloseOnTp)
            val closeOnTpAfterSl = hitTp && hitSl && !closeOnSl && (isShadow || settings.autoCloseOnTp)

            if (!isShadow && !closeOnSl && !closeOnTp && !closeOnTpAfterSl && (hitSl || hitTp || trade.tpReachedTimeMs != null)) {
                // Keep open: mark first touch(es) once and keep measuring the run beyond TP.
                val tpTime = trade.tpReachedTimeMs ?: if (hitTp) closedCandle.openTimeMs else null
                val slTime = trade.slReachedTimeMs ?: if (hitSl) closedCandle.openTimeMs else null
                var beyond = trade.maxBeyondTpPct ?: 0.0
                if (tpTime != null) {
                    for (c in tradeCandles) {
                        if (c.openTimeMs < tpTime) continue
                        val b = when (dir) {
                            TradeDirection.LONG -> (c.high - trade.appliedTp) / trade.entryPrice
                            TradeDirection.SHORT -> (trade.appliedTp - c.low) / trade.entryPrice
                        }
                        beyond = max(beyond, b.coerceAtLeast(0.0))
                    }
                }
                val updated = trade.copy(
                    maePct = maxMae,
                    mfePct = maxMfe,
                    tpReachedTimeMs = tpTime,
                    slReachedTimeMs = slTime,
                    maxBeyondTpPct = if (tpTime != null) beyond else null
                )
                signalDao.upsert(updated)
                val firstTp = trade.tpReachedTimeMs == null && tpTime != null
                val firstSl = trade.slReachedTimeMs == null && slTime != null
                if (!wIsMuted(exchange, marketType, symbol)) {
                    if (firstTp && settings.notifyTpHit) notificationHelper?.notifyLevelReachedStillOpen(updated, false, settings)
                    if (firstSl && settings.notifySlHit) notificationHelper?.notifyLevelReachedStillOpen(updated, true, settings)
                }
                continue
            }

            if (closeOnSl || closeOnTp || closeOnTpAfterSl) {
                val isSl = closeOnSl
                val exitPrice = if (isSl) trade.appliedSl else trade.appliedTp
                val rawRet = when (dir) {
                    TradeDirection.LONG -> (exitPrice - trade.entryPrice) / trade.entryPrice
                    TradeDirection.SHORT -> (trade.entryPrice - exitPrice) / trade.entryPrice
                }
                val netRet = rawRet - config.roundTripFeeRate
                val helped = trade.firstExitWarningPrice?.let { warnPrice ->
                    computeExitWarningHelped(dir, trade.entryPrice, warnPrice, config.roundTripFeeRate, netRet)
                }
                val updated = trade.copy(
                    status = if (isSl) "CLOSED_SL" else "CLOSED_TP",
                    exitTimeMs = closedCandle.openTimeMs,
                    exitPrice = exitPrice,
                    netReturnPct = netRet,
                    maePct = maxMae,
                    mfePct = maxMfe,
                    label = if (isSl) 0 else 1,
                    firstExitWarningHelped = helped,
                    tpReachedTimeMs = trade.tpReachedTimeMs ?: if (!isSl) closedCandle.openTimeMs else null,
                    slReachedTimeMs = trade.slReachedTimeMs ?: if (isSl) closedCandle.openTimeMs else null
                )
                signalDao.upsert(updated)
                if (trade.status == "ACTIVE") {
                    watchlistDao.setInPosition(exchange.name, marketType.name, symbol, false, System.currentTimeMillis())
                    watchlistDao.getAsset(exchange.name, marketType.name, symbol)?.let { w ->
                        watchlistDao.upsert(w.copy(inPosition = false, activeDirection = null, activeConfidence = null))
                    }
                    if (!wIsMuted(exchange, marketType, symbol)) {
                        if (isSl && settings.notifySlHit) notificationHelper?.notifyOutcome(updated, settings)
                        if (!isSl && settings.notifyTpHit) notificationHelper?.notifyOutcome(updated, settings)
                    }
                    notificationHelper?.refreshPersistentNotification(exchange, marketType, settings.keepMonitoringInBackground)
                }
            } else {
                val barsElapsed = ((closedCandle.openTimeMs - trade.signalTimeMs) / DayChunkCodec.MILLIS_PER_MINUTE).toInt()
                if (trade.status == "SHADOW" && barsElapsed >= config.labelHorizonBars) {
                    val rawRet = when (dir) {
                        TradeDirection.LONG -> (closedCandle.close - trade.entryPrice) / trade.entryPrice
                        TradeDirection.SHORT -> (trade.entryPrice - closedCandle.close) / trade.entryPrice
                    }
                    val netRet = rawRet - config.roundTripFeeRate
                    val label = TripleBarrierLabeler.labelCandidate(
                        candles = recentCandles,
                        signalBarIndex = recentCandles.indexOfFirst { it.openTimeMs == trade.signalTimeMs }.coerceAtLeast(0),
                        direction = dir,
                        entryPrice = trade.entryPrice,
                        slPrice = trade.appliedSl,
                        tpPrice = trade.appliedTp,
                        horizonBars = config.labelHorizonBars,
                        roundTripFeeRate = config.roundTripFeeRate,
                        timeoutLabelMode = config.timeoutLabelMode
                    ).label
                    signalDao.upsert(
                        trade.copy(
                            status = "CLOSED_TIMEOUT",
                            exitTimeMs = closedCandle.openTimeMs,
                            exitPrice = closedCandle.close,
                            netReturnPct = netRet,
                            maePct = maxMae,
                            mfePct = maxMfe,
                            label = label
                        )
                    )
                } else {
                    signalDao.upsert(trade.copy(maePct = maxMae, mfePct = maxMfe))
                }
            }
        }
    }

    private suspend fun wIsMuted(exchange: ExchangeId, marketType: MarketType, symbol: String): Boolean =
        watchlistDao.getAsset(exchange.name, marketType.name, symbol)?.muted == true

    private suspend fun closeTradeOnOppositeSignal(
        activeTrade: SignalCandidateEntity,
        candle: Candle,
        feeRate: Double
    ) {
        val dir = TradeDirection.valueOf(activeTrade.direction)
        val rawRet = when (dir) {
            TradeDirection.LONG -> (candle.close - activeTrade.entryPrice) / activeTrade.entryPrice
            TradeDirection.SHORT -> (activeTrade.entryPrice - candle.close) / activeTrade.entryPrice
        }
        val netRet = rawRet - feeRate
        val helped = activeTrade.firstExitWarningPrice?.let { warnPrice ->
            computeExitWarningHelped(dir, activeTrade.entryPrice, warnPrice, feeRate, netRet)
        }
        signalDao.upsert(
            activeTrade.copy(
                status = "CLOSED_OPPOSITE",
                exitTimeMs = candle.openTimeMs,
                exitPrice = candle.close,
                netReturnPct = netRet,
                label = if (netRet > 0.0) 1 else 0,
                firstExitWarningHelped = helped
            )
        )
    }

    /**
     * At each closed candle of an open trade: chance of a run far past TP. The marker turns on when the situation is
     * proven and the chance is above its level, and stays until the chance drops 5 points below that level.
     */
    private suspend fun evaluateRunOn(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        activeTradeId: String,
        candles: List<Candle>,
        snapshots: List<ConfluenceBarSnapshot>,
        currentIdx: Int,
        muted: Boolean,
        settings: AppSettings
    ) {
        val trade = signalDao.getById(activeTradeId) ?: return
        if (trade.status != "ACTIVE") return
        val entity = mlModelDao.getActiveModel(RunOnSpec.modelKey(exchange.name, marketType.name)) ?: return
        val bundle = runCatching { json.decodeFromString<RunOnBundle>(entity.modelJson) }.getOrNull() ?: return
        if (bundle.weights.weights.size != RunOnSpec.FEATURE_COUNT) return

        val dir = TradeDirection.valueOf(trade.direction)
        val close = candles[currentIdx].close
        val ageBars = ((candles[currentIdx].openTimeMs - trade.signalTimeMs) / DayChunkCodec.MILLIS_PER_MINUTE)
            .toInt().coerceAtLeast(1)
        val (cell, progress) = ExitWarningFeatureBuilder.cellFor(
            ageBars, dir, close, trade.entryPrice, trade.appliedSl, trade.appliedTp
        )
        // Already ran far: nothing left to predict, keep whatever is showing
        if (progress >= RunOnSpec.RAN_FAR_PROGRESS) return

        val entryIdx = candles.indexOfFirst { it.openTimeMs >= trade.signalTimeMs }
            .takeIf { it >= 0 } ?: (currentIdx - 1).coerceAtLeast(0)
        val feats = RunOnFeatureBuilder.build(
            candles, snapshots, currentIdx, entryIdx, dir,
            trade.entryPrice, trade.appliedSl, trade.appliedTp, trade.pWin
        ) ?: return
        val p = bundle.weights.predictProbability(feats)
        val rule = bundle.ruleFor(cell.ageBucket, cell.progressBucket)
        val on = RunOnTrainer.decideMarker(rule, p, trade.runOnMarker)

        val firstShown = on && trade.runOnShownTimeMs == null
        val updated = trade.copy(
            runOnProb = p,
            runOnMarker = on,
            runOnShownTimeMs = trade.runOnShownTimeMs ?: if (on) candles[currentIdx].openTimeMs else null
        )
        if (updated != trade) signalDao.upsert(updated)
        if (on && !trade.runOnMarker && settings.notifyRunOn && !muted && (firstShown || trade.runOnShownTimeMs != null)) {
            notificationHelper?.notifyRunOnPossible(updated, p, settings)
        }
    }

    private suspend fun evaluateAndNotifyExitWarning(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        activeTrade: SignalCandidateEntity,
        candles: List<Candle>,
        snapshots: List<ConfluenceBarSnapshot>,
        currentIdx: Int,
        muted: Boolean,
        settings: AppSettings
    ) {
        val rules = exitCellRuleDao.getRules(exchange.name, marketType.name)
        if (rules.isEmpty()) {
            // Safe default [U22]: silent until phase-aware rules exist
            return
        }

        val dir = TradeDirection.valueOf(activeTrade.direction)
        val entryIdx = candles.indexOfFirst { it.openTimeMs >= activeTrade.signalTimeMs }
            .takeIf { it >= 0 } ?: (currentIdx - 1).coerceAtLeast(0)

        val close = candles[currentIdx].close
        val ageBars = ((candles[currentIdx].openTimeMs - activeTrade.signalTimeMs) / DayChunkCodec.MILLIS_PER_MINUTE)
            .toInt()
            .coerceAtLeast(1)
        val (cell, signedProgress) = ExitWarningFeatureBuilder.cellFor(
            ageBars = ageBars,
            direction = dir,
            close = close,
            entryPrice = activeTrade.entryPrice,
            slPrice = activeTrade.appliedSl,
            tpPrice = activeTrade.appliedTp
        )
        val cellRule = rules.firstOrNull {
            it.ageBucket == cell.ageBucket && it.progressBucket == cell.progressBucket
        }

        val exitModelEntity = mlModelDao.getActiveModel("EXIT_${exchange.name}_${marketType.name}")
        val exitBundle = exitModelEntity?.let {
            runCatching { json.decodeFromString<SerializedModelBundle>(it.modelJson) }.getOrNull()
        }?.takeIf { it.weights.weights.size == ExitFeatureSpec.FEATURE_COUNT }

        val exitFeatures = ExitWarningFeatureBuilder.buildStateFeatures(
            candles = candles,
            snapshots = snapshots,
            currentBarIndex = currentIdx,
            entryBarIndex = entryIdx,
            direction = dir,
            entryPrice = activeTrade.entryPrice,
            slPrice = activeTrade.appliedSl,
            tpPrice = activeTrade.appliedTp,
            entryPWin = activeTrade.pWin
        )
        val pRev = if (exitBundle != null && exitFeatures != null) {
            exitBundle.weights.predictProbability(exitFeatures)
        } else {
            null
        }

        val prevEntity = exitWarningStateDao.get(exchange.name, marketType.name, symbol)
        val prevState = ExitWarningState(
            disarmed = prevEntity?.mlWarningFired ?: false,
            streak = prevEntity?.streak ?: 0,
            goneCount = prevEntity?.goneCount ?: 0,
            lastWarnCell = prevEntity?.lastWarnCell
        )

        val trigger = ExitWarningEvaluator.evaluate(
            direction = dir,
            snapshot = snapshots[currentIdx],
            pReversal = pRev,
            rule = cellRule,
            cellCode = cell.code,
            beyondTp = signedProgress > 1.0,
            prevState = prevState,
            notifyExitMl = settings.notifyExitMl,
            notifyExitStructure = settings.notifyExitStructure
        )

        exitWarningStateDao.upsert(
            ExitWarningStateEntity(
                exchange = exchange.name,
                marketType = marketType.name,
                symbol = symbol,
                mlWarningFired = trigger.nextState.disarmed,
                structureWarningFired = false,
                lastWarnedAtMs = if (trigger.shouldWarn) System.currentTimeMillis() else (prevEntity?.lastWarnedAtMs ?: 0L),
                streak = trigger.nextState.streak,
                goneCount = trigger.nextState.goneCount,
                lastWarnCell = trigger.nextState.lastWarnCell
            )
        )

        if (trigger.shouldWarn) {
            val updatedTrade = activeTrade.copy(
                exitWarningCount = activeTrade.exitWarningCount + 1,
                firstExitWarningTimeMs = activeTrade.firstExitWarningTimeMs ?: candles[currentIdx].openTimeMs,
                firstExitWarningPrice = activeTrade.firstExitWarningPrice ?: close,
                exitWarningCell = activeTrade.exitWarningCell ?: cell.code
            )
            signalDao.upsert(updatedTrade)

            if (!muted) {
                val rawUnrealized = when (dir) {
                    TradeDirection.LONG -> (close - activeTrade.entryPrice) / activeTrade.entryPrice
                    TradeDirection.SHORT -> (activeTrade.entryPrice - close) / activeTrade.entryPrice
                }
                val unrealizedNet = rawUnrealized - settings.engineConfig.roundTripFeeRate
                val formattedBody = NotificationHelper.formatExitWarningBody(
                    direction = dir,
                    symbol = symbol,
                    ageMinutes = ageBars,
                    unrealizedNetPct = unrealizedNet,
                    signedProgress = signedProgress,
                    reason = trigger.reason
                )
                notificationHelper?.notifyExitWarning(updatedTrade, formattedBody, settings)
            }
        }
    }

    @Suppress("DEPRECATION")
    private suspend fun loadBestSignalModel(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        preset: RangePreset,
        settings: AppSettings
    ): Pair<SerializedModelBundle?, String?> {
        val isLegacyR240Compatible = preset.id == RangePresets.DEFAULT.id &&
            settings.engineConfig.windowLength == 240 &&
            settings.engineConfig.minGap == 30

        val assetKey = "ASSET_${exchange.name}_${marketType.name}_${symbol}_${preset.id}"
        val perAssetEntity = mlModelDao.getActiveModel(assetKey)
            ?: if (isLegacyR240Compatible) mlModelDao.getActiveModel("ASSET_${exchange.name}_${marketType.name}_$symbol") else null

        if (perAssetEntity != null && perAssetEntity.sampleCount >= settings.minSamplesForPerAssetModel) {
            val bundle = runCatching { json.decodeFromString<SerializedModelBundle>(perAssetEntity.modelJson) }.getOrNull()
            if (bundle != null && bundle.weights.weights.size in FeatureSpec.CORE_FEATURE_COUNT..FeatureSpec.FEATURE_COUNT) {
                return bundle to "Scored with $symbol (${preset.label}) model (${perAssetEntity.sampleCount} samples)."
            }
        }

        val globalKey = "GLOBAL_${exchange.name}_${marketType.name}_${preset.id}"
        val globalEntity = mlModelDao.getActiveModel(globalKey)
            ?: if (isLegacyR240Compatible) mlModelDao.getActiveModel("GLOBAL_${exchange.name}_${marketType.name}") else null

        if (globalEntity != null) {
            val bundle = runCatching { json.decodeFromString<SerializedModelBundle>(globalEntity.modelJson) }.getOrNull()
            if (bundle != null && bundle.weights.weights.size in FeatureSpec.CORE_FEATURE_COUNT..FeatureSpec.FEATURE_COUNT) {
                return bundle to "Scored with global ${marketType.displayName} (${preset.label}) model (${globalEntity.sampleCount} samples)."
            }
        }
        return null to "Unfiltered – model not trained yet."
    }
}
