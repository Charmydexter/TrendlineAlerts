package com.lrmlc.tradingalerts.trade

import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import com.lrmlc.tradingalerts.data.local.ExitWarningStateDao
import com.lrmlc.tradingalerts.data.local.ExitWarningStateEntity
import com.lrmlc.tradingalerts.data.local.MlModelDao
import com.lrmlc.tradingalerts.data.local.SettingsRepository
import com.lrmlc.tradingalerts.data.local.SignalCandidateDao
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.WatchlistDao
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.ThresholdMode
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.data.repository.CandleStoreRepository
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.engine.ConfluenceEngine
import com.lrmlc.tradingalerts.ml.ExitWarningFeatureBuilder
import com.lrmlc.tradingalerts.ml.FeatureBuilder
import com.lrmlc.tradingalerts.ml.LogisticRegressionWeights
import com.lrmlc.tradingalerts.ml.ModelExplainer
import com.lrmlc.tradingalerts.ml.SerializedModelBundle
import com.lrmlc.tradingalerts.ml.TripleBarrierLabeler
import com.lrmlc.tradingalerts.service.NotificationHelper
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.math.max

class TradeLifecycleManager(
    private val candleStore: CandleStoreRepository,
    private val watchlistDao: WatchlistDao,
    private val signalDao: SignalCandidateDao,
    private val mlModelDao: MlModelDao,
    private val exitWarningStateDao: ExitWarningStateDao,
    private val settingsRepository: SettingsRepository,
    private val notificationHelper: NotificationHelper? = null
) {
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * Evaluates newly closed 1-minute candle(s) for [symbol] in chronological order.
     */
    suspend fun processClosedCandle(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        closedCandle: Candle
    ) {
        val settings = settingsRepository.getSettings()
        val config = settings.engineConfig
        val windowLookbackMs = (config.windowLength + 360L) * DayChunkCodec.MILLIS_PER_MINUTE
        val candles = candleStore.loadCandles(
            exchange = exchange,
            marketType = marketType,
            symbol = symbol,
            startOpenTimeMs = closedCandle.openTimeMs - windowLookbackMs,
            endOpenTimeMs = closedCandle.openTimeMs
        )
        if (candles.isEmpty()) return

        // 1) Update open active trade & unresolved shadow trades against the newly closed candle
        reconcileOpenTradesAndShadows(exchange, marketType, symbol, closedCandle, candles, settings)

        // 2) Run ConfluenceEngine across the loaded window
        val engine = ConfluenceEngine(config)
        val snapshots = engine.evaluateAll(candles)
        val lastIdx = snapshots.lastIndex
        if (lastIdx < 0) return
        val lastSnap = snapshots[lastIdx]

        // Update watchlist row live stats
        val existingWatch = watchlistDao.getAsset(exchange.name, marketType.name, symbol)
        val activeTradeNow = signalDao.getActiveTradeForSymbol(exchange.name, marketType.name, symbol)
        if (existingWatch != null) {
            watchlistDao.upsert(
                existingWatch.copy(
                    lastPrice = closedCandle.close,
                    lastCandleReceivedMs = System.currentTimeMillis(),
                    activeDirection = activeTradeNow?.direction,
                    activeConfidence = activeTradeNow?.pWin
                )
            )
        }

        // 3) Check exit warnings for any active position
        if (existingWatch?.inPosition == true && activeTradeNow != null) {
            evaluateAndNotifyExitWarning(
                exchange = exchange,
                marketType = marketType,
                symbol = symbol,
                activeTrade = activeTradeNow,
                candles = candles,
                snapshots = snapshots,
                currentIdx = lastIdx,
                muted = existingWatch.muted,
                settings = settings
            )
        }

        // 4) Check if the closed bar fired a candidate signal
        val dir = lastSnap.candidateDirection ?: return
        val structuralSl = lastSnap.structuralSl ?: return
        val signalId = "${exchange.name}_${marketType.name}_${symbol}_${closedCandle.openTimeMs}"
        if (signalDao.getById(signalId) != null) return // duplicate guard

        val recentSignals = signalDao.getAllForMarket(exchange.name, marketType.name)
            .filter { it.symbol == symbol && it.label != null }
        val lastOutcome = recentSignals.lastOrNull()?.label
        val features = FeatureBuilder.buildFeatures(
            candles = candles,
            snapshots = snapshots,
            barIndex = lastIdx,
            marketType = marketType,
            lastSignalOutcome = lastOutcome
        ) ?: return

        val (bundle, usedModelNote) = loadBestSignalModel(exchange, marketType, symbol)
        val modelTrained = bundle != null
        val pWin = bundle?.weights?.predictProbability(features)
        val threshold = when {
            bundle == null -> 0.0
            settings.thresholdMode == ThresholdMode.MANUAL -> settings.manualThreshold
            else -> bundle.metrics.threshold
        }
        val accepted = !modelTrained || (pWin != null && pWin >= threshold)

        val winningForSymbol = recentSignals.filter { it.label == 1 && it.maePct != null && it.mfePct != null }
        val slTpStats = SlTpManager.computeStatsFromWinningExcursions(
            winningMaePcts = winningForSymbol.mapNotNull { it.maePct },
            winningMfePcts = winningForSymbol.mapNotNull { it.mfePct }
        )
        val slTp = SlTpManager.resolveLevels(
            direction = dir,
            entryPrice = closedCandle.close,
            structuralSl = structuralSl,
            config = config,
            stats = slTpStats,
            autoSlEnabled = settings.autoSlEnabled,
            autoTpEnabled = settings.autoTpEnabled
        )

        val reasons = if (bundle != null && pWin != null) {
            ModelExplainer.explainSignalDrivers(bundle.weights, features, pWin, bundle.metrics)
        } else {
            listOf("Unfiltered – model not trained yet. Signal uses structural confluence rules.")
        }

        val entity = SignalCandidateEntity(
            signalId = signalId,
            exchange = exchange.name,
            marketType = marketType.name,
            symbol = symbol,
            direction = dir.name,
            signalTimeMs = closedCandle.openTimeMs,
            barIndex = lastIdx,
            entryPrice = closedCandle.close,
            structuralSl = slTp.structuralSl,
            defaultTp = slTp.defaultTp,
            appliedSl = slTp.appliedSl,
            appliedTp = slTp.appliedTp,
            slAdjustmentNote = if (slTp.slAdjusted) slTp.slReason else usedModelNote,
            tpAdjustmentNote = if (slTp.tpAdjusted) slTp.tpReason else null,
            pWin = pWin,
            thresholdUsed = if (modelTrained) threshold else null,
            modelWasTrained = modelTrained,
            accepted = accepted,
            status = if (accepted) "ACTIVE" else "SHADOW",
            featuresJson = json.encodeToString(features),
            topReasonsJson = json.encodeToString(reasons),
            notified = false
        )

        if (accepted) {
            // Close any existing active trade on opposite/previous signal
            if (activeTradeNow != null) {
                closeTradeOnOppositeSignal(activeTradeNow, closedCandle, config.roundTripFeeRate)
            }
            signalDao.upsert(entity)
            watchlistDao.setInPosition(
                exchange.name,
                marketType.name,
                symbol,
                inPosition = true,
                updatedAtMs = System.currentTimeMillis()
            )
            watchlistDao.getAsset(exchange.name, marketType.name, symbol)?.let { w ->
                watchlistDao.upsert(
                    w.copy(
                        inPosition = true,
                        inPositionUpdatedAtMs = System.currentTimeMillis(),
                        activeDirection = dir.name,
                        activeConfidence = pWin,
                        lastPrice = closedCandle.close
                    )
                )
            }
            // Reset exit warning states for the new trade
            exitWarningStateDao.upsert(ExitWarningStateEntity(exchange.name, marketType.name, symbol))

            if (existingWatch?.muted != true) {
                notificationHelper?.notifySignal(entity, settings)
                signalDao.markNotified(entity.signalId)
            }
            notificationHelper?.refreshPersistentNotification(exchange, marketType, settings.keepMonitoringInBackground)
        } else {
            // Store shadow trade to prevent selection bias
            signalDao.upsert(entity)
            if (settings.notifyFilteredSignals && existingWatch?.muted != true) {
                notificationHelper?.notifyFilteredSignal(entity, settings)
            }
        }
    }

    private suspend fun reconcileOpenTradesAndShadows(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        closedCandle: Candle,
        recentCandles: List<Candle>,
        settings: AppSettings
    ) {
        val config = settings.engineConfig
        val allOpen = signalDao.getAllForMarket(exchange.name, marketType.name)
            .filter { it.symbol == symbol && (it.status == "ACTIVE" || it.status == "SHADOW") && it.signalTimeMs < closedCandle.openTimeMs }

        for (trade in allOpen) {
            val dir = TradeDirection.valueOf(trade.direction)
            val hitSl = when (dir) {
                TradeDirection.LONG -> closedCandle.low <= trade.appliedSl
                TradeDirection.SHORT -> closedCandle.high >= trade.appliedSl
            }
            val hitTp = when (dir) {
                TradeDirection.LONG -> closedCandle.high >= trade.appliedTp
                TradeDirection.SHORT -> closedCandle.low <= trade.appliedTp
            }

            // Compute MAE/MFE across candles since signal
            val tradeCandles = recentCandles.filter { it.openTimeMs > trade.signalTimeMs && it.openTimeMs <= closedCandle.openTimeMs }
            var maxMae = trade.maePct ?: 0.0
            var maxMfe = trade.mfePct ?: 0.0
            for (c in tradeCandles) {
                val adv = when (dir) {
                    TradeDirection.LONG -> ((trade.entryPrice - c.low) / trade.entryPrice).coerceAtLeast(0.0)
                    TradeDirection.SHORT -> ((c.high - trade.entryPrice) / trade.entryPrice).coerceAtLeast(0.0)
                }
                val fav = when (dir) {
                    TradeDirection.LONG -> ((c.high - trade.entryPrice) / trade.entryPrice).coerceAtLeast(0.0)
                    TradeDirection.SHORT -> ((trade.entryPrice - c.low) / trade.entryPrice).coerceAtLeast(0.0)
                }
                maxMae = max(maxMae, adv)
                maxMfe = max(maxMfe, fav)
            }

            if (hitSl || hitTp) {
                // Conservative: SL takes precedence if both touched in same candle
                val isSl = hitSl
                val exitPrice = if (isSl) trade.appliedSl else trade.appliedTp
                val rawRet = when (dir) {
                    TradeDirection.LONG -> (exitPrice - trade.entryPrice) / trade.entryPrice
                    TradeDirection.SHORT -> (trade.entryPrice - exitPrice) / trade.entryPrice
                }
                val netRet = rawRet - config.roundTripFeeRate
                val updated = trade.copy(
                    status = if (isSl) "CLOSED_SL" else "CLOSED_TP",
                    exitTimeMs = closedCandle.openTimeMs,
                    exitPrice = exitPrice,
                    netReturnPct = netRet,
                    maePct = maxMae,
                    mfePct = maxMfe,
                    label = if (isSl) 0 else 1
                )
                signalDao.upsert(updated)
                if (trade.status == "ACTIVE") {
                    watchlistDao.setInPosition(exchange.name, marketType.name, symbol, false, System.currentTimeMillis())
                    watchlistDao.getAsset(exchange.name, marketType.name, symbol)?.let { w ->
                        watchlistDao.upsert(w.copy(inPosition = false, activeDirection = null, activeConfidence = null))
                    }
                    if (!wIsMuted(exchange, marketType, symbol)) {
                        if (isSl && settings.notifySlHit) notificationHelper?.notifyOutcome(updated, settings)
                        if (!isSl && settings.notifyTpHit) notificationHelper?.notifyOutcome(updated, settings)
                    }
                    notificationHelper?.refreshPersistentNotification(exchange, marketType, settings.keepMonitoringInBackground)
                }
            } else {
                // Check horizon timeout for shadow trades (and update MAE/MFE on active trades)
                val barsElapsed = ((closedCandle.openTimeMs - trade.signalTimeMs) / DayChunkCodec.MILLIS_PER_MINUTE).toInt()
                if (trade.status == "SHADOW" && barsElapsed >= config.labelHorizonBars) {
                    val rawRet = when (dir) {
                        TradeDirection.LONG -> (closedCandle.close - trade.entryPrice) / trade.entryPrice
                        TradeDirection.SHORT -> (trade.entryPrice - closedCandle.close) / trade.entryPrice
                    }
                    val netRet = rawRet - config.roundTripFeeRate
                    val label = TripleBarrierLabeler.labelCandidate(
                        candles = recentCandles,
                        signalBarIndex = recentCandles.indexOfFirst { it.openTimeMs == trade.signalTimeMs }.coerceAtLeast(0),
                        direction = dir,
                        entryPrice = trade.entryPrice,
                        slPrice = trade.appliedSl,
                        tpPrice = trade.appliedTp,
                        horizonBars = config.labelHorizonBars,
                        roundTripFeeRate = config.roundTripFeeRate,
                        timeoutLabelMode = config.timeoutLabelMode
                    ).label
                    signalDao.upsert(
                        trade.copy(
                            status = "CLOSED_TIMEOUT",
                            exitTimeMs = closedCandle.openTimeMs,
                            exitPrice = closedCandle.close,
                            netReturnPct = netRet,
                            maePct = maxMae,
                            mfePct = maxMfe,
                            label = label
                        )
                    )
                } else {
                    signalDao.upsert(trade.copy(maePct = maxMae, mfePct = maxMfe))
                }
            }
        }
    }

    private suspend fun wIsMuted(exchange: ExchangeId, marketType: MarketType, symbol: String): Boolean =
        watchlistDao.getAsset(exchange.name, marketType.name, symbol)?.muted == true

    private suspend fun closeTradeOnOppositeSignal(
        activeTrade: SignalCandidateEntity,
        candle: Candle,
        feeRate: Double
    ) {
        val dir = TradeDirection.valueOf(activeTrade.direction)
        val rawRet = when (dir) {
            TradeDirection.LONG -> (candle.close - activeTrade.entryPrice) / activeTrade.entryPrice
            TradeDirection.SHORT -> (activeTrade.entryPrice - candle.close) / activeTrade.entryPrice
        }
        val netRet = rawRet - feeRate
        signalDao.upsert(
            activeTrade.copy(
                status = "CLOSED_OPPOSITE",
                exitTimeMs = candle.openTimeMs,
                exitPrice = candle.close,
                netReturnPct = netRet,
                label = if (netRet > 0.0) 1 else 0
            )
        )
    }

    private suspend fun evaluateAndNotifyExitWarning(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        activeTrade: SignalCandidateEntity,
        candles: List<Candle>,
        snapshots: List<ConfluenceBarSnapshot>,
        currentIdx: Int,
        muted: Boolean,
        settings: AppSettings
    ) {
        val dir = TradeDirection.valueOf(activeTrade.direction)
        val entryIdx = candles.indexOfFirst { it.openTimeMs >= activeTrade.signalTimeMs }
            .takeIf { it >= 0 } ?: (currentIdx - 1).coerceAtLeast(0)

        val exitModelEntity = mlModelDao.getActiveModel("EXIT_${exchange.name}_${marketType.name}")
        val exitBundle = exitModelEntity?.let {
            runCatching { json.decodeFromString<SerializedModelBundle>(it.modelJson) }.getOrNull()
        }
        val exitFeatures = ExitWarningFeatureBuilder.buildStateFeatures(
            candles = candles,
            snapshots = snapshots,
            currentBarIndex = currentIdx,
            entryBarIndex = entryIdx,
            direction = dir,
            entryPrice = activeTrade.entryPrice,
            slPrice = activeTrade.appliedSl,
            tpPrice = activeTrade.appliedTp
        )
        val pRev = if (exitBundle != null && exitFeatures != null) {
            exitBundle.weights.predictProbability(exitFeatures)
        } else {
            null
        }
        val exitThresh = exitModelEntity?.threshold ?: 0.65
        val prevEntity = exitWarningStateDao.get(exchange.name, marketType.name, symbol)
        val prevState = ExitWarningState(
            mlWarningFired = prevEntity?.mlWarningFired ?: false,
            structureWarningFired = prevEntity?.structureWarningFired ?: false
        )

        val trigger = ExitWarningEvaluator.evaluate(
            direction = dir,
            snapshot = snapshots[currentIdx],
            pReversal = pRev,
            exitThreshold = exitThresh,
            prevState = prevState
        )

        exitWarningStateDao.upsert(
            ExitWarningStateEntity(
                exchange = exchange.name,
                marketType = marketType.name,
                symbol = symbol,
                mlWarningFired = trigger.nextState.mlWarningFired,
                structureWarningFired = trigger.nextState.structureWarningFired,
                lastWarnedAtMs = if (trigger.shouldWarn) System.currentTimeMillis() else (prevEntity?.lastWarnedAtMs ?: 0L)
            )
        )

        if (trigger.shouldWarn && !muted) {
            notificationHelper?.notifyExitWarning(activeTrade, trigger.reason, settings)
        }
    }

    private suspend fun loadBestSignalModel(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String
    ): Pair<SerializedModelBundle?, String?> {
        val settings = settingsRepository.getSettings()
        val perAssetEntity = mlModelDao.getActiveModel("ASSET_${exchange.name}_${marketType.name}_$symbol")
        if (perAssetEntity != null && perAssetEntity.sampleCount >= settings.minSamplesForPerAssetModel) {
            val bundle = runCatching { json.decodeFromString<SerializedModelBundle>(perAssetEntity.modelJson) }.getOrNull()
            if (bundle != null) return bundle to "Scored with $symbol per-asset model (${perAssetEntity.sampleCount} samples)."
        }
        val globalEntity = mlModelDao.getActiveModel("GLOBAL_${exchange.name}_${marketType.name}")
        if (globalEntity != null) {
            val bundle = runCatching { json.decodeFromString<SerializedModelBundle>(globalEntity.modelJson) }.getOrNull()
            if (bundle != null) return bundle to "Scored with global ${marketType.displayName} model (${globalEntity.sampleCount} samples)."
        }
        return null to "Unfiltered – model not trained yet."
    }
}
