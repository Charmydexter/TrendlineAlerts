package com.lrmlc.tradingalerts.trade

import com.lrmlc.tradingalerts.data.local.ExitCellRuleEntity
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.ml.ExitWarningFeatureBuilder

/**
 * Per-trade warning memory.
 * [disarmed] = a warning was sent and the condition has not yet been gone for N candles.
 */
data class ExitWarningState(
    val disarmed: Boolean = false,
    val streak: Int = 0,
    val goneCount: Int = 0,
    val lastWarnCell: String? = null
)

data class ExitWarningTrigger(
    val shouldWarn: Boolean,
    val reason: String,
    val pReversal: Double?,
    val nextState: ExitWarningState,
    val triggeredByMl: Boolean = false,
    val triggeredByStructure: Boolean = false
)

object ExitWarningEvaluator {

    /**
     * Learned, per-situation evaluation (20 situations). No fixed warning limit and no fixed wait:
     * - A situation without a proven rule stays silent.
     * - The condition (ML level reached and/or structure break) must hold for rule.persistN closed candles in a row.
     * - After a warning the same situation may warn again only after the condition has been gone for
     *   persistN candles, or when the trade moves into a different situation that has its own rule.
     */
    fun evaluate(
        direction: TradeDirection,
        snapshot: ConfluenceBarSnapshot,
        pReversal: Double?,
        rule: ExitCellRuleEntity?,
        cellCode: String,
        beyondTp: Boolean,
        prevState: ExitWarningState,
        notifyExitMl: Boolean = true,
        notifyExitStructure: Boolean = true
    ): ExitWarningTrigger {
        val mlCond = rule != null && rule.mlEnabled && notifyExitMl &&
            pReversal != null && pReversal >= rule.mlThreshold
        val structCond = rule != null && rule.structEnabled && notifyExitStructure &&
            ExitWarningFeatureBuilder.isOppositeStructureTriggered(direction, snapshot)
        val cond = mlCond || structCond
        val n = (rule?.persistN ?: 1).coerceIn(1, 3)

        val streak = if (cond) prevState.streak + 1 else 0
        val gone = if (cond) 0 else prevState.goneCount + 1
        var disarmed = prevState.disarmed
        if (!cond && gone >= n) disarmed = false

        val differentSituation = prevState.lastWarnCell != null && prevState.lastWarnCell != cellCode
        val fire = cond && streak >= n && (!disarmed || differentSituation)

        val next = ExitWarningState(
            disarmed = if (fire) true else disarmed,
            streak = streak,
            goneCount = gone,
            lastWarnCell = if (fire) cellCode else prevState.lastWarnCell
        )
        if (!fire) {
            return ExitWarningTrigger(false, "", pReversal, next)
        }

        val fireMl = mlCond
        val fireStruct = structCond
        val reason = buildList {
            if (fireMl && pReversal != null && rule != null) {
                add(
                    if (beyondTp) "profit may be fading (model ${(pReversal * 100).toInt()}%, level ${(rule.mlThreshold * 100).toInt()}%)"
                    else "model sees ${(pReversal * 100).toInt()}% exit risk (level ${(rule.mlThreshold * 100).toInt()}%)"
                )
            }
            if (fireStruct) {
                add(
                    if (direction == TradeDirection.LONG) "price fell below all three levels without a confirmed short signal"
                    else "price rose above all three levels without a confirmed long signal"
                )
            }
        }.joinToString("; ")

        return ExitWarningTrigger(true, reason, pReversal, next, fireMl, fireStruct)
    }
}
