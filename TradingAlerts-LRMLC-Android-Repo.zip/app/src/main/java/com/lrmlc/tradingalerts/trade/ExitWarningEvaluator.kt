package com.lrmlc.tradingalerts.trade

import com.lrmlc.tradingalerts.data.local.ExitCellRuleEntity
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.ml.ExitWarningFeatureBuilder

data class ExitWarningState(
    val mlWarningFired: Boolean = false,
    val structureWarningFired: Boolean = false
)

data class ExitWarningTrigger(
    val shouldWarn: Boolean,
    val reason: String,
    val pReversal: Double?,
    val nextState: ExitWarningState,
    val triggeredByMl: Boolean = false,
    val triggeredByStructure: Boolean = false
)

object ExitWarningEvaluator {

    const val MAX_WARNINGS_PER_TRADE = 2

    /**
     * Phase-aware evaluation using learned OOS cell rules [U22].
     * Anti-spam rails:
     * - At most MAX_WARNINGS_PER_TRADE (2) warnings per trade.
     * - Condition must clear on >= 1 candle before firing again.
     * - If rule is null or disabled, stays completely silent.
     */
    fun evaluate(
        direction: TradeDirection,
        snapshot: ConfluenceBarSnapshot,
        pReversal: Double?,
        rule: ExitCellRuleEntity?,
        prevState: ExitWarningState,
        warningsSoFar: Int,
        notifyExitMl: Boolean = true,
        notifyExitStructure: Boolean = true
    ): ExitWarningTrigger {
        val mlCond = rule != null &&
            rule.mlEnabled &&
            notifyExitMl &&
            pReversal != null &&
            pReversal >= rule.mlThreshold

        val structCond = rule != null &&
            rule.structEnabled &&
            notifyExitStructure &&
            ExitWarningFeatureBuilder.isOppositeStructureTriggered(direction, snapshot)

        val fireMl = mlCond && !prevState.mlWarningFired
        val fireStruct = structCond && !prevState.structureWarningFired

        val nextState = ExitWarningState(
            mlWarningFired = mlCond,
            structureWarningFired = structCond
        )

        if (warningsSoFar >= MAX_WARNINGS_PER_TRADE || (!fireMl && !fireStruct)) {
            return ExitWarningTrigger(
                shouldWarn = false,
                reason = "",
                pReversal = pReversal,
                nextState = nextState
            )
        }

        val thresholdUsed = rule?.mlThreshold ?: 0.70
        val reason = buildList {
            if (fireMl && pReversal != null) {
                add("Exit model reversal risk ${(pReversal * 100).toInt()}% (phase threshold ${(thresholdUsed * 100).toInt()}%).")
            }
            if (fireStruct) {
                if (direction == TradeDirection.LONG) {
                    add("Price dropped below all three trendline levels without a confirmed short signal.")
                } else {
                    add("Price broke above all three trendline levels without a confirmed long signal.")
                }
            }
        }.joinToString(" ")

        return ExitWarningTrigger(
            shouldWarn = true,
            reason = reason,
            pReversal = pReversal,
            nextState = nextState,
            triggeredByMl = fireMl,
            triggeredByStructure = fireStruct
        )
    }
}
