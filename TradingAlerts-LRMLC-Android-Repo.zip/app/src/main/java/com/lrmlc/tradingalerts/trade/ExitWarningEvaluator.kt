package com.lrmlc.tradingalerts.trade

import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot

data class ExitWarningState(
    val mlWarningFired: Boolean = false,
    val structureWarningFired: Boolean = false
)

data class ExitWarningTrigger(
    val shouldWarn: Boolean,
    val reason: String,
    val pReversal: Double?,
    val nextState: ExitWarningState
)

object ExitWarningEvaluator {

    /**
     * Evaluates exit warning conditions once per condition and re-arms after the condition clears.
     * Conditions:
     * 1) Exit logistic regression model predicts P(reversal) >= exitThreshold
     * 2) Opposite raw structure condition occurs (e.g., for LONG, candle high < loLine)
     *    without a confirmed opposite signal firing.
     */
    fun evaluate(
        direction: TradeDirection,
        snapshot: ConfluenceBarSnapshot,
        pReversal: Double?,
        exitThreshold: Double,
        prevState: ExitWarningState
    ): ExitWarningTrigger {
        val mlCond = pReversal != null && pReversal >= exitThreshold
        val structCond = when (direction) {
            TradeDirection.LONG -> snapshot.rawShort && !snapshot.shortFire
            TradeDirection.SHORT -> snapshot.rawLong && !snapshot.longFire
        }

        val fireMl = mlCond && !prevState.mlWarningFired
        val fireStruct = structCond && !prevState.structureWarningFired

        val nextState = ExitWarningState(
            mlWarningFired = mlCond,
            structureWarningFired = structCond
        )

        if (!fireMl && !fireStruct) {
            return ExitWarningTrigger(false, "", pReversal, nextState)
        }

        val reason = buildList {
            if (fireMl && pReversal != null) {
                add("Exit model reversal risk reached ${(pReversal * 100).toInt()}% (threshold ${(exitThreshold * 100).toInt()}%).")
            }
            if (fireStruct) {
                if (direction == TradeDirection.LONG) {
                    add("Price dropped completely below all three levels without a confirmed short signal.")
                } else {
                    add("Price broke completely above all three levels without a confirmed long signal.")
                }
            }
        }.joinToString(" ")

        return ExitWarningTrigger(
            shouldWarn = true,
            reason = reason,
            pReversal = pReversal,
            nextState = nextState
        )
    }
}
