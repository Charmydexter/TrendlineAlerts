package com.lrmlc.tradingalerts.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "candle_day_chunks",
    primaryKeys = ["exchange", "marketType", "symbol", "utcDayIndex"],
    indices = [
        Index(value = ["exchange", "marketType", "symbol"]),
        Index(value = ["utcDayIndex"])
    ]
)
data class CandleDayChunkEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val utcDayIndex: Long,
    val candleCount: Int,
    val minOpenTimeMs: Long,
    val maxOpenTimeMs: Long,
    val byteSize: Int,
    val blob: ByteArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is CandleDayChunkEntity) return false
        return exchange == other.exchange &&
            marketType == other.marketType &&
            symbol == other.symbol &&
            utcDayIndex == other.utcDayIndex &&
            candleCount == other.candleCount &&
            blob.contentEquals(other.blob)
    }

    override fun hashCode(): Int {
        var result = exchange.hashCode()
        result = 31 * result + marketType.hashCode()
        result = 31 * result + symbol.hashCode()
        result = 31 * result + utcDayIndex.hashCode()
        result = 31 * result + candleCount
        result = 31 * result + blob.contentHashCode()
        return result
    }
}

data class ChunkDayCountSummary(
    val utcDayIndex: Long,
    val candleCount: Int
)

data class AssetStorageSummary(
    val symbol: String,
    val totalBytes: Long,
    val totalCandles: Int,
    val dayCount: Int
)

@Entity(
    tableName = "watchlist_assets",
    primaryKeys = ["exchange", "marketType", "symbol"]
)
data class WatchlistEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val displayOrder: Int,
    val inPosition: Boolean = false,
    val inPositionUpdatedAtMs: Long = 0L,
    val muted: Boolean = false,
    val lastCandleReceivedMs: Long = 0L,
    val lastPrice: Double? = null,
    val change24hPct: Double? = null,
    val activeDirection: String? = null, // LONG, SHORT, or null
    val activeConfidence: Double? = null,
    val addedAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "recycle_bin_assets",
    primaryKeys = ["exchange", "marketType", "symbol"]
)
data class RecycleBinEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val removedAtMs: Long
)

@Entity(
    tableName = "signal_candidates",
    indices = [
        Index(value = ["exchange", "marketType", "symbol", "signalTimeMs"]),
        Index(value = ["status"])
    ]
)
data class SignalCandidateEntity(
    @PrimaryKey val signalId: String,
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val direction: String, // LONG or SHORT
    val signalTimeMs: Long,
    val barIndex: Int,
    val entryPrice: Double,
    val structuralSl: Double,
    val defaultTp: Double,
    val appliedSl: Double,
    val appliedTp: Double,
    val slAdjustmentNote: String?,
    val tpAdjustmentNote: String?,
    val manualOverride: Boolean = false,
    val pWin: Double?,
    val thresholdUsed: Double?,
    val modelWasTrained: Boolean,
    val accepted: Boolean,
    val status: String, // ACTIVE, SHADOW, CLOSED_TP, CLOSED_SL, CLOSED_OPPOSITE, CLOSED_MANUAL, CLOSED_TIMEOUT
    val exitTimeMs: Long? = null,
    val exitPrice: Double? = null,
    val netReturnPct: Double? = null,
    val maePct: Double? = null,
    val mfePct: Double? = null,
    val label: Int? = null, // 1 win, 0 loss, null unresolved
    val featuresJson: String,
    val topReasonsJson: String,
    val notified: Boolean = false
)

@Entity(tableName = "ml_models")
data class MlModelEntity(
    @PrimaryKey val modelKey: String, // GLOBAL_<MARKET>, ASSET_<MARKET>_<SYMBOL>, EXIT_<MARKET>
    val modelKind: String,            // GLOBAL, PER_ASSET, EXIT
    val exchange: String,
    val marketType: String,
    val symbol: String?,
    val version: Int,
    val trainedAtMs: Long,
    val sampleCount: Int,
    val threshold: Double,
    val brierScore: Double,
    val winRate: Double,
    val profitFactor: Double,
    val netExpectancy: Double,
    val maxDrawdown: Double,
    val modelJson: String,
    val isActive: Boolean
)

@Entity(
    tableName = "training_jobs",
    indices = [Index(value = ["status", "createdAtMs"])]
)
data class TrainingJobEntity(
    @PrimaryKey val jobId: String,
    val jobType: String, // INITIAL, DAILY, THREE_DAY, WEEKLY, MANUAL
    val exchange: String,
    val marketType: String,
    val stage: String,   // COLLECTING_SAMPLES, TRAINING_GLOBAL, TRAINING_PER_ASSET, TRAINING_EXIT, VALIDATING, COMPLETED
    val datasetCursor: Int,
    val epoch: Int,
    val batchIndex: Int,
    val randomSeed: Long,
    val checkpointJson: String,
    val status: String,  // PENDING, RUNNING, PAUSED, COMPLETED, FAILED
    val progressPct: Int,
    val statusMessage: String,
    val createdAtMs: Long,
    val updatedAtMs: Long
)

@Entity(
    tableName = "training_logs",
    indices = [Index(value = ["timestampMs"])]
)
data class TrainingLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMs: Long,
    val exchange: String,
    val marketType: String,
    val jobType: String,
    val promoted: Boolean,
    val summary: String,
    val metricsJson: String
)

@Entity(
    tableName = "exit_warning_states",
    primaryKeys = ["exchange", "marketType", "symbol"]
)
data class ExitWarningStateEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val mlWarningFired: Boolean = false,
    val structureWarningFired: Boolean = false,
    val lastWarnedAtMs: Long = 0L
)

@Entity(
    tableName = "sync_progress",
    primaryKeys = ["exchange", "marketType", "symbol"]
)
data class SyncProgressEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val targetStartMs: Long,
    val oldestFetchedMs: Long,
    val pagesFetched: Int,
    val completed: Boolean,
    val lastError: String? = null,
    val updatedAtMs: Long = System.currentTimeMillis()
)
