package com.lrmlc.tradingalerts.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "candle_day_chunks",
    primaryKeys = ["exchange", "marketType", "symbol", "utcDayIndex"],
    indices = [
        Index(value = ["exchange", "marketType", "symbol"]),
        Index(value = ["utcDayIndex"])
    ]
)
data class CandleDayChunkEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val utcDayIndex: Long,
    val candleCount: Int,
    val minOpenTimeMs: Long,
    val maxOpenTimeMs: Long,
    val byteSize: Int,
    val blob: ByteArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is CandleDayChunkEntity) return false
        return exchange == other.exchange &&
            marketType == other.marketType &&
            symbol == other.symbol &&
            utcDayIndex == other.utcDayIndex &&
            candleCount == other.candleCount &&
            blob.contentEquals(other.blob)
    }

    override fun hashCode(): Int {
        var result = exchange.hashCode()
        result = 31 * result + marketType.hashCode()
        result = 31 * result + symbol.hashCode()
        result = 31 * result + utcDayIndex.hashCode()
        result = 31 * result + candleCount
        result = 31 * result + blob.contentHashCode()
        return result
    }
}

data class ChunkDayCountSummary(
    val utcDayIndex: Long,
    val candleCount: Int
)

/** Chunk identity without the blob, so exports can load one chunk at a time. */
data class ChunkKey(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val utcDayIndex: Long
)

data class AssetStorageSummary(
    val symbol: String,
    val totalBytes: Long,
    val totalCandles: Int,
    val dayCount: Int
)

@Entity(
    tableName = "watchlist_assets",
    primaryKeys = ["exchange", "marketType", "symbol"]
)
data class WatchlistEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val displayOrder: Int,
    val inPosition: Boolean = false,
    val inPositionUpdatedAtMs: Long = 0L,
    val muted: Boolean = false,
    val lastCandleReceivedMs: Long = 0L,
    val lastPrice: Double? = null,
    val change24hPct: Double? = null,
    val activeDirection: String? = null, // LONG, SHORT, or null
    val activeConfidence: Double? = null,
    val addedAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "recycle_bin_assets",
    primaryKeys = ["exchange", "marketType", "symbol"]
)
data class RecycleBinEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val removedAtMs: Long
)

@Entity(
    tableName = "signal_candidates",
    indices = [
        Index(value = ["exchange", "marketType", "symbol", "signalTimeMs"]),
        Index(value = ["status"])
    ]
)
data class SignalCandidateEntity(
    @PrimaryKey val signalId: String,
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val direction: String, // LONG or SHORT
    val signalTimeMs: Long,
    val barIndex: Int,
    val entryPrice: Double,
    val structuralSl: Double,
    val defaultTp: Double,
    val appliedSl: Double,
    val appliedTp: Double,
    val slAdjustmentNote: String?,
    val tpAdjustmentNote: String?,
    val manualOverride: Boolean = false,
    val pWin: Double?,
    val thresholdUsed: Double?,
    val modelWasTrained: Boolean,
    val accepted: Boolean,
    val status: String, // ACTIVE, SHADOW, CLOSED_TP, CLOSED_SL, CLOSED_OPPOSITE, CLOSED_MANUAL, CLOSED_TIMEOUT (ACTIVE trades may carry tpReachedTimeMs / slReachedTimeMs)
    val exitTimeMs: Long? = null,
    val exitPrice: Double? = null,
    val netReturnPct: Double? = null,
    val maePct: Double? = null,
    val mfePct: Double? = null,
    val label: Int? = null, // 1 win, 0 loss, null unresolved
    val featuresJson: String,
    val topReasonsJson: String,
    val notified: Boolean = false,
    @ColumnInfo(defaultValue = "0")
    val exitWarningCount: Int = 0,
    val firstExitWarningTimeMs: Long? = null,
    val firstExitWarningPrice: Double? = null,
    val firstExitWarningHelped: Boolean? = null,
    val exitWarningCell: String? = null,
    @ColumnInfo(defaultValue = "'R240'")
    val presetId: String = "R240",
    // Job 1: trade stays open after TP/SL touch when auto-close is off
    val tpReachedTimeMs: Long? = null,
    val slReachedTimeMs: Long? = null,
    val maxBeyondTpPct: Double? = null, // best run beyond TP, fraction of entry price (0.0035 = 0.35%)
    // Job 3: learned "expects a run far past TP" marker
    val runOnProb: Double? = null,
    @ColumnInfo(defaultValue = "0")
    val runOnMarker: Boolean = false,
    val runOnShownTimeMs: Long? = null // first time the marker was shown
)

@Entity(tableName = "ml_models")
data class MlModelEntity(
    @PrimaryKey val modelKey: String, // GLOBAL_<EX>_<MKT>_<PRESET>, ASSET_<EX>_<MKT>_<SYM>_<PRESET>, EXIT_<EX>_<MKT>
    val modelKind: String,            // GLOBAL, PER_ASSET, EXIT
    val exchange: String,
    val marketType: String,
    val symbol: String?,
    val version: Int,
    val trainedAtMs: Long,
    val sampleCount: Int,
    val threshold: Double,
    val brierScore: Double,
    val winRate: Double,
    val profitFactor: Double,
    val netExpectancy: Double,
    val maxDrawdown: Double,
    val modelJson: String,
    val isActive: Boolean
)

@Entity(
    tableName = "training_jobs",
    indices = [Index(value = ["status", "createdAtMs"])]
)
data class TrainingJobEntity(
    @PrimaryKey val jobId: String,
    val jobType: String, // INITIAL, DAILY, THREE_DAY, WEEKLY, MANUAL
    val exchange: String,
    val marketType: String,
    val stage: String,   // COLLECTING_SAMPLES, TRAINING_GLOBAL, TRAINING_PER_ASSET, TRAINING_EXIT, VALIDATING, COMPLETED
    val datasetCursor: Int,
    val epoch: Int,
    val batchIndex: Int,
    val randomSeed: Long,
    val checkpointJson: String,
    val status: String,  // PENDING, RUNNING, PAUSED, COMPLETED, FAILED
    val progressPct: Int,
    val statusMessage: String,
    val createdAtMs: Long,
    val updatedAtMs: Long
)

@Entity(
    tableName = "training_logs",
    indices = [Index(value = ["timestampMs"])]
)
data class TrainingLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMs: Long,
    val exchange: String,
    val marketType: String,
    val jobType: String,
    val promoted: Boolean,
    val summary: String,
    val metricsJson: String,
    val reportJson: String? = null
)

@Entity(
    tableName = "exit_warning_states",
    primaryKeys = ["exchange", "marketType", "symbol"]
)
data class ExitWarningStateEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val mlWarningFired: Boolean = false, // v2: true = disarmed after a warning until condition has been gone N candles
    val structureWarningFired: Boolean = false,
    val lastWarnedAtMs: Long = 0L,
    @ColumnInfo(defaultValue = "0")
    val streak: Int = 0,
    @ColumnInfo(defaultValue = "0")
    val goneCount: Int = 0,
    val lastWarnCell: String? = null
)

@Entity(
    tableName = "exit_cell_rules",
    primaryKeys = ["exchange", "marketType", "ageBucket", "progressBucket"]
)
data class ExitCellRuleEntity(
    val exchange: String,
    val marketType: String,
    val ageBucket: Int,
    val progressBucket: Int,
    val mlEnabled: Boolean,
    val mlThreshold: Double,
    val structEnabled: Boolean,
    val precision: Double,
    val warnings: Int,
    val avgSavedRisk: Double,
    val updatedAtMs: Long,
    @ColumnInfo(defaultValue = "1")
    val persistN: Int = 1
)

@Entity(
    tableName = "asset_preset_selection",
    primaryKeys = ["exchange", "marketType", "symbol"]
)
data class AssetPresetSelectionEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val presetId: String,
    val lcbExpectancy: Double,
    val trades: Int,
    val updatedAtMs: Long
)

@Entity(
    tableName = "sync_progress",
    primaryKeys = ["exchange", "marketType", "symbol"]
)
data class SyncProgressEntity(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val targetStartMs: Long,
    val oldestFetchedMs: Long,
    val pagesFetched: Int,
    val completed: Boolean,
    val lastError: String? = null,
    val updatedAtMs: Long = System.currentTimeMillis()
)
