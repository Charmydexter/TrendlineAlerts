package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.model.RangePreset
import com.lrmlc.tradingalerts.data.model.RangePresets
import kotlinx.serialization.Serializable
import kotlin.math.abs
import kotlin.math.sqrt

@Serializable
data class PooledPresetSummary(
    val presetId: String,
    val label: String,
    val windowBars: Int,
    val minGapBars: Int,
    val trades: Int,
    val winRate: Double,
    val expectancyPct: Double,
    val lcbExpectancyPct: Double,
    val threshold: Double,
    val brierScore: Double
)

data class PresetCandidateEval(
    val preset: RangePreset,
    val metrics: ValidationMetrics,
    val oosPredictions: List<Pair<Double, LabeledSample>>
)

data class AssetPresetChoice(
    val symbol: String,
    val selectedPreset: RangePreset,
    val lcbExpectancy: Double,
    val trades: Int,
    val usedPooledFallback: Boolean
)

object PresetSelector {

    const val MIN_ASSET_TRADES = 20
    const val MIN_PRESET_MARGIN = 0.0005 // 0.05% absolute LCB expectancy margin

    fun computeLcbExpectancy(returns: List<Double>): Double {
        if (returns.isEmpty()) return Double.NEGATIVE_INFINITY
        val n = returns.size.toDouble()
        val mean = returns.sum() / n
        if (returns.size == 1) return mean
        var sq = 0.0
        for (r in returns) {
            val d = r - mean
            sq += d * d
        }
        val stdErr = sqrt((sq / (n - 1.0)) / n)
        return mean - 1.0 * stdErr
    }

    fun selectPooledBest(evals: List<PresetCandidateEval>): RangePreset {
        if (evals.isEmpty()) return RangePresets.DEFAULT
        data class Scored(val preset: RangePreset, val lcb: Double, val trades: Int)
        val scored = evals.map { e ->
            val takenReturns = e.oosPredictions
                .filter { it.first >= e.metrics.threshold }
                .map { it.second.netReturnPct }
            val lcb = if (takenReturns.isNotEmpty()) {
                computeLcbExpectancy(takenReturns)
            } else {
                Double.NEGATIVE_INFINITY
            }
            Scored(e.preset, lcb, takenReturns.size)
        }
        val qualified = scored.filter { it.trades >= MIN_ASSET_TRADES && it.lcb.isFinite() }
        val pool = if (qualified.isNotEmpty()) qualified else scored.filter { it.lcb.isFinite() }
        if (pool.isEmpty()) return RangePresets.DEFAULT

        var best = pool.first()
        for (cand in pool.drop(1)) {
            val diff = cand.lcb - best.lcb
            if (diff > 1e-9) {
                best = cand
            } else if (abs(diff) <= 1e-9 && cand.preset.id == RangePresets.DEFAULT.id) {
                // Ties go to R240
                best = cand
            }
        }
        return best.preset
    }

    fun selectPresetForAsset(
        symbol: String,
        assetSampleCounts: Map<String, Int>,
        evals: List<PresetCandidateEval>,
        pooledBestPreset: RangePreset,
        previousPresetId: String? = null,
        minSamplesForPerAsset: Int = 60
    ): AssetPresetChoice {
        val evalById = evals.associateBy { it.preset.id }

        data class AssetScore(val preset: RangePreset, val lcb: Double, val trades: Int)
        val candidates = ArrayList<AssetScore>()
        for (e in evals) {
            val totalCount = assetSampleCounts[e.preset.id] ?: 0
            if (totalCount < minSamplesForPerAsset) continue
            val taken = e.oosPredictions.filter { it.second.symbol == symbol && it.first >= e.metrics.threshold }
            if (taken.size < MIN_ASSET_TRADES) continue
            val lcb = computeLcbExpectancy(taken.map { it.second.netReturnPct })
            if (lcb.isFinite()) {
                candidates.add(AssetScore(e.preset, lcb, taken.size))
            }
        }

        val pooledAssetEval = evalById[pooledBestPreset.id]?.let { e ->
            val taken = e.oosPredictions.filter { it.second.symbol == symbol && it.first >= e.metrics.threshold }
            val lcb = if (taken.isNotEmpty()) computeLcbExpectancy(taken.map { it.second.netReturnPct }) else e.metrics.netExpectancyPct
            AssetScore(pooledBestPreset, lcb, taken.size)
        } ?: AssetScore(pooledBestPreset, 0.0, 0)

        if (candidates.isEmpty()) {
            return AssetPresetChoice(
                symbol = symbol,
                selectedPreset = pooledBestPreset,
                lcbExpectancy = if (pooledAssetEval.lcb.isFinite()) pooledAssetEval.lcb else 0.0,
                trades = pooledAssetEval.trades,
                usedPooledFallback = true
            )
        }

        val bestCandidate = candidates.maxWith(
            compareBy<AssetScore> { it.lcb }.thenBy { it.preset.id == pooledBestPreset.id }
        )

        // Compare against pooled-best baseline on this asset
        val pooledReferenceLcb = if (pooledAssetEval.trades >= MIN_ASSET_TRADES && pooledAssetEval.lcb.isFinite()) {
            pooledAssetEval.lcb
        } else {
            val pooledGlobalReturns = evalById[pooledBestPreset.id]?.oosPredictions
                ?.filter { it.first >= (evalById[pooledBestPreset.id]?.metrics?.threshold ?: 0.5) }
                ?.map { it.second.netReturnPct }
                .orEmpty()
            if (pooledGlobalReturns.isNotEmpty()) computeLcbExpectancy(pooledGlobalReturns) else 0.0
        }

        val beatsPooled = bestCandidate.preset.id == pooledBestPreset.id ||
            bestCandidate.lcb >= pooledReferenceLcb + MIN_PRESET_MARGIN

        if (!beatsPooled) {
            return AssetPresetChoice(
                symbol = symbol,
                selectedPreset = pooledBestPreset,
                lcbExpectancy = pooledReferenceLcb,
                trades = pooledAssetEval.trades,
                usedPooledFallback = true
            )
        }

        // Hysteresis: keep current preset if eligible and not beaten by MIN_PRESET_MARGIN
        if (previousPresetId != null && previousPresetId != bestCandidate.preset.id) {
            val prevScore = candidates.firstOrNull { it.preset.id == previousPresetId }
            if (prevScore != null && bestCandidate.lcb < prevScore.lcb + MIN_PRESET_MARGIN) {
                return AssetPresetChoice(
                    symbol = symbol,
                    selectedPreset = prevScore.preset,
                    lcbExpectancy = prevScore.lcb,
                    trades = prevScore.trades,
                    usedPooledFallback = (prevScore.preset.id == pooledBestPreset.id)
                )
            }
        }

        return AssetPresetChoice(
            symbol = symbol,
            selectedPreset = bestCandidate.preset,
            lcbExpectancy = bestCandidate.lcb,
            trades = bestCandidate.trades,
            usedPooledFallback = (bestCandidate.preset.id == pooledBestPreset.id && candidates.size == 1)
        )
    }
}
