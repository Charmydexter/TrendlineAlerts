package com.lrmlc.tradingalerts.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.lrmlc.tradingalerts.TradingAlertsApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }
        val pendingResult = goAsync()
        val app = context.applicationContext as TradingAlertsApp
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = app.container.settingsRepository.getSettings()
                if (settings.keepMonitoringInBackground && settings.startOnBoot) {
                    MonitoringForegroundService.start(context)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
