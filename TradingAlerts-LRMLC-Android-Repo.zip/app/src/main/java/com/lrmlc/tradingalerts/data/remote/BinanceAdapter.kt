package com.lrmlc.tradingalerts.data.remote

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.InstrumentInfo
import com.lrmlc.tradingalerts.data.model.MarketType
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull

class BinanceAdapter(
    private val restQueue: RestRateLimiterQueue,
    private val spotRestBaseUrl: String = "https://api.binance.com",
    private val perpRestBaseUrl: String = "https://fapi.binance.com",
    private val spotWsBaseUrl: String = "wss://stream.binance.com:9443",
    private val perpWsBaseUrl: String = "wss://fstream.binance.com"
) : ExchangeAdapter {

    override val exchangeId: ExchangeId = ExchangeId.BINANCE
    override val maxPageLimit: Int = 1000
    override val pingIntervalMs: Long = 180_000L // OkHttp also handles WebSocket ping frames

    private val json = Json { ignoreUnknownKeys = true }

    private fun restBase(marketType: MarketType): String =
        if (marketType == MarketType.PERP) perpRestBaseUrl else spotRestBaseUrl

    override suspend fun fetchServerTimeMs(marketType: MarketType): Pair<Long, Long> {
        val path = if (marketType == MarketType.PERP) "/fapi/v1/time" else "/api/v3/time"
        val resp = restQueue.get("${restBase(marketType)}$path")
        return try {
            val root = json.parseToJsonElement(resp.body).jsonObject
            val serverTime = root["serverTime"]?.jsonPrimitive?.longOrNull ?: System.currentTimeMillis()
            serverTime to resp.latencyMs
        } catch (e: Exception) {
            throw ExchangeApiException(NetworkErrorKind.MALFORMED_RESPONSE, message = "Malformed Binance time response")
        }
    }

    override suspend fun fetchUsdtInstruments(marketType: MarketType): Pair<List<InstrumentInfo>, Long> {
        val path = if (marketType == MarketType.PERP) "/fapi/v1/exchangeInfo" else "/api/v3/exchangeInfo"
        val resp = restQueue.get("${restBase(marketType)}$path")
        return parseExchangeInfo(resp.body, marketType) to resp.latencyMs
    }

    internal fun parseExchangeInfo(body: String, marketType: MarketType): List<InstrumentInfo> {
        return try {
            val root = json.parseToJsonElement(body).jsonObject
            val symbols = root["symbols"]?.jsonArray ?: return emptyList()
            val out = ArrayList<InstrumentInfo>(symbols.size)
            for (elem in symbols) {
                val obj = elem.jsonObject
                val status = obj["status"]?.jsonPrimitive?.contentOrNull ?: ""
                val quote = obj["quoteAsset"]?.jsonPrimitive?.contentOrNull ?: ""
                val base = obj["baseAsset"]?.jsonPrimitive?.contentOrNull ?: ""
                val sym = obj["symbol"]?.jsonPrimitive?.contentOrNull ?: ""
                val contractType = obj["contractType"]?.jsonPrimitive?.contentOrNull
                if (status != "TRADING" || quote != "USDT" || sym.isBlank() || base.isBlank()) continue
                if (marketType == MarketType.PERP && contractType != null && contractType != "PERPETUAL") continue

                var tickStr: String? = null
                val filters = obj["filters"]?.jsonArray
                if (filters != null) {
                    for (f in filters) {
                        val fObj = f.jsonObject
                        if (fObj["filterType"]?.jsonPrimitive?.contentOrNull == "PRICE_FILTER") {
                            tickStr = fObj["tickSize"]?.jsonPrimitive?.contentOrNull
                            break
                        }
                    }
                }
                val tick = tickStr?.toDoubleOrNull() ?: 0.0001
                out.add(
                    InstrumentInfo(
                        exchange = ExchangeId.BINANCE,
                        marketType = marketType,
                        symbol = sym,
                        baseAsset = base,
                        quoteAsset = quote,
                        pricePrecision = decimalPlacesFromTick(tickStr),
                        tickSize = tick
                    )
                )
            }
            out
        } catch (e: Exception) {
            throw ExchangeApiException(NetworkErrorKind.MALFORMED_RESPONSE, message = "Malformed Binance exchangeInfo response")
        }
    }

    override suspend fun fetchKlines1m(
        marketType: MarketType,
        symbol: String,
        limit: Int,
        endTimeMs: Long?,
        startTimeMs: Long?
    ): Pair<List<Candle>, Long> {
        val path = if (marketType == MarketType.PERP) "/fapi/v1/klines" else "/api/v3/klines"
        val clampedLimit = limit.coerceIn(1, maxPageLimit)
        val url = buildString {
            append("${restBase(marketType)}$path?symbol=$symbol&interval=1m&limit=$clampedLimit")
            if (endTimeMs != null) append("&endTime=$endTimeMs")
            if (startTimeMs != null) append("&startTime=$startTimeMs")
        }
        val resp = restQueue.get(url)
        return parseKlinesResponse(resp.body) to resp.latencyMs
    }

    internal fun parseKlinesResponse(body: String): List<Candle> {
        return try {
            val arr = json.parseToJsonElement(body).jsonArray
            val candles = ArrayList<Candle>(arr.size)
            for (rowElem in arr) {
                val row = rowElem.jsonArray
                if (row.size < 6) continue
                val t = row[0].jsonPrimitive.longOrNull
                    ?: row[0].jsonPrimitive.contentOrNull?.toLongOrNull() ?: continue
                val o = row[1].jsonPrimitive.contentOrNull?.toDoubleOrNull()
                    ?: row[1].jsonPrimitive.doubleOrNull ?: continue
                val h = row[2].jsonPrimitive.contentOrNull?.toDoubleOrNull()
                    ?: row[2].jsonPrimitive.doubleOrNull ?: continue
                val l = row[3].jsonPrimitive.contentOrNull?.toDoubleOrNull()
                    ?: row[3].jsonPrimitive.doubleOrNull ?: continue
                val c = row[4].jsonPrimitive.contentOrNull?.toDoubleOrNull()
                    ?: row[4].jsonPrimitive.doubleOrNull ?: continue
                val v = row[5].jsonPrimitive.contentOrNull?.toDoubleOrNull()
                    ?: row[5].jsonPrimitive.doubleOrNull ?: 0.0
                if (o.isFinite() && h.isFinite() && l.isFinite() && c.isFinite() && v.isFinite()) {
                    candles.add(Candle(t, o, h, l, c, v))
                }
            }
            candles.sortBy { it.openTimeMs }
            candles
        } catch (e: Exception) {
            throw ExchangeApiException(NetworkErrorKind.MALFORMED_RESPONSE, message = "Malformed Binance klines payload")
        }
    }

    override suspend fun fetchFuturesMetrics(marketType: MarketType, symbol: String, sinceMs: Long): FuturesMetricsBatch {
        if (marketType != MarketType.PERP) return FuturesMetricsBatch()
        val base = restBase(marketType)
        val nowMs = System.currentTimeMillis()
        val funding = ArrayList<Pair<Long, Double>>()
        val oi = ArrayList<Pair<Long, Double>>()
        try {
            val fResp = restQueue.get("$base/fapi/v1/fundingRate?symbol=$symbol&startTime=$sinceMs&limit=1000")
            json.parseToJsonElement(fResp.body).jsonArray.forEach { e ->
                val o = e.jsonObject
                val t = o["fundingTime"]?.jsonPrimitive?.longOrNull
                val r = o["fundingRate"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()
                if (t != null && r != null) funding.add(t to r)
            }
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
        }
        try {
            // Binance only serves ~30 days of open-interest history
            var start = maxOf(sinceMs, nowMs - 29L * 24L * 3600_000L)
            var page = 0
            while (start < nowMs && page < 4) {
                val resp = restQueue.get("$base/futures/data/openInterestHist?symbol=$symbol&period=1h&limit=500&startTime=$start")
                val arr = json.parseToJsonElement(resp.body).jsonArray
                if (arr.isEmpty()) break
                var newest = start
                arr.forEach { e ->
                    val o = e.jsonObject
                    val t = o["timestamp"]?.jsonPrimitive?.longOrNull
                    val v = o["sumOpenInterest"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()
                    if (t != null && v != null) {
                        oi.add(t to v)
                        if (t > newest) newest = t
                    }
                }
                if (newest <= start) break
                start = newest + 1L
                page++
            }
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
        }
        return FuturesMetricsBatch(funding, oi)
    }

    override suspend fun fetch24hTickers(marketType: MarketType): Map<String, Ticker24hInfo> {
        val path = if (marketType == MarketType.PERP) "/fapi/v1/ticker/24hr" else "/api/v3/ticker/24hr"
        val resp = restQueue.get("${restBase(marketType)}$path")
        return parseTickersResponse(resp.body)
    }

    internal fun parseTickersResponse(body: String): Map<String, Ticker24hInfo> {
        return try {
            val arr = json.parseToJsonElement(body).jsonArray
            val map = HashMap<String, Ticker24hInfo>(arr.size)
            for (elem in arr) {
                val obj = elem.jsonObject
                val sym = obj["symbol"]?.jsonPrimitive?.contentOrNull ?: continue
                val last = obj["lastPrice"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: continue
                val pct = obj["priceChangePercent"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: 0.0
                map[sym] = Ticker24hInfo(sym, last, pct)
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }

    override fun buildWebSocketUrl(marketType: MarketType, symbols: List<String>): String {
        val base = if (marketType == MarketType.PERP) perpWsBaseUrl else spotWsBaseUrl
        val streams = symbols.distinct().joinToString("/") { "${it.lowercase()}@kline_1m" }
        return if (streams.isNotBlank()) "$base/stream?streams=$streams" else "$base/ws"
    }

    override fun buildSubscribeMessages(marketType: MarketType, symbols: List<String>): List<String> {
        // Streams are subscribed directly via the combined stream URL, so no extra SUBSCRIBE frame is needed.
        return emptyList()
    }

    override fun buildPingMessage(): String? = null // Binance uses WebSocket ping/pong control frames

    override fun parseWebSocketMessage(text: String): List<WebSocketKlineUpdate> {
        return try {
            val root = json.parseToJsonElement(text).jsonObject
            // Combined stream format: {"stream":"solusdt@kline_1m","data":{...}}
            val payload = root["data"]?.jsonObject ?: root
            val eventType = payload["e"]?.jsonPrimitive?.contentOrNull
            if (eventType != "kline") return emptyList()
            val symbol = payload["s"]?.jsonPrimitive?.contentOrNull ?: return emptyList()
            val k = payload["k"]?.jsonObject ?: return emptyList()
            val t = k["t"]?.jsonPrimitive?.longOrNull
                ?: k["t"]?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: return emptyList()
            val o = k["o"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: return emptyList()
            val h = k["h"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: return emptyList()
            val l = k["l"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: return emptyList()
            val c = k["c"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: return emptyList()
            val v = k["v"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: 0.0
            val isClosed = k["x"]?.jsonPrimitive?.booleanOrNull ?: false
            if (!o.isFinite() || !h.isFinite() || !l.isFinite() || !c.isFinite()) return emptyList()
            listOf(
                WebSocketKlineUpdate(
                    symbol = symbol,
                    candle = Candle(t, o, h, l, c, v),
                    isClosed = isClosed
                )
            )
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun decimalPlacesFromTick(tickStr: String?): Int {
        if (tickStr == null || !tickStr.contains('.')) return 2
        val trimmed = tickStr.trimEnd('0')
        val idx = trimmed.indexOf('.')
        return if (idx < 0) 2 else (trimmed.length - idx - 1).coerceIn(1, 8)
    }
}
