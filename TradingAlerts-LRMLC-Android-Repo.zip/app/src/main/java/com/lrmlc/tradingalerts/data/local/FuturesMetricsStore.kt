package com.lrmlc.tradingalerts.data.local

import com.lrmlc.tradingalerts.ml.FuturesPoint
import java.io.File

/**
 * Small file-backed cache of funding-rate and hourly open-interest history for perpetual contracts
 * (the optional "futures" feature group). Re-downloadable data, so it is not part of backups.
 */
class FuturesMetricsStore(private val dir: File) {

    private class Series(
        val funding: java.util.TreeMap<Long, Double> = java.util.TreeMap(),
        val openInterest: java.util.TreeMap<Long, Double> = java.util.TreeMap()
    )

    private val cache = HashMap<String, Series>()
    private val lastSyncMs = HashMap<String, Long>()

    companion object {
        const val RETAIN_MS = 90L * 24L * 3600_000L
        const val HOUR_MS = 3600_000L
        const val MAX_OI_STALENESS_MS = 2L * HOUR_MS
        const val MAX_FUNDING_STALENESS_MS = 12L * HOUR_MS
    }

    private fun keyOf(exchange: String, symbol: String) = "${exchange}_$symbol"

    private fun fileOf(key: String) = File(dir, "futures_$key.txt")

    @Synchronized
    private fun load(key: String): Series {
        cache[key]?.let { return it }
        val series = Series()
        runCatching {
            val f = fileOf(key)
            if (f.exists()) {
                f.forEachLine { line ->
                    val parts = line.split(',')
                    if (parts.size == 3) {
                        val ts = parts[1].toLongOrNull()
                        val v = parts[2].toDoubleOrNull()
                        if (ts != null && v != null && v.isFinite()) {
                            when (parts[0]) {
                                "F" -> series.funding[ts] = v
                                "O" -> series.openInterest[ts] = v
                            }
                        }
                    }
                }
            }
        }
        cache[key] = series
        return series
    }

    @Synchronized
    fun merge(
        exchange: String,
        symbol: String,
        funding: List<Pair<Long, Double>>,
        openInterest: List<Pair<Long, Double>>,
        nowMs: Long = System.currentTimeMillis()
    ) {
        if (funding.isEmpty() && openInterest.isEmpty()) return
        val key = keyOf(exchange, symbol)
        val series = load(key)
        for ((t, v) in funding) if (v.isFinite()) series.funding[t] = v
        for ((t, v) in openInterest) if (v.isFinite() && v > 0.0) series.openInterest[t] = v
        val cutoff = nowMs - RETAIN_MS
        series.funding.headMap(cutoff).clear()
        series.openInterest.headMap(cutoff).clear()
        runCatching {
            dir.mkdirs()
            fileOf(key).bufferedWriter().use { w ->
                for ((t, v) in series.funding) w.appendLine("F,$t,$v")
                for ((t, v) in series.openInterest) w.appendLine("O,$t,$v")
            }
        }
    }

    @Synchronized
    fun hasData(exchange: String, symbol: String): Boolean {
        val s = load(keyOf(exchange, symbol))
        return s.funding.isNotEmpty() || s.openInterest.size >= 2
    }

    /** Newest stored open-interest timestamp (0 when none) - used to fetch only what is missing. */
    @Synchronized
    fun newestOiTimestamp(exchange: String, symbol: String): Long {
        val m = load(keyOf(exchange, symbol)).openInterest
        return if (m.isEmpty()) 0L else m.lastKey()
    }

    @Synchronized
    fun markSynced(exchange: String, symbol: String, nowMs: Long) {
        lastSyncMs[keyOf(exchange, symbol)] = nowMs
    }

    @Synchronized
    fun lastSyncedAt(exchange: String, symbol: String): Long = lastSyncMs[keyOf(exchange, symbol)] ?: 0L

    /**
     * Funding rate (latest at or before [tMs]) and open-interest change over the last hour, with no look-ahead.
     * Returns null when either is missing or stale, so the feature group stays neutral for that moment.
     */
    @Synchronized
    fun pointAt(exchange: String, symbol: String, tMs: Long): FuturesPoint? {
        val s = load(keyOf(exchange, symbol))
        val fund = s.funding.floorEntry(tMs) ?: return null
        if (tMs - fund.key > MAX_FUNDING_STALENESS_MS) return null
        val now = s.openInterest.floorEntry(tMs) ?: return null
        if (tMs - now.key > MAX_OI_STALENESS_MS) return null
        val prev = s.openInterest.floorEntry(now.key - HOUR_MS) ?: return null
        if (prev.value <= 0.0) return null
        return FuturesPoint(fund.value, (now.value - prev.value) / prev.value)
    }
}
