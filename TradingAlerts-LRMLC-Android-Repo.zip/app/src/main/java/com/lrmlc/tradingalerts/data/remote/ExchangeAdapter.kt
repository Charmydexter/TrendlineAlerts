package com.lrmlc.tradingalerts.data.remote

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.InstrumentInfo
import com.lrmlc.tradingalerts.data.model.MarketType

data class WebSocketKlineUpdate(
    val symbol: String,
    val candle: Candle,
    val isClosed: Boolean
)

data class Ticker24hInfo(
    val symbol: String,
    val lastPrice: Double,
    val change24hPct: Double
)

interface ExchangeAdapter {
    val exchangeId: ExchangeId
    val maxPageLimit: Int
    val pingIntervalMs: Long

    suspend fun fetchServerTimeMs(marketType: MarketType): Pair<Long, Long> // (serverTimeMs, latencyMs)
    suspend fun fetchUsdtInstruments(marketType: MarketType): Pair<List<InstrumentInfo>, Long>
    suspend fun fetchKlines1m(
        marketType: MarketType,
        symbol: String,
        limit: Int = maxPageLimit,
        endTimeMs: Long? = null,
        startTimeMs: Long? = null
    ): Pair<List<Candle>, Long>

    suspend fun fetch24hTickers(marketType: MarketType): Map<String, Ticker24hInfo>

    fun buildWebSocketUrl(marketType: MarketType, symbols: List<String>): String
    fun buildSubscribeMessages(marketType: MarketType, symbols: List<String>): List<String>
    fun buildPingMessage(): String?
    fun parseWebSocketMessage(text: String): List<WebSocketKlineUpdate>
}
