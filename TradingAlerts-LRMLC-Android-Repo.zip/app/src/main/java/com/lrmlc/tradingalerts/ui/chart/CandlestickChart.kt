package com.lrmlc.tradingalerts.ui.chart

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ChartStyle
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.service.PersistentNotificationFormatter
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class ChartSignalMarker(
    val barIndex: Int,
    val direction: TradeDirection,
    val accepted: Boolean
)

object HeikinAshiTransform {
    fun compute(candles: List<Candle>): List<Candle> {
        if (candles.isEmpty()) return emptyList()
        val out = ArrayList<Candle>(candles.size)
        var prevOpen = (candles[0].open + candles[0].close) / 2.0
        var prevClose = candles[0].ohlc4
        for (i in candles.indices) {
            val c = candles[i]
            val haClose = c.ohlc4
            val haOpen = if (i == 0) (c.open + c.close) / 2.0 else (prevOpen + prevClose) / 2.0
            val haHigh = max(c.high, max(haOpen, haClose))
            val haLow = min(c.low, min(haOpen, haClose))
            out.add(c.copy(open = haOpen, high = haHigh, low = haLow, close = haClose))
            prevOpen = haOpen
            prevClose = haClose
        }
        return out
    }
}

@Composable
fun CandlestickChart(
    candles: List<Candle>,
    snapshots: List<ConfluenceBarSnapshot>,
    visibleBarsDefault: Int,
    chartStyle: ChartStyle,
    signalMarkers: List<ChartSignalMarker>,
    activeSlPrice: Double?,
    activeTpPrice: Double?,
    activeEntryPrice: Double?,
    modifier: Modifier = Modifier
) {
    val displayCandles = remember(candles, chartStyle) {
        if (chartStyle == ChartStyle.HEIKIN_ASHI) HeikinAshiTransform.compute(candles) else candles
    }

    var visibleCount by remember(visibleBarsDefault) { mutableFloatStateOf(visibleBarsDefault.toFloat()) }
    var rightOffsetBars by remember(visibleBarsDefault) { mutableFloatStateOf(0f) }
    var crosshairIndex by remember { mutableStateOf<Int?>(null) }

    val total = displayCandles.size
    val clampedVisible = visibleCount.roundToInt().coerceIn(15, max(30, total))
    val maxOffset = max(0, total - clampedVisible).toFloat()
    val safeRightOffset = rightOffsetBars.coerceIn(0f, maxOffset).roundToInt()

    val endIdx = (total - safeRightOffset).coerceIn(0, total)
    val startIdx = max(0, endIdx - clampedVisible)

    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant

    Box(modifier = modifier) {
        if (displayCandles.isEmpty() || endIdx <= startIdx) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Waiting for 1-minute candles...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = labelColor
                )
            }
            return@Box
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(total) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val nextVisible = (visibleCount / zoom).coerceIn(15f, max(30f, total.toFloat()))
                        visibleCount = nextVisible
                        val pxPerBar = size.width / nextVisible.coerceAtLeast(1f)
                        val deltaBars = pan.x / pxPerBar.coerceAtLeast(1f)
                        rightOffsetBars = (rightOffsetBars + deltaBars).coerceIn(0f, max(0f, total - nextVisible))
                    }
                }
                .pointerInput(startIdx, endIdx) {
                    detectTapGestures(
                        onTap = { tap ->
                            val count = endIdx - startIdx
                            if (count > 0 && size.width > 0) {
                                val relIdx = ((tap.x / size.width) * count).toInt().coerceIn(0, count - 1)
                                val tapped = startIdx + relIdx
                                crosshairIndex = if (crosshairIndex == tapped) null else tapped
                            }
                        }
                    )
                }
        ) {
            val count = endIdx - startIdx
            val chartW = size.width
            val chartH = size.height
            val stepX = chartW / count.toFloat()
            val bodyW = (stepX * 0.64f).coerceIn(2f, 22f)

            var minPrice = Double.MAX_VALUE
            var maxPrice = -Double.MAX_VALUE
            for (i in startIdx until endIdx) {
                val c = displayCandles[i]
                if (c.low < minPrice) minPrice = c.low
                if (c.high > maxPrice) maxPrice = c.high
                val snap = snapshots.getOrNull(i)
                snap?.basis?.let {
                    if (it < minPrice) minPrice = it
                    if (it > maxPrice) maxPrice = it
                }
                snap?.resVal?.let {
                    if (it.isFinite() && it > 0) {
                        minPrice = min(minPrice, it)
                        maxPrice = max(maxPrice, it)
                    }
                }
                snap?.supVal?.let {
                    if (it.isFinite() && it > 0) {
                        minPrice = min(minPrice, it)
                        maxPrice = max(maxPrice, it)
                    }
                }
            }
            activeSlPrice?.let { minPrice = min(minPrice, it); maxPrice = max(maxPrice, it) }
            activeTpPrice?.let { minPrice = min(minPrice, it); maxPrice = max(maxPrice, it) }
            activeEntryPrice?.let { minPrice = min(minPrice, it); maxPrice = max(maxPrice, it) }

            val span = (maxPrice - minPrice).coerceAtLeast(maxPrice * 0.001).coerceAtLeast(1e-8)
            val pad = span * 0.08
            val yMin = minPrice - pad
            val yMax = maxPrice + pad
            val yRange = (yMax - yMin).coerceAtLeast(1e-9)

            fun priceToY(price: Double): Float {
                val norm = ((price - yMin) / yRange).toFloat()
                return chartH * (1f - norm)
            }

            // Subtle horizontal grid lines
            for (g in 1..4) {
                val gy = chartH * (g / 5f)
                drawLine(gridColor, Offset(0f, gy), Offset(chartW, gy), strokeWidth = 1f)
            }

            // Draw extended Resistance (fuchsia) & Support (lime) from latest snapshot
            val latestSnap = snapshots.lastOrNull()
            latestSnap?.resistance?.let { res ->
                val yStart = priceToY(res.extrapolateAt(startIdx))
                val yEnd = priceToY(res.extrapolateAt(endIdx - 1))
                drawLine(
                    color = LrmlcColors.ResistanceFuchsia,
                    start = Offset(0f, yStart),
                    end = Offset(chartW - stepX * 0.5f, yEnd),
                    strokeWidth = 3f
                )
            }
            latestSnap?.support?.let { sup ->
                val yStart = priceToY(sup.extrapolateAt(startIdx))
                val yEnd = priceToY(sup.extrapolateAt(endIdx - 1))
                drawLine(
                    color = LrmlcColors.SupportLime,
                    start = Offset(0f, yStart),
                    end = Offset(chartW - stepX * 0.5f, yEnd),
                    strokeWidth = 3f
                )
            }

            // Draw 240-bar OHLC4 SMA (basis) in Blue
            val basisPath = Path()
            var startedBasis = false
            for (i in startIdx until endIdx) {
                val b = snapshots.getOrNull(i)?.basis ?: continue
                val x = (i - startIdx + 0.5f) * stepX
                val y = priceToY(b)
                if (!startedBasis) {
                    basisPath.moveTo(x, y)
                    startedBasis = true
                } else {
                    basisPath.lineTo(x, y)
                }
            }
            if (startedBasis) {
                drawPath(basisPath, color = LrmlcColors.BasisBlue, style = Stroke(width = 3f))
            }

            // Draw Candles
            for (i in startIdx until endIdx) {
                val c = displayCandles[i]
                val xCenter = (i - startIdx + 0.5f) * stepX
                val isUp = c.close >= c.open
                val candleColor = if (isUp) LrmlcColors.LongGreen else LrmlcColors.ShortRed

                val highY = priceToY(c.high)
                val lowY = priceToY(c.low)
                drawLine(candleColor, Offset(xCenter, highY), Offset(xCenter, lowY), strokeWidth = 2f)

                val openY = priceToY(c.open)
                val closeY = priceToY(c.close)
                val topY = min(openY, closeY)
                val rectH = max(2f, kotlin.math.abs(closeY - openY))
                drawRect(
                    color = candleColor,
                    topLeft = Offset(xCenter - bodyW / 2f, topY),
                    size = Size(bodyW, rectH)
                )
            }

            // Draw SL / TP / Entry horizontal levels
            val dash = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
            activeTpPrice?.let { tp ->
                val y = priceToY(tp)
                drawLine(LrmlcColors.SupportLime, Offset(0f, y), Offset(chartW, y), strokeWidth = 2.5f, pathEffect = dash)
            }
            activeSlPrice?.let { sl ->
                val y = priceToY(sl)
                drawLine(LrmlcColors.ShortRed, Offset(0f, y), Offset(chartW, y), strokeWidth = 2.5f, pathEffect = dash)
            }
            activeEntryPrice?.let { entry ->
                val y = priceToY(entry)
                drawLine(Color.White.copy(alpha = 0.65f), Offset(0f, y), Offset(chartW, y), strokeWidth = 1.5f, pathEffect = dash)
            }

            // Draw Signal Arrows
            for (marker in signalMarkers) {
                if (marker.barIndex !in startIdx until endIdx) continue
                val c = displayCandles[marker.barIndex]
                val x = (marker.barIndex - startIdx + 0.5f) * stepX
                val alpha = if (marker.accepted) 1f else 0.45f
                if (marker.direction == TradeDirection.LONG) {
                    val yBase = priceToY(c.low) + 14f
                    val tri = Path().apply {
                        moveTo(x, yBase - 10f)
                        lineTo(x - 7f, yBase + 4f)
                        lineTo(x + 7f, yBase + 4f)
                        close()
                    }
                    drawPath(tri, LrmlcColors.LongGreen.copy(alpha = alpha))
                } else {
                    val yBase = priceToY(c.high) - 14f
                    val tri = Path().apply {
                        moveTo(x, yBase + 10f)
                        lineTo(x - 7f, yBase - 4f)
                        lineTo(x + 7f, yBase - 4f)
                        close()
                    }
                    drawPath(tri, LrmlcColors.ShortRed.copy(alpha = alpha))
                }
            }

            // Crosshair
            crosshairIndex?.takeIf { it in startIdx until endIdx }?.let { idx ->
                val x = (idx - startIdx + 0.5f) * stepX
                val y = priceToY(displayCandles[idx].close)
                drawLine(Color.White.copy(alpha = 0.5f), Offset(x, 0f), Offset(x, chartH), strokeWidth = 1.5f)
                drawLine(Color.White.copy(alpha = 0.5f), Offset(0f, y), Offset(chartW, y), strokeWidth = 1.5f)
                drawCircle(Color.White, radius = 5f, center = Offset(x, y))
            }
        }

        // Crosshair HUD readout
        crosshairIndex?.takeIf { it in candles.indices }?.let { idx ->
            val raw = candles[idx]
            val timeStr = remember(raw.openTimeMs) {
                Instant.ofEpochMilli(raw.openTimeMs)
                    .atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("MM-dd HH:mm"))
            }
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.88f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "$timeStr · O ${PersistentNotificationFormatter.formatPrice(raw.open)} H ${PersistentNotificationFormatter.formatPrice(raw.high)} L ${PersistentNotificationFormatter.formatPrice(raw.low)} C ${PersistentNotificationFormatter.formatPrice(raw.close)}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
