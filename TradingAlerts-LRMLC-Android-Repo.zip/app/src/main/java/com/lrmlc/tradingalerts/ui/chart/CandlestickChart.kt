package com.lrmlc.tradingalerts.ui.chart

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.ChartStyle
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.service.PersistentNotificationFormatter
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import com.lrmlc.tradingalerts.ui.theme.LrmlcShapes
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class ChartSignalMarker(
    val barIndex: Int,
    val direction: TradeDirection,
    val accepted: Boolean
)

object HeikinAshiTransform {
    fun compute(candles: List<Candle>): List<Candle> {
        if (candles.isEmpty()) return emptyList()
        val out = ArrayList<Candle>(candles.size)
        var prevOpen = (candles[0].open + candles[0].close) / 2.0
        var prevClose = candles[0].ohlc4
        for (i in candles.indices) {
            val c = candles[i]
            val haClose = c.ohlc4
            val haOpen = if (i == 0) (c.open + c.close) / 2.0 else (prevOpen + prevClose) / 2.0
            val haHigh = max(c.high, max(haOpen, haClose))
            val haLow = min(c.low, min(haOpen, haClose))
            out.add(c.copy(open = haOpen, high = haHigh, low = haLow, close = haClose))
            prevOpen = haOpen
            prevClose = haClose
        }
        return out
    }
}

@Composable
fun CandlestickChart(
    candles: List<Candle>,
    snapshots: List<ConfluenceBarSnapshot>,
    visibleBarsDefault: Int,
    chartStyle: ChartStyle,
    signalMarkers: List<ChartSignalMarker>,
    activeSlPrice: Double?,
    activeTpPrice: Double?,
    activeEntryPrice: Double?,
    modifier: Modifier = Modifier,
    levelsFaded: Boolean = false,
    exitMarkerBarIndex: Int? = null,
    exitMarkerPrice: Double? = null
) {
    val displayCandles = remember(candles, chartStyle) {
        if (chartStyle == ChartStyle.HEIKIN_ASHI) HeikinAshiTransform.compute(candles) else candles
    }

    var visibleCount by remember(visibleBarsDefault) { mutableFloatStateOf(visibleBarsDefault.toFloat()) }
    var rightOffsetBars by remember(visibleBarsDefault) { mutableFloatStateOf(0f) }
    var crosshairIndex by remember { mutableStateOf<Int?>(null) }

    val total = displayCandles.size
    val clampedVisible = visibleCount.roundToInt().coerceIn(15, max(30, total))
    val maxOffset = max(0, total - clampedVisible).toFloat()
    val safeRightOffset = rightOffsetBars.coerceIn(0f, maxOffset).roundToInt()

    val endIdx = (total - safeRightOffset).coerceIn(0, total)
    val startIdx = max(0, endIdx - clampedVisible)

    val panelBg = MaterialTheme.colorScheme.background.copy(alpha = 0.72f)
    val borderColor = MaterialTheme.colorScheme.outline
    val gridColor = borderColor.copy(alpha = 0.35f)
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant
    val accentColor = MaterialTheme.colorScheme.primary
    val textMeasurer = rememberTextMeasurer()
    val axisTextStyle = TextStyle(
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace,
        color = labelColor
    )
    val pillTextStyle = TextStyle(
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        color = Color.White
    )
    val levelTagStyle = TextStyle(
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
        color = Color.White
    )

    Box(
        modifier = modifier
            .clip(LrmlcShapes.PanelShape)
            .background(panelBg)
            .border(1.dp, borderColor, LrmlcShapes.PanelShape)
    ) {
        if (displayCandles.isEmpty() || endIdx <= startIdx) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Waiting for 1-minute candles...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = labelColor
                )
            }
            return@Box
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .semantics { contentDescription = "1-minute candlestick chart with resistance, support, volume, and trade levels" }
                .pointerInput(total) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val nextVisible = (visibleCount / zoom).coerceIn(15f, max(30f, total.toFloat()))
                        visibleCount = nextVisible
                        val priceAxisPx = 56.dp.toPx()
                        val plotW = (size.width - priceAxisPx).coerceAtLeast(1f)
                        val pxPerBar = ChartAxis.plotStepX(plotW, nextVisible.roundToInt()).coerceAtLeast(1f)
                        val deltaBars = pan.x / pxPerBar
                        // Do not allow panning newest candle past the 7-slot right gap
                        rightOffsetBars = (rightOffsetBars + deltaBars).coerceIn(0f, max(0f, total - nextVisible))
                    }
                }
                .pointerInput(startIdx, endIdx) {
                    fun updateCrosshairAt(x: Float) {
                        val priceAxisPx = 56.dp.toPx()
                        val plotW = (size.width - priceAxisPx).coerceAtLeast(1f)
                        val count = endIdx - startIdx
                        val stepX = ChartAxis.plotStepX(plotW, count)
                        if (count > 0 && stepX > 0f) {
                            val tapped = ChartAxis.xToBarIndex(x, startIdx, endIdx, stepX)
                            crosshairIndex = if (crosshairIndex == tapped) null else tapped
                        }
                    }
                    detectTapGestures(
                        onTap = { tap -> updateCrosshairAt(tap.x) },
                        onLongPress = { pos ->
                            val priceAxisPx = 56.dp.toPx()
                            val plotW = (size.width - priceAxisPx).coerceAtLeast(1f)
                            val count = endIdx - startIdx
                            val stepX = ChartAxis.plotStepX(plotW, count)
                            if (count > 0 && stepX > 0f) {
                                crosshairIndex = ChartAxis.xToBarIndex(pos.x, startIdx, endIdx, stepX)
                            }
                        }
                    )
                }
        ) {
            val priceAxisW = 56.dp.toPx()
            val timeAxisH = 20.dp.toPx()
            val plotW = (size.width - priceAxisW).coerceAtLeast(40f)
            val plotH = (size.height - timeAxisH).coerceAtLeast(40f)

            val count = endIdx - startIdx
            val stepX = ChartAxis.plotStepX(plotW, count)
            val bodyW = (stepX * 0.64f).coerceIn(2f, 20f)

            var minPrice = Double.MAX_VALUE
            var maxPrice = -Double.MAX_VALUE
            var maxVolume = 0.0
            for (i in startIdx until endIdx) {
                val c = displayCandles[i]
                if (c.low < minPrice) minPrice = c.low
                if (c.high > maxPrice) maxPrice = c.high
                if (c.volume > maxVolume) maxVolume = c.volume
                val snap = snapshots.getOrNull(i)
                snap?.basis?.let {
                    minPrice = min(minPrice, it)
                    maxPrice = max(maxPrice, it)
                }
                snap?.resVal?.takeIf { it.isFinite() && it > 0.0 }?.let {
                    minPrice = min(minPrice, it)
                    maxPrice = max(maxPrice, it)
                }
                snap?.supVal?.takeIf { it.isFinite() && it > 0.0 }?.let {
                    minPrice = min(minPrice, it)
                    maxPrice = max(maxPrice, it)
                }
            }
            activeSlPrice?.let { minPrice = min(minPrice, it); maxPrice = max(maxPrice, it) }
            activeTpPrice?.let { minPrice = min(minPrice, it); maxPrice = max(maxPrice, it) }
            activeEntryPrice?.let { minPrice = min(minPrice, it); maxPrice = max(maxPrice, it) }
            exitMarkerPrice?.let { minPrice = min(minPrice, it); maxPrice = max(maxPrice, it) }

            val span = (maxPrice - minPrice).coerceAtLeast(maxPrice * 0.001).coerceAtLeast(1e-8)
            val pad = span * 0.09
            val yMin = minPrice - pad
            val yMax = maxPrice + pad
            val yRange = (yMax - yMin).coerceAtLeast(1e-9)

            fun priceToY(price: Double): Float {
                val norm = ((price - yMin) / yRange).toFloat()
                return plotH * (1f - norm)
            }

            // 1. Horizontal nice ticks + grid lines
            val priceTicks = ChartAxis.computeNiceTicks(yMin, yMax, desiredCount = 5)
            for (tick in priceTicks) {
                val gy = priceToY(tick)
                if (gy in 4f..(plotH - 4f)) {
                    drawLine(gridColor, Offset(0f, gy), Offset(plotW, gy), strokeWidth = 1f)
                    val label = ChartAxis.formatAxisPrice(tick)
                    val measured = textMeasurer.measure(label, axisTextStyle)
                    drawText(
                        textLayoutResult = measured,
                        topLeft = Offset(
                            x = plotW + 4.dp.toPx(),
                            y = (gy - measured.size.height / 2f).coerceIn(0f, plotH - measured.size.height)
                        )
                    )
                }
            }

            // 2. Vertical time ticks + grid lines (4-5 labels)
            val labelSlots = min(5, max(2, count / 10))
            val zoneId = ZoneId.systemDefault()
            var lastDay = -1
            for (s in 0 until labelSlots) {
                val relIdx = if (labelSlots == 1) 0 else ((s * (count - 1)) / (labelSlots - 1)).coerceIn(0, count - 1)
                val barIdx = startIdx + relIdx
                val x = ChartAxis.indexToCenterX(relIdx, stepX)
                drawLine(gridColor, Offset(x, 0f), Offset(x, plotH), strokeWidth = 1f)
                val ts = displayCandles[barIdx].openTimeMs
                val day = Instant.ofEpochMilli(ts).atZone(zoneId).dayOfYear
                val showDate = lastDay != -1 && day != lastDay
                lastDay = day
                val tStr = ChartAxis.formatAxisTime(ts, showDate, zoneId)
                val measured = textMeasurer.measure(tStr, axisTextStyle)
                drawText(
                    textLayoutResult = measured,
                    topLeft = Offset(
                        x = (x - measured.size.width / 2f).coerceIn(2f, plotW - measured.size.width),
                        y = plotH + 3.dp.toPx()
                    )
                )
            }

            // Axis separator borders
            drawLine(borderColor, Offset(plotW, 0f), Offset(plotW, plotH), strokeWidth = 1f)
            drawLine(borderColor, Offset(0f, plotH), Offset(plotW, plotH), strokeWidth = 1f)

            // Plot-clipped content (candles, volume, trendlines, levels, markers)
            clipRect(left = 0f, top = 0f, right = plotW, bottom = plotH) {
                // 3. Volume bars along bottom 18%
                if (maxVolume > 0.0) {
                    val volMaxH = plotH * 0.18f
                    for (i in startIdx until endIdx) {
                        val c = displayCandles[i]
                        if (c.volume <= 0.0) continue
                        val xCenter = ChartAxis.indexToCenterX(i - startIdx, stepX)
                        val barH = ((c.volume / maxVolume).toFloat().coerceIn(0f, 1f)) * volMaxH
                        val isUp = c.close >= c.open
                        val volColor = (if (isUp) LrmlcColors.LongGreen else LrmlcColors.ShortRed).copy(alpha = 0.25f)
                        drawRect(
                            color = volColor,
                            topLeft = Offset(xCenter - bodyW / 2f, plotH - barH),
                            size = Size(bodyW, barH)
                        )
                    }
                }

                // 4. Resistance & Support trendlines extended through the 7-bar gap to plotW
                val latestSnap = snapshots.lastOrNull()
                val rightBarEquiv = (endIdx - 1) + ChartAxis.RIGHT_GAP_SLOTS.toDouble()
                latestSnap?.resistance?.let { res ->
                    val yStart = priceToY(res.extrapolateAt(startIdx))
                    val yEdge = priceToY(res.y2 + res.slopePerBar * (rightBarEquiv - res.x2))
                    drawLine(LrmlcColors.ResistanceFuchsia, Offset(0f, yStart), Offset(plotW, yEdge), strokeWidth = 2f)
                }
                latestSnap?.support?.let { sup ->
                    val yStart = priceToY(sup.extrapolateAt(startIdx))
                    val yEdge = priceToY(sup.y2 + sup.slopePerBar * (rightBarEquiv - sup.x2))
                    drawLine(LrmlcColors.SupportLime, Offset(0f, yStart), Offset(plotW, yEdge), strokeWidth = 2f)
                }

                // 5. Basis line (rolling average), extended softly through gap if latest value available
                val basisPath = Path()
                var startedBasis = false
                var lastBasisX = 0f
                var lastBasisY = 0f
                for (i in startIdx until endIdx) {
                    val b = snapshots.getOrNull(i)?.basis ?: continue
                    val x = ChartAxis.indexToCenterX(i - startIdx, stepX)
                    val y = priceToY(b)
                    if (!startedBasis) {
                        basisPath.moveTo(x, y)
                        startedBasis = true
                    } else {
                        basisPath.lineTo(x, y)
                    }
                    lastBasisX = x
                    lastBasisY = y
                }
                if (startedBasis) {
                    if (lastBasisX < plotW) {
                        basisPath.lineTo(plotW, lastBasisY)
                    }
                    drawPath(basisPath, color = LrmlcColors.BasisBlue, style = Stroke(width = 2f))
                }

                // 6. Candles (never drawn in the 7-slot gap)
                for (i in startIdx until endIdx) {
                    val c = displayCandles[i]
                    val xCenter = ChartAxis.indexToCenterX(i - startIdx, stepX)
                    val isUp = c.close >= c.open
                    val candleColor = if (isUp) LrmlcColors.LongGreen else LrmlcColors.ShortRed

                    val highY = priceToY(c.high)
                    val lowY = priceToY(c.low)
                    drawLine(candleColor, Offset(xCenter, highY), Offset(xCenter, lowY), strokeWidth = 1.5f)

                    val openY = priceToY(c.open)
                    val closeY = priceToY(c.close)
                    val topY = min(openY, closeY)
                    val rectH = max(2f, abs(closeY - openY))
                    drawRoundRect(
                        color = candleColor,
                        topLeft = Offset(xCenter - bodyW / 2f, topY),
                        size = Size(bodyW, rectH),
                        cornerRadius = CornerRadius(1.5f, 1.5f)
                    )
                }

                // 7. SL / TP / Entry lines extended across plotW (faded when closed [U13])
                val levelAlpha = if (levelsFaded) 0.45f else 0.95f
                val dash = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                activeTpPrice?.let { tp ->
                    val y = priceToY(tp)
                    drawLine(LrmlcColors.LongGreen.copy(alpha = levelAlpha), Offset(0f, y), Offset(plotW, y), strokeWidth = 2f, pathEffect = dash)
                }
                activeSlPrice?.let { sl ->
                    val y = priceToY(sl)
                    drawLine(LrmlcColors.ShortRed.copy(alpha = levelAlpha), Offset(0f, y), Offset(plotW, y), strokeWidth = 2f, pathEffect = dash)
                }
                activeEntryPrice?.let { entry ->
                    val y = priceToY(entry)
                    drawLine(accentColor.copy(alpha = levelAlpha), Offset(0f, y), Offset(plotW, y), strokeWidth = 1.75f, pathEffect = dash)
                }

                // 8. Last-price dashed horizontal line
                val newest = displayCandles[endIdx - 1]
                val lastCloseY = priceToY(newest.close)
                val lastDirColor = if (newest.close >= newest.open) LrmlcColors.LongGreen else LrmlcColors.ShortRed
                drawLine(
                    color = lastDirColor.copy(alpha = 0.7f),
                    start = Offset(0f, lastCloseY),
                    end = Offset(plotW, lastCloseY),
                    strokeWidth = 1.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                )

                // 9. Signal Arrows & Exit Marker
                for (marker in signalMarkers) {
                    if (marker.barIndex !in startIdx until endIdx) continue
                    val c = displayCandles[marker.barIndex]
                    val x = ChartAxis.indexToCenterX(marker.barIndex - startIdx, stepX)
                    val alpha = if (marker.accepted) 1f else 0.45f
                    if (marker.direction == TradeDirection.LONG) {
                        val yBase = priceToY(c.low) + 14f
                        val tri = Path().apply {
                            moveTo(x, yBase - 10f)
                            lineTo(x - 7f, yBase + 4f)
                            lineTo(x + 7f, yBase + 4f)
                            close()
                        }
                        drawPath(tri, LrmlcColors.LongGreen.copy(alpha = alpha))
                    } else {
                        val yBase = priceToY(c.high) - 14f
                        val tri = Path().apply {
                            moveTo(x, yBase + 10f)
                            lineTo(x - 7f, yBase - 4f)
                            lineTo(x + 7f, yBase - 4f)
                            close()
                        }
                        drawPath(tri, LrmlcColors.ShortRed.copy(alpha = alpha))
                    }
                }
                if (exitMarkerBarIndex != null && exitMarkerPrice != null && exitMarkerBarIndex in startIdx until endIdx) {
                    val exX = ChartAxis.indexToCenterX(exitMarkerBarIndex - startIdx, stepX)
                    val exY = priceToY(exitMarkerPrice)
                    drawCircle(color = accentColor, radius = 6f, center = Offset(exX, exY))
                    drawLine(Color.White, Offset(exX - 3.5f, exY - 3.5f), Offset(exX + 3.5f, exY + 3.5f), strokeWidth = 1.5f)
                    drawLine(Color.White, Offset(exX - 3.5f, exY + 3.5f), Offset(exX + 3.5f, exY - 3.5f), strokeWidth = 1.5f)
                }

                // 10. Crosshair lines inside plot
                crosshairIndex?.takeIf { it in startIdx until endIdx }?.let { idx ->
                    val x = ChartAxis.indexToCenterX(idx - startIdx, stepX)
                    val y = priceToY(displayCandles[idx].close)
                    drawLine(accentColor.copy(alpha = 0.65f), Offset(x, 0f), Offset(x, plotH), strokeWidth = 1.5f)
                    drawLine(accentColor.copy(alpha = 0.65f), Offset(0f, y), Offset(plotW, y), strokeWidth = 1.5f)
                    drawCircle(accentColor, radius = 5f, center = Offset(x, y))
                }
            }

            // Small level tag pills on right side of plot (R, S, TP, SL, Entry)
            val rightEdgeEq = (endIdx - 1) + ChartAxis.RIGHT_GAP_SLOTS.toDouble()
            val latestSnapForTags = snapshots.lastOrNull()
            fun drawSideTag(tag: String, price: Double, color: Color) {
                val py = priceToY(price)
                if (py !in 8f..(plotH - 8f)) return
                val lay = textMeasurer.measure(tag, levelTagStyle)
                val w = lay.size.width + 8f
                val h = lay.size.height + 4f
                val left = (plotW - w - 3f).coerceAtLeast(0f)
                val top = (py - h / 2f).coerceIn(0f, plotH - h)
                drawRoundRect(color.copy(alpha = 0.9f), Offset(left, top), Size(w, h), CornerRadius(4f, 4f))
                drawText(lay, topLeft = Offset(left + 4f, top + 2f))
            }
            latestSnapForTags?.resistance?.let { r ->
                drawSideTag("R", r.y2 + r.slopePerBar * (rightEdgeEq - r.x2), LrmlcColors.ResistanceFuchsia)
            }
            latestSnapForTags?.support?.let { s ->
                drawSideTag("S", s.y2 + s.slopePerBar * (rightEdgeEq - s.x2), LrmlcColors.SupportLime)
            }
            activeTpPrice?.let { drawSideTag("TP", it, LrmlcColors.LongGreen.copy(alpha = if (levelsFaded) 0.55f else 1f)) }
            activeSlPrice?.let { drawSideTag("SL", it, LrmlcColors.ShortRed.copy(alpha = if (levelsFaded) 0.55f else 1f)) }
            activeEntryPrice?.let { drawSideTag("Entry", it, accentColor.copy(alpha = if (levelsFaded) 0.55f else 1f)) }

            // Last-price filled pill on right price axis
            val newestCandle = displayCandles[endIdx - 1]
            val lastY = priceToY(newestCandle.close)
            val lastColor = if (newestCandle.close >= newestCandle.open) LrmlcColors.LongGreen else LrmlcColors.ShortRed
            val lastLabel = ChartAxis.formatAxisPrice(newestCandle.close)
            val lastMeasured = textMeasurer.measure(lastLabel, pillTextStyle)
            val pillW = (priceAxisW - 4.dp.toPx()).coerceAtLeast(lastMeasured.size.width + 6f)
            val pillH = lastMeasured.size.height + 6f
            val lastTop = (lastY - pillH / 2f).coerceIn(0f, plotH - pillH)
            drawRoundRect(lastColor, Offset(plotW + 2.dp.toPx(), lastTop), Size(pillW, pillH), CornerRadius(4f, 4f))
            drawText(lastMeasured, topLeft = Offset(plotW + 5.dp.toPx(), lastTop + 3f))

            // Crosshair axis pills (price on price axis, time on time axis)
            crosshairIndex?.takeIf { it in startIdx until endIdx }?.let { idx ->
                val c = displayCandles[idx]
                val cx = ChartAxis.indexToCenterX(idx - startIdx, stepX)
                val cy = priceToY(c.close)

                val pStr = ChartAxis.formatAxisPrice(c.close)
                val pLay = textMeasurer.measure(pStr, pillTextStyle)
                val pH = pLay.size.height + 6f
                val pTop = (cy - pH / 2f).coerceIn(0f, plotH - pH)
                drawRoundRect(accentColor, Offset(plotW + 2.dp.toPx(), pTop), Size(pillW, pH), CornerRadius(4f, 4f))
                drawText(pLay, topLeft = Offset(plotW + 5.dp.toPx(), pTop + 3f))

                val tStr = ChartAxis.formatAxisTime(c.openTimeMs, showDate = false, zoneId = zoneId)
                val tLay = textMeasurer.measure(tStr, pillTextStyle)
                val tW = tLay.size.width + 10f
                val tH = timeAxisH - 2f
                val tLeft = (cx - tW / 2f).coerceIn(0f, plotW - tW)
                drawRoundRect(accentColor, Offset(tLeft, plotH + 1f), Size(tW, tH), CornerRadius(4f, 4f))
                drawText(tLay, topLeft = Offset(tLeft + 5f, plotH + 3f))
            }
        }

        // Crosshair OHLCV HUD overlay
        crosshairIndex?.takeIf { it in candles.indices }?.let { idx ->
            val raw = candles[idx]
            val timeStr = remember(raw.openTimeMs) {
                Instant.ofEpochMilli(raw.openTimeMs)
                    .atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("MM-dd HH:mm"))
            }
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.90f), RoundedCornerShape(8.dp))
                    .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "$timeStr · O ${PersistentNotificationFormatter.formatPrice(raw.open)} H ${PersistentNotificationFormatter.formatPrice(raw.high)} L ${PersistentNotificationFormatter.formatPrice(raw.low)} C ${PersistentNotificationFormatter.formatPrice(raw.close)}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
