package com.lrmlc.tradingalerts.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.lrmlc.tradingalerts.TradingAlertsApp
import com.lrmlc.tradingalerts.data.local.GapDetector
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.remote.WebSocketFeedEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MonitoringForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var monitorJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopMonitoringAndSelf()
            return START_NOT_STICKY
        }

        val container = (applicationContext as TradingAlertsApp).container
        serviceScope.launch {
            val settings = container.settingsRepository.getSettings()
            val notif = container.notificationHelper.buildPersistentNotification(
                settings.exchange,
                settings.marketType,
                monitoringOn = true
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NotificationHelper.PERSISTENT_NOTIFICATION_ID,
                    notif,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NotificationHelper.PERSISTENT_NOTIFICATION_ID, notif)
            }
            _isServiceRunning.value = true
            startFeedLoop()
        }

        return START_STICKY
    }

    private fun startFeedLoop() {
        if (monitorJob?.isActive == true) return
        val container = (applicationContext as TradingAlertsApp).container

        monitorJob = serviceScope.launch {
            // Observe watchlist + settings changes to keep WS subscribed cleanly
            launch {
                container.settingsRepository.settingsFlow.collectLatest { settings ->
                    val watchlist = container.watchlistRepository.getWatchlist(settings.exchange, settings.marketType)
                    val symbols = watchlist.map { it.symbol }
                    val adapter = container.adapterFor(settings.exchange)

                    // Trim retention automatically
                    container.candleStore.trimOlderThanRetention(settings.retentionDays)

                    // Fill gaps before live WebSocket processing
                    container.historySyncManager.fillGapsForWatchlist(adapter, settings.marketType, symbols, lookbackDays = 3)
                    container.notificationHelper.refreshPersistentNotification(
                        settings.exchange,
                        settings.marketType,
                        monitoringOn = true
                    )

                    container.webSocketFeedClient.start(adapter, settings.marketType, symbols)
                }
            }

            // Collect WebSocket events
            container.webSocketFeedClient.events.collect { event ->
                val settings = container.settingsRepository.getSettings()
                val adapter = container.adapterFor(settings.exchange)
                when (event) {
                    is WebSocketFeedEvent.ReconnectedAfterDrop -> {
                        val symbols = container.watchlistRepository
                            .getWatchlist(settings.exchange, settings.marketType)
                            .map { it.symbol }
                        container.historySyncManager.fillGapsForWatchlist(
                            adapter = adapter,
                            marketType = settings.marketType,
                            symbols = symbols,
                            lookbackDays = 2
                        )
                    }

                    is WebSocketFeedEvent.CandleUpdate -> {
                        val u = event.update
                        // Emit forming candle for open chart UI
                        container.liveFormingCandles.emitForming(u.symbol, u.candle)

                        if (u.isClosed) {
                            val alignedTime = GapDetector.floorToMinute(u.candle.openTimeMs)
                            val closedCandle = u.candle.copy(openTimeMs = alignedTime)
                            container.candleStore.appendCandles(
                                settings.exchange,
                                settings.marketType,
                                u.symbol,
                                listOf(closedCandle)
                            )
                            container.tradeLifecycleManager.processClosedCandle(
                                exchange = settings.exchange,
                                marketType = settings.marketType,
                                symbol = u.symbol,
                                closedCandle = closedCandle
                            )
                        }
                    }

                    else -> Unit
                }
            }
        }
    }

    private fun stopMonitoringAndSelf() {
        val container = (applicationContext as TradingAlertsApp).container
        container.webSocketFeedClient.stop()
        _isServiceRunning.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        val container = (applicationContext as TradingAlertsApp).container
        container.webSocketFeedClient.stop()
        _isServiceRunning.value = false
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.lrmlc.tradingalerts.ACTION_START_MONITORING"
        const val ACTION_STOP = "com.lrmlc.tradingalerts.ACTION_STOP_MONITORING"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_START
            }
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}

class LiveFormingCandleHub {
    private val _formingBySymbol = MutableStateFlow<Map<String, Candle>>(emptyMap())
    val formingBySymbol: StateFlow<Map<String, Candle>> = _formingBySymbol.asStateFlow()

    fun emitForming(symbol: String, candle: Candle) {
        val next = _formingBySymbol.value.toMutableMap()
        next[symbol] = candle
        _formingBySymbol.value = next
    }
}
