package com.lrmlc.tradingalerts.data.remote

import com.lrmlc.tradingalerts.data.model.MarketType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener

data class ConnectionTestStep(
    val name: String,
    val passed: Boolean,
    val latencyMs: Long?,
    val detail: String
)

data class ConnectionTestReport(
    val steps: List<ConnectionTestStep>,
    val allPassed: Boolean
)

class ConnectionTester(
    private val okHttpClient: OkHttpClient,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val wsTimeoutMs: Long = 15_000L
) {
    suspend fun runTest(
        adapter: ExchangeAdapter,
        marketType: MarketType,
        testSymbol: String = "BTCUSDT"
    ): ConnectionTestReport = withContext(ioDispatcher) {
        val steps = ArrayList<ConnectionTestStep>(4)

        // 1. Server time / ping
        try {
            val (_, latency) = adapter.fetchServerTimeMs(marketType)
            steps.add(ConnectionTestStep("Server time / ping", true, latency, "Reachable (${latency} ms)"))
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            steps.add(ConnectionTestStep("Server time / ping", false, null, formatErrorDetail(e)))
        }

        // 2. Single 1m kline request
        try {
            val (candles, latency) = adapter.fetchKlines1m(marketType, testSymbol, limit = 2)
            if (candles.isNotEmpty()) {
                steps.add(ConnectionTestStep("1m Kline request ($testSymbol)", true, latency, "Received ${candles.size} candles"))
            } else {
                steps.add(ConnectionTestStep("1m Kline request ($testSymbol)", false, latency, "Empty candle response (invalid symbol?)"))
            }
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            steps.add(ConnectionTestStep("1m Kline request ($testSymbol)", false, null, formatErrorDetail(e)))
        }

        // 3. Instrument list reachability
        try {
            val (instruments, latency) = adapter.fetchUsdtInstruments(marketType)
            if (instruments.isNotEmpty()) {
                steps.add(ConnectionTestStep("Instrument list", true, latency, "${instruments.size} active USDT pairs"))
            } else {
                steps.add(ConnectionTestStep("Instrument list", false, latency, "No USDT pairs returned"))
            }
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            steps.add(ConnectionTestStep("Instrument list", false, null, formatErrorDetail(e)))
        }

        // 4. Short WebSocket handshake
        val wsStep = testWebSocketHandshake(adapter, marketType, testSymbol)
        steps.add(wsStep)

        ConnectionTestReport(
            steps = steps,
            allPassed = steps.all { it.passed }
        )
    }

    private suspend fun testWebSocketHandshake(
        adapter: ExchangeAdapter,
        marketType: MarketType,
        symbol: String
    ): ConnectionTestStep {
        val url = adapter.buildWebSocketUrl(marketType, listOf(symbol))
        val deferred = CompletableDeferred<ConnectionTestStep>()
        val startNs = System.nanoTime()

        val req = Request.Builder().url(url).build()
        val ws = okHttpClient.newWebSocket(
            req,
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    val latency = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                    adapter.buildSubscribeMessages(marketType, listOf(symbol)).forEach {
                        webSocket.send(it)
                    }
                    deferred.complete(
                        ConnectionTestStep(
                            name = "WebSocket handshake",
                            passed = true,
                            latencyMs = latency,
                            detail = "Connected (${latency} ms)"
                        )
                    )
                    webSocket.close(1000, "Connection test complete")
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    val code = response?.code
                    val reason = when {
                        code == 451 || code == 403 -> "Blocked by region or firewall (HTTP $code)"
                        code == 429 || code == 418 -> "Rate limited (HTTP $code)"
                        else -> formatErrorDetail(t, "WebSocket connection failed")
                    }
                    deferred.complete(
                        ConnectionTestStep(
                            name = "WebSocket handshake",
                            passed = false,
                            latencyMs = null,
                            detail = reason
                        )
                    )
                }
            }
        )

        val result = withTimeoutOrNull(wsTimeoutMs) { deferred.await() }
        if (result == null) {
            ws.cancel()
            return ConnectionTestStep(
                name = "WebSocket handshake",
                passed = false,
                latencyMs = null,
                detail = "Timed out waiting for WebSocket handshake"
            )
        }
        return result
    }

    private fun formatErrorDetail(t: Throwable, fallback: String = "Failed"): String {
        val msg = t.message?.trim()
        return if (!msg.isNullOrEmpty()) msg else (t::class.simpleName ?: fallback)
    }
}
