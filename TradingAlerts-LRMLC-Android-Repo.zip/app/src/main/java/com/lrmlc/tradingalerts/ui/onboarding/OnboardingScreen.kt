package com.lrmlc.tradingalerts.ui.onboarding

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lrmlc.tradingalerts.R
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.data.remote.ConnectionTestReport
import com.lrmlc.tradingalerts.data.repository.DefaultWatchlistResolution
import com.lrmlc.tradingalerts.data.repository.DownloadProgressSnapshot
import com.lrmlc.tradingalerts.ml.TrainingStatusSnapshot
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    settings: AppSettings,
    connectionReport: ConnectionTestReport?,
    isTestingConnection: Boolean,
    defaultResolution: DefaultWatchlistResolution?,
    watchlistSymbols: List<String>,
    downloadProgress: DownloadProgressSnapshot,
    trainingStatus: TrainingStatusSnapshot,
    onSelectExchange: (ExchangeId) -> Unit,
    onSelectMarketType: (MarketType) -> Unit,
    onRunConnectionTest: () -> Unit,
    onLoadDefaults: () -> Unit,
    onRemoveWatchlistSymbol: (String) -> Unit,
    onStartHistoryDownload: () -> Unit,
    onPauseDownload: () -> Unit,
    onResumeDownload: () -> Unit,
    onCompleteOnboarding: (enableBackgroundMonitoring: Boolean) -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    var enableBg by remember { mutableStateOf(true) }
    val context = LocalContext.current

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Step ${step + 1} of 6",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        LinearProgressIndicator(
            progress = { (step + 1) / 6f },
            modifier = Modifier.fillMaxWidth()
        )

        when (step) {
            0 -> {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(LrmlcColors.CharcoalBase),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(R.drawable.ic_brand_logo),
                            contentDescription = "Trading Alerts LRMLC logo",
                            modifier = Modifier.size(38.dp)
                        )
                    }
                    Column {
                        Text(
                            "Trading Alerts (LRMLC)",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Logistic Regression Machine Learning & Confluence",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("How it works", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            "• Monitors up to 20 crypto assets on 1-minute candles using public read-only exchange feeds.\n" +
                                "• Computes exact rolling trendlines, 4-hour average, and gated confluence signals.\n" +
                                "• Trains an on-device logistic regression model from good, bad, and shadow trades—no external API keys or servers.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Risk Disclaimer", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(
                            "This app provides informational alerts and statistical modeling only. It never places orders, never handles funds or API keys, and is not financial advice. Crypto scalping carries substantial risk of loss.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Button(onClick = { step = 1 }, modifier = Modifier.fillMaxWidth()) {
                    Text("Accept & Continue")
                }
            }

            1 -> {
                Text("Select Market Data Source", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Choose your exchange and market type. Only public market endpoints are used.", style = MaterialTheme.typography.bodyMedium)

                Text("Exchange", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ExchangeId.entries.forEach { ex ->
                        FilterChip(
                            selected = settings.exchange == ex,
                            onClick = { onSelectExchange(ex) },
                            label = { Text(ex.displayName) }
                        )
                    }
                }

                Text("Market Type", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MarketType.entries.forEach { mt ->
                        FilterChip(
                            selected = settings.marketType == mt,
                            onClick = { onSelectMarketType(mt) },
                            label = { Text(mt.displayName) }
                        )
                    }
                }

                OutlinedButton(
                    onClick = onRunConnectionTest,
                    enabled = !isTestingConnection,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (isTestingConnection) "Testing Connection..." else "Run Connection Test")
                }

                connectionReport?.let { report ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            report.steps.forEach { s ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = if (s.passed) Icons.Default.CheckCircle else Icons.Default.Error,
                                        contentDescription = null,
                                        tint = if (s.passed) LrmlcColors.LongGreen else LrmlcColors.ShortRed
                                    )
                                    Column {
                                        Text(s.name, fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium)
                                        Text(s.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { step = 0 }, modifier = Modifier.weight(1f)) { Text("Back") }
                    Button(
                        onClick = {
                            onLoadDefaults()
                            step = 2
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Next") }
                }
            }

            2 -> {
                Text("Confirm Default Watchlist", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Resolving the default 20 USDT assets on ${settings.exchange.displayName} ${settings.marketType.displayName}. Tap any asset to remove it if desired.",
                    style = MaterialTheme.typography.bodyMedium
                )

                defaultResolution?.unavailableNotes?.takeIf { it.isNotEmpty() }?.let { notes ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Unavailable Symbols Skipped", style = MaterialTheme.typography.titleSmall, color = LrmlcColors.WarningAmber)
                            notes.forEach { note ->
                                Text("• $note", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                if (watchlistSymbols.isEmpty()) {
                    Text("Resolving symbols from exchange...", style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(onClick = onLoadDefaults) { Text("Retry Symbol Lookup") }
                } else {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        watchlistSymbols.forEach { sym ->
                            FilterChip(
                                selected = true,
                                onClick = { onRemoveWatchlistSymbol(sym) },
                                label = { Text("${sym.stripUsdtSuffix()} ×") }
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { step = 1 }, modifier = Modifier.weight(1f)) { Text("Back") }
                    Button(onClick = { step = 3 }, modifier = Modifier.weight(1f)) { Text("Confirm (${watchlistSymbols.size}/20)") }
                }
            }

            3 -> {
                Text("Notifications & Background Service", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Grant notification permission so trade alerts, exit warnings, and the persistent status bar notification work reliably.", style = MaterialTheme.typography.bodyMedium)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Button(
                        onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Allow Notifications")
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Keep monitoring in background", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Runs a persistent low-priority foreground service hosting the single WebSocket stream.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = enableBg, onCheckedChange = { enableBg = it })
                    }
                }

                OutlinedButton(
                    onClick = {
                        val pm = context.getSystemService(PowerManager::class.java)
                        if (pm != null && !pm.isIgnoringBatteryOptimizations(context.packageName)) {
                            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                data = Uri.parse("package:${context.packageName}")
                            }
                            runCatching { context.startActivity(intent) }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Battery Optimization Exemption Guide")
                }

                Text(
                    "Note: Some phone manufacturers (e.g. Xiaomi, Huawei, Oppo, Samsung aggressive sleep modes) may still limit background tasks unless exempted in system battery settings.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { step = 2 }, modifier = Modifier.weight(1f)) { Text("Back") }
                    Button(
                        onClick = {
                            onStartHistoryDownload()
                            step = 4
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Start 4-Week Sync") }
                }
            }

            4 -> {
                Text("Downloading 4-Week 1m History", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Downloading ~40,560 1-minute candles per asset newest-first via a gentle single-request queue (~350ms spacing) to respect exchange limits.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(downloadProgress.statusMessage, fontWeight = FontWeight.Medium)
                        LinearProgressIndicator(
                            progress = { downloadProgress.progressFraction },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "Assets: ${downloadProgress.completedAssets}/${downloadProgress.totalAssets} · Pages: ${downloadProgress.completedPages}/${downloadProgress.totalEstimatedPages}" +
                                (downloadProgress.etaSeconds?.let { " · ETA ~${it / 60}m ${it % 60}s" } ?: ""),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        downloadProgress.lastError?.let {
                            Text(it, color = LrmlcColors.ShortRed, style = MaterialTheme.typography.bodySmall)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (downloadProgress.isRunning) {
                                OutlinedButton(onClick = onPauseDownload) { Text("Pause") }
                            } else {
                                OutlinedButton(onClick = onResumeDownload) { Text("Resume") }
                            }
                        }
                    }
                }

                Button(
                    onClick = { step = 5 },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (downloadProgress.isRunning) "Continue While Syncing in Background" else "Next: Model Training")
                }
            }

            5 -> {
                Text("Initial On-Device Training", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Once history finishes syncing, the resumable WorkManager trainer extracts features, labels triple-barrier outcomes, and runs purged walk-forward validation. You can enter the app right now.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(trainingStatus.stageMessage, fontWeight = FontWeight.Medium)
                        LinearProgressIndicator(
                            progress = { trainingStatus.progressPct / 100f },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("${trainingStatus.progressPct}% complete", style = MaterialTheme.typography.bodySmall)
                    }
                }

                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { onCompleteOnboarding(enableBg) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Trading Alerts (LRMLC)")
                }
            }
        }
    }
}
