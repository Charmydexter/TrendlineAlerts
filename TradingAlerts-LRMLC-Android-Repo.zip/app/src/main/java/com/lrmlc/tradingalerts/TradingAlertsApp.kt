package com.lrmlc.tradingalerts

import android.app.Application
import com.lrmlc.tradingalerts.di.AppContainer
import com.lrmlc.tradingalerts.ml.TrainingWorker
import com.lrmlc.tradingalerts.service.MonitoringForegroundService
import kotlinx.coroutines.launch

class TradingAlertsApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.notificationHelper.ensureChannels()
        TrainingWorker.schedulePeriodicCadences(this)

        container.applicationScope.launch {
            val settings = container.settingsRepository.getSettings()
            if (settings.onboardingCompleted && settings.keepMonitoringInBackground) {
                MonitoringForegroundService.start(this@TradingAlertsApp)
            }
            // Resume any interrupted ML training job if present
            val resumable = container.database.trainingJobDao().getNextResumableJob()
            if (resumable != null) {
                TrainingWorker.enqueueOneTime(this@TradingAlertsApp, resumable.jobId)
            }
        }
    }
}
