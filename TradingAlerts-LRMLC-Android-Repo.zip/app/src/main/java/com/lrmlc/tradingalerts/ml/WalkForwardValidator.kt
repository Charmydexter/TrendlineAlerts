package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import kotlinx.serialization.Serializable
import kotlin.math.abs
import kotlin.math.max

@Serializable
data class CalibrationBucket(
    val minProb: Double,
    val maxProb: Double,
    val sampleCount: Int,
    val predictedAvg: Double,
    val actualWinRate: Double
)

@Serializable
data class ValidationMetrics(
    val threshold: Double,
    val breakEvenThreshold: Double,
    val tradesTaken: Int,
    val totalOutOfSample: Int,
    val winRate: Double,
    val netExpectancyPct: Double,
    val profitFactor: Double,
    val maxDrawdownPct: Double,
    val brierScore: Double,
    val baselineExpectancyPct: Double,
    val baselineWinRate: Double,
    val calibrationBuckets: List<CalibrationBucket>
)

@Serializable
data class SerializedModelBundle(
    val weights: LogisticRegressionWeights,
    val metrics: ValidationMetrics
)

object WalkForwardValidator {

    /**
     * Evaluates purged and embargoed walk-forward folds over time-ordered samples.
     * Purge + embargo prevents label leakage across overlapping 1-minute trade horizons.
     */
    fun validateAndSelectThreshold(
        chronologicalSamples: List<LabeledSample>,
        featureCount: Int,
        horizonBars: Int,
        rewardToRisk: Double,
        params: LogisticHyperParams = LogisticHyperParams(),
        priorWeights: DoubleArray? = null,
        folds: Int = 3
    ): Pair<LogisticRegressionWeights, ValidationMetrics> {
        val sorted = chronologicalSamples.sortedBy { it.timestampMs }
        val breakEven = (1.0 / (1.0 + rewardToRisk.coerceAtLeast(0.1))).coerceIn(0.30, 0.80)

        if (sorted.size < 25) {
            val stats = StandardizationStats.fit(sorted.map { it.features }, featureCount)
            val weighted = OverlapWeightCalculator.assignOverlapWeights(sorted)
            val model = LogisticRegressionTrainer.trainWithCheckpoints(weighted, stats, featureCount, params, priorWeights)
            val metrics = evaluatePredictions(
                preds = sorted.map { model.predictProbability(it.features) to it },
                breakEvenThreshold = breakEven,
                chosenThreshold = max(0.55, breakEven)
            )
            return model to metrics
        }

        val purgeGapMs = horizonBars.coerceAtLeast(1) * DayChunkCodec.MILLIS_PER_MINUTE
        val oosPreds = ArrayList<Pair<Double, LabeledSample>>()

        val foldCount = folds.coerceIn(2, 5)
        val chunkSize = (sorted.size / (foldCount + 1)).coerceAtLeast(5)

        for (f in 1..foldCount) {
            val testStartIdx = f * chunkSize
            val testEndIdx = if (f == foldCount) sorted.size else minOf(sorted.size, (f + 1) * chunkSize)
            if (testStartIdx >= testEndIdx || testStartIdx < 10) continue

            val testStartMs = sorted[testStartIdx].timestampMs
            val testEndMs = sorted[testEndIdx - 1].exitTimeMs

            // Purge any training sample whose label horizon overlaps the test fold, plus embargo after test fold
            val trainSet = sorted.subList(0, testStartIdx).filter { s ->
                s.exitTimeMs + purgeGapMs < testStartMs
            }
            if (trainSet.size < 10) continue

            val testSet = sorted.subList(testStartIdx, testEndIdx)
            val stats = StandardizationStats.fit(trainSet.map { it.features }, featureCount)
            val weightedTrain = OverlapWeightCalculator.assignOverlapWeights(trainSet)
            val foldModel = LogisticRegressionTrainer.trainWithCheckpoints(
                samples = weightedTrain,
                stats = stats,
                featureCount = featureCount,
                params = params,
                priorWeights = priorWeights
            )
            for (testSample in testSet) {
                val p = foldModel.predictProbability(testSample.features)
                oosPreds.add(p to testSample)
            }
        }

        // Fit final production model on all samples
        val fullStats = StandardizationStats.fit(sorted.map { it.features }, featureCount)
        val weightedAll = OverlapWeightCalculator.assignOverlapWeights(sorted)
        val finalModel = LogisticRegressionTrainer.trainWithCheckpoints(
            samples = weightedAll,
            stats = fullStats,
            featureCount = featureCount,
            params = params,
            priorWeights = priorWeights
        )

        val evalSource = if (oosPreds.isNotEmpty()) oosPreds else sorted.map { finalModel.predictProbability(it.features) to it }
        val bestThreshold = selectOptimalThreshold(evalSource, breakEven)
        val metrics = evaluatePredictions(evalSource, breakEven, bestThreshold)
        return finalModel to metrics
    }

    fun selectOptimalThreshold(
        preds: List<Pair<Double, LabeledSample>>,
        breakEvenThreshold: Double
    ): Double {
        if (preds.isEmpty()) return max(0.55, breakEvenThreshold)
        val start = (breakEvenThreshold * 100).toInt().coerceIn(30, 85)
        var bestThresh = breakEvenThreshold
        var bestScore = Double.NEGATIVE_INFINITY

        for (tPct in start..85 step 2) {
            val t = tPct / 100.0
            val taken = preds.filter { it.first >= t }
            if (taken.size < max(3, preds.size / 15)) continue
            val expPct = taken.map { it.second.netReturnPct }.average()
            // Slightly prefer thresholds with reasonable sample coverage
            val score = expPct
            if (score > bestScore) {
                bestScore = score
                bestThresh = t
            }
        }
        return bestThresh.coerceAtLeast(breakEvenThreshold)
    }

    fun evaluatePredictions(
        preds: List<Pair<Double, LabeledSample>>,
        breakEvenThreshold: Double,
        chosenThreshold: Double
    ): ValidationMetrics {
        if (preds.isEmpty()) {
            return ValidationMetrics(
                threshold = chosenThreshold,
                breakEvenThreshold = breakEvenThreshold,
                tradesTaken = 0,
                totalOutOfSample = 0,
                winRate = 0.0,
                netExpectancyPct = 0.0,
                profitFactor = 0.0,
                maxDrawdownPct = 0.0,
                brierScore = 0.25,
                baselineExpectancyPct = 0.0,
                baselineWinRate = 0.0,
                calibrationBuckets = emptyList()
            )
        }

        val baselineWinRate = preds.count { it.second.label == 1 }.toDouble() / preds.size
        val baselineExp = preds.map { it.second.netReturnPct }.average()

        var brierSum = 0.0
        for ((p, s) in preds) {
            val d = p - s.label.toDouble()
            brierSum += d * d
        }
        val brier = brierSum / preds.size

        val taken = preds.filter { it.first >= chosenThreshold }
        val takenWins = taken.count { it.second.label == 1 }
        val winRate = if (taken.isNotEmpty()) takenWins.toDouble() / taken.size else 0.0
        val netExp = if (taken.isNotEmpty()) taken.map { it.second.netReturnPct }.average() else 0.0

        var grossWin = 0.0
        var grossLoss = 0.0
        var cumPnl = 0.0
        var peakPnl = 0.0
        var maxDd = 0.0
        for ((_, s) in taken) {
            val r = s.netReturnPct
            if (r >= 0) grossWin += r else grossLoss += abs(r)
            cumPnl += r
            if (cumPnl > peakPnl) peakPnl = cumPnl
            val dd = peakPnl - cumPnl
            if (dd > maxDd) maxDd = dd
        }
        val pf = when {
            grossLoss > 1e-9 -> grossWin / grossLoss
            grossWin > 0.0 -> 9.99
            else -> 0.0
        }

        val ranges = listOf(
            0.0 to 0.5,
            0.5 to 0.6,
            0.6 to 0.7,
            0.7 to 0.8,
            0.8 to 1.01
        )
        val buckets = ranges.mapNotNull { (lo, hi) ->
            val inBucket = preds.filter { it.first >= lo && it.first < hi }
            if (inBucket.isEmpty()) null else {
                CalibrationBucket(
                    minProb = lo,
                    maxProb = hi.coerceAtMost(1.0),
                    sampleCount = inBucket.size,
                    predictedAvg = inBucket.map { it.first }.average(),
                    actualWinRate = inBucket.count { it.second.label == 1 }.toDouble() / inBucket.size
                )
            }
        }

        return ValidationMetrics(
            threshold = chosenThreshold,
            breakEvenThreshold = breakEvenThreshold,
            tradesTaken = taken.size,
            totalOutOfSample = preds.size,
            winRate = winRate,
            netExpectancyPct = netExp,
            profitFactor = pf,
            maxDrawdownPct = maxDd,
            brierScore = brier,
            baselineExpectancyPct = baselineExp,
            baselineWinRate = baselineWinRate,
            calibrationBuckets = buckets
        )
    }

    /**
     * Promotion rule: replace active model only if the new model beats both the active model
     * and the no-filter baseline on recent out-of-sample data.
     */
    fun shouldPromote(
        newMetrics: ValidationMetrics,
        existingActiveMetrics: ValidationMetrics?,
        newModelOnRecent: ValidationMetrics? = null,
        activeModelOnRecent: ValidationMetrics? = null
    ): Pair<Boolean, String> {
        val recentNew = newModelOnRecent ?: newMetrics
        if (recentNew.tradesTaken < 3) {
            return false to "Not enough recent out-of-sample trades (${recentNew.tradesTaken}) to confirm improvement."
        }
        if (recentNew.netExpectancyPct < recentNew.baselineExpectancyPct - 1e-6) {
            return false to "Kept existing model: candidate expectancy (${formatPct(recentNew.netExpectancyPct)}) did not beat the no-filter baseline (${formatPct(recentNew.baselineExpectancyPct)})."
        }
        if (existingActiveMetrics == null) {
            return true to "Promoted first validated model (expectancy ${formatPct(recentNew.netExpectancyPct)} vs baseline ${formatPct(recentNew.baselineExpectancyPct)})."
        }
        val activeExp = activeModelOnRecent?.netExpectancyPct ?: existingActiveMetrics.netExpectancyPct
        return if (recentNew.netExpectancyPct >= activeExp - 1e-6) {
            true to "Promoted new model: outperformed active model (${formatPct(recentNew.netExpectancyPct)} vs ${formatPct(activeExp)}) and no-filter baseline."
        } else {
            false to "Kept previous active model: its recent expectancy (${formatPct(activeExp)}) beat candidate (${formatPct(recentNew.netExpectancyPct)})."
        }
    }

    private fun formatPct(v: Double): String = String.format(java.util.Locale.US, "%+.3f%%", v * 100.0)
}
