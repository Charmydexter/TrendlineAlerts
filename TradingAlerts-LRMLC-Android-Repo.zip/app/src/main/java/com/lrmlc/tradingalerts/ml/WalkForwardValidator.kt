package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import kotlinx.serialization.Serializable
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.sqrt

@Serializable
data class CalibrationBucket(
    val minProb: Double,
    val maxProb: Double,
    val sampleCount: Int,
    val predictedAvg: Double,
    val actualWinRate: Double
)

/** Result of one of the (up to three) unseen test periods of the walk-forward check. */
@Serializable
data class FoldStat(
    val period: Int,
    val trades: Int,
    val expectancyPct: Double,
    val winRate: Double
)

@Serializable
data class ValidationMetrics(
    val threshold: Double,
    val breakEvenThreshold: Double,
    val tradesTaken: Int,
    val totalOutOfSample: Int,
    val winRate: Double,
    val netExpectancyPct: Double,
    val profitFactor: Double,
    val maxDrawdownPct: Double,
    val brierScore: Double,
    val baselineExpectancyPct: Double,
    val baselineWinRate: Double,
    val calibrationBuckets: List<CalibrationBucket>,
    val metricsAreOptimistic: Boolean = false,
    val manualThreshold: Double? = null,
    val manualTradesTaken: Int? = null,
    val manualWinRate: Double? = null,
    val manualExpectancyPct: Double? = null,
    val manualProfitFactor: Double? = null,
    val foldStats: List<FoldStat> = emptyList()
) {
    /** Stable = positive in at least two of the three test periods. Needs all three periods to judge. */
    fun isUnstable(): Boolean =
        foldStats.size >= 3 && foldStats.count { it.trades > 0 && it.expectancyPct > 0.0 } < 2

    fun positivePeriods(): Int = foldStats.count { it.trades > 0 && it.expectancyPct > 0.0 }
}

@Serializable
data class SerializedModelBundle(
    val weights: LogisticRegressionWeights,
    val metrics: ValidationMetrics,
    /** Feature groups this model was proven on. Older bundles only knew the core features. */
    val groups: List<String> = listOf("CORE"),
    val halfLifeDays: Int = 0,
    val l2Lambda: Double = 0.02,
    val epochs: Int = 25,
    val realTradesUsed: Int = 0
) {
    fun enabledGroups(): Set<FeatureSpec.Group> = FeatureSpec.parseGroups(groups)

    /** Applies this model's group mask so features of dropped groups stay neutral. */
    fun maskFeatures(raw: DoubleArray): DoubleArray = FeatureSpec.applyMask(raw, enabledGroups())
}

data class WalkForwardResult(
    val model: LogisticRegressionWeights,
    val metrics: ValidationMetrics,
    val oosPredictions: List<Pair<Double, LabeledSample>>
)

object WalkForwardValidator {

    const val MIN_HOLDOUT_TRADES = 30
    const val MIN_PROMOTION_MARGIN = 0.0005 // 0.05% absolute expectancy
    const val PROMOTION_COOLDOWN_MS = 24L * 60L * 60L * 1000L
    const val SAMPLE_GROWTH_BYPASS = 1.20

    fun computeFeeAwareBreakEven(
        samples: List<LabeledSample>,
        rewardToRisk: Double
    ): Double {
        val wins = samples.filter { it.netReturnPct > 0.0 }
        val losses = samples.filter { it.netReturnPct <= 0.0 }
        val raw = if (wins.size >= 10 && losses.size >= 10) {
            val avgWinNet = wins.map { it.netReturnPct }.average()
            val avgLossNet = losses.map { abs(it.netReturnPct) }.average()
            val denom = avgWinNet + avgLossNet
            if (denom > 1e-12) avgLossNet / denom else 1.0 / (1.0 + rewardToRisk.coerceAtLeast(0.1))
        } else {
            1.0 / (1.0 + rewardToRisk.coerceAtLeast(0.1))
        }
        return raw.coerceIn(0.30, 0.85)
    }

    /**
     * Evaluates purged and embargoed walk-forward folds over time-ordered samples,
     * keeping out-of-sample predictions for calibration and per-asset preset selection.
     */
    fun validateWithOosPredictions(
        chronologicalSamples: List<LabeledSample>,
        featureCount: Int,
        horizonBars: Int,
        rewardToRisk: Double,
        params: LogisticHyperParams = LogisticHyperParams(),
        priorWeights: DoubleArray? = null,
        folds: Int = 3,
        manualThreshold: Double? = null
    ): WalkForwardResult {
        val sorted = chronologicalSamples.sortedBy { it.timestampMs }
        val breakEven = computeFeeAwareBreakEven(sorted, rewardToRisk)

        if (sorted.size < 25) {
            val stats = StandardizationStats.fit(sorted.map { it.features }, featureCount)
            val weighted = OverlapWeightCalculator.assignOverlapWeights(sorted)
            val model = LogisticRegressionTrainer.trainWithCheckpoints(weighted, stats, featureCount, params, priorWeights)
            val preds = sorted.map { model.predictProbability(it.features) to it }
            val metrics = evaluatePredictions(
                preds = preds,
                breakEvenThreshold = breakEven,
                chosenThreshold = max(0.55, breakEven).coerceIn(0.30, 0.85),
                metricsAreOptimistic = true,
                manualThreshold = manualThreshold
            )
            return WalkForwardResult(model, metrics, preds)
        }

        val purgeGapMs = horizonBars.coerceAtLeast(1) * DayChunkCodec.MILLIS_PER_MINUTE
        val oosPreds = ArrayList<Pair<Double, LabeledSample>>()
        val oosFolds = ArrayList<List<Pair<Double, LabeledSample>>>()

        val foldCount = folds.coerceIn(2, 5)
        val chunkSize = (sorted.size / (foldCount + 1)).coerceAtLeast(5)

        for (f in 1..foldCount) {
            val testStartIdx = f * chunkSize
            val testEndIdx = if (f == foldCount) sorted.size else minOf(sorted.size, (f + 1) * chunkSize)
            if (testStartIdx >= testEndIdx || testStartIdx < 10) continue

            val testStartMs = sorted[testStartIdx].timestampMs

            // Purge any training sample whose label horizon overlaps the test fold, plus embargo
            val trainSet = sorted.subList(0, testStartIdx).filter { s ->
                s.exitTimeMs + purgeGapMs < testStartMs
            }
            if (trainSet.size < 10) continue

            val testSet = sorted.subList(testStartIdx, testEndIdx)
            val stats = StandardizationStats.fit(trainSet.map { it.features }, featureCount)
            val weightedTrain = OverlapWeightCalculator.assignOverlapWeights(trainSet)
            val foldModel = LogisticRegressionTrainer.trainWithCheckpoints(
                samples = weightedTrain,
                stats = stats,
                featureCount = featureCount,
                params = params,
                priorWeights = priorWeights
            )
            val foldList = ArrayList<Pair<Double, LabeledSample>>(testSet.size)
            for (testSample in testSet) {
                val p = foldModel.predictProbability(testSample.features)
                val pair = p to testSample
                foldList.add(pair)
                oosPreds.add(pair)
            }
            if (foldList.isNotEmpty()) {
                oosFolds.add(foldList)
            }
        }

        // Evaluate whether isotonic calibration strictly improves OOS Brier (checked on a split of OOS)
        val useCalibrator = shouldAdoptIsotonicCalibration(oosPreds)
        val prodCalibrator = if (useCalibrator) {
            IsotonicCalibrator.fitPoolAdjacentViolators(oosPreds.map { it.first to it.second.label })
        } else {
            null
        }

        // Fit final production model on all samples and attach calibrator if adopted
        val fullStats = StandardizationStats.fit(sorted.map { it.features }, featureCount)
        val weightedAll = OverlapWeightCalculator.assignOverlapWeights(sorted)
        val rawFinalModel = LogisticRegressionTrainer.trainWithCheckpoints(
            samples = weightedAll,
            stats = fullStats,
            featureCount = featureCount,
            params = params,
            priorWeights = priorWeights
        )
        val finalModel = rawFinalModel.copy(calibrator = prodCalibrator)

        // Calibrate OOS predictions per split without leaking eval fold into threshold tuning
        val evalOosPreds: List<Pair<Double, LabeledSample>>
        val metrics: ValidationMetrics

        if (oosFolds.size >= 2 && oosFolds.last().size >= 30) {
            val tuneFolds = oosFolds.dropLast(1).flatten()
            val reportFold = oosFolds.last()
            val splitCalibrator = if (useCalibrator) {
                IsotonicCalibrator.fitPoolAdjacentViolators(tuneFolds.map { it.first to it.second.label })
            } else {
                null
            }
            val tunedPreds = if (splitCalibrator != null) {
                tuneFolds.map { (p, s) -> splitCalibrator.calibrate(p) to s }
            } else {
                tuneFolds
            }
            val reportPreds = if (splitCalibrator != null) {
                reportFold.map { (p, s) -> splitCalibrator.calibrate(p) to s }
            } else {
                reportFold
            }
            val bestThreshold = selectOptimalThreshold(tunedPreds, breakEven)
            metrics = evaluatePredictions(
                preds = reportPreds,
                breakEvenThreshold = breakEven,
                chosenThreshold = bestThreshold,
                metricsAreOptimistic = false,
                manualThreshold = manualThreshold
            )
            evalOosPreds = if (prodCalibrator != null) {
                oosPreds.map { (p, s) -> prodCalibrator.calibrate(p) to s }
            } else {
                oosPreds
            }
        } else {
            val basePreds = if (oosPreds.isNotEmpty()) {
                oosPreds
            } else {
                sorted.map { rawFinalModel.predictRawProbability(it.features) to it }
            }
            val calibratedBase = if (prodCalibrator != null && oosPreds.isNotEmpty()) {
                basePreds.map { (p, s) -> prodCalibrator.calibrate(p) to s }
            } else {
                basePreds
            }
            val bestThreshold = selectOptimalThreshold(calibratedBase, breakEven)
            metrics = evaluatePredictions(
                preds = calibratedBase,
                breakEvenThreshold = breakEven,
                chosenThreshold = bestThreshold,
                metricsAreOptimistic = true,
                manualThreshold = manualThreshold
            )
            evalOosPreds = calibratedBase
        }

        val foldStats = oosFolds.mapIndexed { idx, fold ->
            val calibrated = if (prodCalibrator != null) fold.map { (p, s) -> prodCalibrator.calibrate(p) to s } else fold
            val taken = calibrated.filter { it.first >= metrics.threshold }
            FoldStat(
                period = idx + 1,
                trades = taken.size,
                expectancyPct = if (taken.isNotEmpty()) taken.sumOf { it.second.netReturnPct } / taken.size else 0.0,
                winRate = if (taken.isNotEmpty()) taken.count { it.second.label == 1 }.toDouble() / taken.size else 0.0
            )
        }
        return WalkForwardResult(finalModel, metrics.copy(foldStats = foldStats), evalOosPreds)
    }

    fun validateAndSelectThreshold(
        chronologicalSamples: List<LabeledSample>,
        featureCount: Int,
        horizonBars: Int,
        rewardToRisk: Double,
        params: LogisticHyperParams = LogisticHyperParams(),
        priorWeights: DoubleArray? = null,
        folds: Int = 3,
        manualThreshold: Double? = null
    ): Pair<LogisticRegressionWeights, ValidationMetrics> {
        val res = validateWithOosPredictions(
            chronologicalSamples = chronologicalSamples,
            featureCount = featureCount,
            horizonBars = horizonBars,
            rewardToRisk = rewardToRisk,
            params = params,
            priorWeights = priorWeights,
            folds = folds,
            manualThreshold = manualThreshold
        )
        return res.model to res.metrics
    }

    private fun shouldAdoptIsotonicCalibration(oosPreds: List<Pair<Double, LabeledSample>>): Boolean {
        if (oosPreds.size < 40) return false
        val splitIdx = oosPreds.size / 2
        val calTrain = oosPreds.subList(0, splitIdx)
        val calEval = oosPreds.subList(splitIdx, oosPreds.size)
        val cal = IsotonicCalibrator.fitPoolAdjacentViolators(calTrain.map { it.first to it.second.label })
            ?: return false
        var rawBrier = 0.0
        var calBrier = 0.0
        for ((p, s) in calEval) {
            val y = s.label.toDouble()
            val dr = p - y
            val dc = cal.calibrate(p) - y
            rawBrier += dr * dr
            calBrier += dc * dc
        }
        return (calBrier / calEval.size) < (rawBrier / calEval.size) - 1e-6
    }

    fun selectOptimalThreshold(
        preds: List<Pair<Double, LabeledSample>>,
        breakEvenThreshold: Double
    ): Double {
        val be = breakEvenThreshold.coerceIn(0.30, 0.85)
        if (preds.isEmpty()) return max(0.55, be)
        val minTrades = max(30, preds.size / 10)
        if (preds.size < minTrades) return be

        val start = (be * 100).toInt().coerceIn(30, 85)
        var bestThresh = be
        var bestScore = Double.NEGATIVE_INFINITY

        for (tPct in start..85 step 2) {
            val t = tPct / 100.0
            val taken = preds.filter { it.first >= t }
            if (taken.size < minTrades) continue
            val n = taken.size.toDouble()
            val mean = taken.sumOf { it.second.netReturnPct } / n
            val variance = if (taken.size > 1) {
                var sq = 0.0
                for ((_, s) in taken) {
                    val d = s.netReturnPct - mean
                    sq += d * d
                }
                sq / (n - 1.0)
            } else {
                0.0
            }
            val stdErr = sqrt(variance / n)
            // Lower confidence bound prevents noise-chasing on small tail slices
            val lcbScore = mean - 1.0 * stdErr
            if (lcbScore > bestScore + 1e-12) {
                bestScore = lcbScore
                bestThresh = t
            }
        }
        return bestThresh.coerceAtLeast(be)
    }

    fun evaluatePredictions(
        preds: List<Pair<Double, LabeledSample>>,
        breakEvenThreshold: Double,
        chosenThreshold: Double,
        metricsAreOptimistic: Boolean = false,
        manualThreshold: Double? = null
    ): ValidationMetrics {
        if (preds.isEmpty()) {
            return ValidationMetrics(
                threshold = chosenThreshold,
                breakEvenThreshold = breakEvenThreshold,
                tradesTaken = 0,
                totalOutOfSample = 0,
                winRate = 0.0,
                netExpectancyPct = 0.0,
                profitFactor = 0.0,
                maxDrawdownPct = 0.0,
                brierScore = 0.25,
                baselineExpectancyPct = 0.0,
                baselineWinRate = 0.0,
                calibrationBuckets = emptyList(),
                metricsAreOptimistic = metricsAreOptimistic,
                manualThreshold = manualThreshold
            )
        }

        val baselineWinRate = preds.count { it.second.label == 1 }.toDouble() / preds.size
        val baselineExp = preds.map { it.second.netReturnPct }.average()

        var brierSum = 0.0
        for ((p, s) in preds) {
            val d = p - s.label.toDouble()
            brierSum += d * d
        }
        val brier = brierSum / preds.size

        val primary = computeThresholdStats(preds, chosenThreshold)
        val manualStats = manualThreshold?.let { computeThresholdStats(preds, it) }

        val ranges = listOf(
            0.0 to 0.5,
            0.5 to 0.6,
            0.6 to 0.7,
            0.7 to 0.8,
            0.8 to 1.01
        )
        val buckets = ranges.mapNotNull { (lo, hi) ->
            val inBucket = preds.filter { it.first >= lo && it.first < hi }
            if (inBucket.isEmpty()) null else {
                CalibrationBucket(
                    minProb = lo,
                    maxProb = hi.coerceAtMost(1.0),
                    sampleCount = inBucket.size,
                    predictedAvg = inBucket.map { it.first }.average(),
                    actualWinRate = inBucket.count { it.second.label == 1 }.toDouble() / inBucket.size
                )
            }
        }

        return ValidationMetrics(
            threshold = chosenThreshold,
            breakEvenThreshold = breakEvenThreshold,
            tradesTaken = primary.tradesTaken,
            totalOutOfSample = preds.size,
            winRate = primary.winRate,
            netExpectancyPct = primary.netExp,
            profitFactor = primary.profitFactor,
            maxDrawdownPct = primary.maxDrawdown,
            brierScore = brier,
            baselineExpectancyPct = baselineExp,
            baselineWinRate = baselineWinRate,
            calibrationBuckets = buckets,
            metricsAreOptimistic = metricsAreOptimistic,
            manualThreshold = manualThreshold,
            manualTradesTaken = manualStats?.tradesTaken,
            manualWinRate = manualStats?.winRate,
            manualExpectancyPct = manualStats?.netExp,
            manualProfitFactor = manualStats?.profitFactor
        )
    }

    private data class ThresholdStats(
        val tradesTaken: Int,
        val winRate: Double,
        val netExp: Double,
        val profitFactor: Double,
        val maxDrawdown: Double
    )

    private fun computeThresholdStats(
        preds: List<Pair<Double, LabeledSample>>,
        threshold: Double
    ): ThresholdStats {
        val taken = preds.filter { it.first >= threshold }
        val takenWins = taken.count { it.second.label == 1 }
        val winRate = if (taken.isNotEmpty()) takenWins.toDouble() / taken.size else 0.0
        val netExp = if (taken.isNotEmpty()) taken.map { it.second.netReturnPct }.average() else 0.0

        var grossWin = 0.0
        var grossLoss = 0.0
        var cumPnl = 0.0
        var peakPnl = 0.0
        var maxDd = 0.0
        for ((_, s) in taken) {
            val r = s.netReturnPct
            if (r >= 0) grossWin += r else grossLoss += abs(r)
            cumPnl += r
            if (cumPnl > peakPnl) peakPnl = cumPnl
            val dd = peakPnl - cumPnl
            if (dd > maxDd) maxDd = dd
        }
        val pf = when {
            grossLoss > 1e-9 -> grossWin / grossLoss
            grossWin > 0.0 -> 9.99
            else -> 0.0
        }
        return ThresholdStats(taken.size, winRate, netExp, pf, maxDd)
    }

    /**
     * Promotion rule [U6]:
     * - Candidate and active models must take at least MIN_HOLDOUT_TRADES (30) on the hold-out.
     * - Candidate expectancy must exceed the no-filter baseline.
     * - Candidate expectancy must exceed active + MIN_PROMOTION_MARGIN (0.05%).
     * - At most one promotion per 24h unless sample count grew by >= 20%.
     */
    fun shouldPromote(
        newMetrics: ValidationMetrics,
        existingActiveMetrics: ValidationMetrics?,
        newModelOnRecent: ValidationMetrics? = null,
        activeModelOnRecent: ValidationMetrics? = null,
        nowMs: Long = System.currentTimeMillis(),
        lastPromotedAtMs: Long = 0L,
        lastPromotedSampleCount: Int = 0,
        currentSampleCount: Int = 0
    ): Pair<Boolean, String> {
        val holdoutNew = newModelOnRecent ?: newMetrics
        if (holdoutNew.tradesTaken < MIN_HOLDOUT_TRADES) {
            return false to "Kept existing model: only ${holdoutNew.tradesTaken} hold-out trades (need $MIN_HOLDOUT_TRADES)."
        }
        if (holdoutNew.netExpectancyPct <= holdoutNew.baselineExpectancyPct + 1e-9) {
            return false to "Kept existing model: candidate expectancy (${formatPct(holdoutNew.netExpectancyPct)}) did not beat the no-filter baseline (${formatPct(holdoutNew.baselineExpectancyPct)})."
        }
        if (existingActiveMetrics == null) {
            return true to "Promoted first validated model (${formatPct(holdoutNew.netExpectancyPct)} vs baseline ${formatPct(holdoutNew.baselineExpectancyPct)})."
        }

        if (lastPromotedAtMs > 0L) {
            val withinCooldown = (nowMs - lastPromotedAtMs) < PROMOTION_COOLDOWN_MS
            val requiredSamples = ceil(lastPromotedSampleCount * SAMPLE_GROWTH_BYPASS).toInt()
            val sampleGrowthOk = lastPromotedSampleCount > 0 && currentSampleCount >= requiredSamples
            if (withinCooldown && !sampleGrowthOk) {
                return false to "Kept existing model: 24h promotion cooldown active (samples $currentSampleCount vs $requiredSamples needed to bypass)."
            }
        }

        if (activeModelOnRecent != null && activeModelOnRecent.tradesTaken < MIN_HOLDOUT_TRADES) {
            return false to "Kept existing model: active model had only ${activeModelOnRecent.tradesTaken} hold-out trades (need $MIN_HOLDOUT_TRADES for comparison)."
        }

        val activeExp = activeModelOnRecent?.netExpectancyPct ?: existingActiveMetrics.netExpectancyPct
        return if (holdoutNew.netExpectancyPct >= activeExp + MIN_PROMOTION_MARGIN) {
            true to "Promoted new model: outperformed active model (${formatPct(holdoutNew.netExpectancyPct)} vs ${formatPct(activeExp)}) and no-filter baseline."
        } else {
            false to "Kept previous active model: candidate (${formatPct(holdoutNew.netExpectancyPct)}) did not beat active (${formatPct(activeExp)}) by +0.050% margin."
        }
    }

    private fun formatPct(v: Double): String = String.format(java.util.Locale.US, "%+.3f%%", v * 100.0)
}
