package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.engine.TrendlineAnchorPair
import java.time.Instant
import java.time.ZoneOffset
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Latest funding rate and 1-hour open-interest change for a perpetual contract (futures group). */
data class FuturesPoint(
    val fundingRate: Double,
    val oiChange1h: Double
)

object FeatureBuilder {

    private const val EPS = 1e-9
    private const val MINUTE_MS = 60_000L
    private const val DAY_BARS = 1440

    fun buildFeatures(
        candles: List<Candle>,
        snapshots: List<ConfluenceBarSnapshot>,
        barIndex: Int,
        marketType: MarketType,
        lastSignalOutcome: Int?, // 1 = win, 0 = loss, null = none
        windowBars: Int = 240,
        masterCandles: List<Candle>? = null, // 1-minute history of the master (market-context) asset
        isMasterAsset: Boolean = false, // true when this coin IS the master asset -> neutral context
        futures: FuturesPoint? = null // perpetual markets only; null -> neutral
    ): DoubleArray? {
        if (barIndex !in snapshots.indices || barIndex !in candles.indices) return null
        val snap = snapshots[barIndex]
        val res = snap.resistance ?: return null
        val sup = snap.support ?: return null
        val resVal = snap.resVal ?: return null
        val supVal = snap.supVal ?: return null
        val basis = snap.basis ?: return null
        val hiLine = snap.hiLine ?: return null
        val loLine = snap.loLine ?: return null
        val dir = snap.candidateDirection ?: return null

        val bar = candles[barIndex]
        val close = bar.close.coerceAtLeast(EPS)
        val winLen = windowBars.coerceAtLeast(20)
        val winDiv = winLen.toDouble()
        val medVolWin = rollingMedianVolume(candles, barIndex, winLen).coerceAtLeast(EPS)

        val f = DoubleArray(FeatureSpec.FEATURE_COUNT)

        // 0..11 Line geometry
        f[0] = (res.slopePerBar / close) * 100.0
        f[1] = (sup.slopePerBar / close) * 100.0
        f[2] = (hiLine - loLine) / close
        f[3] = (barIndex - res.x1) / winDiv
        f[4] = (barIndex - res.x2) / winDiv
        f[5] = (barIndex - sup.x1) / winDiv
        f[6] = (barIndex - sup.x2) / winDiv
        f[7] = (res.x2 - res.x1) / winDiv
        f[8] = (sup.x2 - sup.x1) / winDiv
        f[9] = snap.resUpdatesInWindow / winDiv
        f[10] = snap.supUpdatesInWindow / winDiv
        f[11] = ((sup.slopePerBar - res.slopePerBar) / close) * 100.0

        // 12..22 Position in structure
        f[12] = (bar.low - hiLine) / close
        f[13] = (loLine - bar.high) / close
        f[14] = (close - hiLine) / close
        f[15] = (close - loLine) / close
        f[16] = (close - basis) / close
        f[17] = if (abs(hiLine - resVal) <= 1e-12) 1.0 else 0.0
        f[18] = if (abs(loLine - supVal) <= 1e-12) 1.0 else 0.0
        val prevBasis = snap.prevBasis ?: basis
        f[19] = ((basis - prevBasis) / close) * 100.0
        val structDist = when (dir) {
            TradeDirection.LONG -> (close - loLine).coerceAtLeast(EPS)
            TradeDirection.SHORT -> (hiLine - close).coerceAtLeast(EPS)
        }
        val slDistSafe = snap.slDist.coerceAtLeast(EPS)
        f[20] = (structDist / slDistSafe).coerceIn(0.0, 5.0)
        f[21] = (snap.tpDist / structDist).coerceIn(0.0, 10.0)
        f[22] = if (abs(hiLine - basis) <= 1e-12 || abs(loLine - basis) <= 1e-12) 1.0 else 0.0

        // 23..27 Gate & history
        val oppRaw = when (dir) {
            TradeDirection.LONG -> snap.barsSinceLastRawShort
            TradeDirection.SHORT -> snap.barsSinceLastRawLong
        } ?: winLen
        f[23] = (oppRaw / winDiv).coerceIn(0.0, 4.0)
        f[24] = ((snap.barsSinceLastSignal ?: winLen) / winDiv).coerceIn(0.0, 4.0)
        f[25] = when (lastSignalOutcome) {
            1 -> 1.0
            0 -> -1.0
            else -> 0.0
        }
        f[26] = snap.recentRiskRejectionsLast60 / 10.0
        f[27] = snap.consecutiveBarsOutside / 20.0

        // 28..55 Volume behavior from birth of resistance, support, and pair
        val resStats = computeLineVolumeStats(
            candles = candles,
            pair = res,
            barIndex = barIndex,
            medVolWin = medVolWin,
            firstBreakoutBar = snap.firstOutsideBarSinceResBirth
        )
        val supStats = computeLineVolumeStats(
            candles = candles,
            pair = sup,
            barIndex = barIndex,
            medVolWin = medVolWin,
            firstBreakoutBar = snap.firstOutsideBarSinceSupBirth
        )

        // Anchors
        f[28] = resStats.volA1RelMed
        f[29] = resStats.volA2RelMed
        f[30] = resStats.volA2ToA1Ratio
        f[31] = supStats.volA1RelMed
        f[32] = supStats.volA2RelMed
        f[33] = supStats.volA2ToA1Ratio
        f[34] = 0.5 * (resStats.volA2ToA1Ratio + supStats.volA2ToA1Ratio)

        // Since birth vs before birth
        f[35] = resStats.avgSinceVsBefore
        f[36] = supStats.avgSinceVsBefore
        f[37] = 0.5 * (resStats.avgSinceVsBefore + supStats.avgSinceVsBefore)

        // Normalized slope of volume since birth
        f[38] = resStats.normSlopeSinceBirth
        f[39] = supStats.normSlopeSinceBirth
        f[40] = 0.5 * (resStats.normSlopeSinceBirth + supStats.normSlopeSinceBirth)

        // Up-bar volume share since birth
        f[41] = resStats.upVolShareSinceBirth
        f[42] = supStats.upVolShareSinceBirth
        f[43] = 0.5 * (resStats.upVolShareSinceBirth + supStats.upVolShareSinceBirth)

        // Cumulative volume since birth vs median over same bar count
        f[44] = resStats.cumVolVsMedian
        f[45] = supStats.cumVolVsMedian
        f[46] = 0.5 * (resStats.cumVolVsMedian + supStats.cumVolVsMedian)

        // Signal bar and last 3 bars relative to avg since birth
        f[47] = resStats.sigVolVsAvgSinceBirth
        f[48] = resStats.last3VolVsAvgSinceBirth
        f[49] = supStats.sigVolVsAvgSinceBirth
        f[50] = supStats.last3VolVsAvgSinceBirth
        f[51] = 0.5 * (resStats.sigVolVsAvgSinceBirth + supStats.sigVolVsAvgSinceBirth)
        f[52] = 0.5 * (resStats.last3VolVsAvgSinceBirth + supStats.last3VolVsAvgSinceBirth)

        // Volume change between birth and first bar outside all 3 levels
        f[53] = resStats.birthToBreakoutChange
        f[54] = supStats.birthToBreakoutChange
        f[55] = 0.5 * (resStats.birthToBreakoutChange + supStats.birthToBreakoutChange)

        // 56..64 Price behavior (clock-time lags 1, 5, 15, 60 remain fixed)
        val range = (bar.high - bar.low).coerceAtLeast(EPS)
        f[56] = (bar.high - bar.low) / close
        f[57] = (abs(bar.close - bar.open) / range).coerceIn(0.0, 1.0)
        f[58] = ((bar.close - bar.low) / range).coerceIn(0.0, 1.0)
        f[59] = returnOver(candles, barIndex, 1)
        f[60] = returnOver(candles, barIndex, 5)
        f[61] = returnOver(candles, barIndex, 15)
        f[62] = returnOver(candles, barIndex, 60)
        f[63] = realizedVolatility(candles, barIndex, 60)
        f[64] = (bar.volume / medVolWin).coerceIn(0.0, 20.0)

        // 65..70 Context
        val dt = Instant.ofEpochMilli(bar.openTimeMs).atOffset(ZoneOffset.UTC)
        val hourAngle = 2.0 * PI * (dt.hour + dt.minute / 60.0) / 24.0
        val dayAngle = 2.0 * PI * (dt.dayOfWeek.value - 1) / 7.0
        f[65] = sin(hourAngle)
        f[66] = cos(hourAngle)
        f[67] = sin(dayAngle)
        f[68] = cos(dayAngle)
        f[69] = if (dir == TradeDirection.LONG) 1.0 else -1.0
        f[70] = if (marketType == MarketType.PERP) 1.0 else 0.0

        // 71..90 Optional learned groups (zeroed later by the group mask when a group did not prove itself)
        fillMarketContext(f, candles, barIndex, masterCandles, isMasterAsset)
        fillVolatilityMood(f, candles, barIndex)
        fillBiggerPicture(f, candles, barIndex)
        if (futures != null) {
            f[89] = (futures.fundingRate * 100.0).coerceIn(-5.0, 5.0)
            f[90] = futures.oiChange1h.coerceIn(-0.5, 0.5)
        }

        // Guard any NaN/Infinite
        for (i in f.indices) {
            if (!f[i].isFinite()) f[i] = 0.0
        }
        return f
    }


    // ---------------------------------------------------------------------------------------------
    // Market context (71..75): neutral (all 0) for the master asset itself or when master data is missing
    // ---------------------------------------------------------------------------------------------
    private fun fillMarketContext(
        f: DoubleArray,
        candles: List<Candle>,
        barIndex: Int,
        master: List<Candle>?,
        isMaster: Boolean
    ) {
        if (isMaster || master == null || master.size < 70) return
        val t = candles[barIndex].openTimeMs
        // Live, the master's candle can land a moment after the coin's: accept the latest one within 2 minutes
        val mIdx = findAtOrBefore(master, t, 2 * MINUTE_MS)
        if (mIdx < 0) return
        val mT = master[mIdx].openTimeMs
        val mNow = master[mIdx].close
        if (mNow <= EPS) return

        val m15 = master.getOrNull(findByTime(master, mT - 15 * MINUTE_MS))?.close
        val m60 = master.getOrNull(findByTime(master, mT - 60 * MINUTE_MS))?.close
        val masterRet15 = if (m15 != null && m15 > EPS) (mNow - m15) / m15 else 0.0
        val masterRet60 = if (m60 != null && m60 > EPS) (mNow - m60) / m60 else 0.0
        f[71] = masterRet15
        f[72] = masterRet60
        f[73] = if (mIdx >= 60) realizedVolatility(master, mIdx, 60) else 0.0
        f[74] = if (m60 != null) returnOver(candles, barIndex, 60) - masterRet60 else 0.0

        // Correlation of 1-minute returns over the last 60 minutes (time-aligned pairs only)
        val xs = ArrayList<Double>(60)
        val ys = ArrayList<Double>(60)
        for (k in 0 until 60) {
            val i = barIndex - k
            if (i < 1) break
            val ownT = candles[i].openTimeMs
            if (candles[i - 1].openTimeMs != ownT - MINUTE_MS) continue
            val mi = findByTime(master, ownT)
            val mp = findByTime(master, ownT - MINUTE_MS)
            if (mi < 0 || mp < 0) continue
            val c0 = candles[i - 1].close
            val m0 = master[mp].close
            if (c0 <= EPS || m0 <= EPS) continue
            xs.add((candles[i].close - c0) / c0)
            ys.add((master[mi].close - m0) / m0)
        }
        if (xs.size >= 30) f[75] = pearson(xs, ys)
    }

    // ---------------------------------------------------------------------------------------------
    // Volatility mood (76..80)
    // ---------------------------------------------------------------------------------------------
    private fun avgRangePct(candles: List<Candle>, from: Int, to: Int): Double {
        val lo = from.coerceAtLeast(0)
        if (to < lo) return 0.0
        var sum = 0.0
        for (i in lo..to) {
            val c = candles[i]
            sum += (c.high - c.low) / c.close.coerceAtLeast(EPS)
        }
        return sum / (to - lo + 1)
    }

    private fun fillVolatilityMood(f: DoubleArray, candles: List<Candle>, barIndex: Int) {
        val r5 = avgRangePct(candles, barIndex - 4, barIndex)
        val r30 = avgRangePct(candles, barIndex - 29, barIndex)
        f[76] = r5
        f[77] = r30
        if (barIndex >= 120) {
            val rDay = avgRangePct(candles, barIndex - DAY_BARS + 1, barIndex).coerceAtLeast(EPS)
            f[78] = ln((r30.coerceAtLeast(EPS)) / rDay).coerceIn(-3.0, 3.0)
            val medDay = rollingMedianVolume(candles, barIndex, DAY_BARS).coerceAtLeast(EPS)
            var v5 = 0.0
            for (i in (barIndex - 4)..barIndex) v5 += candles[i].volume
            v5 /= 5.0
            f[80] = ln((v5 / medDay).coerceAtLeast(1e-3)).coerceIn(-3.0, 3.0)
        }
        if (barIndex >= 30) {
            val recent = avgRangePct(candles, barIndex - 14, barIndex).coerceAtLeast(EPS)
            val prior = avgRangePct(candles, barIndex - 29, barIndex - 15).coerceAtLeast(EPS)
            f[79] = ln(recent / prior).coerceIn(-3.0, 3.0)
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Bigger-picture view (81..88): 5m and 15m candles built from the 1-minute data
    // ---------------------------------------------------------------------------------------------
    /** Closes of consecutive time buckets ending at [barIndex], newest first. The newest bucket is the (partial) current one. */
    private fun bucketCloses(candles: List<Candle>, barIndex: Int, bucketMs: Long, maxBuckets: Int): List<Double> {
        val out = ArrayList<Double>(maxBuckets)
        var lastBucket = Long.MIN_VALUE
        var i = barIndex
        val oldestAllowed = candles[barIndex].openTimeMs - bucketMs * (maxBuckets + 1L)
        while (i >= 0 && out.size < maxBuckets) {
            val c = candles[i]
            if (c.openTimeMs < oldestAllowed) break
            val b = Math.floorDiv(c.openTimeMs, bucketMs)
            if (b != lastBucket) {
                out.add(c.close)
                lastBucket = b
            }
            i--
        }
        return out
    }

    private fun fillBiggerPicture(f: DoubleArray, candles: List<Candle>, barIndex: Int) {
        val close = candles[barIndex].close.coerceAtLeast(EPS)
        val c5 = bucketCloses(candles, barIndex, 5 * MINUTE_MS, 20)
        if (c5.size >= 2) f[81] = (c5[0] - c5[1]) / c5[1].coerceAtLeast(EPS)
        if (c5.size >= 4) f[82] = (c5[0] - c5[3]) / c5[3].coerceAtLeast(EPS)
        if (c5.size >= 15) {
            // RSI(14) on 5-minute closes, scaled to -1..1
            var gain = 0.0
            var loss = 0.0
            for (k in 0 until 14) {
                val d = c5[k] - c5[k + 1] // newer minus older
                if (d >= 0) gain += d else loss -= d
            }
            val rsi = when {
                gain + loss <= EPS -> 50.0
                loss <= EPS -> 100.0
                else -> 100.0 - 100.0 / (1.0 + gain / loss)
            }
            f[88] = (rsi - 50.0) / 50.0
        }
        val c15 = bucketCloses(candles, barIndex, 15 * MINUTE_MS, 20)
        if (c15.size >= 2) f[83] = (c15[0] - c15[1]) / c15[1].coerceAtLeast(EPS)
        if (c15.size >= 4) f[84] = (c15[0] - c15[3]) / c15[3].coerceAtLeast(EPS)
        if (c15.size >= 5) {
            val avg = c15.average()
            f[85] = (close - avg) / close
        }
        if (barIndex >= 59) {
            var hi = Double.NEGATIVE_INFINITY
            var lo = Double.POSITIVE_INFINITY
            for (i in (barIndex - 59)..barIndex) {
                if (candles[i].high > hi) hi = candles[i].high
                if (candles[i].low < lo) lo = candles[i].low
            }
            f[86] = (hi - close) / close
            f[87] = (close - lo) / close
        }
    }

    internal fun findAtOrBefore(list: List<Candle>, t: Long, maxLagMs: Long): Int {
        var lo = 0
        var hi = list.size - 1
        var best = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (list[mid].openTimeMs <= t) { best = mid; lo = mid + 1 } else hi = mid - 1
        }
        return if (best >= 0 && t - list[best].openTimeMs <= maxLagMs) best else -1
    }

    internal fun findByTime(list: List<Candle>, t: Long): Int {
        var lo = 0
        var hi = list.size - 1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            val mt = list[mid].openTimeMs
            when {
                mt < t -> lo = mid + 1
                mt > t -> hi = mid - 1
                else -> return mid
            }
        }
        return -1
    }

    private fun pearson(xs: List<Double>, ys: List<Double>): Double {
        val n = xs.size
        if (n < 2) return 0.0
        val mx = xs.average()
        val my = ys.average()
        var sxy = 0.0
        var sxx = 0.0
        var syy = 0.0
        for (i in 0 until n) {
            val dx = xs[i] - mx
            val dy = ys[i] - my
            sxy += dx * dy
            sxx += dx * dx
            syy += dy * dy
        }
        val den = sqrt(sxx * syy)
        return if (den > 1e-18) (sxy / den).coerceIn(-1.0, 1.0) else 0.0
    }

    private data class LineVolumeStats(
        val volA1RelMed: Double,
        val volA2RelMed: Double,
        val volA2ToA1Ratio: Double,
        val avgSinceVsBefore: Double,
        val normSlopeSinceBirth: Double,
        val upVolShareSinceBirth: Double,
        val cumVolVsMedian: Double,
        val sigVolVsAvgSinceBirth: Double,
        val last3VolVsAvgSinceBirth: Double,
        val birthToBreakoutChange: Double
    )

    private fun computeLineVolumeStats(
        candles: List<Candle>,
        pair: TrendlineAnchorPair,
        barIndex: Int,
        medVolWin: Double,
        firstBreakoutBar: Int?
    ): LineVolumeStats {
        val v1 = candles.getOrNull(pair.x1)?.volume ?: medVolWin
        val v2 = candles.getOrNull(pair.x2)?.volume ?: medVolWin
        val volA1Rel = (v1 / medVolWin).coerceIn(0.0, 20.0)
        val volA2Rel = (v2 / medVolWin).coerceIn(0.0, 20.0)
        val a2ToA1 = (v2 / v1.coerceAtLeast(EPS)).coerceIn(0.0, 10.0)

        val birth = pair.birthBar.coerceIn(0, barIndex)
        val sinceCount = (barIndex - birth + 1).coerceAtLeast(1)

        var sinceSum = 0.0
        var upVolSum = 0.0
        for (idx in birth..barIndex) {
            val c = candles[idx]
            sinceSum += c.volume
            if (c.isUpBar) upVolSum += c.volume
        }
        val avgSince = (sinceSum / sinceCount).coerceAtLeast(EPS)

        val preLen = minOf(sinceCount.coerceAtLeast(15), birth)
        val avgBefore = if (preLen > 0) {
            var preSum = 0.0
            for (idx in (birth - preLen) until birth) {
                preSum += candles[idx].volume
            }
            (preSum / preLen).coerceAtLeast(EPS)
        } else {
            medVolWin
        }
        val avgSinceVsBefore = (avgSince / avgBefore).coerceIn(0.0, 10.0)

        val normSlope = if (sinceCount >= 2) {
            val n = sinceCount.toDouble()
            val meanX = (n - 1.0) / 2.0
            var num = 0.0
            var den = 0.0
            for (k in 0 until sinceCount) {
                val dx = k - meanX
                num += dx * (candles[birth + k].volume - avgSince)
                den += dx * dx
            }
            if (den > EPS) ((num / den) / avgSince).coerceIn(-2.0, 2.0) else 0.0
        } else {
            0.0
        }

        val upShare = if (sinceSum > EPS) (upVolSum / sinceSum).coerceIn(0.0, 1.0) else 0.5
        val cumVsMed = (sinceSum / (medVolWin * sinceCount)).coerceIn(0.0, 10.0)

        val sigVolVsBirth = (candles[barIndex].volume / avgSince).coerceIn(0.0, 20.0)
        val last3Start = max(0, barIndex - 2)
        var last3Sum = 0.0
        for (idx in last3Start..barIndex) last3Sum += candles[idx].volume
        val last3Avg = last3Sum / (barIndex - last3Start + 1)
        val last3VolVsBirth = (last3Avg / avgSince).coerceIn(0.0, 20.0)

        val birthVol = candles[birth].volume.coerceAtLeast(EPS)
        val breakoutIdx = (firstBreakoutBar ?: barIndex).coerceIn(birth, barIndex)
        val breakoutVol = candles[breakoutIdx].volume
        val birthToBreakout = ((breakoutVol - birthVol) / birthVol).coerceIn(-1.0, 10.0)

        return LineVolumeStats(
            volA1RelMed = volA1Rel,
            volA2RelMed = volA2Rel,
            volA2ToA1Ratio = a2ToA1,
            avgSinceVsBefore = avgSinceVsBefore,
            normSlopeSinceBirth = normSlope,
            upVolShareSinceBirth = upShare,
            cumVolVsMedian = cumVsMed,
            sigVolVsAvgSinceBirth = sigVolVsBirth,
            last3VolVsAvgSinceBirth = last3VolVsBirth,
            birthToBreakoutChange = birthToBreakout
        )
    }

    private fun rollingMedianVolume(candles: List<Candle>, barIndex: Int, lookback: Int): Double {
        val start = max(0, barIndex - lookback + 1)
        val slice = DoubleArray(barIndex - start + 1)
        for (i in slice.indices) slice[i] = candles[start + i].volume
        slice.sort()
        val mid = slice.size / 2
        return if (slice.size % 2 == 0) 0.5 * (slice[mid - 1] + slice[mid]) else slice[mid]
    }

    private fun returnOver(candles: List<Candle>, barIndex: Int, lag: Int): Double {
        if (barIndex < lag) return 0.0
        val prev = candles[barIndex - lag].close
        if (prev <= EPS) return 0.0
        return (candles[barIndex].close - prev) / prev
    }

    private fun realizedVolatility(candles: List<Candle>, barIndex: Int, window: Int): Double {
        val start = max(1, barIndex - window + 1)
        val count = barIndex - start + 1
        if (count < 2) return 0.0
        val rets = DoubleArray(count)
        var sum = 0.0
        for (i in 0 until count) {
            val c0 = candles[start + i - 1].close.coerceAtLeast(EPS)
            val c1 = candles[start + i].close.coerceAtLeast(EPS)
            val r = ln(c1 / c0)
            rets[i] = r
            sum += r
        }
        val mean = sum / count
        var sq = 0.0
        for (r in rets) {
            val d = r - mean
            sq += d * d
        }
        return sqrt(sq / (count - 1))
    }
}
