package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import com.lrmlc.tradingalerts.engine.TrendlineAnchorPair
import java.time.Instant
import java.time.ZoneOffset
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

object FeatureBuilder {

    private const val EPS = 1e-9

    fun buildFeatures(
        candles: List<Candle>,
        snapshots: List<ConfluenceBarSnapshot>,
        barIndex: Int,
        marketType: MarketType,
        lastSignalOutcome: Int? // 1 = win, 0 = loss, null = none
    ): DoubleArray? {
        if (barIndex !in snapshots.indices || barIndex !in candles.indices) return null
        val snap = snapshots[barIndex]
        val res = snap.resistance ?: return null
        val sup = snap.support ?: return null
        val resVal = snap.resVal ?: return null
        val supVal = snap.supVal ?: return null
        val basis = snap.basis ?: return null
        val hiLine = snap.hiLine ?: return null
        val loLine = snap.loLine ?: return null
        val dir = snap.candidateDirection ?: return null

        val bar = candles[barIndex]
        val close = bar.close.coerceAtLeast(EPS)
        val winLen = 240
        val medVol240 = rollingMedianVolume(candles, barIndex, winLen).coerceAtLeast(EPS)

        val f = DoubleArray(FeatureSpec.FEATURE_COUNT)

        // 0..11 Line geometry
        f[0] = (res.slopePerBar / close) * 100.0
        f[1] = (sup.slopePerBar / close) * 100.0
        f[2] = (hiLine - loLine) / close
        f[3] = (barIndex - res.x1) / 240.0
        f[4] = (barIndex - res.x2) / 240.0
        f[5] = (barIndex - sup.x1) / 240.0
        f[6] = (barIndex - sup.x2) / 240.0
        f[7] = (res.x2 - res.x1) / 240.0
        f[8] = (sup.x2 - sup.x1) / 240.0
        f[9] = snap.resUpdatesLast240 / 240.0
        f[10] = snap.supUpdatesLast240 / 240.0
        f[11] = ((sup.slopePerBar - res.slopePerBar) / close) * 100.0

        // 12..22 Position in structure
        f[12] = (bar.low - hiLine) / close
        f[13] = (loLine - bar.high) / close
        f[14] = (close - hiLine) / close
        f[15] = (close - loLine) / close
        f[16] = (close - basis) / close
        f[17] = if (abs(hiLine - resVal) <= 1e-12) 1.0 else 0.0
        f[18] = if (abs(loLine - supVal) <= 1e-12) 1.0 else 0.0
        val prevBasis = snap.prevBasis ?: basis
        f[19] = ((basis - prevBasis) / close) * 100.0
        val structDist = when (dir) {
            TradeDirection.LONG -> (close - loLine).coerceAtLeast(EPS)
            TradeDirection.SHORT -> (hiLine - close).coerceAtLeast(EPS)
        }
        val slDistSafe = snap.slDist.coerceAtLeast(EPS)
        f[20] = (structDist / slDistSafe).coerceIn(0.0, 5.0)
        f[21] = (snap.tpDist / structDist).coerceIn(0.0, 10.0)
        f[22] = if (abs(hiLine - basis) <= 1e-12 || abs(loLine - basis) <= 1e-12) 1.0 else 0.0

        // 23..27 Gate & history
        val oppRaw = when (dir) {
            TradeDirection.LONG -> snap.barsSinceLastRawShort
            TradeDirection.SHORT -> snap.barsSinceLastRawLong
        } ?: 240
        f[23] = (oppRaw / 240.0).coerceIn(0.0, 4.0)
        f[24] = ((snap.barsSinceLastSignal ?: 240) / 240.0).coerceIn(0.0, 4.0)
        f[25] = when (lastSignalOutcome) {
            1 -> 1.0
            0 -> -1.0
            else -> 0.0
        }
        f[26] = snap.recentRiskRejectionsLast60 / 10.0
        f[27] = snap.consecutiveBarsOutside / 20.0

        // 28..55 Volume behavior from birth of resistance, support, and pair
        val resStats = computeLineVolumeStats(
            candles = candles,
            pair = res,
            barIndex = barIndex,
            medVol240 = medVol240,
            firstBreakoutBar = snap.firstOutsideBarSinceResBirth
        )
        val supStats = computeLineVolumeStats(
            candles = candles,
            pair = sup,
            barIndex = barIndex,
            medVol240 = medVol240,
            firstBreakoutBar = snap.firstOutsideBarSinceSupBirth
        )

        // Anchors
        f[28] = resStats.volA1RelMed
        f[29] = resStats.volA2RelMed
        f[30] = resStats.volA2ToA1Ratio
        f[31] = supStats.volA1RelMed
        f[32] = supStats.volA2RelMed
        f[33] = supStats.volA2ToA1Ratio
        f[34] = 0.5 * (resStats.volA2ToA1Ratio + supStats.volA2ToA1Ratio)

        // Since birth vs before birth
        f[35] = resStats.avgSinceVsBefore
        f[36] = supStats.avgSinceVsBefore
        f[37] = 0.5 * (resStats.avgSinceVsBefore + supStats.avgSinceVsBefore)

        // Normalized slope of volume since birth
        f[38] = resStats.normSlopeSinceBirth
        f[39] = supStats.normSlopeSinceBirth
        f[40] = 0.5 * (resStats.normSlopeSinceBirth + supStats.normSlopeSinceBirth)

        // Up-bar volume share since birth
        f[41] = resStats.upVolShareSinceBirth
        f[42] = supStats.upVolShareSinceBirth
        f[43] = 0.5 * (resStats.upVolShareSinceBirth + supStats.upVolShareSinceBirth)

        // Cumulative volume since birth vs median over same bar count
        f[44] = resStats.cumVolVsMedian
        f[45] = supStats.cumVolVsMedian
        f[46] = 0.5 * (resStats.cumVolVsMedian + supStats.cumVolVsMedian)

        // Signal bar and last 3 bars relative to avg since birth
        f[47] = resStats.sigVolVsAvgSinceBirth
        f[48] = resStats.last3VolVsAvgSinceBirth
        f[49] = supStats.sigVolVsAvgSinceBirth
        f[50] = supStats.last3VolVsAvgSinceBirth
        f[51] = 0.5 * (resStats.sigVolVsAvgSinceBirth + supStats.sigVolVsAvgSinceBirth)
        f[52] = 0.5 * (resStats.last3VolVsAvgSinceBirth + supStats.last3VolVsAvgSinceBirth)

        // Volume change between birth and first bar outside all 3 levels
        f[53] = resStats.birthToBreakoutChange
        f[54] = supStats.birthToBreakoutChange
        f[55] = 0.5 * (resStats.birthToBreakoutChange + supStats.birthToBreakoutChange)

        // 56..64 Price behavior
        val range = (bar.high - bar.low).coerceAtLeast(EPS)
        f[56] = (bar.high - bar.low) / close
        f[57] = (abs(bar.close - bar.open) / range).coerceIn(0.0, 1.0)
        f[58] = ((bar.close - bar.low) / range).coerceIn(0.0, 1.0)
        f[59] = returnOver(candles, barIndex, 1)
        f[60] = returnOver(candles, barIndex, 5)
        f[61] = returnOver(candles, barIndex, 15)
        f[62] = returnOver(candles, barIndex, 60)
        f[63] = realizedVolatility(candles, barIndex, 60)
        f[64] = (bar.volume / medVol240).coerceIn(0.0, 20.0)

        // 65..70 Context
        val dt = Instant.ofEpochMilli(bar.openTimeMs).atOffset(ZoneOffset.UTC)
        val hourAngle = 2.0 * PI * (dt.hour + dt.minute / 60.0) / 24.0
        val dayAngle = 2.0 * PI * (dt.dayOfWeek.value - 1) / 7.0
        f[65] = sin(hourAngle)
        f[66] = cos(hourAngle)
        f[67] = sin(dayAngle)
        f[68] = cos(dayAngle)
        f[69] = if (dir == TradeDirection.LONG) 1.0 else -1.0
        f[70] = if (marketType == MarketType.PERP) 1.0 else 0.0

        // Guard any NaN/Infinite
        for (i in f.indices) {
            if (!f[i].isFinite()) f[i] = 0.0
        }
        return f
    }

    private data class LineVolumeStats(
        val volA1RelMed: Double,
        val volA2RelMed: Double,
        val volA2ToA1Ratio: Double,
        val avgSinceVsBefore: Double,
        val normSlopeSinceBirth: Double,
        val upVolShareSinceBirth: Double,
        val cumVolVsMedian: Double,
        val sigVolVsAvgSinceBirth: Double,
        val last3VolVsAvgSinceBirth: Double,
        val birthToBreakoutChange: Double
    )

    private fun computeLineVolumeStats(
        candles: List<Candle>,
        pair: TrendlineAnchorPair,
        barIndex: Int,
        medVol240: Double,
        firstBreakoutBar: Int?
    ): LineVolumeStats {
        val v1 = candles.getOrNull(pair.x1)?.volume ?: medVol240
        val v2 = candles.getOrNull(pair.x2)?.volume ?: medVol240
        val volA1Rel = (v1 / medVol240).coerceIn(0.0, 20.0)
        val volA2Rel = (v2 / medVol240).coerceIn(0.0, 20.0)
        val a2ToA1 = (v2 / v1.coerceAtLeast(EPS)).coerceIn(0.0, 10.0)

        val birth = pair.birthBar.coerceIn(0, barIndex)
        val sinceCount = (barIndex - birth + 1).coerceAtLeast(1)

        var sinceSum = 0.0
        var upVolSum = 0.0
        for (idx in birth..barIndex) {
            val c = candles[idx]
            sinceSum += c.volume
            if (c.isUpBar) upVolSum += c.volume
        }
        val avgSince = (sinceSum / sinceCount).coerceAtLeast(EPS)

        // Average volume before birth (using same window length or up to 240 bars before birth)
        val preLen = minOf(sinceCount.coerceAtLeast(15), birth)
        val avgBefore = if (preLen > 0) {
            var preSum = 0.0
            for (idx in (birth - preLen) until birth) {
                preSum += candles[idx].volume
            }
            (preSum / preLen).coerceAtLeast(EPS)
        } else {
            medVol240
        }
        val avgSinceVsBefore = (avgSince / avgBefore).coerceIn(0.0, 10.0)

        // Linear regression slope of volume since birth normalized by avgSince
        val normSlope = if (sinceCount >= 2) {
            val n = sinceCount.toDouble()
            val meanX = (n - 1.0) / 2.0
            var num = 0.0
            var den = 0.0
            for (k in 0 until sinceCount) {
                val dx = k - meanX
                num += dx * (candles[birth + k].volume - avgSince)
                den += dx * dx
            }
            if (den > EPS) ((num / den) / avgSince).coerceIn(-2.0, 2.0) else 0.0
        } else {
            0.0
        }

        val upShare = if (sinceSum > EPS) (upVolSum / sinceSum).coerceIn(0.0, 1.0) else 0.5
        val cumVsMed = (sinceSum / (medVol240 * sinceCount)).coerceIn(0.0, 10.0)

        val sigVolVsBirth = (candles[barIndex].volume / avgSince).coerceIn(0.0, 20.0)
        val last3Start = max(0, barIndex - 2)
        var last3Sum = 0.0
        for (idx in last3Start..barIndex) last3Sum += candles[idx].volume
        val last3Avg = last3Sum / (barIndex - last3Start + 1)
        val last3VolVsBirth = (last3Avg / avgSince).coerceIn(0.0, 20.0)

        val birthVol = candles[birth].volume.coerceAtLeast(EPS)
        val breakoutIdx = (firstBreakoutBar ?: barIndex).coerceIn(birth, barIndex)
        val breakoutVol = candles[breakoutIdx].volume
        val birthToBreakout = ((breakoutVol - birthVol) / birthVol).coerceIn(-1.0, 10.0)

        return LineVolumeStats(
            volA1RelMed = volA1Rel,
            volA2RelMed = volA2Rel,
            volA2ToA1Ratio = a2ToA1,
            avgSinceVsBefore = avgSinceVsBefore,
            normSlopeSinceBirth = normSlope,
            upVolShareSinceBirth = upShare,
            cumVolVsMedian = cumVsMed,
            sigVolVsAvgSinceBirth = sigVolVsBirth,
            last3VolVsAvgSinceBirth = last3VolVsBirth,
            birthToBreakoutChange = birthToBreakout
        )
    }

    private fun rollingMedianVolume(candles: List<Candle>, barIndex: Int, lookback: Int): Double {
        val start = max(0, barIndex - lookback + 1)
        val slice = DoubleArray(barIndex - start + 1)
        for (i in slice.indices) slice[i] = candles[start + i].volume
        slice.sort()
        val mid = slice.size / 2
        return if (slice.size % 2 == 0) 0.5 * (slice[mid - 1] + slice[mid]) else slice[mid]
    }

    private fun returnOver(candles: List<Candle>, barIndex: Int, lag: Int): Double {
        if (barIndex < lag) return 0.0
        val prev = candles[barIndex - lag].close
        if (prev <= EPS) return 0.0
        return (candles[barIndex].close - prev) / prev
    }

    private fun realizedVolatility(candles: List<Candle>, barIndex: Int, window: Int): Double {
        val start = max(1, barIndex - window + 1)
        val count = barIndex - start + 1
        if (count < 2) return 0.0
        val rets = DoubleArray(count)
        var sum = 0.0
        for (i in 0 until count) {
            val c0 = candles[start + i - 1].close.coerceAtLeast(EPS)
            val c1 = candles[start + i].close.coerceAtLeast(EPS)
            val r = ln(c1 / c0)
            rets[i] = r
            sum += r
        }
        val mean = sum / count
        var sq = 0.0
        for (r in rets) {
            val d = r - mean
            sq += d * d
        }
        return sqrt(sq / (count - 1))
    }
}
