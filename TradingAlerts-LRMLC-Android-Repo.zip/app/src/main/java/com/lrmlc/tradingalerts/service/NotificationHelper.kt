package com.lrmlc.tradingalerts.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.lrmlc.tradingalerts.MainActivity
import com.lrmlc.tradingalerts.R
import com.lrmlc.tradingalerts.data.local.SignalCandidateDao
import com.lrmlc.tradingalerts.data.local.WatchlistDao
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import java.time.LocalTime

class NotificationHelper(
    private val context: Context,
    private val watchlistDao: WatchlistDao,
    private val signalDao: SignalCandidateDao
) {
    companion object {
        const val CHANNEL_SIGNALS = "lrmlc_signals"
        const val CHANNEL_EXITS = "lrmlc_exits"
        const val CHANNEL_MONITORING = "lrmlc_monitoring"
        const val CHANNEL_OUTCOMES = "lrmlc_outcomes"

        const val PERSISTENT_NOTIFICATION_ID = 1001
        const val EXTRA_OPEN_SYMBOL = "open_symbol"
    }

    private val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannels() {
        val signals = NotificationChannel(
            CHANNEL_SIGNALS,
            context.getString(R.string.channel_signals_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.channel_signals_desc)
            enableVibration(true)
        }

        val exits = NotificationChannel(
            CHANNEL_EXITS,
            context.getString(R.string.channel_exits_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.channel_exits_desc)
            enableVibration(true)
        }

        val monitoring = NotificationChannel(
            CHANNEL_MONITORING,
            context.getString(R.string.channel_monitoring_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = context.getString(R.string.channel_monitoring_desc)
            setShowBadge(false)
            setSound(null, null)
        }

        val outcomes = NotificationChannel(
            CHANNEL_OUTCOMES,
            context.getString(R.string.channel_outcomes_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.channel_outcomes_desc)
        }

        manager.createNotificationChannels(listOf(signals, exits, monitoring, outcomes))
    }

    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun isInQuietHours(settings: AppSettings, nowLocal: LocalTime = LocalTime.now()): Boolean {
        if (!settings.quietHoursEnabled) return false
        val nowMin = nowLocal.hour * 60 + nowLocal.minute
        val start = settings.quietHoursStartMinute
        val end = settings.quietHoursEndMinute
        return if (start <= end) {
            nowMin in start until end
        } else {
            nowMin >= start || nowMin < end
        }
    }

    fun notifySignal(signal: SignalCandidateEntity, settings: AppSettings) {
        if (!hasNotificationPermission() || isInQuietHours(settings) || signal.notified) return
        ensureChannels()
        val dir = TradeDirection.valueOf(signal.direction)
        val cleanSym = signal.symbol.stripUsdtSuffix()
        val title = "${dir.emoji} ${dir.label} • $cleanSym"
        val entryStr = PersistentNotificationFormatter.formatPrice(signal.entryPrice)
        val tpStr = PersistentNotificationFormatter.formatPrice(signal.appliedTp)
        val slStr = PersistentNotificationFormatter.formatPrice(signal.appliedSl)
        val confSuffix = if (!signal.modelWasTrained) {
            " · Unfiltered"
        } else {
            signal.pWin?.let { " · ${(it * 100).toInt()}%" }.orEmpty()
        }
        val body = "Entry $entryStr · TP $tpStr · SL $slStr$confSuffix"

        val notif = NotificationCompat.Builder(context, CHANNEL_SIGNALS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(chartDeepLinkIntent(signal.symbol, signal.signalId.hashCode()))
            .build()

        manager.notify(signal.signalId.hashCode(), notif)
    }

    fun notifyExitWarning(trade: SignalCandidateEntity, reason: String, settings: AppSettings) {
        if (!hasNotificationPermission() || isInQuietHours(settings)) return
        ensureChannels()
        val dir = TradeDirection.valueOf(trade.direction)
        val cleanSym = trade.symbol.stripUsdtSuffix()
        val title = "${dir.emoji} Exit • $cleanSym"
        val tpStr = PersistentNotificationFormatter.formatPrice(trade.appliedTp)
        val slStr = PersistentNotificationFormatter.formatPrice(trade.appliedSl)
        val body = "$reason (TP $tpStr · SL $slStr)"

        val notif = NotificationCompat.Builder(context, CHANNEL_EXITS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(chartDeepLinkIntent(trade.symbol, ("EXIT_" + trade.symbol).hashCode()))
            .build()

        manager.notify(("EXIT_" + trade.signalId).hashCode(), notif)
    }

    fun notifyOutcome(trade: SignalCandidateEntity, settings: AppSettings) {
        if (!hasNotificationPermission() || isInQuietHours(settings)) return
        ensureChannels()
        val cleanSym = trade.symbol.stripUsdtSuffix()
        val isTp = trade.status == "CLOSED_TP"
        val title = if (isTp) "TP Hit • $cleanSym" else "SL Hit • $cleanSym"
        val exitStr = trade.exitPrice?.let { PersistentNotificationFormatter.formatPrice(it) } ?: "—"
        val body = "${trade.direction} closed at $exitStr"

        val notif = NotificationCompat.Builder(context, CHANNEL_OUTCOMES)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setContentIntent(chartDeepLinkIntent(trade.symbol, ("OUT_" + trade.signalId).hashCode()))
            .build()

        manager.notify(("OUT_" + trade.signalId).hashCode(), notif)
    }

    fun notifyFilteredSignal(signal: SignalCandidateEntity, settings: AppSettings) {
        if (!hasNotificationPermission() || isInQuietHours(settings)) return
        ensureChannels()
        val dir = TradeDirection.valueOf(signal.direction)
        val cleanSym = signal.symbol.stripUsdtSuffix()
        val pct = signal.pWin?.let { "${(it * 100).toInt()}%" } ?: "—"
        val title = "Filtered ${dir.label} • $cleanSym ($pct)"
        val tpStr = PersistentNotificationFormatter.formatPrice(signal.appliedTp)
        val slStr = PersistentNotificationFormatter.formatPrice(signal.appliedSl)
        val body = "Tracked as shadow trade · TP $tpStr · SL $slStr"

        val notif = NotificationCompat.Builder(context, CHANNEL_OUTCOMES)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setContentIntent(chartDeepLinkIntent(signal.symbol, ("FLT_" + signal.signalId).hashCode()))
            .build()

        manager.notify(("FLT_" + signal.signalId).hashCode(), notif)
    }

    suspend fun buildPersistentNotification(
        exchange: ExchangeId,
        marketType: MarketType,
        monitoringOn: Boolean
    ): Notification {
        ensureChannels()
        val watchlist = watchlistDao.getWatchlist(exchange.name, marketType.name)
        val activeTrades = signalDao.getActiveTrades(exchange.name, marketType.name)
            .associateBy { it.symbol }

        val positioned = watchlist
            .filter { it.inPosition }
            .map { w ->
                val trade = activeTrades[w.symbol]
                val dirStr = trade?.direction ?: w.activeDirection
                val dir = dirStr?.let { runCatching { TradeDirection.valueOf(it) }.getOrNull() }
                PositionedAssetBannerItem(
                    symbol = w.symbol,
                    direction = dir,
                    tpPrice = trade?.appliedTp,
                    slPrice = trade?.appliedSl,
                    updatedAtMs = maxOf(w.inPositionUpdatedAtMs, trade?.signalTimeMs ?: 0L)
                )
            }

        val content = PersistentNotificationFormatter.format(monitoringOn, positioned)
        val openMain = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(context, CHANNEL_MONITORING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(content.title)
            .setContentText(content.body)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openMain)
            .build()
    }

    suspend fun refreshPersistentNotification(
        exchange: ExchangeId,
        marketType: MarketType,
        monitoringOn: Boolean
    ) {
        if (!hasNotificationPermission() || !monitoringOn) return
        val notif = buildPersistentNotification(exchange, marketType, monitoringOn)
        manager.notify(PERSISTENT_NOTIFICATION_ID, notif)
    }

    private fun chartDeepLinkIntent(symbol: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_SYMBOL, symbol)
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
