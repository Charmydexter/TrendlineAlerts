package com.lrmlc.tradingalerts.data.model

import kotlinx.serialization.Serializable

@Serializable
enum class ExchangeId(val displayName: String) {
    BYBIT("Bybit"),
    BINANCE("Binance")
}

@Serializable
enum class MarketType(val displayName: String) {
    SPOT("Spot"),
    PERP("Perp")
}

@Serializable
enum class TradeDirection(val emoji: String, val label: String) {
    LONG("👆", "LONG"),
    SHORT("👇", "SHORT")
}

@Serializable
enum class ChartStyle {
    HEIKIN_ASHI,
    CANDLES
}

@Serializable
enum class ThresholdMode {
    AUTO_EXPECTANCY,
    MANUAL
}

@Serializable
enum class TimeoutLabelMode {
    SIGN_OF_NET_AFTER_FEES,
    EXCLUDE
}

@Serializable
data class Candle(
    val openTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
) {
    val ohlc4: Double get() = (open + high + low + close) / 4.0
    val isUpBar: Boolean get() = close > open
}

@Serializable
data class InstrumentInfo(
    val exchange: ExchangeId,
    val marketType: MarketType,
    val symbol: String, // e.g. SOLUSDT
    val baseAsset: String, // e.g. SOL
    val quoteAsset: String, // e.g. USDT
    val pricePrecision: Int = 4,
    val tickSize: Double = 0.0001
)

@Serializable
data class EngineConfig(
    val windowLength: Int = 240,
    val minGap: Int = 30,
    val capitalUsd: Double = 20.0,
    val maxLossUsd: Double = 0.50,
    val takeProfitUsd: Double = 0.50,
    val roundTripFeeRate: Double = 0.001, // 0.1%
    val labelHorizonBars: Int = 60,
    val timeoutLabelMode: TimeoutLabelMode = TimeoutLabelMode.SIGN_OF_NET_AFTER_FEES
)

@Serializable
data class AppSettings(
    val onboardingCompleted: Boolean = false,
    val exchange: ExchangeId = ExchangeId.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val chartStyle: ChartStyle = ChartStyle.HEIKIN_ASHI,
    val darkTheme: Boolean = true,
    val engineConfig: EngineConfig = EngineConfig(),
    val autoSlEnabled: Boolean = true,
    val autoTpEnabled: Boolean = true,
    val thresholdMode: ThresholdMode = ThresholdMode.AUTO_EXPECTANCY,
    val manualThreshold: Double = 0.55,
    val minSamplesForPerAssetModel: Int = 60,
    val retentionDays: Int = 42,
    val keepMonitoringInBackground: Boolean = false,
    val startOnBoot: Boolean = false,
    val notifyTpHit: Boolean = false,
    val notifySlHit: Boolean = false,
    val notifyFilteredSignals: Boolean = false,
    val quietHoursEnabled: Boolean = false,
    val quietHoursStartMinute: Int = 23 * 60, // 23:00
    val quietHoursEndMinute: Int = 7 * 60     // 07:00
)

fun String.stripUsdtSuffix(): String {
    val upper = trim().uppercase()
    return if (upper.endsWith("USDT") && upper.length > 4) upper.dropLast(4) else upper
}

fun String.ensureUsdtSymbol(): String {
    val upper = trim().uppercase()
    return if (upper.endsWith("USDT")) upper else "${upper}USDT"
}

object DefaultWatchlist {
    val DEFAULT_BASES = listOf(
        "1INCH", "GRAM", "HYPE", "XLM", "XRP",
        "SOL", "ZEC", "SUI", "SEI", "HBAR",
        "APT", "CAKE", "ATOM", "FIL", "INJ",
        "NEAR", "IOTA", "POL", "SAND", "WLD"
    )
    const val MAX_WATCHLIST_SIZE = 20
    const val MAX_RECYCLE_BIN_SIZE = 10
}
