package com.lrmlc.tradingalerts.data.model

import kotlinx.serialization.Serializable

@Serializable
enum class ExchangeId(val displayName: String) {
    BYBIT("Bybit"),
    BINANCE("Binance")
}

@Serializable
enum class MarketType(val displayName: String) {
    SPOT("Spot"),
    PERP("Perp")
}

@Serializable
enum class TradeDirection(val emoji: String, val label: String) {
    LONG("👆", "LONG"),
    SHORT("👇", "SHORT")
}

@Serializable
enum class ChartStyle {
    HEIKIN_ASHI,
    CANDLES
}

@Serializable
enum class ThresholdMode {
    AUTO_EXPECTANCY,
    MANUAL
}

@Serializable
enum class TimeoutLabelMode {
    SIGN_OF_NET_AFTER_FEES,
    EXCLUDE
}

@Serializable
enum class AccentColor(val label: String) {
    BLUE("Blue"),
    TEAL("Teal"),
    VIOLET("Violet"),
    AMBER("Amber")
}

@Serializable
data class RangePreset(
    val id: String,
    val windowBars: Int,
    val minGapBars: Int,
    val label: String
)

object RangePresets {
    val R30 = RangePreset(id = "R30", windowBars = 30, minGapBars = 3, label = "30m")
    val R60 = RangePreset(id = "R60", windowBars = 60, minGapBars = 7, label = "1h")
    val R120 = RangePreset(id = "R120", windowBars = 120, minGapBars = 15, label = "2h")
    val R240 = RangePreset(id = "R240", windowBars = 240, minGapBars = 30, label = "4h")

    val ALL: List<RangePreset> = listOf(R30, R60, R120, R240)
    val DEFAULT: RangePreset = R240

    fun byId(id: String?): RangePreset = ALL.firstOrNull { it.id == id } ?: DEFAULT
}

@Serializable
data class Candle(
    val openTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
) {
    val ohlc4: Double get() = (open + high + low + close) / 4.0
    val isUpBar: Boolean get() = close > open
}

@Serializable
data class InstrumentInfo(
    val exchange: ExchangeId,
    val marketType: MarketType,
    val symbol: String, // e.g. SOLUSDT
    val baseAsset: String, // e.g. SOL
    val quoteAsset: String, // e.g. USDT
    val pricePrecision: Int = 4,
    val tickSize: Double = 0.0001
)

@Serializable
data class EngineConfig(
    @Deprecated("Fixed range presets in RangePresets.ALL are used instead.")
    val windowLength: Int = 240,
    @Deprecated("Fixed range presets in RangePresets.ALL are used instead.")
    val minGap: Int = 30,
    val capitalUsd: Double = 20.0,
    val maxLossUsd: Double = 0.50,
    val takeProfitUsd: Double = 0.50,
    val roundTripFeeRate: Double = 0.001, // 0.1%
    val labelHorizonBars: Int = 60,
    val timeoutLabelMode: TimeoutLabelMode = TimeoutLabelMode.SIGN_OF_NET_AFTER_FEES
)

@Serializable
data class AppSettings(
    val onboardingCompleted: Boolean = false,
    val exchange: ExchangeId = ExchangeId.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val chartStyle: ChartStyle = ChartStyle.HEIKIN_ASHI,
    val darkTheme: Boolean = true,
    val accentColor: AccentColor = AccentColor.BLUE,
    val engineConfig: EngineConfig = EngineConfig(),
    val autoSlEnabled: Boolean = true,
    val autoTpEnabled: Boolean = true,
    val thresholdMode: ThresholdMode = ThresholdMode.AUTO_EXPECTANCY,
    val manualThreshold: Double = 0.55,
    val minSamplesForPerAssetModel: Int = 60,
    val retentionDays: Int = 42,
    val keepMonitoringInBackground: Boolean = false,
    val startOnBoot: Boolean = false,
    val autoCloseOnTp: Boolean = false,
    val autoCloseOnSl: Boolean = true,
    val notifyTpHit: Boolean = false,
    val notifySlHit: Boolean = false,
    val notifyFilteredSignals: Boolean = false,
    val notifyExitMl: Boolean = true,
    val notifyExitStructure: Boolean = true,
    /** Optional notification "Possible run past TP" - off by default. */
    val notifyRunOn: Boolean = false,
    /** Backup export: include stored 1m candles. On by default; remembered so the switch does not reset. */
    val backupIncludeCandles: Boolean = true,
    val quietHoursEnabled: Boolean = false,
    val quietHoursStartMinute: Int = 23 * 60, // 23:00
    val quietHoursEndMinute: Int = 7 * 60,    // 07:00
    val lastSeenAlertTimeMs: Long = 0L,
    /** Master asset used for market-context features (BTC by default). Only one is ever active. */
    val marketContextAsset: String = DEFAULT_MASTER_ASSET,
    /** Backend store of up to [MAX_MASTER_SLOTS] master datasets (active + retired ones being phased out). */
    val masterSlots: List<MasterSlot> = emptyList()
)

const val DEFAULT_MASTER_ASSET = "BTCUSDT"
const val MAX_MASTER_SLOTS = 5

/**
 * One backend slot holding the 1-minute history of a master asset.
 * [retiredAtMs] == 0 means this slot is the active master; otherwise its data is being phased out.
 */
@Serializable
data class MasterSlot(
    val exchange: String,
    val marketType: String,
    val symbol: String,
    val retiredAtMs: Long = 0L,
    val retiredDayCount: Int = 0
)

fun String.stripUsdtSuffix(): String {
    val upper = trim().uppercase()
    return if (upper.endsWith("USDT") && upper.length > 4) upper.dropLast(4) else upper
}

fun String.ensureUsdtSymbol(): String {
    val upper = trim().uppercase()
    return if (upper.endsWith("USDT")) upper else "${upper}USDT"
}

object DefaultWatchlist {
    val DEFAULT_BASES = listOf(
        "1INCH", "GRAM", "HYPE", "XLM", "XRP",
        "SOL", "ZEC", "SUI", "SEI", "HBAR",
        "APT", "CAKE", "ATOM", "FIL", "INJ",
        "NEAR", "IOTA", "POL", "SAND", "WLD"
    )
    const val MAX_WATCHLIST_SIZE = 20
    const val MAX_RECYCLE_BIN_SIZE = 10
}
