package com.lrmlc.tradingalerts.data.local

import com.lrmlc.tradingalerts.data.model.Candle

data class TimeGap(
    val startOpenTimeMs: Long,
    val endOpenTimeMs: Long
) {
    val expectedBars: Int
        get() = (((endOpenTimeMs - startOpenTimeMs) / DayChunkCodec.MILLIS_PER_MINUTE) + 1).toInt().coerceAtLeast(0)
}

object GapDetector {
    fun floorToMinute(timeMs: Long): Long =
        (timeMs / DayChunkCodec.MILLIS_PER_MINUTE) * DayChunkCodec.MILLIS_PER_MINUTE

    fun latestClosedMinuteOpenMs(nowMs: Long): Long {
        val currentMinuteOpen = floorToMinute(nowMs)
        return currentMinuteOpen - DayChunkCodec.MILLIS_PER_MINUTE
    }

    /**
     * Given a desired inclusive range [startOpenTimeMs, endOpenTimeMs] of 1-minute candle open timestamps
     * and the already-stored candles in that range, returns contiguous missing minute ranges sorted oldest->newest.
     */
    fun findMissingRanges(
        startOpenTimeMs: Long,
        endOpenTimeMs: Long,
        storedCandles: List<Candle>
    ): List<TimeGap> {
        val alignedStart = floorToMinute(startOpenTimeMs)
        val alignedEnd = floorToMinute(endOpenTimeMs)
        if (alignedEnd < alignedStart) return emptyList()

        val present = HashSet<Long>(storedCandles.size * 2 + 16)
        for (c in storedCandles) {
            val t = floorToMinute(c.openTimeMs)
            if (t in alignedStart..alignedEnd) {
                present.add(t)
            }
        }

        val gaps = ArrayList<TimeGap>()
        var gapStart: Long? = null
        var cursor = alignedStart
        while (cursor <= alignedEnd) {
            if (!present.contains(cursor)) {
                if (gapStart == null) gapStart = cursor
            } else if (gapStart != null) {
                gaps.add(TimeGap(gapStart, cursor - DayChunkCodec.MILLIS_PER_MINUTE))
                gapStart = null
            }
            cursor += DayChunkCodec.MILLIS_PER_MINUTE
        }
        if (gapStart != null) {
            gaps.add(TimeGap(gapStart, alignedEnd))
        }
        return gaps
    }

    /**
     * Fast chunk-level check using day chunk summaries before decoding full blobs when possible.
     */
    fun findIncompleteOrMissingDays(
        startOpenTimeMs: Long,
        endOpenTimeMs: Long,
        dayCounts: Map<Long, Int>
    ): List<Long> {
        val startDay = DayChunkCodec.utcDayIndexOf(floorToMinute(startOpenTimeMs))
        val endDay = DayChunkCodec.utcDayIndexOf(floorToMinute(endOpenTimeMs))
        val missingDays = ArrayList<Long>()
        for (day in startDay..endDay) {
            val dayStart = day * DayChunkCodec.MILLIS_PER_DAY
            val dayEnd = dayStart + (DayChunkCodec.MINUTES_PER_DAY - 1) * DayChunkCodec.MILLIS_PER_MINUTE
            val expectedStart = maxOf(floorToMinute(startOpenTimeMs), dayStart)
            val expectedEnd = minOf(floorToMinute(endOpenTimeMs), dayEnd)
            val expectedCount = (((expectedEnd - expectedStart) / DayChunkCodec.MILLIS_PER_MINUTE) + 1).toInt()
            val storedCount = dayCounts[day] ?: 0
            if (storedCount < expectedCount) {
                missingDays.add(day)
            }
        }
        return missingDays
    }
}
