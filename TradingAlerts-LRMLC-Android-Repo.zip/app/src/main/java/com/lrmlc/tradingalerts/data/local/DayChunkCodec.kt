package com.lrmlc.tradingalerts.data.local

import com.lrmlc.tradingalerts.data.model.Candle
import java.nio.ByteBuffer
import java.nio.ByteOrder

object DayChunkCodec {
    private const val MAGIC_0: Byte = 'L'.code.toByte()
    private const val MAGIC_1: Byte = 'R'.code.toByte()
    private const val MAGIC_2: Byte = 'M'.code.toByte()
    private const val MAGIC_3: Byte = 'C'.code.toByte()
    private const val VERSION: Byte = 1
    private const val HEADER_BYTES = 7
    private const val RECORD_BYTES = 42
    const val MILLIS_PER_MINUTE = 60_000L
    const val MILLIS_PER_DAY = 86_400_000L
    const val MINUTES_PER_DAY = 1440

    data class EncodedDayChunk(
        val utcDayIndex: Long,
        val candleCount: Int,
        val minOpenTimeMs: Long,
        val maxOpenTimeMs: Long,
        val blob: ByteArray
    )

    fun utcDayIndexOf(openTimeMs: Long): Long = Math.floorDiv(openTimeMs, MILLIS_PER_DAY)

    fun minuteOfDayOf(openTimeMs: Long): Int {
        val mod = Math.floorMod(openTimeMs, MILLIS_PER_DAY)
        return (mod / MILLIS_PER_MINUTE).toInt()
    }

    fun encodeDay(utcDayIndex: Long, candles: List<Candle>): EncodedDayChunk {
        val dayStartMs = utcDayIndex * MILLIS_PER_DAY
        val byMinute = HashMap<Int, Candle>(candles.size.coerceAtMost(MINUTES_PER_DAY))
        for (c in candles) {
            if (utcDayIndexOf(c.openTimeMs) != utcDayIndex) continue
            val minute = minuteOfDayOf(c.openTimeMs)
            if (minute in 0 until MINUTES_PER_DAY) {
                val alignedTime = dayStartMs + minute * MILLIS_PER_MINUTE
                byMinute[minute] = c.copy(openTimeMs = alignedTime)
            }
        }
        val sortedMinutes = byMinute.keys.sorted()
        val count = sortedMinutes.size
        val buf = ByteBuffer.allocate(HEADER_BYTES + count * RECORD_BYTES)
            .order(ByteOrder.BIG_ENDIAN)
        buf.put(MAGIC_0)
        buf.put(MAGIC_1)
        buf.put(MAGIC_2)
        buf.put(MAGIC_3)
        buf.put(VERSION)
        buf.putShort(count.toShort())

        var minT = Long.MAX_VALUE
        var maxT = Long.MIN_VALUE
        for (minute in sortedMinutes) {
            val c = byMinute.getValue(minute)
            if (c.openTimeMs < minT) minT = c.openTimeMs
            if (c.openTimeMs > maxT) maxT = c.openTimeMs
            buf.putShort(minute.toShort())
            buf.putDouble(c.open)
            buf.putDouble(c.high)
            buf.putDouble(c.low)
            buf.putDouble(c.close)
            buf.putDouble(c.volume)
        }
        if (count == 0) {
            minT = 0L
            maxT = 0L
        }
        return EncodedDayChunk(
            utcDayIndex = utcDayIndex,
            candleCount = count,
            minOpenTimeMs = minT,
            maxOpenTimeMs = maxT,
            blob = buf.array()
        )
    }

    fun decodeDay(utcDayIndex: Long, blob: ByteArray): List<Candle> {
        if (blob.size < HEADER_BYTES) return emptyList()
        val buf = ByteBuffer.wrap(blob).order(ByteOrder.BIG_ENDIAN)
        if (buf.get() != MAGIC_0 || buf.get() != MAGIC_1 || buf.get() != MAGIC_2 || buf.get() != MAGIC_3) {
            return emptyList()
        }
        val version = buf.get()
        if (version != VERSION) return emptyList()
        val count = buf.getShort().toInt() and 0xFFFF
        if (blob.size < HEADER_BYTES + count * RECORD_BYTES) return emptyList()

        val dayStartMs = utcDayIndex * MILLIS_PER_DAY
        val result = ArrayList<Candle>(count)
        for (i in 0 until count) {
            val minute = buf.getShort().toInt() and 0xFFFF
            val o = buf.getDouble()
            val h = buf.getDouble()
            val l = buf.getDouble()
            val c = buf.getDouble()
            val v = buf.getDouble()
            result.add(
                Candle(
                    openTimeMs = dayStartMs + minute * MILLIS_PER_MINUTE,
                    open = o,
                    high = h,
                    low = l,
                    close = c,
                    volume = v
                )
            )
        }
        return result
    }

    fun mergeDay(utcDayIndex: Long, existingBlob: ByteArray?, incoming: List<Candle>): EncodedDayChunk {
        val existing = if (existingBlob != null) decodeDay(utcDayIndex, existingBlob) else emptyList()
        if (existing.isEmpty()) return encodeDay(utcDayIndex, incoming)
        val combined = ArrayList<Candle>(existing.size + incoming.size)
        combined.addAll(existing)
        combined.addAll(incoming)
        return encodeDay(utcDayIndex, combined)
    }
}
