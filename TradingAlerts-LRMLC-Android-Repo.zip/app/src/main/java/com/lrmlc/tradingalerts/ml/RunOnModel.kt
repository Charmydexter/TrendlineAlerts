package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import com.lrmlc.tradingalerts.data.local.ExitCellRuleEntity
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import kotlinx.serialization.Serializable
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max

object RunOnSpec {
    /** Total distance from entry (in TP distances) that counts as "ran far past TP": TP + half a TP further. */
    const val RAN_FAR_PROGRESS = 1.5
    const val MIN_PRECISION = 0.65
    const val MIN_MARGIN_OVER_BASE = 0.10
    const val MIN_TEST_CASES = 30
    /** Marker stays on until the chance drops this far below the situation's level (no flicker). */
    const val HYSTERESIS = 0.05
    const val EXTRA_FEATURES = 4
    const val FEATURE_COUNT = ExitFeatureSpec.FEATURE_COUNT + EXTRA_FEATURES
    const val MODEL_KIND = "RUNON"

    fun modelKey(exchange: String, marketType: String) = "RUNON_${exchange}_$marketType"
}

/** Result of replaying a trade past its TP. Progress values are in TP distances from entry. */
data class RunOnReplay(
    val tpIndex: Int,
    val endIndex: Int,
    val peakProgress: Double,   // best point reached beyond entry, in TP distances (>= 1)
    val barsToPeak: Int,        // candles from the TP touch to the peak
    val endProgress: Double,    // where the replay ended
    val endPrice: Double,
    val endReason: String,      // ENTRY, STOP or TIME
    val ranFar: Boolean
)

object RunOnLabeler {

    /**
     * Keeps a trade that touched TP at [tpIndex] until the first of: price back to entry, stop touched, or
     * twice the normal trade length ([horizonBars] x 2, counted from entry) has passed. Records how far it ran.
     * A candle that ends the replay does not count toward the peak (its intrabar order is unknown).
     */
    fun replay(
        candles: List<Candle>,
        signalBarIndex: Int,
        tpIndex: Int,
        direction: TradeDirection,
        entryPrice: Double,
        slPrice: Double,
        tpPrice: Double,
        horizonBars: Int
    ): RunOnReplay? {
        if (tpIndex !in candles.indices || entryPrice <= 0.0) return null
        val tpSpan = abs(tpPrice - entryPrice).coerceAtLeast(1e-12)
        val slSpan = abs(entryPrice - slPrice).coerceAtLeast(1e-12)
        val limit = minOf(candles.lastIndex, signalBarIndex + 2 * horizonBars.coerceAtLeast(1))
        if (limit < tpIndex) return null

        fun fav(price: Double) = when (direction) {
            TradeDirection.LONG -> price - entryPrice
            TradeDirection.SHORT -> entryPrice - price
        }
        fun best(c: Candle) = fav(if (direction == TradeDirection.LONG) c.high else c.low)
        fun worst(c: Candle) = fav(if (direction == TradeDirection.LONG) c.low else c.high)
        fun priceAtFav(f: Double) = if (direction == TradeDirection.LONG) entryPrice + f else entryPrice - f

        var peak = best(candles[tpIndex]) / tpSpan
        var peakIdx = tpIndex
        var endIdx = limit
        var endFav = fav(candles[limit].close)
        var reason = "TIME"
        for (k in (tpIndex + 1)..limit) {
            val c = candles[k]
            val w = worst(c)
            if (w <= -slSpan) {
                endIdx = k; endFav = -slSpan; reason = "STOP"; break
            }
            if (w <= 0.0) {
                endIdx = k; endFav = 0.0; reason = "ENTRY"; break
            }
            val p = best(c) / tpSpan
            if (p > peak) { peak = p; peakIdx = k }
        }
        return RunOnReplay(
            tpIndex = tpIndex,
            endIndex = endIdx,
            peakProgress = peak,
            barsToPeak = peakIdx - tpIndex,
            endProgress = endFav / tpSpan,
            endPrice = priceAtFav(endFav),
            endReason = reason,
            ranFar = peak >= RunOnSpec.RAN_FAR_PROGRESS
        )
    }
}

object RunOnFeatureBuilder {

    /** Appends TP distance, reward-to-risk, momentum and volume trend to the Job 2 trade-moment features. */
    fun extend(
        base: DoubleArray,
        candles: List<Candle>,
        idx: Int,
        direction: TradeDirection,
        entryPrice: Double,
        slPrice: Double,
        tpPrice: Double
    ): DoubleArray {
        val out = base.copyOf(RunOnSpec.FEATURE_COUNT)
        val n = ExitFeatureSpec.FEATURE_COUNT
        val entry = entryPrice.coerceAtLeast(1e-9)
        val tpSpan = abs(tpPrice - entry).coerceAtLeast(1e-12)
        val slSpan = abs(entry - slPrice).coerceAtLeast(1e-12)
        out[n] = (tpSpan / entry).coerceIn(0.0, 0.5)
        out[n + 1] = (tpSpan / slSpan).coerceIn(0.0, 10.0)
        val c = candles[idx].close
        val c5 = candles.getOrNull(idx - 5)?.close ?: c
        val mom = if (c5 > 1e-9) (c - c5) / c5 else 0.0
        out[n + 2] = if (direction == TradeDirection.LONG) mom else -mom
        if (idx >= 15) {
            var recent = 0.0
            for (k in (idx - 4)..idx) recent += candles[k].volume
            var prior = 0.0
            for (k in (idx - 14)..(idx - 5)) prior += candles[k].volume
            recent /= 5.0
            prior /= 10.0
            out[n + 3] = ln((recent.coerceAtLeast(1e-9)) / prior.coerceAtLeast(1e-9)).coerceIn(-3.0, 3.0)
        }
        for (i in out.indices) if (!out[i].isFinite()) out[i] = 0.0
        return out
    }

    fun build(
        candles: List<Candle>,
        snapshots: List<ConfluenceBarSnapshot>,
        currentIdx: Int,
        entryIdx: Int,
        direction: TradeDirection,
        entryPrice: Double,
        slPrice: Double,
        tpPrice: Double,
        entryPWin: Double?
    ): DoubleArray? {
        val base = ExitWarningFeatureBuilder.buildStateFeatures(
            candles = candles,
            snapshots = snapshots,
            currentBarIndex = currentIdx,
            entryBarIndex = entryIdx,
            direction = direction,
            entryPrice = entryPrice,
            slPrice = slPrice,
            tpPrice = tpPrice,
            entryPWin = entryPWin
        ) ?: return null
        return extend(base, candles, currentIdx, direction, entryPrice, slPrice, tpPrice)
    }
}

@Serializable
data class RunOnCellRule(
    val ageBucket: Int,
    val progressBucket: Int,
    val enabled: Boolean,
    val level: Double,
    val precision: Double,
    val markers: Int,     // test moments at or above the level
    val testCases: Int,   // all unseen test moments in this situation
    val baseRate: Double  // how often a run-on happened in this situation overall
)

@Serializable
data class RunOnBundle(
    val weights: LogisticRegressionWeights,
    val rules: List<RunOnCellRule>,
    val trainedAtMs: Long
) {
    fun ruleFor(ageBucket: Int, progressBucket: Int): RunOnCellRule? =
        rules.firstOrNull { it.ageBucket == ageBucket && it.progressBucket == progressBucket }

    fun provenCount(): Int = rules.count { it.enabled }

    /** Re-uses the Insights 5x4 grid. */
    fun asGridRules(exchange: String, marketType: String): List<ExitCellRuleEntity> = rules.map {
        ExitCellRuleEntity(
            exchange = exchange,
            marketType = marketType,
            ageBucket = it.ageBucket,
            progressBucket = it.progressBucket,
            mlEnabled = it.enabled,
            mlThreshold = it.level,
            structEnabled = false,
            precision = it.precision,
            warnings = it.markers,
            avgSavedRisk = 0.0,
            updatedAtMs = trainedAtMs
        )
    }
}

object RunOnTrainer {

    /** Marker decision with hysteresis. [currentlyOn] is the saved marker of the trade. */
    fun decideMarker(rule: RunOnCellRule?, probability: Double, currentlyOn: Boolean): Boolean {
        if (rule == null || !rule.enabled) return false
        return if (currentlyOn) probability >= rule.level - RunOnSpec.HYSTERESIS else probability >= rule.level
    }

    /**
     * Trains on the earlier trades and proves each of the 20 situations on later, unseen trades. A situation shows
     * the marker only if, at the lowest level from 55% to 90%, the model is right at least 65% of the time, at least
     * 10 points above that situation's normal rate, with at least 30 test cases. Returns null when there is too
     * little data to train at all (nothing is shown then).
     */
    fun train(
        samples: List<ExitStateSample>,
        horizonBars: Int,
        nowMs: Long
    ): RunOnBundle? {
        if (samples.isEmpty()) return null
        val sorted = samples.sortedBy { it.entryTimeMs }
        val entryTimes = sorted.map { it.entryTimeMs }.distinct().sorted()
        if (entryTimes.size < 6) return null
        val splitIdx = ((entryTimes.size * 2) / 3).coerceIn(2, entryTimes.size - 1)
        val oosStart = entryTimes[splitIdx]
        val purgeMs = horizonBars.coerceAtLeast(1) * 2 * DayChunkCodec.MILLIS_PER_MINUTE
        val train = sorted.filter { it.entryTimeMs < oosStart && it.sample.exitTimeMs + purgeMs < oosStart }
            .ifEmpty { sorted.filter { it.entryTimeMs < oosStart } }
        val oos = sorted.filter { it.entryTimeMs >= oosStart }
        if (train.size < 40 || oos.size < RunOnSpec.MIN_TEST_CASES) return null
        if (train.none { it.sample.label == 1 } || train.none { it.sample.label == 0 }) return null

        val trainLabeled = train.map { it.sample }
        val stats = StandardizationStats.fit(trainLabeled.map { it.features }, RunOnSpec.FEATURE_COUNT)
        val weighted = OverlapWeightCalculator.assignOverlapWeights(trainLabeled)
        val model = LogisticRegressionTrainer.trainWithCheckpoints(
            samples = weighted,
            stats = stats,
            featureCount = RunOnSpec.FEATURE_COUNT,
            params = LogisticHyperParams(epochs = 22, batchSize = 32, learningRate = 0.03, l2Lambda = 0.03)
        )
        val scored = oos.map { model.predictProbability(it.sample.features) to it }

        val rules = ArrayList<RunOnCellRule>(ExitFeatureSpec.SITUATIONS)
        for (a in 0 until ExitFeatureSpec.AGE_BUCKETS) {
            for (p in 0 until ExitFeatureSpec.PROGRESS_BUCKETS) {
                val cell = scored.filter { it.second.ageBucket == a && it.second.progressBucket == p }
                rules.add(evaluateCell(a, p, cell))
            }
        }
        return RunOnBundle(model, rules, nowMs)
    }

    private fun evaluateCell(a: Int, p: Int, cell: List<Pair<Double, ExitStateSample>>): RunOnCellRule {
        val silent = RunOnCellRule(a, p, false, 0.90, 0.0, 0, cell.size, 0.0)
        if (cell.size < RunOnSpec.MIN_TEST_CASES) return silent.copy(
            baseRate = if (cell.isEmpty()) 0.0 else cell.count { it.second.sample.label == 1 }.toDouble() / cell.size
        )
        val base = cell.count { it.second.sample.label == 1 }.toDouble() / cell.size
        val need = max(RunOnSpec.MIN_PRECISION, base + RunOnSpec.MIN_MARGIN_OVER_BASE).coerceAtMost(0.98)
        for (pct in 55..90 step 5) {
            val t = pct / 100.0
            val marked = cell.filter { it.first >= t }
            if (marked.size < RunOnSpec.MIN_TEST_CASES) continue
            val prec = marked.count { it.second.sample.label == 1 }.toDouble() / marked.size
            if (prec >= need) {
                return RunOnCellRule(a, p, true, t, prec, marked.size, cell.size, base)
            }
        }
        return silent.copy(baseRate = base)
    }

    fun summaryLine(bundle: RunOnBundle?): String =
        if (bundle == null) "Run-on markers: learning (not enough trades past TP yet; nothing shown)."
        else "Run-on markers: proven in ${bundle.provenCount()}/${ExitFeatureSpec.SITUATIONS} situations (65%+ right, 10+ pts above normal, 30+ test cases)."
}
