package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.model.Candle
import kotlinx.serialization.Serializable
import kotlin.math.pow

/** Proof result for one optional feature group on one range preset. Percent values are in percent (0.03 = 0.03%). */
@Serializable
data class GroupProof(
    val group: String,
    val label: String,
    val scorePct: Double? = null, // cautious (lower-bound) expectancy with this group added
    val gainPct: Double? = null,  // improvement over the baseline without any new group
    val kept: Boolean = false,
    val note: String = ""
)

/** What the learning search decided for one range preset. */
@Serializable
data class PresetLearning(
    val presetId: String,
    val enabledGroups: List<String> = listOf("CORE"),
    val baselineScorePct: Double? = null,
    val groupProofs: List<GroupProof> = emptyList(),
    val halfLifeDays: Int = 0, // 0 = no fading
    val l2Lambda: Double = 0.02,
    val epochs: Int = 25,
    val tuningNote: String = "",
    val timedOut: Boolean = false,
    val foldStats: List<FoldStat> = emptyList(),
    val unstable: Boolean = false,
    val positivePeriods: Int = 0
)

@Serializable
data class LearningReport(
    val masterAsset: String = "BTCUSDT",
    val masterDataLoaded: Boolean = false,
    val futuresDataLoaded: Boolean = false,
    val realTradesUsed: Int = 0,
    val gapSetupsSkipped: Int = 0,
    val primaryPresetId: String = "R240",
    val presets: List<PresetLearning> = emptyList()
) {
    fun primary(): PresetLearning? = presets.firstOrNull { it.presetId == primaryPresetId } ?: presets.firstOrNull()

    fun groupsLine(): String {
        val p = primary() ?: return "Learning inputs: not trained yet"
        val labels = p.enabledGroups.mapNotNull { n ->
            FeatureSpec.Group.values().firstOrNull { it.name == n }?.takeIf { it != FeatureSpec.Group.CORE }?.label
        }
        return if (labels.isEmpty()) "Extra feature groups on: none (none proved useful yet)"
        else "Extra feature groups on: ${labels.joinToString(", ")}"
    }

    fun decayLine(): String {
        val p = primary() ?: return ""
        return if (p.halfLifeDays > 0) "Recent data counts more: half-life ${p.halfLifeDays} days" else "Recent data fading: off (no fading scored best)"
    }

    fun tuningLine(): String {
        val p = primary() ?: return ""
        return "Learning settings: overfitting strength ${p.l2Lambda}, ${p.epochs} passes" +
            (if (p.tuningNote.isNotBlank()) " (${p.tuningNote})" else "")
    }

    fun periodsLine(): String {
        val p = primary() ?: return ""
        if (p.foldStats.isEmpty()) return "Test periods: not enough data for three periods"
        val parts = p.foldStats.joinToString(" | ") { f ->
            "P${f.period} " + (if (f.trades == 0) "no trades" else String.format(java.util.Locale.US, "%+.3f%% (%d)", f.expectancyPct * 100.0, f.trades))
        }
        return "Test periods: $parts" + if (p.unstable) " - UNSTABLE" else ""
    }
}

data class LearningSearchInput(
    val presetId: String,
    val samples: List<LabeledSample>, // chronological, full-length feature vectors, isReal flags set
    val nowMs: Long,
    val horizonBars: Int,
    val rewardToRisk: Double,
    val baseParams: LogisticHyperParams
)

data class LearningSearchOutcome(
    val groups: Set<FeatureSpec.Group>,
    val halfLifeDays: Int,
    val params: LogisticHyperParams,
    val preparedSamples: List<LabeledSample>, // masked + recency/real-trade weighted
    val learning: PresetLearning
)

/** Detects setups that sit on top of missing 1-minute candles (more than [maxMissing] in a row). */
class GapGuard(candles: List<Candle>, private val maxMissing: Int = 2) {
    private val cum = IntArray(candles.size)

    init {
        for (k in 1 until candles.size) {
            val missing = ((candles[k].openTimeMs - candles[k - 1].openTimeMs) / 60_000L) - 1L
            cum[k] = cum[k - 1] + (if (missing > maxMissing) 1 else 0)
        }
    }

    /** True when a too-long hole lies between candle index [from] and [to] (inclusive range). */
    fun hasBadGap(from: Int, to: Int): Boolean {
        if (cum.isEmpty()) return false
        val a = from.coerceIn(0, cum.lastIndex)
        val b = to.coerceIn(0, cum.lastIndex)
        if (b <= a) return false
        return cum[b] - cum[a] > 0
    }
}

object LearningEnhancer {

    /** 0.03 percentage points per trade, expressed as a fraction. */
    const val MIN_GROUP_GAIN = 0.0003
    const val MIN_SCORE_TRADES = 20
    const val MIN_SIGNAL_SHARE = 0.20
    const val DEFAULT_HALF_LIFE_DAYS = 14
    const val REAL_TRADE_WEIGHT = 2.0
    const val DEFAULT_TIME_BUDGET_MS = 45_000L

    /** Order matters: the first entry is the incumbent that must be beaten. 0 = no fading. */
    val HALF_LIFE_OPTIONS = listOf(14, 7, 28, 0)
    val L2_OPTIONS = listOf(0.005, 0.02, 0.08)
    val EPOCH_OPTIONS = listOf(15, 25, 40)

    private const val MILLIS_PER_DAY = 86_400_000.0

    /** Cautious (lower-bound) expectancy of the trades the model would take on unseen data. -inf when it cannot be judged. */
    fun scoreOf(res: WalkForwardResult): Double {
        if (res.metrics.metricsAreOptimistic) return Double.NEGATIVE_INFINITY
        val taken = res.oosPredictions
            .filter { it.first >= res.metrics.threshold }
            .map { it.second.netReturnPct }
        if (taken.size < MIN_SCORE_TRADES) return Double.NEGATIVE_INFINITY
        return PresetSelector.computeLcbExpectancy(taken)
    }

    fun recencyWeight(timestampMs: Long, nowMs: Long, halfLifeDays: Int): Double {
        if (halfLifeDays <= 0) return 1.0
        val ageDays = ((nowMs - timestampMs).coerceAtLeast(0L)) / MILLIS_PER_DAY
        return 0.5.pow(ageDays / halfLifeDays.toDouble()).coerceAtLeast(0.02)
    }

    fun prepare(
        samples: List<LabeledSample>,
        groups: Set<FeatureSpec.Group>,
        halfLifeDays: Int,
        nowMs: Long
    ): List<LabeledSample> = samples.map { s ->
        val w = recencyWeight(s.timestampMs, nowMs, halfLifeDays) * (if (s.isReal) REAL_TRADE_WEIGHT else 1.0)
        s.copy(features = FeatureSpec.applyMask(s.features, groups), baseWeight = w)
    }

    /** True when enough samples carry real (non-neutral) values for the group to be worth testing. */
    fun groupHasData(samples: List<LabeledSample>, group: FeatureSpec.Group): Boolean {
        if (samples.isEmpty()) return false
        var withData = 0
        for (s in samples) {
            var any = false
            for (i in group.indices) {
                if (i < s.features.size && s.features[i] != 0.0) { any = true; break }
            }
            if (any) withData++
        }
        return withData.toDouble() / samples.size >= MIN_SIGNAL_SHARE
    }

    private fun pct(v: Double): Double? = if (v.isFinite()) v * 100.0 else null

    /**
     * Proves each optional feature group on unseen data, then picks the recency half-life and the learning
     * settings. Everything is judged with the cautious (lower-bound) expectancy on out-of-sample trades.
     * Falls back to the current settings when the time budget runs out.
     */
    fun search(
        input: LearningSearchInput,
        timeBudgetMs: Long = DEFAULT_TIME_BUDGET_MS,
        checkCancelled: () -> Unit = {}
    ): LearningSearchOutcome {
        val deadlineNs = System.nanoTime() + timeBudgetMs * 1_000_000L
        fun overtime(): Boolean = System.nanoTime() > deadlineNs

        fun evaluate(groups: Set<FeatureSpec.Group>, halfLife: Int, params: LogisticHyperParams): Double {
            checkCancelled()
            val prepared = prepare(input.samples, groups, halfLife, input.nowMs)
            val res = WalkForwardValidator.validateWithOosPredictions(
                chronologicalSamples = prepared,
                featureCount = FeatureSpec.FEATURE_COUNT,
                horizonBars = input.horizonBars,
                rewardToRisk = input.rewardToRisk,
                params = params
            )
            return scoreOf(res)
        }

        var timedOut = false
        val core = setOf(FeatureSpec.Group.CORE)
        val baseParams = input.baseParams

        // 1) Baseline without any new group
        val baseScore = evaluate(core, DEFAULT_HALF_LIFE_DAYS, baseParams)

        // 2) Each group added on its own
        val proofs = ArrayList<GroupProof>()
        val groupScores = HashMap<FeatureSpec.Group, Double>()
        for (g in FeatureSpec.OPTIONAL_GROUPS) {
            if (!groupHasData(input.samples, g)) {
                proofs.add(GroupProof(g.name, g.label, kept = false, note = "no data yet"))
                continue
            }
            if (!baseScore.isFinite()) {
                proofs.add(GroupProof(g.name, g.label, kept = false, note = "baseline cannot be judged yet (too few unseen trades)"))
                continue
            }
            if (overtime()) {
                timedOut = true
                proofs.add(GroupProof(g.name, g.label, kept = false, note = "skipped: time limit"))
                continue
            }
            val sc = evaluate(core + g, DEFAULT_HALF_LIFE_DAYS, baseParams)
            groupScores[g] = sc
            val gain = if (sc.isFinite()) sc - baseScore else Double.NaN
            val keep = gain.isFinite() && gain >= MIN_GROUP_GAIN
            proofs.add(
                GroupProof(
                    group = g.name,
                    label = g.label,
                    scorePct = pct(sc),
                    gainPct = if (gain.isFinite()) gain * 100.0 else null,
                    kept = keep,
                    note = if (keep) "helps on unseen data" else "does not help enough (needs +0.03 pts/trade) - dropped"
                )
            )
        }

        // 3) Combination check: all kept groups together must not be worse than the best single one
        var kept: Set<FeatureSpec.Group> = proofs.filter { it.kept }
            .mapNotNull { p -> FeatureSpec.Group.values().firstOrNull { it.name == p.group } }
            .toSet()
        if (kept.size > 1) {
            val bestSingle = kept.maxByOrNull { groupScores[it] ?: Double.NEGATIVE_INFINITY }!!
            val bestSingleScore = groupScores[bestSingle] ?: Double.NEGATIVE_INFINITY
            val useAll = if (overtime()) {
                timedOut = true
                false
            } else {
                val comb = evaluate(core + kept, DEFAULT_HALF_LIFE_DAYS, baseParams)
                comb.isFinite() && comb >= bestSingleScore - 1e-9
            }
            if (!useAll) {
                val dropped = kept - bestSingle
                kept = setOf(bestSingle)
                for (i in proofs.indices) {
                    val p = proofs[i]
                    if (p.kept && dropped.any { it.name == p.group }) {
                        proofs[i] = p.copy(kept = false, note = "dropped: not better together with the other groups")
                    }
                }
            }
        }
        val chosenGroups: Set<FeatureSpec.Group> = core + kept

        // 4) Recency half-life: 14 / 7 / 28 days or no fading, best on unseen data
        var bestHalfLife = DEFAULT_HALF_LIFE_DAYS
        var bestScore = Double.NEGATIVE_INFINITY
        var decayDone = true
        for ((idx, hl) in HALF_LIFE_OPTIONS.withIndex()) {
            if (idx > 0 && overtime()) { timedOut = true; decayDone = false; break }
            val sc = evaluate(chosenGroups, hl, baseParams)
            if (idx == 0 || sc > bestScore + 1e-9) {
                bestScore = sc
                bestHalfLife = hl
            }
        }

        // 5) Learning settings: overfitting strength x passes. Falls back to current settings if too slow.
        var chosenParams = baseParams
        var tuningNote = "current settings kept"
        if (decayDone && !overtime()) {
            var tuneBest = baseParams
            var tuneScore = bestScore
            var finished = true
            outer@ for (l2 in L2_OPTIONS) {
                for (ep in EPOCH_OPTIONS) {
                    if (l2 == baseParams.l2Lambda && ep == baseParams.epochs) continue
                    if (overtime()) { finished = false; break@outer }
                    val cand = baseParams.copy(l2Lambda = l2, epochs = ep)
                    val sc = evaluate(chosenGroups, bestHalfLife, cand)
                    if (sc > tuneScore + 1e-9) {
                        tuneScore = sc
                        tuneBest = cand
                    }
                }
            }
            if (finished) {
                chosenParams = tuneBest
                tuningNote = if (tuneBest == baseParams) "search found no better settings" else "tuned on unseen data"
            } else {
                timedOut = true
                tuningNote = "search would run too long - current settings kept"
            }
        } else {
            timedOut = true
            tuningNote = "time limit - current settings kept"
        }

        val prepared = prepare(input.samples, chosenGroups, bestHalfLife, input.nowMs)
        val learning = PresetLearning(
            presetId = input.presetId,
            enabledGroups = chosenGroups.map { it.name },
            baselineScorePct = pct(baseScore),
            groupProofs = proofs,
            halfLifeDays = bestHalfLife,
            l2Lambda = chosenParams.l2Lambda,
            epochs = chosenParams.epochs,
            tuningNote = tuningNote,
            timedOut = timedOut
        )
        return LearningSearchOutcome(chosenGroups, bestHalfLife, chosenParams, prepared, learning)
    }
}
