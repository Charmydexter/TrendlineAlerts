package com.lrmlc.tradingalerts.ui.insights

import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import com.lrmlc.tradingalerts.ml.CalibrationBucket
import com.lrmlc.tradingalerts.ml.ModelExplainer
import com.lrmlc.tradingalerts.ml.TrainingReportBuilder
import com.lrmlc.tradingalerts.ml.ValidationMetrics

enum class InsightsRange(val label: String, val hours: Long) {
    H24("24h", 24L),
    D7("7d", 24L * 7L),
    D30("30d", 24L * 30L)
}

data class InsightsKpiSummary(
    val winRate: Double,
    val ciLow: Double,
    val ciHigh: Double,
    val breakEven: Double,
    val netExpectancyPct: Double,
    val profitFactor: Double,
    val tradesTaken: Int,
    val totalOutOfSample: Int,
    val brierScore: Double,
    val baselineBrier: Double,
    val hasMetrics: Boolean
)

data class TrainingTrendPoint(
    val timestampMs: Long,
    val expectancyPct: Double,
    val winRate: Double,
    val promoted: Boolean
)

data class AlertOutcomesBreakdown(
    val tpCount: Int,
    val slCount: Int,
    val oppositeCount: Int,
    val manualCount: Int,
    val activeCount: Int,
    val cumulativeReturnsPct: List<Double>
) {
    val totalCount: Int get() = tpCount + slCount + oppositeCount + manualCount + activeCount
}

object InsightsStats {

    fun filterSignalsByRange(
        signals: List<SignalCandidateEntity>,
        range: InsightsRange,
        nowMs: Long = System.currentTimeMillis()
    ): List<SignalCandidateEntity> {
        val cutoff = nowMs - range.hours * 3_600_000L
        return signals.filter { it.signalTimeMs >= cutoff }
    }

    fun filterLogsByRange(
        logs: List<TrainingLogEntity>,
        range: InsightsRange,
        nowMs: Long = System.currentTimeMillis()
    ): List<TrainingLogEntity> {
        val cutoff = nowMs - range.hours * 3_600_000L
        return logs.filter { it.timestampMs >= cutoff }
    }

    fun extractKpis(metrics: ValidationMetrics?): InsightsKpiSummary {
        if (metrics == null || metrics.totalOutOfSample <= 0) {
            return InsightsKpiSummary(0.0, 0.0, 0.0, 0.5, 0.0, 0.0, 0, 0, 0.25, 0.25, hasMetrics = false)
        }
        val wins = (metrics.winRate * metrics.tradesTaken).toInt().coerceIn(0, metrics.tradesTaken)
        val (lo, hi) = ModelExplainer.wilsonInterval(wins, metrics.tradesTaken)
        val baseBrier = ModelExplainer.baselineBrier(metrics.baselineWinRate)
        return InsightsKpiSummary(
            winRate = metrics.winRate,
            ciLow = lo,
            ciHigh = hi,
            breakEven = metrics.breakEvenThreshold,
            netExpectancyPct = metrics.netExpectancyPct,
            profitFactor = metrics.profitFactor,
            tradesTaken = metrics.tradesTaken,
            totalOutOfSample = metrics.totalOutOfSample,
            brierScore = metrics.brierScore,
            baselineBrier = baseBrier,
            hasMetrics = true
        )
    }

    fun extractCalibrationPoints(metrics: ValidationMetrics?): List<CalibrationBucket> =
        metrics?.calibrationBuckets?.filter { it.sampleCount > 0 }.orEmpty()

    fun buildTrainingTrend(
        logs: List<TrainingLogEntity>,
        range: InsightsRange,
        nowMs: Long = System.currentTimeMillis()
    ): List<TrainingTrendPoint> {
        return filterLogsByRange(logs, range, nowMs)
            .sortedBy { it.timestampMs }
            .mapNotNull { log ->
                val m = TrainingReportBuilder.parseMetrics(log) ?: return@mapNotNull null
                TrainingTrendPoint(
                    timestampMs = log.timestampMs,
                    expectancyPct = m.netExpectancyPct,
                    winRate = m.winRate,
                    promoted = log.promoted
                )
            }
    }

    fun buildAlertOutcomes(
        signals: List<SignalCandidateEntity>,
        range: InsightsRange,
        nowMs: Long = System.currentTimeMillis()
    ): AlertOutcomesBreakdown {
        val accepted = filterSignalsByRange(signals, range, nowMs)
            .filter { it.accepted }
            .sortedBy { it.exitTimeMs ?: it.signalTimeMs }
        var tp = 0
        var sl = 0
        var opp = 0
        var manual = 0
        var active = 0
        val cumulative = ArrayList<Double>()
        var running = 0.0
        for (sig in accepted) {
            when (sig.status) {
                "CLOSED_TP" -> tp++
                "CLOSED_SL" -> sl++
                "CLOSED_OPPOSITE" -> opp++
                "CLOSED_MANUAL" -> manual++
                else -> active++
            }
            if (sig.status != "ACTIVE" && sig.netReturnPct != null) {
                running += sig.netReturnPct
                cumulative.add(running)
            }
        }
        return AlertOutcomesBreakdown(
            tpCount = tp,
            slCount = sl,
            oppositeCount = opp,
            manualCount = manual,
            activeCount = active,
            cumulativeReturnsPct = cumulative
        )
    }
}
