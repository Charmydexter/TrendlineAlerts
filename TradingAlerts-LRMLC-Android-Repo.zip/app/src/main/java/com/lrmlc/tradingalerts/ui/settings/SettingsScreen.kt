package com.lrmlc.tradingalerts.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lrmlc.tradingalerts.backup.ImportPreview
import com.lrmlc.tradingalerts.data.local.AssetStorageSummary
import com.lrmlc.tradingalerts.data.local.RecycleBinEntity
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.ChartStyle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.ThresholdMode
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.data.remote.ConnectionTestReport
import com.lrmlc.tradingalerts.ml.TrainingStatusSnapshot
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    connectionReport: ConnectionTestReport?,
    isTestingConnection: Boolean,
    trainingStatus: TrainingStatusSnapshot,
    watchlist: List<WatchlistEntity>,
    recycleBin: List<RecycleBinEntity>,
    storageSummary: List<AssetStorageSummary>,
    importPreview: ImportPreview?,
    onUpdateSettings: ((AppSettings) -> AppSettings) -> Unit,
    onRunConnectionTest: () -> Unit,
    onTrainNow: () -> Unit,
    onPauseTraining: () -> Unit,
    onResumeTraining: () -> Unit,
    onRemoveWatchlistAsset: (String) -> Unit,
    onRestoreBinAsset: (String) -> Unit,
    onDeleteBinAsset: (String) -> Unit,
    onRefreshStorage: () -> Unit,
    onClearAssetStorage: (String) -> Unit,
    onExportBackup: (Uri, Boolean) -> Unit,
    onInspectImportUri: (Uri) -> Unit,
    onConfirmImport: () -> Unit,
    onDismissImportPreview: () -> Unit
) {
    val context = LocalContext.current
    var includeCandlesInExport by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/gzip")
    ) { uri ->
        if (uri != null) onExportBackup(uri, includeCandlesInExport)
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onInspectImportUri(uri)
    }

    LaunchedEffect(Unit) {
        onRefreshStorage()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Data Source & Connection Test
            item {
                SectionCard("Market Data Source") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ExchangeId.entries.forEach { ex ->
                            FilterChip(
                                selected = settings.exchange == ex,
                                onClick = { onUpdateSettings { it.copy(exchange = ex) } },
                                label = { Text(ex.displayName) }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MarketType.entries.forEach { mt ->
                            FilterChip(
                                selected = settings.marketType == mt,
                                onClick = { onUpdateSettings { it.copy(marketType = mt) } },
                                label = { Text(mt.displayName) }
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = onRunConnectionTest,
                        enabled = !isTestingConnection,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isTestingConnection) "Testing..." else "Test Exchange Connection")
                    }
                    connectionReport?.steps?.forEach { step ->
                        Text(
                            text = "${if (step.passed) "✓" else "✕"} ${step.name}: ${step.detail}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (step.passed) LrmlcColors.LongGreen else LrmlcColors.ShortRed
                        )
                    }
                }
            }

            // Chart & Theme
            item {
                SectionCard("Appearance & Chart") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = settings.chartStyle == ChartStyle.HEIKIN_ASHI,
                            onClick = { onUpdateSettings { it.copy(chartStyle = ChartStyle.HEIKIN_ASHI) } },
                            label = { Text("Heikin Ashi") }
                        )
                        FilterChip(
                            selected = settings.chartStyle == ChartStyle.CANDLES,
                            onClick = { onUpdateSettings { it.copy(chartStyle = ChartStyle.CANDLES) } },
                            label = { Text("Normal Candles") }
                        )
                    }
                    SwitchRow("Dark Charcoal Theme", settings.darkTheme) { dark ->
                        onUpdateSettings { it.copy(darkTheme = dark) }
                    }
                }
            }

            // Confluence & Risk Parameters
            item {
                var capitalText by remember(settings.engineConfig.capitalUsd) { mutableStateOf(settings.engineConfig.capitalUsd.toString()) }
                var riskText by remember(settings.engineConfig.maxLossUsd) { mutableStateOf(settings.engineConfig.maxLossUsd.toString()) }
                var tpText by remember(settings.engineConfig.takeProfitUsd) { mutableStateOf(settings.engineConfig.takeProfitUsd.toString()) }
                var feeText by remember(settings.engineConfig.roundTripFeeRate) { mutableStateOf((settings.engineConfig.roundTripFeeRate * 100.0).toString()) }
                var winText by remember(settings.engineConfig.windowLength) { mutableStateOf(settings.engineConfig.windowLength.toString()) }
                var gapText by remember(settings.engineConfig.minGap) { mutableStateOf(settings.engineConfig.minGap.toString()) }

                SectionCard("Confluence & Risk Parameters") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = capitalText, onValueChange = { capitalText = it }, label = { Text("Capital ($)") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = riskText, onValueChange = { riskText = it }, label = { Text("Max Loss ($)") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = tpText, onValueChange = { tpText = it }, label = { Text("Min TP ($)") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = winText, onValueChange = { winText = it }, label = { Text("Window (bars)") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = gapText, onValueChange = { gapText = it }, label = { Text("Min Gap") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = feeText, onValueChange = { feeText = it }, label = { Text("Fee (%)") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Button(
                        onClick = {
                            onUpdateSettings { cur ->
                                cur.copy(
                                    engineConfig = cur.engineConfig.copy(
                                        capitalUsd = (capitalText.toDoubleOrNull() ?: cur.engineConfig.capitalUsd).coerceAtLeast(0.01),
                                        maxLossUsd = (riskText.toDoubleOrNull() ?: cur.engineConfig.maxLossUsd).coerceAtLeast(0.01),
                                        takeProfitUsd = (tpText.toDoubleOrNull() ?: cur.engineConfig.takeProfitUsd).coerceAtLeast(0.01),
                                        windowLength = (winText.toIntOrNull() ?: cur.engineConfig.windowLength).coerceAtLeast(50),
                                        minGap = (gapText.toIntOrNull() ?: cur.engineConfig.minGap).coerceAtLeast(1),
                                        roundTripFeeRate = ((feeText.toDoubleOrNull() ?: 0.1) / 100.0).coerceIn(0.0, 0.05)
                                    )
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save Strategy Parameters") }
                }
            }

            // ML & SL/TP Controls
            item {
                SectionCard("Machine Learning & SL/TP") {
                    SwitchRow("Auto-SL (learned 80th pct MAE)", settings.autoSlEnabled) { v ->
                        onUpdateSettings { it.copy(autoSlEnabled = v) }
                    }
                    SwitchRow("Auto-TP (learned median MFE)", settings.autoTpEnabled) { v ->
                        onUpdateSettings { it.copy(autoTpEnabled = v) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = settings.thresholdMode == ThresholdMode.AUTO_EXPECTANCY,
                            onClick = { onUpdateSettings { it.copy(thresholdMode = ThresholdMode.AUTO_EXPECTANCY) } },
                            label = { Text("Auto Threshold") }
                        )
                        FilterChip(
                            selected = settings.thresholdMode == ThresholdMode.MANUAL,
                            onClick = { onUpdateSettings { it.copy(thresholdMode = ThresholdMode.MANUAL) } },
                            label = { Text("Manual (${(settings.manualThreshold * 100).toInt()}%)") }
                        )
                    }
                    if (settings.thresholdMode == ThresholdMode.MANUAL) {
                        Slider(
                            value = settings.manualThreshold.toFloat(),
                            onValueChange = { v -> onUpdateSettings { it.copy(manualThreshold = v.toDouble()) } },
                            valueRange = 0.45f..0.85f
                        )
                    }
                    Text(trainingStatus.stageMessage, style = MaterialTheme.typography.bodySmall)
                    if (trainingStatus.isRunning) {
                        LinearProgressIndicator(progress = { trainingStatus.progressPct / 100f }, modifier = Modifier.fillMaxWidth())
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onTrainNow, enabled = !trainingStatus.isRunning) { Text("Train Now") }
                        if (trainingStatus.isRunning) {
                            OutlinedButton(onClick = onPauseTraining) { Text("Pause") }
                        } else if (trainingStatus.isPaused) {
                            OutlinedButton(onClick = onResumeTraining) { Text("Resume") }
                        }
                    }
                }
            }

            // Notifications & Background Monitoring
            item {
                SectionCard("Notifications & Background Service") {
                    SwitchRow("Keep monitoring in background", settings.keepMonitoringInBackground) { v ->
                        onUpdateSettings { it.copy(keepMonitoringInBackground = v) }
                    }
                    SwitchRow("Start monitoring on boot", settings.startOnBoot) { v ->
                        onUpdateSettings { it.copy(startOnBoot = v) }
                    }
                    SwitchRow("Notify on TP hit", settings.notifyTpHit) { v ->
                        onUpdateSettings { it.copy(notifyTpHit = v) }
                    }
                    SwitchRow("Notify on SL hit", settings.notifySlHit) { v ->
                        onUpdateSettings { it.copy(notifySlHit = v) }
                    }
                    SwitchRow("Notify on filtered signals", settings.notifyFilteredSignals) { v ->
                        onUpdateSettings { it.copy(notifyFilteredSignals = v) }
                    }
                    SwitchRow("Quiet hours (23:00–07:00)", settings.quietHoursEnabled) { v ->
                        onUpdateSettings { it.copy(quietHoursEnabled = v) }
                    }
                    OutlinedButton(
                        onClick = {
                            val pm = context.getSystemService(PowerManager::class.java)
                            if (pm != null && !pm.isIgnoringBatteryOptimizations(context.packageName)) {
                                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                }
                                runCatching { context.startActivity(intent) }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open Battery Optimization Exemption")
                    }
                    Text(
                        "Some phone manufacturers (Xiaomi, Huawei, Oppo, Samsung) may still restrict background WebSockets under aggressive battery saving.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Watchlist & 10-slot Recycle Bin
            item {
                SectionCard("Watchlist (${watchlist.size}/20) & Recycle Bin (${recycleBin.size}/10)") {
                    watchlist.forEach { w ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(w.symbol.stripUsdtSuffix(), fontWeight = FontWeight.Medium)
                            TextButton(onClick = { onRemoveWatchlistAsset(w.symbol) }) { Text("Remove") }
                        }
                    }
                    if (recycleBin.isNotEmpty()) {
                        Text("Recycle Bin (candles preserved)", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                        recycleBin.forEach { b ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(b.symbol.stripUsdtSuffix())
                                Row {
                                    TextButton(onClick = { onRestoreBinAsset(b.symbol) }) { Text("Restore") }
                                    TextButton(onClick = { onDeleteBinAsset(b.symbol) }) { Text("Delete", color = LrmlcColors.ShortRed) }
                                }
                            }
                        }
                    }
                }
            }

            // Storage & Retention
            item {
                SectionCard("Storage & Retention (${settings.retentionDays} days)") {
                    Slider(
                        value = settings.retentionDays.toFloat(),
                        onValueChange = { v -> onUpdateSettings { it.copy(retentionDays = v.toInt()) } },
                        valueRange = 14f..90f
                    )
                    val totalBytes = storageSummary.sumOf { it.totalBytes }
                    Text(
                        "Total stored (${settings.exchange.displayName} ${settings.marketType.displayName}): ${String.format(Locale.US, "%.2f MB", totalBytes / (1024.0 * 1024.0))}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    storageSummary.forEach { s ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("${s.symbol.stripUsdtSuffix()} · ${s.totalCandles} bars (${String.format(Locale.US, "%.2f MB", s.totalBytes / (1024.0 * 1024.0))})", style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { onClearAssetStorage(s.symbol) }) { Text("Clear", color = LrmlcColors.ShortRed) }
                        }
                    }
                }
            }

            // Export & Import (SAF)
            item {
                SectionCard("Backup Export & Import") {
                    SwitchRow("Include stored 1m candles in export", includeCandlesInExport) {
                        includeCandlesInExport = it
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { exportLauncher.launch("lrmlc_backup_${System.currentTimeMillis()}.lrmlc.json.gz") },
                            modifier = Modifier.weight(1f)
                        ) { Text("Export Backup") }
                        OutlinedButton(
                            onClick = { importLauncher.launch(arrayOf("*/*")) },
                            modifier = Modifier.weight(1f)
                        ) { Text("Import Backup") }
                    }
                }
            }

            // About & Disclaimer
            item {
                SectionCard("About Trading Alerts (LRMLC)") {
                    Text(
                        "Version 1.0.0 · Pure on-device Logistic Regression Machine Learning & Confluence. Public read-only market data only. No accounts, no API keys, no telemetry, no order execution.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    importPreview?.let { p ->
        AlertDialog(
            onDismissRequest = onDismissImportPreview,
            title = { Text("Import Backup Preview") },
            text = {
                Text(
                    "Schema v${p.schemaVersion}\n" +
                        "• Watchlist entries: ${p.watchlistCount}\n" +
                        "• Recycle bin entries: ${p.recycleBinCount}\n" +
                        "• Trained ML models: ${p.modelCount}\n" +
                        "• Trade & shadow logs: ${p.signalCount}\n" +
                        "• Candle day chunks: ${p.candleChunkCount}\n\n" +
                        "Safe merge preserves any existing symbols/data not overwritten by this backup."
                )
            },
            confirmButton = {
                Button(onClick = onConfirmImport) { Text("Merge Import") }
            },
            dismissButton = {
                TextButton(onClick = onDismissImportPreview) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
