package com.lrmlc.tradingalerts.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lrmlc.tradingalerts.backup.ImportPreview
import com.lrmlc.tradingalerts.data.local.AssetStorageSummary
import com.lrmlc.tradingalerts.data.local.ExitCellRuleEntity
import com.lrmlc.tradingalerts.data.local.RecycleBinEntity
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.data.model.AccentColor
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.ChartStyle
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.ThresholdMode
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.data.remote.ConnectionTestReport
import com.lrmlc.tradingalerts.ml.ExitWarningFeatureBuilder
import com.lrmlc.tradingalerts.ml.TrainingStatusSnapshot
import com.lrmlc.tradingalerts.trade.SlTpManager
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import com.lrmlc.tradingalerts.ui.theme.LrmlcShapes
import com.lrmlc.tradingalerts.ui.theme.SectionHeaderLabel
import com.lrmlc.tradingalerts.ui.theme.accentColorValue
import com.lrmlc.tradingalerts.ui.theme.cardBorderStroke
import java.util.Locale
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    connectionReport: ConnectionTestReport?,
    isTestingConnection: Boolean,
    trainingStatus: TrainingStatusSnapshot,
    watchlist: List<WatchlistEntity>,
    recycleBin: List<RecycleBinEntity>,
    storageSummary: List<AssetStorageSummary>,
    importPreview: ImportPreview?,
    exitCellRules: List<ExitCellRuleEntity> = emptyList(),
    onUpdateSettings: ((AppSettings) -> AppSettings) -> Unit,
    onRunConnectionTest: () -> Unit,
    onTrainNow: () -> Unit,
    onPauseTraining: () -> Unit,
    onResumeTraining: () -> Unit,
    onRemoveWatchlistAsset: (String) -> Unit,
    onRestoreBinAsset: (String) -> Unit,
    onDeleteBinAsset: (String) -> Unit,
    onRefreshStorage: () -> Unit,
    onClearAssetStorage: (String) -> Unit,
    onExportBackup: (Uri, Boolean) -> Unit,
    onInspectImportUri: (Uri) -> Unit,
    onConfirmImport: () -> Unit,
    onDismissImportPreview: () -> Unit
) {
    val context = LocalContext.current
    var includeCandlesInExport by remember { mutableStateOf(false) }
    val tnumStyle = TextStyle(fontFamily = FontFamily.Monospace, fontFeatureSettings = "tnum")

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/gzip")
    ) { uri ->
        if (uri != null) onExportBackup(uri, includeCandlesInExport)
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onInspectImportUri(uri)
    }

    LaunchedEffect(Unit) {
        onRefreshStorage()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Settings", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "${settings.exchange.displayName} ${settings.marketType.displayName} · Strategy & Preferences",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Data Source & Connection Test
            item {
                SectionCard("Market Data Source") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ExchangeId.entries.forEach { ex ->
                            FilterChip(
                                selected = settings.exchange == ex,
                                onClick = { onUpdateSettings { it.copy(exchange = ex) } },
                                label = { Text(ex.displayName) },
                                shape = LrmlcShapes.ButtonShape,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MarketType.entries.forEach { mt ->
                            FilterChip(
                                selected = settings.marketType == mt,
                                onClick = { onUpdateSettings { it.copy(marketType = mt) } },
                                label = { Text(mt.displayName) },
                                shape = LrmlcShapes.ButtonShape,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = onRunConnectionTest,
                        enabled = !isTestingConnection,
                        shape = LrmlcShapes.ButtonShape,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isTestingConnection) "Testing..." else "Test Exchange Connection")
                    }
                    connectionReport?.steps?.forEach { step ->
                        Text(
                            text = "${if (step.passed) "✓" else "✕"} ${step.name}: ${step.detail}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (step.passed) LrmlcColors.LongGreen else LrmlcColors.ShortRed
                        )
                    }
                }
            }

            // Chart, Theme & Accent [U19]
            item {
                SectionCard("Appearance & Chart") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = settings.chartStyle == ChartStyle.HEIKIN_ASHI,
                            onClick = { onUpdateSettings { it.copy(chartStyle = ChartStyle.HEIKIN_ASHI) } },
                            label = { Text("Heikin Ashi") },
                            shape = LrmlcShapes.ButtonShape,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        FilterChip(
                            selected = settings.chartStyle == ChartStyle.CANDLES,
                            onClick = { onUpdateSettings { it.copy(chartStyle = ChartStyle.CANDLES) } },
                            label = { Text("Normal Candles") },
                            shape = LrmlcShapes.ButtonShape,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                    SwitchRow("Dark Theme", settings.darkTheme) { dark ->
                        onUpdateSettings { it.copy(darkTheme = dark) }
                    }
                    Text("Accent Color", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AccentColor.entries.forEach { accent ->
                            val swatchColor = accentColorValue(accent, settings.darkTheme)
                            val selected = settings.accentColor == accent
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.clickable {
                                    onUpdateSettings { it.copy(accentColor = accent) }
                                }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(swatchColor)
                                        .then(
                                            if (selected) Modifier.border(2.5.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                            else Modifier
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (selected) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = "${accent.displayName} selected",
                                            tint = if (settings.darkTheme) LrmlcColors.DarkOnPrimary else Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = accent.displayName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Confluence & Risk Parameters [U9, U20]
            item {
                val savedCap = settings.engineConfig.capitalUsd
                var capitalText by remember(savedCap) { mutableStateOf(savedCap.toString()) }
                var riskText by remember(settings.engineConfig.maxLossUsd) { mutableStateOf(settings.engineConfig.maxLossUsd.toString()) }
                var tpText by remember(settings.engineConfig.takeProfitUsd) { mutableStateOf(settings.engineConfig.takeProfitUsd.toString()) }
                var feeText by remember(settings.engineConfig.roundTripFeeRate) { mutableStateOf((settings.engineConfig.roundTripFeeRate * 100.0).toString()) }

                val draftCap = (capitalText.toDoubleOrNull() ?: savedCap).coerceAtLeast(0.01)
                val draftRisk = (riskText.toDoubleOrNull() ?: settings.engineConfig.maxLossUsd).coerceAtLeast(0.01)
                val draftTp = (tpText.toDoubleOrNull() ?: settings.engineConfig.takeProfitUsd).coerceAtLeast(0.01)
                val draftFeeRate = ((feeText.toDoubleOrNull() ?: (settings.engineConfig.roundTripFeeRate * 100.0)) / 100.0).coerceIn(0.0, 0.05)

                val barrierMetrics = remember(draftCap, draftRisk, draftTp, draftFeeRate) {
                    SlTpManager.computeBarrierMetrics(draftCap, draftRisk, draftTp, draftFeeRate)
                }

                SectionCard("Confluence & Risk Parameters") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = capitalText, onValueChange = { capitalText = it }, label = { Text("Capital ($)") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = riskText, onValueChange = { riskText = it }, label = { Text("Max Loss ($)") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = tpText, onValueChange = { tpText = it }, label = { Text("Min TP ($)") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = feeText, onValueChange = { feeText = it }, label = { Text("Fee (%)") }, modifier = Modifier.weight(1f), singleLine = true)
                    }

                    // Derived barrier percentages [U9]
                    Text(
                        text = String.format(
                            Locale.US,
                            "Stop = %.2f%% | TP = %.2f%% | Fee = %.1f%% of barrier",
                            barrierMetrics.stopDistancePct,
                            barrierMetrics.tpDistancePct,
                            barrierMetrics.feeAsPctOfBarrier
                        ),
                        style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                        fontWeight = FontWeight.SemiBold,
                        color = if (barrierMetrics.feeExceeds10Pct) LrmlcColors.WarningAmber else MaterialTheme.colorScheme.primary
                    )
                    if (barrierMetrics.feeExceeds10Pct) {
                        Text(
                            text = "Warning: fees exceed 10% of the barrier distance. Consider scaling your SL/TP limits.",
                            style = MaterialTheme.typography.bodySmall,
                            color = LrmlcColors.WarningAmber
                        )
                    }

                    val parsedCap = capitalText.toDoubleOrNull()
                    if (parsedCap != null && parsedCap > 0.0 && abs(parsedCap - savedCap) > 1e-6) {
                        OutlinedButton(
                            onClick = {
                                val ratio = parsedCap / savedCap.coerceAtLeast(0.01)
                                val scaledRisk = (riskText.toDoubleOrNull() ?: settings.engineConfig.maxLossUsd) * ratio
                                val scaledTp = (tpText.toDoubleOrNull() ?: settings.engineConfig.takeProfitUsd) * ratio
                                riskText = String.format(Locale.US, "%.2f", scaledRisk)
                                tpText = String.format(Locale.US, "%.2f", scaledTp)
                            },
                            shape = LrmlcShapes.ButtonShape,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Scale limits to keep distance")
                        }
                    }

                    // Fixed ranges read-only row [U20]
                    Text(
                        text = "Ranges (fixed): 30m/3 | 1h/7 | 2h/15 | 4h/30. The app picks the best range per asset.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            onUpdateSettings { cur ->
                                cur.copy(
                                    engineConfig = cur.engineConfig.copy(
                                        capitalUsd = (capitalText.toDoubleOrNull() ?: cur.engineConfig.capitalUsd).coerceAtLeast(0.01),
                                        maxLossUsd = (riskText.toDoubleOrNull() ?: cur.engineConfig.maxLossUsd).coerceAtLeast(0.01),
                                        takeProfitUsd = (tpText.toDoubleOrNull() ?: cur.engineConfig.takeProfitUsd).coerceAtLeast(0.01),
                                        roundTripFeeRate = ((feeText.toDoubleOrNull() ?: 0.1) / 100.0).coerceIn(0.0, 0.05)
                                    )
                                )
                            }
                        },
                        shape = LrmlcShapes.ButtonShape,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save Strategy Parameters") }
                }
            }

            // ML & SL/TP Controls
            item {
                SectionCard("Machine Learning & SL/TP") {
                    SwitchRow("Auto-SL (learned 80th pct MAE)", settings.autoSlEnabled) { v ->
                        onUpdateSettings { it.copy(autoSlEnabled = v) }
                    }
                    SwitchRow("Auto-TP (learned median MFE)", settings.autoTpEnabled) { v ->
                        onUpdateSettings { it.copy(autoTpEnabled = v) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = settings.thresholdMode == ThresholdMode.AUTO_EXPECTANCY,
                            onClick = { onUpdateSettings { it.copy(thresholdMode = ThresholdMode.AUTO_EXPECTANCY) } },
                            label = { Text("Auto Threshold") },
                            shape = LrmlcShapes.ButtonShape,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        FilterChip(
                            selected = settings.thresholdMode == ThresholdMode.MANUAL,
                            onClick = { onUpdateSettings { it.copy(thresholdMode = ThresholdMode.MANUAL) } },
                            label = { Text("Manual (${(settings.manualThreshold * 100).toInt()}%)") },
                            shape = LrmlcShapes.ButtonShape,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                    if (settings.thresholdMode == ThresholdMode.MANUAL) {
                        Slider(
                            value = settings.manualThreshold.toFloat(),
                            onValueChange = { v -> onUpdateSettings { it.copy(manualThreshold = v.toDouble()) } },
                            valueRange = 0.45f..0.85f
                        )
                    }
                    Text(trainingStatus.stageMessage, style = MaterialTheme.typography.bodySmall)
                    if (trainingStatus.isRunning) {
                        LinearProgressIndicator(progress = { trainingStatus.progressPct / 100f }, modifier = Modifier.fillMaxWidth())
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onTrainNow, enabled = !trainingStatus.isRunning, shape = LrmlcShapes.ButtonShape) { Text("Train Now") }
                        if (trainingStatus.isRunning) {
                            OutlinedButton(onClick = onPauseTraining, shape = LrmlcShapes.ButtonShape) { Text("Pause") }
                        } else if (trainingStatus.isPaused) {
                            OutlinedButton(onClick = onResumeTraining, shape = LrmlcShapes.ButtonShape) { Text("Resume") }
                        }
                    }
                }
            }

            // Phase-Aware Exit Warnings [U22]
            item {
                val exitSummary = remember(exitCellRules) { ExitWarningFeatureBuilder.summarizeRules(exitCellRules) }
                SectionCard("Exit Warnings") {
                    SwitchRow("ML exit warnings", settings.notifyExitMl) { v ->
                        onUpdateSettings { it.copy(notifyExitMl = v) }
                    }
                    SwitchRow("Structure exit warnings", settings.notifyExitStructure) { v ->
                        onUpdateSettings { it.copy(notifyExitStructure = v) }
                    }
                    val statusLine = exitSummary.statusLine
                    Text(
                        text = statusLine,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (exitSummary.reliableCellCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Notifications & Background Monitoring
            item {
                SectionCard("Notifications & Background Service") {
                    SwitchRow("Keep monitoring in background", settings.keepMonitoringInBackground) { v ->
                        onUpdateSettings { it.copy(keepMonitoringInBackground = v) }
                    }
                    SwitchRow("Start monitoring on boot", settings.startOnBoot) { v ->
                        onUpdateSettings { it.copy(startOnBoot = v) }
                    }
                    SwitchRow("Notify on TP hit", settings.notifyTpHit) { v ->
                        onUpdateSettings { it.copy(notifyTpHit = v) }
                    }
                    SwitchRow("Notify on SL hit", settings.notifySlHit) { v ->
                        onUpdateSettings { it.copy(notifySlHit = v) }
                    }
                    SwitchRow("Notify on filtered signals", settings.notifyFilteredSignals) { v ->
                        onUpdateSettings { it.copy(notifyFilteredSignals = v) }
                    }
                    SwitchRow("Quiet hours (23:00–07:00)", settings.quietHoursEnabled) { v ->
                        onUpdateSettings { it.copy(quietHoursEnabled = v) }
                    }
                    OutlinedButton(
                        onClick = {
                            val pm = context.getSystemService(PowerManager::class.java)
                            if (pm != null && !pm.isIgnoringBatteryOptimizations(context.packageName)) {
                                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                }
                                runCatching { context.startActivity(intent) }
                            }
                        },
                        shape = LrmlcShapes.ButtonShape,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open Battery Optimization Exemption")
                    }
                    Text(
                        "Some phone manufacturers (Xiaomi, Huawei, Oppo, Samsung) may still restrict background WebSockets under aggressive battery saving.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Watchlist & 10-slot Recycle Bin
            item {
                SectionCard("Watchlist (${watchlist.size}/20) & Recycle Bin (${recycleBin.size}/10)") {
                    watchlist.forEach { w ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(w.symbol.stripUsdtSuffix(), fontWeight = FontWeight.Medium)
                            TextButton(onClick = { onRemoveWatchlistAsset(w.symbol) }) { Text("Remove") }
                        }
                    }
                    if (recycleBin.isNotEmpty()) {
                        Text("Recycle Bin (candles preserved)", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                        recycleBin.forEach { b ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(b.symbol.stripUsdtSuffix())
                                Row {
                                    TextButton(onClick = { onRestoreBinAsset(b.symbol) }) { Text("Restore") }
                                    TextButton(onClick = { onDeleteBinAsset(b.symbol) }) { Text("Delete", color = LrmlcColors.ShortRed) }
                                }
                            }
                        }
                    }
                }
            }

            // Storage & Retention
            item {
                SectionCard("Storage & Retention (${settings.retentionDays} days)") {
                    Slider(
                        value = settings.retentionDays.toFloat(),
                        onValueChange = { v -> onUpdateSettings { it.copy(retentionDays = v.toInt()) } },
                        valueRange = 14f..90f
                    )
                    val totalBytes = storageSummary.sumOf { it.totalBytes }
                    Text(
                        "Total stored (${settings.exchange.displayName} ${settings.marketType.displayName}): ${String.format(Locale.US, "%.2f MB", totalBytes / (1024.0 * 1024.0))}",
                        style = MaterialTheme.typography.bodySmall.merge(tnumStyle)
                    )
                    storageSummary.forEach { s ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("${s.symbol.stripUsdtSuffix()} · ${s.totalCandles} bars (${String.format(Locale.US, "%.2f MB", s.totalBytes / (1024.0 * 1024.0))})", style = MaterialTheme.typography.bodySmall.merge(tnumStyle))
                            TextButton(onClick = { onClearAssetStorage(s.symbol) }) { Text("Clear", color = LrmlcColors.ShortRed) }
                        }
                    }
                }
            }

            // Export & Import (SAF)
            item {
                SectionCard("Backup Export & Import") {
                    SwitchRow("Include stored 1m candles in export", includeCandlesInExport) {
                        includeCandlesInExport = it
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { exportLauncher.launch("lrmlc_backup_${System.currentTimeMillis()}.lrmlc.json.gz") },
                            shape = LrmlcShapes.ButtonShape,
                            modifier = Modifier.weight(1f)
                        ) { Text("Export Backup") }
                        OutlinedButton(
                            onClick = { importLauncher.launch(arrayOf("*/*")) },
                            shape = LrmlcShapes.ButtonShape,
                            modifier = Modifier.weight(1f)
                        ) { Text("Import Backup") }
                    }
                }
            }

            // About & Disclaimer
            item {
                SectionCard("About Trading Alerts (LRMLC)") {
                    Text(
                        "Version 1.0.0 · Pure on-device Logistic Regression Machine Learning & Confluence. Public read-only market data only. No accounts, no API keys, no telemetry, no order execution.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    importPreview?.let { p ->
        AlertDialog(
            onDismissRequest = onDismissImportPreview,
            title = { Text("Import Backup Preview") },
            text = {
                Text(
                    "Schema v${p.schemaVersion}\n" +
                        "• Watchlist entries: ${p.watchlistCount}\n" +
                        "• Recycle bin entries: ${p.recycleBinCount}\n" +
                        "• Trained ML models: ${p.modelCount}\n" +
                        "• Trade & shadow logs: ${p.signalCount}\n" +
                        "• Candle day chunks: ${p.candleChunkCount}\n\n" +
                        "Safe merge preserves any existing symbols/data not overwritten by this backup."
                )
            },
            confirmButton = {
                Button(onClick = onConfirmImport, shape = LrmlcShapes.ButtonShape) { Text("Merge Import") }
            },
            dismissButton = {
                TextButton(onClick = onDismissImportPreview) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.animateContentSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = LrmlcShapes.CardShape,
        border = cardBorderStroke()
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionHeaderLabel(title)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
