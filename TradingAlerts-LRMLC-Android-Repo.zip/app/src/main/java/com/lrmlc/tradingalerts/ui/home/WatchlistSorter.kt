package com.lrmlc.tradingalerts.ui.home

import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.service.PersistentNotificationFormatter
import java.util.Locale

data class FeedStatusState(
    val label: String,
    val isOk: Boolean,
    val isStale: Boolean,
    val maxAgeSeconds: Long? = null
)

data class SlTpDisplay(
    val isActive: Boolean,
    val slText: String,
    val tpText: String,
    val combinedText: String
)

/**
 * Pure UI sort for Home watchlist [U14]:
 * - Assets with at least one accepted alert (accepted == true) come first, ordered by newest signalTimeMs DESC.
 * - Assets without accepted alerts follow in their original relative order (displayOrder).
 * - Shadow signals (accepted == false) are completely ignored.
 */
fun sortWatchlistByRecentAlert(
    watchlist: List<WatchlistEntity>,
    signals: List<SignalCandidateEntity>
): List<WatchlistEntity> {
    if (watchlist.size <= 1) return watchlist
    val newestAcceptedBySymbol = HashMap<String, Long>()
    for (sig in signals) {
        if (!sig.accepted) continue
        val prev = newestAcceptedBySymbol[sig.symbol]
        if (prev == null || sig.signalTimeMs > prev) {
            newestAcceptedBySymbol[sig.symbol] = sig.signalTimeMs
        }
    }
    if (newestAcceptedBySymbol.isEmpty()) return watchlist

    return watchlist.withIndex()
        .sortedWith { a, b ->
            val tA = newestAcceptedBySymbol[a.value.symbol]
            val tB = newestAcceptedBySymbol[b.value.symbol]
            when {
                tA != null && tB != null -> {
                    val cmp = tB.compareTo(tA)
                    if (cmp != 0) cmp else a.index.compareTo(b.index)
                }
                tA != null -> -1
                tB != null -> 1
                else -> a.index.compareTo(b.index)
            }
        }
        .map { it.value }
}

/**
 * Computes header feed status from all watchlist rows [U21].
 */
fun computeFeedStatus(
    watchlist: List<WatchlistEntity>,
    nowMs: Long = System.currentTimeMillis()
): FeedStatusState {
    val withData = watchlist.filter { it.lastCandleReceivedMs > 0L }
    if (withData.isEmpty()) {
        return FeedStatusState(label = "No candles yet", isOk = false, isStale = false, maxAgeSeconds = null)
    }
    val agesSec = withData.map { ((nowMs - it.lastCandleReceivedMs) / 1000L).coerceAtLeast(0L) }
    val maxAge = agesSec.maxOrNull() ?: 0L
    val staleCount = agesSec.count { it >= 90L }
    return if (staleCount == 0) {
        FeedStatusState(
            label = "Feed OK ${maxAge}s",
            isOk = true,
            isStale = false,
            maxAgeSeconds = maxAge
        )
    } else {
        FeedStatusState(
            label = "Feed stale · $staleCount of ${withData.size}",
            isOk = false,
            isStale = true,
            maxAgeSeconds = maxAge
        )
    }
}

/**
 * Formats the reserved second line on each Home row [U21].
 */
fun formatSlTpLine(activeTrade: SignalCandidateEntity?, runOnGlyph: String = "\uD83D\uDCA5"): SlTpDisplay {
    if (activeTrade == null) {
        return SlTpDisplay(isActive = false, slText = "--", tpText = "--", combinedText = "--")
    }
    val sl = PersistentNotificationFormatter.formatPrice(activeTrade.appliedSl)
    val tp = PersistentNotificationFormatter.formatPrice(activeTrade.appliedTp) +
        (if (activeTrade.tpReachedTimeMs != null) " \u2713" else "") +
        (if (activeTrade.runOnMarker) " $runOnGlyph" else "")
    return SlTpDisplay(
        isActive = true,
        slText = sl,
        tpText = tp,
        combinedText = "SL $sl · TP $tp"
    )
}

fun formatOutcomeChipText(signal: SignalCandidateEntity, nowMs: Long = System.currentTimeMillis()): String {
    val retStr = signal.netReturnPct?.let { String.format(Locale.US, "%+.1f%%", it * 100.0) }
    val outcomeLabel = when (signal.status) {
        "CLOSED_TP" -> "TP"
        "CLOSED_SL" -> "SL"
        "CLOSED_OPPOSITE" -> "Opp"
        "CLOSED_MANUAL" -> "Manual"
        else -> signal.direction
    }
    val refMs = signal.exitTimeMs ?: signal.signalTimeMs
    val ageStr = formatCompactAge(nowMs - refMs)
    return if (retStr != null) "$outcomeLabel $retStr · $ageStr" else "$outcomeLabel · $ageStr"
}

fun formatCompactAge(elapsedMs: Long): String {
    val sec = (elapsedMs / 1000L).coerceAtLeast(0L)
    return when {
        sec < 60L -> "${sec}s"
        sec < 3600L -> "${sec / 60L}m"
        sec < 86_400L -> "${sec / 3600L}h"
        else -> "${sec / 86_400L}d"
    }
}
