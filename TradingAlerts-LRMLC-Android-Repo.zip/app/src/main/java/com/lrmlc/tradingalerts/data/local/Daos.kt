package com.lrmlc.tradingalerts.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface CandleChunkDao {
    @Query(
        "SELECT * FROM candle_day_chunks " +
            "WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol " +
            "AND utcDayIndex BETWEEN :startDay AND :endDay ORDER BY utcDayIndex ASC"
    )
    suspend fun getChunksInRange(
        exchange: String,
        marketType: String,
        symbol: String,
        startDay: Long,
        endDay: Long
    ): List<CandleDayChunkEntity>

    @Query(
        "SELECT * FROM candle_day_chunks " +
            "WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol " +
            "ORDER BY utcDayIndex ASC"
    )
    suspend fun getAllChunksForAsset(
        exchange: String,
        marketType: String,
        symbol: String
    ): List<CandleDayChunkEntity>

    @Query(
        "SELECT * FROM candle_day_chunks " +
            "WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol " +
            "AND utcDayIndex = :utcDayIndex LIMIT 1"
    )
    suspend fun getChunk(
        exchange: String,
        marketType: String,
        symbol: String,
        utcDayIndex: Long
    ): CandleDayChunkEntity?

    @Query(
        "SELECT utcDayIndex, candleCount FROM candle_day_chunks " +
            "WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol " +
            "AND utcDayIndex BETWEEN :startDay AND :endDay"
    )
    suspend fun getDayCounts(
        exchange: String,
        marketType: String,
        symbol: String,
        startDay: Long,
        endDay: Long
    ): List<ChunkDayCountSummary>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChunk(chunk: CandleDayChunkEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChunks(chunks: List<CandleDayChunkEntity>)

    @Query(
        "DELETE FROM candle_day_chunks " +
            "WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol"
    )
    suspend fun deleteAllForAsset(exchange: String, marketType: String, symbol: String)

    @Query("DELETE FROM candle_day_chunks WHERE utcDayIndex < :minAllowedDay")
    suspend fun trimOlderThan(minAllowedDay: Long): Int

    @Query(
        "SELECT symbol, COALESCE(SUM(byteSize), 0) AS totalBytes, " +
            "COALESCE(SUM(candleCount), 0) AS totalCandles, COUNT(*) AS dayCount " +
            "FROM candle_day_chunks WHERE exchange = :exchange AND marketType = :marketType " +
            "GROUP BY symbol ORDER BY totalBytes DESC"
    )
    suspend fun getStorageSummary(exchange: String, marketType: String): List<AssetStorageSummary>

    @Query("SELECT * FROM candle_day_chunks")
    suspend fun exportAllChunks(): List<CandleDayChunkEntity>
}

@Dao
interface WatchlistDao {
    @Query(
        "SELECT * FROM watchlist_assets WHERE exchange = :exchange AND marketType = :marketType " +
            "ORDER BY displayOrder ASC, addedAtMs ASC"
    )
    fun observeWatchlist(exchange: String, marketType: String): Flow<List<WatchlistEntity>>

    @Query(
        "SELECT * FROM watchlist_assets WHERE exchange = :exchange AND marketType = :marketType " +
            "ORDER BY displayOrder ASC, addedAtMs ASC"
    )
    suspend fun getWatchlist(exchange: String, marketType: String): List<WatchlistEntity>

    @Query(
        "SELECT * FROM watchlist_assets WHERE exchange = :exchange AND marketType = :marketType " +
            "AND symbol = :symbol LIMIT 1"
    )
    suspend fun getAsset(exchange: String, marketType: String, symbol: String): WatchlistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: WatchlistEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<WatchlistEntity>)

    @Query(
        "DELETE FROM watchlist_assets WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol"
    )
    suspend fun delete(exchange: String, marketType: String, symbol: String)

    @Query(
        "UPDATE watchlist_assets SET inPosition = :inPosition, inPositionUpdatedAtMs = :updatedAtMs " +
            "WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol"
    )
    suspend fun setInPosition(
        exchange: String,
        marketType: String,
        symbol: String,
        inPosition: Boolean,
        updatedAtMs: Long
    )

    @Query(
        "UPDATE watchlist_assets SET muted = :muted " +
            "WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol"
    )
    suspend fun setMuted(exchange: String, marketType: String, symbol: String, muted: Boolean)

    @Query("SELECT * FROM watchlist_assets")
    suspend fun exportAll(): List<WatchlistEntity>
}

@Dao
interface RecycleBinDao {
    @Query(
        "SELECT * FROM recycle_bin_assets WHERE exchange = :exchange AND marketType = :marketType " +
            "ORDER BY removedAtMs DESC"
    )
    fun observeBin(exchange: String, marketType: String): Flow<List<RecycleBinEntity>>

    @Query(
        "SELECT * FROM recycle_bin_assets WHERE exchange = :exchange AND marketType = :marketType " +
            "ORDER BY removedAtMs ASC"
    )
    suspend fun getBinOldestFirst(exchange: String, marketType: String): List<RecycleBinEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: RecycleBinEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<RecycleBinEntity>)

    @Query(
        "DELETE FROM recycle_bin_assets WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol"
    )
    suspend fun delete(exchange: String, marketType: String, symbol: String)

    @Query("SELECT * FROM recycle_bin_assets")
    suspend fun exportAll(): List<RecycleBinEntity>
}

@Dao
interface SignalCandidateDao {
    @Query(
        "SELECT * FROM signal_candidates WHERE exchange = :exchange AND marketType = :marketType " +
            "AND status = 'ACTIVE' ORDER BY signalTimeMs DESC"
    )
    fun observeActiveTrades(exchange: String, marketType: String): Flow<List<SignalCandidateEntity>>

    @Query(
        "SELECT * FROM signal_candidates WHERE exchange = :exchange AND marketType = :marketType " +
            "AND status = 'ACTIVE'"
    )
    suspend fun getActiveTrades(exchange: String, marketType: String): List<SignalCandidateEntity>

    @Query(
        "SELECT * FROM signal_candidates WHERE exchange = :exchange AND marketType = :marketType " +
            "AND symbol = :symbol AND status = 'ACTIVE' ORDER BY signalTimeMs DESC LIMIT 1"
    )
    suspend fun getActiveTradeForSymbol(
        exchange: String,
        marketType: String,
        symbol: String
    ): SignalCandidateEntity?

    @Query(
        "SELECT * FROM signal_candidates WHERE exchange = :exchange AND marketType = :marketType " +
            "AND symbol = :symbol ORDER BY signalTimeMs DESC LIMIT :limit"
    )
    fun observeSignalsForSymbol(
        exchange: String,
        marketType: String,
        symbol: String,
        limit: Int = 100
    ): Flow<List<SignalCandidateEntity>>

    @Query(
        "SELECT * FROM signal_candidates WHERE exchange = :exchange AND marketType = :marketType " +
            "ORDER BY signalTimeMs DESC LIMIT :limit"
    )
    fun observeRecentSignals(
        exchange: String,
        marketType: String,
        limit: Int = 500
    ): Flow<List<SignalCandidateEntity>>

    @Query(
        "SELECT * FROM signal_candidates WHERE exchange = :exchange AND marketType = :marketType " +
            "ORDER BY signalTimeMs ASC"
    )
    suspend fun getAllForMarket(exchange: String, marketType: String): List<SignalCandidateEntity>

    @Query("SELECT * FROM signal_candidates WHERE signalId = :signalId LIMIT 1")
    suspend fun getById(signalId: String): SignalCandidateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SignalCandidateEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<SignalCandidateEntity>)

    @Query("UPDATE signal_candidates SET notified = 1 WHERE signalId = :signalId")
    suspend fun markNotified(signalId: String)

    @Query(
        "DELETE FROM signal_candidates WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol"
    )
    suspend fun deleteForSymbol(exchange: String, marketType: String, symbol: String)

    @Query("SELECT * FROM signal_candidates")
    suspend fun exportAll(): List<SignalCandidateEntity>
}

@Dao
interface MlModelDao {
    @Query("SELECT * FROM ml_models WHERE isActive = 1 AND exchange = :exchange AND marketType = :marketType")
    fun observeActiveModels(exchange: String, marketType: String): Flow<List<MlModelEntity>>

    @Query("SELECT * FROM ml_models WHERE isActive = 1 AND exchange = :exchange AND marketType = :marketType")
    suspend fun getActiveModelsForMarket(exchange: String, marketType: String): List<MlModelEntity>

    @Query("SELECT * FROM ml_models WHERE modelKey = :modelKey AND isActive = 1 LIMIT 1")
    suspend fun getActiveModel(modelKey: String): MlModelEntity?

    @Query("SELECT * FROM ml_models WHERE isActive = 1")
    suspend fun getAllActiveModels(): List<MlModelEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(model: MlModelEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(models: List<MlModelEntity>)

    @Query("UPDATE ml_models SET isActive = 0 WHERE modelKey = :modelKey")
    suspend fun deactivateKey(modelKey: String)

    @Transaction
    suspend fun atomicSwapActive(model: MlModelEntity) {
        deactivateKey(model.modelKey)
        upsert(model.copy(isActive = true))
    }

    @Query("SELECT * FROM ml_models")
    suspend fun exportAll(): List<MlModelEntity>
}

@Dao
interface TrainingJobDao {
    @Query("SELECT * FROM training_jobs ORDER BY updatedAtMs DESC LIMIT 20")
    fun observeRecentJobs(): Flow<List<TrainingJobEntity>>

    @Query("SELECT * FROM training_jobs WHERE status IN ('PENDING', 'RUNNING', 'PAUSED') ORDER BY createdAtMs ASC LIMIT 1")
    suspend fun getNextResumableJob(): TrainingJobEntity?

    @Query("SELECT * FROM training_jobs WHERE jobId = :jobId LIMIT 1")
    suspend fun getJob(jobId: String): TrainingJobEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(job: TrainingJobEntity)

    @Query("UPDATE training_jobs SET status = :status, statusMessage = :message, updatedAtMs = :updatedAtMs WHERE jobId = :jobId")
    suspend fun updateStatus(jobId: String, status: String, message: String, updatedAtMs: Long)

    @Query("DELETE FROM training_jobs WHERE status = 'COMPLETED' AND updatedAtMs < :olderThanMs")
    suspend fun pruneCompleted(olderThanMs: Long)
}

@Dao
interface TrainingLogDao {
    @Query(
        "SELECT * FROM training_logs WHERE exchange = :exchange AND marketType = :marketType " +
            "ORDER BY timestampMs DESC LIMIT :limit"
    )
    fun observeLogs(exchange: String, marketType: String, limit: Int = 100): Flow<List<TrainingLogEntity>>

    @Query("SELECT * FROM training_logs WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): TrainingLogEntity?

    @Query(
        "SELECT * FROM training_logs WHERE exchange = :exchange AND marketType = :marketType " +
            "AND timestampMs >= :sinceMs ORDER BY timestampMs DESC LIMIT :limit"
    )
    suspend fun getLogsSince(
        exchange: String,
        marketType: String,
        sinceMs: Long,
        limit: Int = 100
    ): List<TrainingLogEntity>

    @Query(
        "SELECT * FROM training_logs WHERE exchange = :exchange AND marketType = :marketType " +
            "ORDER BY timestampMs DESC LIMIT 1"
    )
    suspend fun getLatestForMarket(exchange: String, marketType: String): TrainingLogEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: TrainingLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<TrainingLogEntity>)

    @Query("SELECT * FROM training_logs")
    suspend fun exportAll(): List<TrainingLogEntity>
}

@Dao
interface ExitWarningStateDao {
    @Query(
        "SELECT * FROM exit_warning_states WHERE exchange = :exchange AND marketType = :marketType " +
            "AND symbol = :symbol LIMIT 1"
    )
    suspend fun get(exchange: String, marketType: String, symbol: String): ExitWarningStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(state: ExitWarningStateEntity)
}

@Dao
interface ExitCellRuleDao {
    @Query(
        "SELECT * FROM exit_cell_rules WHERE exchange = :exchange AND marketType = :marketType " +
            "ORDER BY ageBucket ASC, progressBucket ASC"
    )
    fun observeRules(exchange: String, marketType: String): Flow<List<ExitCellRuleEntity>>

    @Query(
        "SELECT * FROM exit_cell_rules WHERE exchange = :exchange AND marketType = :marketType " +
            "ORDER BY ageBucket ASC, progressBucket ASC"
    )
    suspend fun getRules(exchange: String, marketType: String): List<ExitCellRuleEntity>

    @Query(
        "SELECT * FROM exit_cell_rules WHERE exchange = :exchange AND marketType = :marketType " +
            "AND ageBucket = :ageBucket AND progressBucket = :progressBucket LIMIT 1"
    )
    suspend fun getRule(
        exchange: String,
        marketType: String,
        ageBucket: Int,
        progressBucket: Int
    ): ExitCellRuleEntity?

    @Query("DELETE FROM exit_cell_rules WHERE exchange = :exchange AND marketType = :marketType")
    suspend fun deleteForMarket(exchange: String, marketType: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rules: List<ExitCellRuleEntity>)

    @Transaction
    suspend fun replaceForMarket(exchange: String, marketType: String, rules: List<ExitCellRuleEntity>) {
        deleteForMarket(exchange, marketType)
        if (rules.isNotEmpty()) upsertAll(rules)
    }

    @Query("SELECT * FROM exit_cell_rules")
    suspend fun exportAll(): List<ExitCellRuleEntity>
}

@Dao
interface AssetPresetSelectionDao {
    @Query("SELECT * FROM asset_preset_selection WHERE exchange = :exchange AND marketType = :marketType")
    fun observeSelections(exchange: String, marketType: String): Flow<List<AssetPresetSelectionEntity>>

    @Query("SELECT * FROM asset_preset_selection WHERE exchange = :exchange AND marketType = :marketType")
    suspend fun getSelections(exchange: String, marketType: String): List<AssetPresetSelectionEntity>

    @Query(
        "SELECT * FROM asset_preset_selection WHERE exchange = :exchange AND marketType = :marketType " +
            "AND symbol = :symbol LIMIT 1"
    )
    suspend fun getSelection(exchange: String, marketType: String, symbol: String): AssetPresetSelectionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<AssetPresetSelectionEntity>)

    @Query("SELECT * FROM asset_preset_selection")
    suspend fun exportAll(): List<AssetPresetSelectionEntity>
}

@Dao
interface SyncProgressDao {
    @Query("SELECT * FROM sync_progress WHERE exchange = :exchange AND marketType = :marketType")
    fun observeForMarket(exchange: String, marketType: String): Flow<List<SyncProgressEntity>>

    @Query(
        "SELECT * FROM sync_progress WHERE exchange = :exchange AND marketType = :marketType " +
            "AND symbol = :symbol LIMIT 1"
    )
    suspend fun get(exchange: String, marketType: String, symbol: String): SyncProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(progress: SyncProgressEntity)

    @Query("DELETE FROM sync_progress WHERE exchange = :exchange AND marketType = :marketType AND symbol = :symbol")
    suspend fun deleteForSymbol(exchange: String, marketType: String, symbol: String)
}
