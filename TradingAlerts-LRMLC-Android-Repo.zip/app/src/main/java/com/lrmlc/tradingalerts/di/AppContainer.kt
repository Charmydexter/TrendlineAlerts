package com.lrmlc.tradingalerts.di

import android.content.Context
import com.lrmlc.tradingalerts.backup.BackupManager
import com.lrmlc.tradingalerts.data.local.AppDatabase
import com.lrmlc.tradingalerts.data.local.FuturesMetricsStore
import com.lrmlc.tradingalerts.data.local.SettingsRepository
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.remote.BinanceAdapter
import com.lrmlc.tradingalerts.data.remote.BybitAdapter
import com.lrmlc.tradingalerts.data.remote.ConnectionTester
import com.lrmlc.tradingalerts.data.remote.ExchangeAdapter
import com.lrmlc.tradingalerts.data.remote.RestRateLimiterQueue
import com.lrmlc.tradingalerts.data.remote.WebSocketFeedClient
import com.lrmlc.tradingalerts.data.repository.CandleStoreRepository
import com.lrmlc.tradingalerts.data.repository.HistorySyncManager
import com.lrmlc.tradingalerts.data.repository.MarketContextManager
import com.lrmlc.tradingalerts.data.repository.WatchlistRepository
import com.lrmlc.tradingalerts.ml.TrainingOrchestrator
import com.lrmlc.tradingalerts.service.LiveFormingCandleHub
import com.lrmlc.tradingalerts.service.NotificationHelper
import com.lrmlc.tradingalerts.trade.TradeLifecycleManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    val database: AppDatabase = AppDatabase.create(appContext)
    val settingsRepository = SettingsRepository(appContext)
    val restQueue = RestRateLimiterQueue(okHttpClient)

    val bybitAdapter = BybitAdapter(restQueue)
    val binanceAdapter = BinanceAdapter(restQueue)
    val connectionTester = ConnectionTester(okHttpClient)
    val webSocketFeedClient = WebSocketFeedClient(okHttpClient, applicationScope)
    val liveFormingCandles = LiveFormingCandleHub()

    val candleStore = CandleStoreRepository(database.candleChunkDao())
    val watchlistRepository = WatchlistRepository(
        watchlistDao = database.watchlistDao(),
        recycleBinDao = database.recycleBinDao(),
        candleStore = candleStore,
        signalDao = database.signalCandidateDao(),
        syncProgressDao = database.syncProgressDao()
    )
    val historySyncManager = HistorySyncManager(
        candleStore = candleStore,
        syncProgressDao = database.syncProgressDao(),
        settingsRepository = settingsRepository
    )

    val futuresMetricsStore = FuturesMetricsStore(java.io.File(appContext.filesDir, "futures"))
    val marketContextManager = MarketContextManager(
        candleStore = candleStore,
        settingsRepository = settingsRepository,
        watchlistDao = database.watchlistDao(),
        historySyncManager = historySyncManager,
        futuresStore = futuresMetricsStore
    )

    val notificationHelper = NotificationHelper(
        context = appContext,
        watchlistDao = database.watchlistDao(),
        signalDao = database.signalCandidateDao()
    )

    val tradeLifecycleManager = TradeLifecycleManager(
        candleStore = candleStore,
        watchlistDao = database.watchlistDao(),
        signalDao = database.signalCandidateDao(),
        mlModelDao = database.mlModelDao(),
        exitWarningStateDao = database.exitWarningStateDao(),
        exitCellRuleDao = database.exitCellRuleDao(),
        assetPresetSelectionDao = database.assetPresetSelectionDao(),
        settingsRepository = settingsRepository,
        notificationHelper = notificationHelper,
        futuresStore = futuresMetricsStore
    )

    val trainingOrchestrator = TrainingOrchestrator(
        candleStore = candleStore,
        watchlistDao = database.watchlistDao(),
        signalDao = database.signalCandidateDao(),
        mlModelDao = database.mlModelDao(),
        trainingJobDao = database.trainingJobDao(),
        trainingLogDao = database.trainingLogDao(),
        exitCellRuleDao = database.exitCellRuleDao(),
        assetPresetSelectionDao = database.assetPresetSelectionDao(),
        settingsRepository = settingsRepository,
        marketContext = marketContextManager,
        futuresStore = futuresMetricsStore,
        contextPreparer = { exchange, marketType, symbols ->
            val adapter = adapterFor(exchange)
            marketContextManager.ensureSlots()
            marketContextManager.syncMasterHistory(adapter)
            marketContextManager.syncFutures(adapter, marketType, symbols, System.currentTimeMillis() + 45_000L)
        }
    )

    val backupManager = BackupManager(
        db = database,
        settingsRepository = settingsRepository
    )

    fun adapterFor(exchange: ExchangeId): ExchangeAdapter = when (exchange) {
        ExchangeId.BYBIT -> bybitAdapter
        ExchangeId.BINANCE -> binanceAdapter
    }
}
