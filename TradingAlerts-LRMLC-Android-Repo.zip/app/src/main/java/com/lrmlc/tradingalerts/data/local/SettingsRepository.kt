package com.lrmlc.tradingalerts.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.lrmlc.tradingalerts.data.model.AppSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "lrmlc_settings")

class SettingsRepository(private val context: Context) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val settingsJsonKey = stringPreferencesKey("app_settings_json")
    private val batteryGuideShownKey = booleanPreferencesKey("battery_guide_shown")
    private val downloadPausedKey = booleanPreferencesKey("history_download_paused")

    val settingsFlow: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        val raw = prefs[settingsJsonKey]
        if (raw.isNullOrBlank()) {
            AppSettings()
        } else {
            runCatching { json.decodeFromString<AppSettings>(raw) }.getOrDefault(AppSettings())
        }
    }

    val batteryGuideShownFlow: Flow<Boolean> = context.settingsDataStore.data.map { prefs ->
        prefs[batteryGuideShownKey] ?: false
    }

    val downloadPausedFlow: Flow<Boolean> = context.settingsDataStore.data.map { prefs ->
        prefs[downloadPausedKey] ?: false
    }

    suspend fun getSettings(): AppSettings = settingsFlow.first()

    suspend fun updateSettings(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { prefs ->
            val current = prefs[settingsJsonKey]?.let {
                runCatching { json.decodeFromString<AppSettings>(it) }.getOrNull()
            } ?: AppSettings()
            val updated = transform(current)
            prefs[settingsJsonKey] = json.encodeToString(updated)
        }
    }

    suspend fun setSettings(newSettings: AppSettings) {
        context.settingsDataStore.edit { prefs ->
            prefs[settingsJsonKey] = json.encodeToString(newSettings)
        }
    }

    suspend fun markBatteryGuideShown() {
        context.settingsDataStore.edit { prefs ->
            prefs[batteryGuideShownKey] = true
        }
    }

    suspend fun setDownloadPaused(paused: Boolean) {
        context.settingsDataStore.edit { prefs ->
            prefs[downloadPausedKey] = paused
        }
    }
}
