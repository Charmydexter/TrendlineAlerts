package com.lrmlc.tradingalerts.ui.insights

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lrmlc.tradingalerts.data.local.AssetPresetSelectionEntity
import com.lrmlc.tradingalerts.data.local.ExitCellRuleEntity
import com.lrmlc.tradingalerts.data.local.MlModelEntity
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.RangePresets
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.ml.ExitWarningFeatureBuilder
import com.lrmlc.tradingalerts.ml.RunOnBundle
import com.lrmlc.tradingalerts.ml.RunOnSpec
import com.lrmlc.tradingalerts.ml.RunOnTrainer
import com.lrmlc.tradingalerts.ml.ModelExplainer
import com.lrmlc.tradingalerts.ml.SerializedModelBundle
import com.lrmlc.tradingalerts.ml.TrainingReportBuilder
import com.lrmlc.tradingalerts.trade.SlTpManager
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import com.lrmlc.tradingalerts.ui.theme.LrmlcShapes
import com.lrmlc.tradingalerts.ui.theme.SectionHeaderLabel
import com.lrmlc.tradingalerts.ui.theme.cardBorderStroke
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private enum class ExportTarget { COPY, SHARE, SAVE }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun InsightsScreen(
    settings: AppSettings,
    activeModels: List<MlModelEntity>,
    recentSignals: List<SignalCandidateEntity>,
    trainingLogs: List<TrainingLogEntity>,
    exitCellRules: List<ExitCellRuleEntity>,
    assetPresetSelections: List<AssetPresetSelectionEntity>,
    needsRetrain: Boolean,
    onBuildSingleReport: suspend (Long) -> String,
    onBuildRangeReport: suspend (Long) -> String,
    onTrainNow: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val json = remember { Json { ignoreUnknownKeys = true } }
    val tnumStyle = TextStyle(fontFamily = FontFamily.Monospace, fontFeatureSettings = "tnum")

    var selectedRange by remember { mutableStateOf(InsightsRange.D7) }
    var pendingSaveMarkdown by remember { mutableStateOf<String?>(null) }

    val saveMarkdownLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/markdown")
    ) { uri ->
        val content = pendingSaveMarkdown
        pendingSaveMarkdown = null
        if (uri != null && content != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { os ->
                    os.write(content.toByteArray(Charsets.UTF_8))
                }
            }.onSuccess {
                scope.launch { snackbarHostState.showSnackbar("Report saved as Markdown") }
            }.onFailure { err ->
                scope.launch { snackbarHostState.showSnackbar("Save failed: ${err.message ?: "error"}") }
            }
        }
    }

    fun dispatchExport(target: ExportTarget, tag: String, buildMarkdown: suspend () -> String) {
        scope.launch {
            val md = runCatching { buildMarkdown() }.getOrElse { err ->
                snackbarHostState.showSnackbar("Could not build report: ${err.message ?: "error"}")
                return@launch
            }
            when (target) {
                ExportTarget.COPY -> {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Trading Alerts Report", md))
                    snackbarHostState.showSnackbar("Report copied to clipboard")
                }
                ExportTarget.SHARE -> {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "Trading Alerts Report ($tag)")
                        putExtra(Intent.EXTRA_TEXT, md)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share Markdown Report"))
                }
                ExportTarget.SAVE -> {
                    pendingSaveMarkdown = md
                    val ts = DateTimeFormatter.ofPattern("yyyyMMdd-HHmm", Locale.US)
                        .withZone(ZoneId.systemDefault())
                        .format(Instant.now())
                    val ex = settings.exchange.name.lowercase(Locale.US)
                    val mkt = settings.marketType.name.lowercase(Locale.US)
                    saveMarkdownLauncher.launch("training-report_${ex}_${mkt}_${tag}_${ts}.md")
                }
            }
        }
    }

    val globalEntities = activeModels.filter { it.modelKind == "GLOBAL" }
    val pooledBestModel = globalEntities.maxByOrNull { it.trainedAtMs }
    val activePreset = pooledBestModel?.modelKey?.substringAfterLast('_')
        ?.let { RangePresets.byId(it) } ?: RangePresets.DEFAULT
    val perAssetModels = activeModels.filter { it.modelKind == "PER_ASSET" }

    val globalBundle = remember(pooledBestModel?.modelJson) {
        pooledBestModel?.let { runCatching { json.decodeFromString<SerializedModelBundle>(it.modelJson) }.getOrNull() }
    }

    val latestReportData = remember(trainingLogs) {
        trainingLogs.firstNotNullOfOrNull { TrainingReportBuilder.parseReportData(it) }
    }

    val shadowResolved = recentSignals.filter { !it.accepted && it.label != null }
    val takenResolved = recentSignals.filter { it.accepted && it.label != null }
    val shadowWins = shadowResolved.count { it.label == 1 }
    val takenWins = takenResolved.count { it.label == 1 }

    val exitWarnedAccepted = recentSignals.filter { it.accepted && it.exitWarningCount > 0 }
    val exitWarnedResolved = exitWarnedAccepted.filter { it.firstExitWarningHelped != null }
    val exitHelpedCount = exitWarnedResolved.count { it.firstExitWarningHelped == true }
    val exitRuleSummary = remember(exitCellRules) { ExitWarningFeatureBuilder.summarizeRules(exitCellRules) }

    val slTpSummary = remember(recentSignals) {
        val winners = recentSignals.filter { it.label == 1 && it.maePct != null && it.mfePct != null }
        SlTpManager.computeStatsFromWinningExcursions(
            winners.mapNotNull { it.maePct },
            winners.mapNotNull { it.mfePct }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Model Insights", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "${settings.exchange.displayName} ${settings.marketType.displayName} · Active range ${activePreset.label}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 0. Infographic Header [U16]
            item(key = "infographic_header") {
                InsightsInfographicsHeader(
                    metrics = globalBundle?.metrics,
                    recentSignals = recentSignals,
                    trainingLogs = trainingLogs,
                    selectedRange = selectedRange,
                    onSelectRange = { selectedRange = it }
                )
            }

            if (needsRetrain) {
                item(key = "retrain_banner") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = LrmlcColors.WarningAmber.copy(alpha = 0.14f)),
                        shape = LrmlcShapes.CardShape,
                        border = cardBorderStroke()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = LrmlcColors.WarningAmber)
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Retrain recommended", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text(
                                    "Legacy non-preset models were deactivated. Run training to calibrate all 4 range presets and phase exit rules.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Button(onClick = onTrainNow, shape = LrmlcShapes.ButtonShape) {
                                Text("Train")
                            }
                        }
                    }
                }
            }

            // 1. Active Models & Thresholds [U5, U7, U8, U10]
            item(key = "active_models") {
                Card(
                    modifier = Modifier.animateContentSize(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = LrmlcShapes.CardShape,
                    border = cardBorderStroke()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionHeaderLabel("Active Models & Thresholds (${settings.marketType.displayName})")
                        if (globalBundle == null || pooledBestModel == null) {
                            Text(
                                "No global model trained yet. Sync 4 weeks of candles and run training to unlock ML filtering.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            val m = globalBundle.metrics
                            val wins = (m.winRate * m.tradesTaken).toInt().coerceIn(0, m.tradesTaken)
                            val (ciLo, ciHi) = ModelExplainer.wilsonInterval(wins, m.tradesTaken)
                            val baseBrier = ModelExplainer.baselineBrier(m.baselineWinRate)

                            Text(ModelExplainer.explainValidationInPlainWords(m), style = MaterialTheme.typography.bodyMedium)

                            if (m.tradesTaken < 150) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(LrmlcColors.WarningAmber.copy(alpha = 0.16f))
                                        .padding(horizontal = 10.dp, vertical = 5.dp)
                                ) {
                                    Text(
                                        text = "Too few trades (${m.tradesTaken}) to trust these numbers.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = LrmlcColors.WarningAmber,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Text(
                                text = String.format(
                                    Locale.US,
                                    "Active threshold: %d%% · Fee-aware break-even: %.1f%% · Win rate: %.1f%% (95%% CI %.0f–%.0f%%, %d trades)",
                                    (pooledBestModel.threshold * 100).toInt(),
                                    m.breakEvenThreshold * 100.0,
                                    m.winRate * 100.0,
                                    ciLo * 100.0,
                                    ciHi * 100.0,
                                    m.tradesTaken
                                ),
                                style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )

                            if (m.manualThreshold != null && m.manualTradesTaken != null) {
                                Text(
                                    text = String.format(
                                        Locale.US,
                                        "Metrics at your manual threshold (%d%%): %d trades · Win %.1f%% · Exp %+.2f%%",
                                        (m.manualThreshold * 100).toInt(),
                                        m.manualTradesTaken,
                                        (m.manualWinRate ?: 0.0) * 100.0,
                                        (m.manualExpectancyPct ?: 0.0) * 100.0
                                    ),
                                    style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            val brierFlag = if (m.brierScore > baseBrier) " (worse than constant baseline!)" else " (beats baseline)"
                            Text(
                                text = String.format(
                                    Locale.US,
                                    "Brier: %.3f vs baseline %.3f%s · Per-asset models: %d",
                                    m.brierScore,
                                    baseBrier,
                                    brierFlag,
                                    perAssetModels.size
                                ),
                                style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                                color = if (m.brierScore > baseBrier) LrmlcColors.ShortRed else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            ModelExplainer.explainSlTpAdaptation(slTpSummary),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 2. Range Selection (U20)
            item(key = "range_selection") {
                Card(
                    modifier = Modifier.animateContentSize(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = LrmlcShapes.CardShape,
                    border = cardBorderStroke()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionHeaderLabel("Range Selection (Auto Per Asset)")
                        val pooledSummaries = latestReportData?.pooledPresetSummaries.orEmpty()
                        if (pooledSummaries.isEmpty()) {
                            Text(
                                "Pooled preset metrics will appear after training across 30m / 1h / 2h / 4h.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Text("Pooled performance (common evaluation period):", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                            pooledSummaries.forEach { p ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${p.label} (${p.windowBars}/${p.minGapBars})", style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        String.format(Locale.US, "Win %.0f%% · Exp %+.2f%% · %d trades", p.winRate * 100.0, p.expectancyPct * 100.0, p.trades),
                                        style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        if (assetPresetSelections.isNotEmpty()) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            Text("Per-asset selected range:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                            assetPresetSelections.sortedBy { it.symbol }.forEach { sel ->
                                val preset = RangePresets.byId(sel.presetId)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(sel.symbol.stripUsdtSuffix(), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        String.format(Locale.US, "%s · %d trades · LCB %+.2f%%", preset.label, sel.trades, sel.lcbExpectancy * 100.0),
                                        style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. Exit Warnings Quality & 5x4 Situation Grid [U22]
            item(key = "exit_warnings") {
                Card(
                    modifier = Modifier.animateContentSize(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = LrmlcShapes.CardShape,
                    border = cardBorderStroke()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionHeaderLabel("Phase-Aware Exit Warnings")
                        val helpedPct = if (exitWarnedResolved.isNotEmpty()) {
                            "${(exitHelpedCount * 100) / exitWarnedResolved.size}%"
                        } else "--"
                        Text(
                            "Exit warnings: ${exitWarnedAccepted.size}, $helpedPct would have helped (${exitWarnedResolved.size} resolved)",
                            style = MaterialTheme.typography.bodyMedium.merge(tnumStyle),
                            fontWeight = FontWeight.SemiBold
                        )
                        val ruleText = if (exitRuleSummary.reliableCellCount > 0) {
                            exitRuleSummary.statusLine
                        } else {
                            if (exitCellRules.isEmpty()) "Exit warnings: learning" else "Learning: needs more trades (silent until a situation proves itself on unseen trades)."
                        }
                        Text(ruleText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (exitCellRules.isNotEmpty()) {
                            ExitPhaseCellGrid(exitCellRules)
                        }
                    }
                }
            }

            // 3a. Run-past-TP markers + 5x4 situation grid
            item(key = "run_on_markers") {
                val runOnEntity = activeModels.firstOrNull { it.modelKind == RunOnSpec.MODEL_KIND }
                val runOnBundle = remember(runOnEntity?.modelJson) {
                    runOnEntity?.let { runCatching { json.decodeFromString<RunOnBundle>(it.modelJson) }.getOrNull() }
                }
                val shown = recentSignals.filter { it.accepted && it.runOnShownTimeMs != null }
                val resolved = shown.filter { it.status != "ACTIVE" || it.tpReachedTimeMs != null }
                val wentFar = resolved.count { t ->
                    val tpDist = kotlin.math.abs(t.appliedTp - t.entryPrice) / t.entryPrice.coerceAtLeast(1e-9)
                    (t.maxBeyondTpPct ?: 0.0) >= 0.5 * tpDist
                }
                Card(
                    modifier = Modifier.animateContentSize(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = LrmlcShapes.CardShape,
                    border = cardBorderStroke()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionHeaderLabel("Run Past TP Markers")
                        val pct = if (resolved.isNotEmpty()) "${(wentFar * 100) / resolved.size}%" else "--"
                        Text(
                            "Run-on markers: ${shown.size} shown, $pct went at least half a TP further (${resolved.size} resolved)",
                            style = MaterialTheme.typography.bodyMedium.merge(tnumStyle),
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            RunOnTrainer.summaryLine(runOnBundle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (runOnBundle != null) {
                            ExitPhaseCellGrid(runOnBundle.asGridRules(settings.exchange.name, settings.marketType.name))
                        }
                    }
                }
            }

            // 3b. Learning inputs: proven feature groups, recency, tuned settings, test periods, real trades
            item(key = "learning_inputs") {
                val learning = latestReportData?.learning
                val unstable = globalBundle?.metrics?.isUnstable() ?: (learning?.primary()?.unstable ?: false)
                Card(
                    modifier = Modifier.animateContentSize(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = LrmlcShapes.CardShape,
                    border = cardBorderStroke()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionHeaderLabel("Learning inputs")
                        if (learning == null) {
                            Text(
                                "Learning inputs: not trained yet",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Text(learning.groupsLine(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            Text("Master asset: ${learning.masterAsset}" + if (learning.masterDataLoaded) "" else " (no data yet - neutral)",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(learning.decayLine(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(learning.tuningLine(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                learning.periodsLine() + if (unstable && !learning.periodsLine().endsWith("UNSTABLE")) " - UNSTABLE" else "",
                                style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                                color = if (unstable) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "Real trades used (double weight): ${learning.realTradesUsed} · Setups skipped over missing candles: ${learning.gapSetupsSkipped}",
                                style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            learning.primary()?.groupProofs?.forEach { gp ->
                                val gain = gp.gainPct?.let { String.format(java.util.Locale.US, "%+.3f pts", it) } ?: "n/a"
                                Text(
                                    "${gp.label}: ${if (gp.kept) "ON" else "off"} ($gain) - ${gp.note}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (gp.kept) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // 4. Top Positive & Negative Factors [U20]
            if (globalBundle != null) {
                val positives = ModelExplainer.topLearnedFactors(globalBundle.weights, positive = true, limit = 5, windowLabel = activePreset.label)
                val negatives = ModelExplainer.topLearnedFactors(globalBundle.weights, positive = false, limit = 5, windowLabel = activePreset.label)

                item(key = "learned_factors") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = LrmlcShapes.CardShape,
                        border = cardBorderStroke()
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            SectionHeaderLabel("What Helped & Hurt Signals (${activePreset.label})")
                            Text("What Helped Signals Win", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = LrmlcColors.LongGreen)
                            if (positives.isEmpty()) Text("Gathering more training samples.", style = MaterialTheme.typography.bodySmall)
                            positives.forEach { f -> Text("• ${f.sentence}", style = MaterialTheme.typography.bodySmall) }

                            Text("What Hurt Signals", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = LrmlcColors.ShortRed)
                            if (negatives.isEmpty()) Text("Gathering more training samples.", style = MaterialTheme.typography.bodySmall)
                            negatives.forEach { f -> Text("• ${f.sentence}", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }

                // 5. Calibration buckets table [U8, U12]
                if (globalBundle.metrics.calibrationBuckets.isNotEmpty()) {
                    item(key = "calibration_buckets") {
                        val baseBrier = ModelExplainer.baselineBrier(globalBundle.metrics.baselineWinRate)
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = LrmlcShapes.CardShape,
                            border = cardBorderStroke()
                        ) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                SectionHeaderLabel("Probability Calibration")
                                Text(
                                    String.format(
                                        Locale.US,
                                        "Brier: %.3f vs baseline %.3f (lower is better).",
                                        globalBundle.metrics.brierScore,
                                        baseBrier
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                globalBundle.metrics.calibrationBuckets.forEach { b ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Scored ${(b.predictedAvg * 100).toInt()}%", style = MaterialTheme.typography.bodySmall.merge(tnumStyle))
                                        Text(
                                            "Won ${(b.actualWinRate * 100).toInt()}% (${b.sampleCount} trades)",
                                            style = MaterialTheme.typography.bodySmall.merge(tnumStyle),
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 6. Shadow Trades & Latest Breakdown
            item(key = "shadow_trades") {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = LrmlcShapes.CardShape,
                    border = cardBorderStroke()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionHeaderLabel("Shadow Trades (Selection-Bias Guard)")
                        val takenRate = if (takenResolved.isNotEmpty()) "${(takenWins * 100) / takenResolved.size}%" else "--"
                        val shadowRate = if (shadowResolved.isNotEmpty()) "${(shadowWins * 100) / shadowResolved.size}%" else "--"
                        Text(
                            "Accepted & resolved: ${takenResolved.size} (Win rate $takenRate)\n" +
                                "Filtered shadow trades tracked: ${shadowResolved.size} (Win rate $shadowRate)",
                            style = MaterialTheme.typography.bodySmall.merge(tnumStyle)
                        )
                    }
                }
            }

            // 7. Training History Log + Markdown Export [U11, U15]
            item(key = "history_header") {
                val now = System.currentTimeMillis()
                val h24Logs = remember(trainingLogs) { InsightsStats.filterLogsByRange(trainingLogs, InsightsRange.H24, now) }
                val d7Logs = remember(trainingLogs) { InsightsStats.filterLogsByRange(trainingLogs, InsightsRange.D7, now) }
                val d30Logs = remember(trainingLogs) { InsightsStats.filterLogsByRange(trainingLogs, InsightsRange.D30, now) }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionHeaderLabel("Training History Log (Export Markdown)")
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            Triple("Last 24 hours", InsightsRange.H24, h24Logs.size),
                            Triple("Last 7 days", InsightsRange.D7, d7Logs.size),
                            Triple("Last 30 days", InsightsRange.D30, d30Logs.size)
                        ).forEach { (title, rangeObj, count) ->
                            var menuExpanded by remember { mutableStateOf(false) }
                            Box {
                                FilterChip(
                                    selected = false,
                                    enabled = count > 0,
                                    onClick = { menuExpanded = true },
                                    label = { Text("$title · $count runs", style = MaterialTheme.typography.labelSmall) },
                                    shape = LrmlcShapes.ButtonShape,
                                    colors = FilterChipDefaults.filterChipColors()
                                )
                                ExportMenu(
                                    expanded = menuExpanded,
                                    onDismiss = { menuExpanded = false },
                                    onCopy = {
                                        menuExpanded = false
                                        dispatchExport(ExportTarget.COPY, rangeObj.label) { onBuildRangeReport(rangeObj.hours) }
                                    },
                                    onShare = {
                                        menuExpanded = false
                                        dispatchExport(ExportTarget.SHARE, rangeObj.label) { onBuildRangeReport(rangeObj.hours) }
                                    },
                                    onSave = {
                                        menuExpanded = false
                                        dispatchExport(ExportTarget.SAVE, rangeObj.label) { onBuildRangeReport(rangeObj.hours) }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            if (trainingLogs.isEmpty()) {
                item(key = "empty_logs") {
                    Text("No training runs logged yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(trainingLogs, key = { it.id }) { log ->
                    val timeStr = remember(log.timestampMs) {
                        Instant.ofEpochMilli(log.timestampMs)
                            .atZone(ZoneId.systemDefault())
                            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
                    }
                    val parsedData = remember(log.reportJson) { TrainingReportBuilder.parseReportData(log) }
                    val snapshotLine = remember(log.id, log.reportJson, log.metricsJson) {
                        TrainingReportBuilder.compactSnapshotLine(log, parsedData)
                    }
                    var rowMenuOpen by remember { mutableStateOf(false) }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = LrmlcShapes.CardShape,
                        border = cardBorderStroke()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = "$timeStr · ${log.jobType}",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                if (log.promoted) LrmlcColors.LongGreen.copy(alpha = 0.16f)
                                                else MaterialTheme.colorScheme.surfaceVariant
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (log.promoted) "Promoted" else "Kept",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (log.promoted) LrmlcColors.LongGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Text(
                                    text = snapshotLine,
                                    style = MaterialTheme.typography.labelSmall.merge(tnumStyle),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                            Box {
                                IconButton(onClick = { rowMenuOpen = true }) {
                                    Icon(Icons.Default.Share, contentDescription = "Export training report")
                                }
                                ExportMenu(
                                    expanded = rowMenuOpen,
                                    onDismiss = { rowMenuOpen = false },
                                    onCopy = {
                                        rowMenuOpen = false
                                        dispatchExport(ExportTarget.COPY, "single") { onBuildSingleReport(log.id) }
                                    },
                                    onShare = {
                                        rowMenuOpen = false
                                        dispatchExport(ExportTarget.SHARE, "single") { onBuildSingleReport(log.id) }
                                    },
                                    onSave = {
                                        rowMenuOpen = false
                                        dispatchExport(ExportTarget.SAVE, "single") { onBuildSingleReport(log.id) }
                                    }
                                )
                            }
                        }
                    }
                }
            }
            item(key = "insights_bottom_spacer") { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun ExportMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onSave: () -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text("Copy") }, onClick = onCopy)
        DropdownMenuItem(text = { Text("Share") }, onClick = onShare)
        DropdownMenuItem(text = { Text("Save as .md") }, onClick = onSave)
    }
}
