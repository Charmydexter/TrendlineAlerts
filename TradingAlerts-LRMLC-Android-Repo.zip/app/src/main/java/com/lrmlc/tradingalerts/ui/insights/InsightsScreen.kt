package com.lrmlc.tradingalerts.ui.insights

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lrmlc.tradingalerts.data.local.MlModelEntity
import com.lrmlc.tradingalerts.data.local.SignalCandidateEntity
import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import com.lrmlc.tradingalerts.data.model.AppSettings
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import com.lrmlc.tradingalerts.ml.ModelExplainer
import com.lrmlc.tradingalerts.ml.SerializedModelBundle
import com.lrmlc.tradingalerts.trade.SlTpManager
import com.lrmlc.tradingalerts.ui.theme.LrmlcColors
import kotlinx.serialization.json.Json
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InsightsScreen(
    settings: AppSettings,
    activeModels: List<MlModelEntity>,
    recentSignals: List<SignalCandidateEntity>,
    trainingLogs: List<TrainingLogEntity>
) {
    val json = remember { Json { ignoreUnknownKeys = true } }
    val globalEntity = activeModels.firstOrNull { it.modelKind == "GLOBAL" }
    val exitEntity = activeModels.firstOrNull { it.modelKind == "EXIT" }
    val perAssetModels = activeModels.filter { it.modelKind == "PER_ASSET" }

    val globalBundle = remember(globalEntity?.modelJson) {
        globalEntity?.let { runCatching { json.decodeFromString<SerializedModelBundle>(it.modelJson) }.getOrNull() }
    }

    val shadowResolved = recentSignals.filter { !it.accepted && it.label != null }
    val takenResolved = recentSignals.filter { it.accepted && it.label != null }
    val shadowWins = shadowResolved.count { it.label == 1 }
    val takenWins = takenResolved.count { it.label == 1 }

    val slTpSummary = remember(recentSignals) {
        val winners = recentSignals.filter { it.label == 1 && it.maePct != null && it.mfePct != null }
        SlTpManager.computeStatsFromWinningExcursions(
            winners.mapNotNull { it.maePct },
            winners.mapNotNull { it.mfePct }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Model Insights", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Thresholds & Model Summary
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Active Models & Thresholds (${settings.marketType.displayName})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        if (globalBundle == null || globalEntity == null) {
                            Text("No global model trained yet. Sync 4 weeks of candles and run training to unlock ML filtering.", style = MaterialTheme.typography.bodyMedium)
                        } else {
                            Text(ModelExplainer.explainValidationInPlainWords(globalBundle.metrics), style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "Global threshold: ${(globalEntity.threshold * 100).toInt()}% (break-even ${(globalBundle.metrics.breakEvenThreshold * 100).toInt()}%) · Per-asset models active: ${perAssetModels.size} · Exit-reversal threshold: ${exitEntity?.let { "${(it.threshold * 100).toInt()}%" } ?: "Default 65%"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            ModelExplainer.explainSlTpAdaptation(slTpSummary),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 2. Top Positive & Negative Factors
            if (globalBundle != null) {
                val positives = ModelExplainer.topLearnedFactors(globalBundle.weights, positive = true, limit = 5)
                val negatives = ModelExplainer.topLearnedFactors(globalBundle.weights, positive = false, limit = 5)

                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("What Helped Signals Win", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = LrmlcColors.LongGreen)
                            if (positives.isEmpty()) Text("Gathering more training samples.", style = MaterialTheme.typography.bodySmall)
                            positives.forEach { f ->
                                Text("• ${f.sentence}", style = MaterialTheme.typography.bodySmall)
                            }
                            Text("What Hurt Signals", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = LrmlcColors.ShortRed)
                            if (negatives.isEmpty()) Text("Gathering more training samples.", style = MaterialTheme.typography.bodySmall)
                            negatives.forEach { f ->
                                Text("• ${f.sentence}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                // 3. Calibration buckets
                if (globalBundle.metrics.calibrationBuckets.isNotEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Probability Calibration", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Brier calibration score: ${String.format(Locale.US, "%.3f", globalBundle.metrics.brierScore)} (lower is better).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                globalBundle.metrics.calibrationBuckets.forEach { b ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Scored ${(b.predictedAvg * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                                        Text("Won ${(b.actualWinRate * 100).toInt()}% (${b.sampleCount} trades)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Latest Signal 3-Reason Breakdown
            val latestAccepted = recentSignals.firstOrNull { it.accepted } ?: recentSignals.firstOrNull()
            if (latestAccepted != null) {
                val reasons = runCatching { json.decodeFromString<List<String>>(latestAccepted.topReasonsJson) }.getOrDefault(emptyList())
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                "Latest Signal Breakdown: ${latestAccepted.symbol.stripUsdtSuffix()} (${latestAccepted.direction})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (reasons.isEmpty()) {
                                Text("Waiting for live scored signal reasons.", style = MaterialTheme.typography.bodySmall)
                            } else {
                                reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                }
            }

            // 5. Shadow-trade bias-prevention stats
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Shadow Trades (Selection-Bias Guard)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        val takenRate = if (takenResolved.isNotEmpty()) "${(takenWins * 100) / takenResolved.size}%" else "—"
                        val shadowRate = if (shadowResolved.isNotEmpty()) "${(shadowWins * 100) / shadowResolved.size}%" else "—"
                        Text(
                            "Accepted & resolved: ${takenResolved.size} (Win rate $takenRate)\n" +
                                "Filtered shadow trades tracked: ${shadowResolved.size} (Win rate $shadowRate)",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            // 6. Training History Log
            item {
                Text("Training History Log", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            }
            if (trainingLogs.isEmpty()) {
                item {
                    Text("No training runs logged yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(trainingLogs, key = { it.id }) { log ->
                    val timeStr = Instant.ofEpochMilli(log.timestampMs)
                        .atZone(ZoneId.systemDefault())
                        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${log.jobType} · ${if (log.promoted) "Promoted" else "Kept Previous"}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                                Text(timeStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(log.summary, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
