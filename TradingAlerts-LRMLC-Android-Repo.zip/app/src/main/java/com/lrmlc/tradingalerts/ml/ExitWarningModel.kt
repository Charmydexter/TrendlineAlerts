package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.local.DayChunkCodec
import com.lrmlc.tradingalerts.data.local.ExitCellRuleEntity
import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max

object ExitFeatureSpec {
    const val FEATURE_COUNT = 24
    val AGE_BUCKET_LABELS = listOf("1-2m", "3-5m", "6-10m", "11-20m", "21+m")
    val AGE_BUCKET_MIN_BARS = listOf(1, 3, 6, 11, 21)
    val PROGRESS_BUCKET_LABELS = listOf("LOSS", "NEAR", "PROFIT")
    val PROGRESS_BUCKET_DISPLAY = listOf("In loss (<-20%)", "Near entry", "In profit (>+20%)")

    val NAMES = listOf(
        "Progress toward TP",
        "Progress toward SL",
        "Distance to hiLine",
        "Distance to loLine",
        "Distance to rolling average",
        "Lines crossed against trade",
        "1-minute return against trade",
        "5-minute return against trade",
        "Volume ratio vs entry",
        "Log trade age",
        "Age 1-2m",
        "Age 3-5m",
        "Age 6-10m",
        "Age 11-20m",
        "Age 21+m",
        "Signed barrier progress",
        "Signed barrier progress squared",
        "Age 1-2m x progress",
        "Age 3-5m x progress",
        "Age 6-10m x progress",
        "Age 11-20m x progress",
        "Age 21+m x progress",
        "Entry model confidence",
        "Stop distance (%)"
    )
}

data class ExitPhaseCell(
    val ageBucket: Int,
    val progressBucket: Int
) {
    val ageLabel: String get() = ExitFeatureSpec.AGE_BUCKET_LABELS[ageBucket.coerceIn(0, 4)]
    val progressLabel: String get() = ExitFeatureSpec.PROGRESS_BUCKET_LABELS[progressBucket.coerceIn(0, 2)]
    val code: String get() = "$ageLabel|$progressLabel"
}

data class ExitStateSample(
    val entryTimeMs: Long,
    val sample: LabeledSample,
    val ageBucket: Int,
    val progressBucket: Int,
    val structTriggered: Boolean,
    val savedRisk: Double
)

data class ExitRuleSummary(
    val learnedMinBars: Int?,
    val reliableCellCount: Int,
    val statusLine: String,
    val reportLine: String
)

data class ExitTrainingResult(
    val weights: LogisticRegressionWeights,
    val rules: List<ExitCellRuleEntity>,
    val overallThreshold: Double,
    val summary: ExitRuleSummary
)

object ExitWarningFeatureBuilder {

    const val MIN_CELL_OOS_STATES = 30
    const val MIN_BASE_PRECISION = 0.70
    const val BASE_RATE_PRECISION_BOOST = 0.10
    const val MIN_SAVED_RISK_FRACTION = 0.25

    fun computeAgeBars(currentBarIndex: Int, entryBarIndex: Int): Int =
        (currentBarIndex - entryBarIndex).coerceAtLeast(0)

    fun ageBucketFor(ageBars: Int): Int = when {
        ageBars <= 2 -> 0
        ageBars <= 5 -> 1
        ageBars <= 10 -> 2
        ageBars <= 20 -> 3
        else -> 4
    }

    fun computeSignedProgress(
        direction: TradeDirection,
        close: Double,
        entryPrice: Double,
        slPrice: Double,
        tpPrice: Double
    ): Double {
        val tpSpan = abs(tpPrice - entryPrice).coerceAtLeast(1e-9)
        val slSpan = abs(entryPrice - slPrice).coerceAtLeast(1e-9)
        val raw = when (direction) {
            TradeDirection.LONG -> {
                if (close >= entryPrice) (close - entryPrice) / tpSpan
                else -(entryPrice - close) / slSpan
            }
            TradeDirection.SHORT -> {
                if (close <= entryPrice) (entryPrice - close) / tpSpan
                else -(close - entryPrice) / slSpan
            }
        }
        return raw.coerceIn(-1.0, 1.0)
    }

    fun progressBucketFor(progress: Double): Int = when {
        progress < -0.2 -> 0
        progress <= 0.2 -> 1
        else -> 2
    }

    fun cellFor(
        ageBars: Int,
        direction: TradeDirection,
        close: Double,
        entryPrice: Double,
        slPrice: Double,
        tpPrice: Double
    ): Pair<ExitPhaseCell, Double> {
        val progress = computeSignedProgress(direction, close, entryPrice, slPrice, tpPrice)
        return ExitPhaseCell(ageBucketFor(ageBars), progressBucketFor(progress)) to progress
    }

    fun computeExitLabel(
        outcome: BarrierOutcome,
        unrealizedNetPct: Double,
        finalNetPct: Double,
        stopDistPct: Double
    ): Int {
        val isLoss = outcome == BarrierOutcome.SL_HIT || outcome == BarrierOutcome.TIMEOUT_LOSS
        if (!isLoss) return 0
        val saved = unrealizedNetPct - finalNetPct
        return if (saved >= MIN_SAVED_RISK_FRACTION * stopDistPct.coerceAtLeast(1e-9)) 1 else 0
    }

    fun isOppositeStructureTriggered(
        direction: TradeDirection,
        snapshot: ConfluenceBarSnapshot
    ): Boolean = when (direction) {
        TradeDirection.LONG -> snapshot.rawShort && !snapshot.shortFire
        TradeDirection.SHORT -> snapshot.rawLong && !snapshot.longFire
    }

    fun buildStateFeatures(
        candles: List<Candle>,
        snapshots: List<ConfluenceBarSnapshot>,
        currentBarIndex: Int,
        entryBarIndex: Int,
        direction: TradeDirection,
        entryPrice: Double,
        slPrice: Double,
        tpPrice: Double,
        entryPWin: Double? = null
    ): DoubleArray? {
        if (currentBarIndex !in candles.indices || currentBarIndex !in snapshots.indices) return null
        val snap = snapshots[currentBarIndex]
        val bar = candles[currentBarIndex]
        val close = bar.close.coerceAtLeast(1e-9)
        val safeEntryPrice = entryPrice.coerceAtLeast(1e-9)
        val hiLine = snap.hiLine ?: return null
        val loLine = snap.loLine ?: return null
        val basis = snap.basis ?: return null
        val resVal = snap.resVal ?: return null
        val supVal = snap.supVal ?: return null

        val tpSpan = abs(tpPrice - safeEntryPrice).coerceAtLeast(1e-9)
        val slSpan = abs(safeEntryPrice - slPrice).coerceAtLeast(1e-9)

        val progressTp = when (direction) {
            TradeDirection.LONG -> (close - safeEntryPrice) / tpSpan
            TradeDirection.SHORT -> (safeEntryPrice - close) / tpSpan
        }.coerceIn(-2.0, 2.0)

        val progressSl = when (direction) {
            TradeDirection.LONG -> (safeEntryPrice - close) / slSpan
            TradeDirection.SHORT -> (close - safeEntryPrice) / slSpan
        }.coerceIn(-2.0, 2.0)

        val distHi = (close - hiLine) / close
        val distLo = (close - loLine) / close
        val distBasis = (close - basis) / close

        val linesCrossedAgainst = when (direction) {
            TradeDirection.LONG -> {
                var c = 0
                if (close < resVal) c++
                if (close < supVal) c++
                if (close < basis) c++
                c / 3.0
            }
            TradeDirection.SHORT -> {
                var c = 0
                if (close > resVal) c++
                if (close > supVal) c++
                if (close > basis) c++
                c / 3.0
            }
        }

        val c1 = candles.getOrNull(currentBarIndex - 1)?.close ?: close
        val c5 = candles.getOrNull(currentBarIndex - 5)?.close ?: close
        val retAgainst1 = when (direction) {
            TradeDirection.LONG -> (c1 - close) / c1.coerceAtLeast(1e-9)
            TradeDirection.SHORT -> (close - c1) / c1.coerceAtLeast(1e-9)
        }
        val retAgainst5 = when (direction) {
            TradeDirection.LONG -> (c5 - close) / c5.coerceAtLeast(1e-9)
            TradeDirection.SHORT -> (close - c5) / c5.coerceAtLeast(1e-9)
        }

        val safeEntryIdx = entryBarIndex.coerceIn(0, currentBarIndex)
        var volSum = 0.0
        for (i in safeEntryIdx..currentBarIndex) volSum += candles[i].volume
        val avgVolSinceEntry = (volSum / (currentBarIndex - safeEntryIdx + 1)).coerceAtLeast(1e-9)
        val volRatio = (bar.volume / avgVolSinceEntry).coerceIn(0.0, 10.0)

        val age = computeAgeBars(currentBarIndex, safeEntryIdx)
        val ageBucket = ageBucketFor(age)
        val signedProgress = computeSignedProgress(direction, close, safeEntryPrice, slPrice, tpPrice)
        val stopDistPct = (slSpan / safeEntryPrice).coerceIn(0.0, 0.5)

        val f = DoubleArray(ExitFeatureSpec.FEATURE_COUNT)
        f[0] = progressTp
        f[1] = progressSl
        f[2] = distHi
        f[3] = distLo
        f[4] = distBasis
        f[5] = linesCrossedAgainst
        f[6] = retAgainst1
        f[7] = retAgainst5
        f[8] = volRatio
        f[9] = ln(1.0 + age.toDouble())
        f[10 + ageBucket] = 1.0
        f[15] = signedProgress
        f[16] = signedProgress * signedProgress
        f[17 + ageBucket] = signedProgress
        f[22] = (entryPWin ?: 0.5).coerceIn(0.0, 1.0)
        f[23] = stopDistPct

        for (i in f.indices) {
            if (!f[i].isFinite()) f[i] = 0.0
        }
        return f
    }

    /**
     * Splits exit states chronologically by trade (purged), trains logistic regression on the earlier portion,
     * and calibrates per-phase cell rules strictly out-of-sample.
     */
    fun trainAndEvaluatePhaseRules(
        samples: List<ExitStateSample>,
        exchange: String,
        marketType: String,
        horizonBars: Int,
        nowMs: Long = System.currentTimeMillis()
    ): ExitTrainingResult {
        val emptyWeights = LogisticRegressionWeights(
            weights = DoubleArray(ExitFeatureSpec.FEATURE_COUNT),
            bias = 0.0,
            stats = StandardizationStats(
                DoubleArray(ExitFeatureSpec.FEATURE_COUNT),
                DoubleArray(ExitFeatureSpec.FEATURE_COUNT) { 1.0 }
            )
        )
        if (samples.isEmpty()) {
            val emptyRules = buildSilentRules(exchange, marketType, nowMs)
            return ExitTrainingResult(emptyWeights, emptyRules, 0.70, summarizeRules(emptyRules))
        }

        val sorted = samples.sortedBy { it.entryTimeMs }
        val distinctEntryTimes = sorted.map { it.entryTimeMs }.distinct().sorted()
        if (distinctEntryTimes.size < 4) {
            val emptyRules = buildSilentRules(exchange, marketType, nowMs)
            return ExitTrainingResult(emptyWeights, emptyRules, 0.70, summarizeRules(emptyRules))
        }

        val splitIdx = ((distinctEntryTimes.size * 2) / 3).coerceIn(2, distinctEntryTimes.size - 1)
        val oosStartEntryMs = distinctEntryTimes[splitIdx]
        val purgeGapMs = horizonBars.coerceAtLeast(1) * DayChunkCodec.MILLIS_PER_MINUTE

        val trainStates = sorted.filter { it.entryTimeMs < oosStartEntryMs && (it.sample.exitTimeMs + purgeGapMs) < oosStartEntryMs }
        val effectiveTrain = if (trainStates.size >= 20) {
            trainStates
        } else {
            sorted.filter { it.entryTimeMs < oosStartEntryMs }
        }
        val oosStates = sorted.filter { it.entryTimeMs >= oosStartEntryMs }

        if (effectiveTrain.size < 20 || oosStates.size < MIN_CELL_OOS_STATES) {
            val emptyRules = buildSilentRules(exchange, marketType, nowMs)
            return ExitTrainingResult(emptyWeights, emptyRules, 0.70, summarizeRules(emptyRules))
        }

        val trainLabeled = effectiveTrain.map { it.sample }
        val stats = StandardizationStats.fit(trainLabeled.map { it.features }, ExitFeatureSpec.FEATURE_COUNT)
        val weighted = OverlapWeightCalculator.assignOverlapWeights(trainLabeled)
        val model = LogisticRegressionTrainer.trainWithCheckpoints(
            samples = weighted,
            stats = stats,
            featureCount = ExitFeatureSpec.FEATURE_COUNT,
            params = LogisticHyperParams(epochs = 22, batchSize = 32, learningRate = 0.03, l2Lambda = 0.03)
        )

        val oosScored = oosStates.map { state ->
            model.predictProbability(state.sample.features) to state
        }

        // Precompute age-bucket group rules for sparse-cell fallback
        val groupRules = HashMap<Int, CellEval>(5)
        for (ageBucket in 0..4) {
            val groupItems = oosScored.filter { it.second.ageBucket == ageBucket }
            groupRules[ageBucket] = evaluateCellStates(groupItems)
        }

        val rules = ArrayList<ExitCellRuleEntity>(15)
        for (ageBucket in 0..4) {
            val groupEval = groupRules[ageBucket] ?: CellEval.SILENT
            for (progressBucket in 0..2) {
                val cellItems = oosScored.filter {
                    it.second.ageBucket == ageBucket && it.second.progressBucket == progressBucket
                }
                val chosen: CellEval = if (cellItems.size >= MIN_CELL_OOS_STATES) {
                    evaluateCellStates(cellItems)
                } else {
                    // Sparse cell may inherit from its age-bucket group ONLY if that group passed the gate
                    if (groupEval.mlEnabled || groupEval.structEnabled) groupEval else CellEval.SILENT
                }
                rules.add(
                    ExitCellRuleEntity(
                        exchange = exchange,
                        marketType = marketType,
                        ageBucket = ageBucket,
                        progressBucket = progressBucket,
                        mlEnabled = chosen.mlEnabled,
                        mlThreshold = chosen.mlThreshold,
                        structEnabled = chosen.structEnabled,
                        precision = chosen.precision,
                        warnings = chosen.warnings,
                        avgSavedRisk = chosen.avgSavedRisk,
                        updatedAtMs = nowMs
                    )
                )
            }
        }

        val summary = summarizeRules(rules)
        val enabledThresholds = rules.filter { it.mlEnabled }.map { it.mlThreshold }
        val representativeThreshold = enabledThresholds.minOrNull() ?: 0.70

        return ExitTrainingResult(
            weights = model,
            rules = rules,
            overallThreshold = representativeThreshold,
            summary = summary
        )
    }

    private data class CellEval(
        val mlEnabled: Boolean,
        val mlThreshold: Double,
        val structEnabled: Boolean,
        val precision: Double,
        val warnings: Int,
        val avgSavedRisk: Double
    ) {
        companion object {
            val SILENT = CellEval(
                mlEnabled = false,
                mlThreshold = 0.75,
                structEnabled = false,
                precision = 0.0,
                warnings = 0,
                avgSavedRisk = 0.0
            )
        }
    }

    private fun evaluateCellStates(items: List<Pair<Double, ExitStateSample>>): CellEval {
        if (items.size < MIN_CELL_OOS_STATES) return CellEval.SILENT
        val baseRate = items.count { it.second.sample.label == 1 }.toDouble() / items.size
        val minPrecision = max(MIN_BASE_PRECISION, baseRate + BASE_RATE_PRECISION_BOOST).coerceAtMost(0.98)

        var chosenMl = false
        var chosenThresh = 0.90
        var chosenMlPrecision = 0.0
        var chosenMlWarnings = 0
        var chosenSaved = 0.0

        for (pct in 55..90 step 5) {
            val t = pct / 100.0
            val warned = items.filter { it.first >= t }
            if (warned.size < MIN_CELL_OOS_STATES) continue
            val tp = warned.count { it.second.sample.label == 1 }
            val prec = tp.toDouble() / warned.size
            if (prec >= minPrecision) {
                chosenMl = true
                chosenThresh = t
                chosenMlPrecision = prec
                chosenMlWarnings = warned.size
                chosenSaved = warned.map { it.second.savedRisk }.average()
                break
            }
        }

        val structWarned = items.filter { it.second.structTriggered }
        var structEnabled = false
        var structPrec = 0.0
        var structSaved = 0.0
        if (structWarned.size >= MIN_CELL_OOS_STATES) {
            val tp = structWarned.count { it.second.sample.label == 1 }
            val prec = tp.toDouble() / structWarned.size
            if (prec >= minPrecision) {
                structEnabled = true
                structPrec = prec
                structSaved = structWarned.map { it.second.savedRisk }.average()
            }
        }

        val precision = if (chosenMl) chosenMlPrecision else structPrec
        val warnings = if (chosenMl) chosenMlWarnings else if (structEnabled) structWarned.size else 0
        val avgSaved = if (chosenMl) chosenSaved else if (structEnabled) structSaved else 0.0

        return CellEval(
            mlEnabled = chosenMl,
            mlThreshold = chosenThresh,
            structEnabled = structEnabled,
            precision = precision,
            warnings = warnings,
            avgSavedRisk = avgSaved
        )
    }

    fun buildSilentRules(exchange: String, marketType: String, nowMs: Long = 0L): List<ExitCellRuleEntity> =
        (0..4).flatMap { ageBucket ->
            (0..2).map { progBucket ->
                ExitCellRuleEntity(
                    exchange = exchange,
                    marketType = marketType,
                    ageBucket = ageBucket,
                    progressBucket = progBucket,
                    mlEnabled = false,
                    mlThreshold = 0.75,
                    structEnabled = false,
                    precision = 0.0,
                    warnings = 0,
                    avgSavedRisk = 0.0,
                    updatedAtMs = nowMs
                )
            }
        }

    fun summarizeRules(rules: List<ExitCellRuleEntity>): ExitRuleSummary {
        if (rules.isEmpty()) {
            return ExitRuleSummary(
                learnedMinBars = null,
                reliableCellCount = 0,
                statusLine = "Learning: needs more trades",
                reportLine = "Exit rules: Learning (0/15 phases reliable yet)."
            )
        }
        val activeCells = rules.filter { it.mlEnabled || it.structEnabled }
        if (activeCells.isEmpty()) {
            return ExitRuleSummary(
                learnedMinBars = null,
                reliableCellCount = 0,
                statusLine = "Learning: needs more trades",
                reportLine = "Exit rules: Learning (0/15 phases passed precision gate)."
            )
        }
        val earliestAge = activeCells.minOf { it.ageBucket }.coerceIn(0, 4)
        val minBars = ExitFeatureSpec.AGE_BUCKET_MIN_BARS[earliestAge]
        val mlThresholds = activeCells.filter { it.mlEnabled }.map { "${(it.mlThreshold * 100).toInt()}%" }.distinct()
        val threshDesc = if (mlThresholds.isEmpty()) "structure-only" else mlThresholds.joinToString("/")
        return ExitRuleSummary(
            learnedMinBars = minBars,
            reliableCellCount = activeCells.size,
            statusLine = "Learned: ML warnings start after about $minBars bars; reliable in ${activeCells.size} of 15 phases",
            reportLine = "Exit rules: starts ~${minBars}m in, reliable in ${activeCells.size}/15 phases (ML thresholds: $threshDesc)."
        )
    }

    /**
     * Kept for simple fallback callers; wraps trainAndEvaluatePhaseRules.
     */
    fun trainExitModel(samples: List<LabeledSample>): Pair<LogisticRegressionWeights, Double> {
        if (samples.isEmpty()) {
            val stats = StandardizationStats(
                DoubleArray(ExitFeatureSpec.FEATURE_COUNT),
                DoubleArray(ExitFeatureSpec.FEATURE_COUNT) { 1.0 }
            )
            return LogisticRegressionWeights(DoubleArray(ExitFeatureSpec.FEATURE_COUNT), 0.0, stats) to 0.70
        }
        val wrapped = samples.map { s ->
            val ageBucket = (10..14).indexOfFirst { (s.features.getOrNull(it) ?: 0.0) > 0.5 }.coerceAtLeast(0)
            val progress = s.features.getOrNull(15) ?: 0.0
            ExitStateSample(
                entryTimeMs = s.timestampMs,
                sample = s,
                ageBucket = ageBucket,
                progressBucket = progressBucketFor(progress),
                structTriggered = false,
                savedRisk = if (s.label == 1) 0.5 else 0.0
            )
        }
        val res = trainAndEvaluatePhaseRules(wrapped, "BYBIT", "PERP", 60)
        return res.weights to res.overallThreshold
    }
}
