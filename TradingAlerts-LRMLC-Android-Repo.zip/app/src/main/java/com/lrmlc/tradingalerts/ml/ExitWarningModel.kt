package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.model.Candle
import com.lrmlc.tradingalerts.data.model.TradeDirection
import com.lrmlc.tradingalerts.engine.ConfluenceBarSnapshot
import kotlin.math.abs

object ExitFeatureSpec {
    const val FEATURE_COUNT = 10
    val NAMES = listOf(
        "Progress toward TP",
        "Progress toward SL",
        "Distance to hiLine",
        "Distance to loLine",
        "Distance to 4h average",
        "Lines crossed against trade",
        "1-minute return against trade",
        "5-minute return against trade",
        "Volume ratio vs entry",
        "Bars elapsed since entry"
    )
}

object ExitWarningFeatureBuilder {

    fun buildStateFeatures(
        candles: List<Candle>,
        snapshots: List<ConfluenceBarSnapshot>,
        currentBarIndex: Int,
        entryBarIndex: Int,
        direction: TradeDirection,
        entryPrice: Double,
        slPrice: Double,
        tpPrice: Double
    ): DoubleArray? {
        if (currentBarIndex !in candles.indices || currentBarIndex !in snapshots.indices) return null
        val snap = snapshots[currentBarIndex]
        val bar = candles[currentBarIndex]
        val close = bar.close.coerceAtLeast(1e-9)
        val hiLine = snap.hiLine ?: return null
        val loLine = snap.loLine ?: return null
        val basis = snap.basis ?: return null
        val resVal = snap.resVal ?: return null
        val supVal = snap.supVal ?: return null

        val tpSpan = abs(tpPrice - entryPrice).coerceAtLeast(1e-9)
        val slSpan = abs(entryPrice - slPrice).coerceAtLeast(1e-9)

        val progressTp = when (direction) {
            TradeDirection.LONG -> (close - entryPrice) / tpSpan
            TradeDirection.SHORT -> (entryPrice - close) / tpSpan
        }.coerceIn(-2.0, 2.0)

        val progressSl = when (direction) {
            TradeDirection.LONG -> (entryPrice - close) / slSpan
            TradeDirection.SHORT -> (close - entryPrice) / slSpan
        }.coerceIn(-2.0, 2.0)

        val distHi = (close - hiLine) / close
        val distLo = (close - loLine) / close
        val distBasis = (close - basis) / close

        val linesCrossedAgainst = when (direction) {
            TradeDirection.LONG -> {
                var c = 0
                if (close < resVal) c++
                if (close < supVal) c++
                if (close < basis) c++
                c / 3.0
            }
            TradeDirection.SHORT -> {
                var c = 0
                if (close > resVal) c++
                if (close > supVal) c++
                if (close > basis) c++
                c / 3.0
            }
        }

        val c1 = candles.getOrNull(currentBarIndex - 1)?.close ?: close
        val c5 = candles.getOrNull(currentBarIndex - 5)?.close ?: close
        val retAgainst1 = when (direction) {
            TradeDirection.LONG -> (c1 - close) / c1.coerceAtLeast(1e-9)
            TradeDirection.SHORT -> (close - c1) / c1.coerceAtLeast(1e-9)
        }
        val retAgainst5 = when (direction) {
            TradeDirection.LONG -> (c5 - close) / c5.coerceAtLeast(1e-9)
            TradeDirection.SHORT -> (close - c5) / c5.coerceAtLeast(1e-9)
        }

        val safeEntryIdx = entryBarIndex.coerceIn(0, currentBarIndex)
        var volSum = 0.0
        for (i in safeEntryIdx..currentBarIndex) volSum += candles[i].volume
        val avgVolSinceEntry = (volSum / (currentBarIndex - safeEntryIdx + 1)).coerceAtLeast(1e-9)
        val volRatio = (bar.volume / avgVolSinceEntry).coerceIn(0.0, 10.0)
        val barsElapsed = ((currentBarIndex - safeEntryIdx) / 60.0).coerceIn(0.0, 2.0)

        return doubleArrayOf(
            progressTp,
            progressSl,
            distHi,
            distLo,
            distBasis,
            linesCrossedAgainst,
            retAgainst1,
            retAgainst5,
            volRatio,
            barsElapsed
        )
    }

    fun trainExitModel(samples: List<LabeledSample>): Pair<LogisticRegressionWeights, Double> {
        if (samples.isEmpty()) {
            val stats = StandardizationStats(DoubleArray(ExitFeatureSpec.FEATURE_COUNT), DoubleArray(ExitFeatureSpec.FEATURE_COUNT) { 1.0 })
            return LogisticRegressionWeights(DoubleArray(ExitFeatureSpec.FEATURE_COUNT), 0.0, stats) to 0.65
        }
        val stats = StandardizationStats.fit(samples.map { it.features }, ExitFeatureSpec.FEATURE_COUNT)
        val weighted = OverlapWeightCalculator.assignOverlapWeights(samples)
        val model = LogisticRegressionTrainer.trainWithCheckpoints(
            samples = weighted,
            stats = stats,
            featureCount = ExitFeatureSpec.FEATURE_COUNT,
            params = LogisticHyperParams(epochs = 20, batchSize = 32, learningRate = 0.03, l2Lambda = 0.02)
        )
        // Pick threshold maximizing balanced accuracy / precision >= 0.60
        var bestThresh = 0.65
        var bestF1 = -1.0
        for (pct in 55..80 step 5) {
            val t = pct / 100.0
            var tp = 0
            var fp = 0
            var fn = 0
            for (s in samples) {
                val p = model.predictProbability(s.features)
                val pred = p >= t
                if (pred && s.label == 1) tp++
                else if (pred && s.label == 0) fp++
                else if (!pred && s.label == 1) fn++
            }
            val denom = 2 * tp + fp + fn
            val f1 = if (denom > 0) (2.0 * tp) / denom else 0.0
            if (f1 > bestF1) {
                bestF1 = f1
                bestThresh = t
            }
        }
        return model to bestThresh
    }
}
