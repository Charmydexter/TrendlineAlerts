package com.lrmlc.tradingalerts.ml

import com.lrmlc.tradingalerts.data.local.TrainingLogEntity
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

@Serializable
data class ReportPerAssetRow(
    val symbol: String,
    val presetId: String = "R240",
    val samples: Int,
    val threshold: Double,
    val winRate: Double,
    val netExpectancyPct: Double,
    val profitFactor: Double,
    val updatedOrKept: String
)

@Serializable
data class ReportAssetPresetRow(
    val symbol: String,
    val presetId: String,
    val presetLabel: String,
    val trades: Int,
    val lcbExpectancyPct: Double
)

@Serializable
data class ReportLiveOutcomes(
    val acceptedAlerts: Int = 0,
    val resolvedTp: Int = 0,
    val resolvedSl: Int = 0,
    val resolvedOpposite: Int = 0,
    val resolvedManual: Int = 0,
    val winRate: Double? = null,
    val shadowCount: Int = 0,
    val shadowWinRate: Double? = null
)

@Serializable
data class TrainingReportData(
    val jobType: String,
    val startedAtMs: Long,
    val endedAtMs: Long,
    val durationMs: Long,
    val exchange: String,
    val marketType: String,
    val capitalUsd: Double,
    val maxLossUsd: Double,
    val takeProfitUsd: Double,
    val roundTripFeeRate: Double,
    val labelHorizonBars: Int,
    val windowLength: Int,
    val minGap: Int,
    val thresholdMode: String,
    val manualThreshold: Double,
    val minSamplesForPerAssetModel: Int,
    val retentionDays: Int,
    val stopDistancePct: Double,
    val tpDistancePct: Double,
    val feeAsPctOfBarrier: Double,
    val rangePresetsSummary: String = "30m/3 | 1h/7 | 2h/15 | 4h/30",
    val activeRangeLabel: String = "4h",
    val symbolCount: Int,
    val symbols: List<String>,
    val samplesPerSymbol: Map<String, Int>,
    val totalSetups: Int,
    val dataWindowStartMs: Long,
    val dataWindowEndMs: Long,
    val winLabelShare: Double,
    val timeoutCount: Int,
    val globalMetrics: ValidationMetrics,
    val promoted: Boolean,
    val promotionReason: String,
    val candidateHoldoutMetrics: ValidationMetrics? = null,
    val activeHoldoutMetrics: ValidationMetrics? = null,
    val perAssetRows: List<ReportPerAssetRow> = emptyList(),
    val pooledPresetSummaries: List<PooledPresetSummary> = emptyList(),
    val assetPresetSelections: List<ReportAssetPresetRow> = emptyList(),
    val pooledBestPresetId: String = "R240",
    val topPositiveFactors: List<ReadableFactor> = emptyList(),
    val topNegativeFactors: List<ReadableFactor> = emptyList(),
    val exitRuleSummary: String? = null,
    val liveOutcomes: ReportLiveOutcomes = ReportLiveOutcomes()
)

object TrainingReportBuilder {

    const val MAX_RANGE_RUNS = 100
    const val SIZE_GUARD_CHARS = 400_000

    private val json = Json { ignoreUnknownKeys = true }
    private val utcDateTime = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm 'UTC'", Locale.US)
        .withZone(ZoneOffset.UTC)
    private val utcShortTime = DateTimeFormatter.ofPattern("MM-dd HH:mm", Locale.US)
        .withZone(ZoneOffset.UTC)

    fun parseReportData(log: TrainingLogEntity): TrainingReportData? {
        val raw = log.reportJson ?: return null
        if (raw.isBlank()) return null
        return runCatching { json.decodeFromString<TrainingReportData>(raw) }.getOrNull()
    }

    fun parseMetrics(log: TrainingLogEntity): ValidationMetrics? {
        if (log.metricsJson.isBlank() || log.metricsJson == "{}") return null
        return runCatching { json.decodeFromString<ValidationMetrics>(log.metricsJson) }.getOrNull()
    }

    fun compactSnapshotLine(log: TrainingLogEntity, data: TrainingReportData?): String {
        val m = data?.globalMetrics ?: parseMetrics(log)
        val winStr = m?.let { String.format(Locale.US, "%.1f%%", it.winRate * 100.0) } ?: "--"
        val expStr = m?.let { String.format(Locale.US, "%+.3f%%", it.netExpectancyPct * 100.0) } ?: "--"
        val tradesStr = m?.let { "${it.tradesTaken}/${it.totalOutOfSample}" } ?: "--"
        return if (data != null) {
            String.format(
                Locale.US,
                "Win %s · Exp %s · %s trades · \$%.0f (SL \$%.2f / TP \$%.2f · %s)",
                winStr,
                expStr,
                tradesStr,
                data.capitalUsd,
                data.maxLossUsd,
                data.takeProfitUsd,
                data.activeRangeLabel
            )
        } else {
            "Win $winStr · Exp $expStr · $tradesStr trades"
        }
    }

    fun buildSingle(log: TrainingLogEntity, data: TrainingReportData? = parseReportData(log)): String {
        val sb = StringBuilder(4096)
        sb.append("# Trading Alerts Training Report (Single Run)\n\n")
        sb.append("- **Market**: ${log.exchange} ${log.marketType}\n")
        sb.append("- **Generated**: ${formatTime(log.timestampMs)}\n\n")

        appendPreamble(sb)
        appendSingleRunBody(
            sb = sb,
            runNumber = 1,
            log = log,
            data = data,
            prevData = null,
            prevRunNumber = null,
            includePerAssetAndFactors = true
        )
        appendGlossary(sb)
        return sb.toString()
    }

    fun buildRange(
        logs: List<TrainingLogEntity>,
        rangeLabel: String,
        nowMs: Long = System.currentTimeMillis()
    ): String {
        if (logs.isEmpty()) {
            return buildString {
                append("# Trading Alerts Training Report ($rangeLabel)\n\n")
                append("Generated: ${formatTime(nowMs)}\n\n")
                append("No training runs found in the selected window ($rangeLabel).\n")
            }
        }

        val sortedNewestFirst = logs.sortedByDescending { it.timestampMs }
        val wasTruncated = sortedNewestFirst.size > MAX_RANGE_RUNS
        val selectedChronological = sortedNewestFirst.take(MAX_RANGE_RUNS).reversed()
        val parsed = selectedChronological.map { it to parseReportData(it) }

        val fullAttempt = renderRangeMarkdown(
            entries = parsed,
            rangeLabel = rangeLabel,
            nowMs = nowMs,
            wasTruncated = wasTruncated,
            originalTotalCount = logs.size,
            compactOlderRuns = false
        )
        if (fullAttempt.length <= SIZE_GUARD_CHARS) {
            return fullAttempt
        }
        return renderRangeMarkdown(
            entries = parsed,
            rangeLabel = rangeLabel,
            nowMs = nowMs,
            wasTruncated = wasTruncated,
            originalTotalCount = logs.size,
            compactOlderRuns = true
        )
    }

    private fun renderRangeMarkdown(
        entries: List<Pair<TrainingLogEntity, TrainingReportData?>>,
        rangeLabel: String,
        nowMs: Long,
        wasTruncated: Boolean,
        originalTotalCount: Int,
        compactOlderRuns: Boolean
    ): String {
        val sb = StringBuilder(16384)
        val firstTs = entries.first().first.timestampMs
        val lastTs = entries.last().first.timestampMs
        sb.append("# Trading Alerts Training Report ($rangeLabel)\n\n")
        sb.append("- **Range**: $rangeLabel\n")
        sb.append("- **Span**: ${formatTime(firstTs)} to ${formatTime(lastTs)}\n")
        sb.append("- **Runs included**: ${entries.size}")
        if (wasTruncated) {
            sb.append(" (truncated to the $MAX_RANGE_RUNS most recent runs out of $originalTotalCount)")
        }
        sb.append("\n")
        sb.append("- **Generated**: ${formatTime(nowMs)}\n")
        if (compactOlderRuns) {
            sb.append("- **Size notice**: Report exceeded 400,000 characters; comparison table covers all runs, while per-asset tables and learned-factor lists are included only for the newest 5 runs.\n")
        }
        sb.append("\n")

        appendPreamble(sb)

        // Settings change timeline
        sb.append("## Settings change timeline\n\n")
        val changes = ArrayList<String>()
        for (i in 1 until entries.size) {
            val prevData = entries[i - 1].second
            val currLog = entries[i].first
            val currData = entries[i].second
            if (prevData != null && currData != null) {
                val diffs = diffSettingsAndDataset(prevData, currData)
                if (diffs.isNotEmpty()) {
                    changes.add("- Run ${i + 1}, ${utcShortTime.format(Instant.ofEpochMilli(currLog.timestampMs))}: ${diffs.joinToString("; ")}")
                }
            }
        }
        if (changes.isEmpty()) {
            sb.append("No settings or dataset changes detected across captured runs.\n\n")
        } else {
            changes.forEach { sb.append(it).append('\n') }
            sb.append('\n')
        }

        // Comparison table (oldest to newest)
        sb.append("## Run comparison table (oldest to newest)\n\n")
        sb.append("| Run | Time (UTC) | Job | Capital | SL / TP (Barrier %) | Threshold | Trades / OOS | Win Rate | Expectancy | Profit Factor | Brier | Decision |\n")
        sb.append("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |\n")
        entries.forEachIndexed { idx, (log, data) ->
            val m = data?.globalMetrics ?: parseMetrics(log)
            val timeStr = utcShortTime.format(Instant.ofEpochMilli(log.timestampMs))
            val capStr = data?.let { String.format(Locale.US, "\$%.2f", it.capitalUsd) } ?: "N/A"
            val barrierStr = data?.let {
                String.format(
                    Locale.US,
                    "\$%.2f/\$%.2f (%.2f%%/%.2f%%)",
                    it.maxLossUsd,
                    it.takeProfitUsd,
                    it.stopDistancePct,
                    it.tpDistancePct
                )
            } ?: "N/A"
            val threshStr = m?.let { String.format(Locale.US, "%.0f%%", it.threshold * 100.0) } ?: "N/A"
            val tradesStr = m?.let { "${it.tradesTaken}/${it.totalOutOfSample}" } ?: "N/A"
            val winStr = m?.let { String.format(Locale.US, "%.2f%%", it.winRate * 100.0) } ?: "N/A"
            val expStr = m?.let { String.format(Locale.US, "%+.3f%%", it.netExpectancyPct * 100.0) } ?: "N/A"
            val pfStr = m?.let { String.format(Locale.US, "%.2f", it.profitFactor) } ?: "N/A"
            val brierStr = m?.let { String.format(Locale.US, "%.4f", it.brierScore) } ?: "N/A"
            val decStr = if (log.promoted) "Promoted" else "Kept"
            sb.append("| ${idx + 1} | $timeStr | ${log.jobType} | $capStr | $barrierStr | $threshStr | $tradesStr | $winStr | $expStr | $pfStr | $brierStr | $decStr |\n")
        }
        sb.append('\n')

        // Detailed run sections
        sb.append("## Detailed runs\n\n")
        val newestCutoff = (entries.size - 5).coerceAtLeast(0)
        var lastFullRunNum: Int? = null
        var lastFullData: TrainingReportData? = null
        entries.forEachIndexed { idx, (log, data) ->
            val runNum = idx + 1
            val includeDetails = !compactOlderRuns || idx >= newestCutoff
            sb.append("### Run $runNum — ${formatTime(log.timestampMs)} (${log.jobType})\n\n")
            appendSingleRunBody(
                sb = sb,
                runNumber = runNum,
                log = log,
                data = data,
                prevData = lastFullData,
                prevRunNumber = lastFullRunNum,
                includePerAssetAndFactors = includeDetails
            )
            if (data != null) {
                lastFullData = data
                lastFullRunNum = runNum
            }
        }

        appendGlossary(sb)
        return sb.toString()
    }

    private fun appendPreamble(sb: StringBuilder) {
        sb.append("## (a) Preamble for assistant\n\n")
        sb.append("This Markdown export comes from a crypto trading signal-alert app using public 1-minute market candles (Bybit/Binance). ")
        sb.append("Entry signals come from a deterministic triple-confluence rule (rolling channel + two trendlines), filtered by regularized logistic-regression models trained with purged walk-forward validation on triple-barrier labels.\n\n")
        sb.append("**Instructions for reading this report**:\n")
        sb.append("1. Explain what changed and what the numbers mean in plain, non-jargon language.\n")
        sb.append("2. Use ONLY numbers explicitly present in this report; never invent missing metrics.\n")
        sb.append("3. Explicitly say when something is missing (for example, legacy logs marked with limited data).\n")
        sb.append("4. Flag small sample sizes, confidence intervals, and uncertainty prominently.\n")
        sb.append("5. Provide no financial advice or profit guarantees.\n\n")
        sb.append("**Suggested questions to ask**:\n")
        sb.append("- Why did this run promote or keep the existing model, and are the out-of-sample trades large enough to trust?\n")
        sb.append("- Is the model better calibrated and beating the baseline Brier score and break-even win rate?\n")
        sb.append("- Which asset range presets and learned factors are driving performance right now?\n\n")
    }

    private fun appendSingleRunBody(
        sb: StringBuilder,
        runNumber: Int,
        log: TrainingLogEntity,
        data: TrainingReportData?,
        prevData: TrainingReportData?,
        prevRunNumber: Int?,
        includePerAssetAndFactors: Boolean
    ) {
        val metrics = data?.globalMetrics ?: parseMetrics(log)

        sb.append("#### (b) Run summary and decision\n\n")
        if (data == null) {
            sb.append("- **Notice**: Limited data: this log was created before full report capture.\n")
        } else {
            val durSec = data.durationMs / 1000.0
            sb.append("- **Started**: ${formatTime(data.startedAtMs)} | **Ended**: ${formatTime(data.endedAtMs)} | **Duration**: ${String.format(Locale.US, "%.1f", durSec)}s\n")
        }
        sb.append("- **Job type**: ${log.jobType} | **Decision**: ${if (log.promoted) "Promoted" else "Kept"}\n")
        sb.append("- **Summary**: ${log.summary}\n")
        if (data != null && !data.exitRuleSummary.isNullOrBlank()) {
            sb.append("- **Exit rules**: ${data.exitRuleSummary}\n")
        }
        sb.append('\n')

        sb.append("#### (c) Settings and derived barrier math\n\n")
        if (data == null) {
            sb.append("Limited data: settings snapshot not available for this legacy run.\n\n")
        } else if (prevData != null && prevRunNumber != null && sameSettings(prevData, data)) {
            sb.append("Same as Run $prevRunNumber.\n\n")
        } else {
            sb.append("- **Exchange / Market**: ${data.exchange} ${data.marketType}\n")
            sb.append("- **Capital**: \$${String.format(Locale.US, "%.2f", data.capitalUsd)} | **Max loss**: \$${String.format(Locale.US, "%.2f", data.maxLossUsd)} (${String.format(Locale.US, "%.2f%%", data.stopDistancePct)}) | **Take profit**: \$${String.format(Locale.US, "%.2f", data.takeProfitUsd)} (${String.format(Locale.US, "%.2f%%", data.tpDistancePct)})\n")
            sb.append("- **Round-trip fee**: ${String.format(Locale.US, "%.3f%%", data.roundTripFeeRate * 100.0)} (${String.format(Locale.US, "%.1f%%", data.feeAsPctOfBarrier)} of barrier)\n")
            sb.append("- **Horizon**: ${data.labelHorizonBars} min | **Range presets**: ${data.rangePresetsSummary} (active pooled-best: ${data.activeRangeLabel})\n")
            sb.append("- **Threshold mode**: ${data.thresholdMode} (manual target ${String.format(Locale.US, "%.0f%%", data.manualThreshold * 100.0)}) | **Per-asset min samples**: ${data.minSamplesForPerAssetModel} | **Retention**: ${data.retentionDays} days\n\n")
        }

        sb.append("#### (d) Dataset\n\n")
        if (data == null) {
            sb.append("Limited data: dataset breakdown not available for this legacy run.\n\n")
        } else if (prevData != null && prevRunNumber != null && sameDataset(prevData, data)) {
            sb.append("Same as Run $prevRunNumber.\n\n")
        } else {
            sb.append("- **Symbols (${data.symbolCount})**: ${data.symbols.joinToString(", ")}\n")
            sb.append("- **Total setups**: ${data.totalSetups} | **Win-label share**: ${String.format(Locale.US, "%.2f%%", data.winLabelShare * 100.0)} | **Timeouts**: ${data.timeoutCount}\n")
            sb.append("- **Data window**: ${formatTime(data.dataWindowStartMs)} to ${formatTime(data.dataWindowEndMs)}\n")
            val symBreakdown = data.samplesPerSymbol.entries.sortedByDescending { it.value }
                .joinToString(", ") { "${it.key}: ${it.value}" }
            sb.append("- **Setups per symbol**: $symBreakdown\n\n")
        }

        sb.append("#### (e) Out-of-sample results & calibration\n\n")
        if (metrics == null) {
            sb.append("No validation metrics recorded.\n\n")
        } else {
            val wins = (metrics.winRate * metrics.tradesTaken).toInt().coerceIn(0, metrics.tradesTaken)
            val (ciLo, ciHi) = ModelExplainer.wilsonInterval(wins, metrics.tradesTaken)
            val baseBrier = ModelExplainer.baselineBrier(metrics.baselineWinRate)
            sb.append("| Metric | Value |\n| --- | --- |\n")
            sb.append("| Confidence threshold | ${String.format(Locale.US, "%.0f%%", metrics.threshold * 100.0)} |\n")
            sb.append("| Fee-aware break-even | ${String.format(Locale.US, "%.2f%%", metrics.breakEvenThreshold * 100.0)} |\n")
            sb.append("| Trades taken / total OOS | ${metrics.tradesTaken} / ${metrics.totalOutOfSample} |\n")
            sb.append("| Win rate (95% Wilson CI) | ${String.format(Locale.US, "%.2f%% (%.1f%%-%.1f%%)", metrics.winRate * 100.0, ciLo * 100.0, ciHi * 100.0)} |\n")
            sb.append("| Baseline win rate | ${String.format(Locale.US, "%.2f%%", metrics.baselineWinRate * 100.0)} |\n")
            sb.append("| Net expectancy per trade | ${String.format(Locale.US, "%+.3f%%", metrics.netExpectancyPct * 100.0)} |\n")
            sb.append("| Baseline expectancy | ${String.format(Locale.US, "%+.3f%%", metrics.baselineExpectancyPct * 100.0)} |\n")
            sb.append("| Profit factor | ${String.format(Locale.US, "%.2f", metrics.profitFactor)} |\n")
            sb.append("| Max drawdown | ${String.format(Locale.US, "%.3f%%", metrics.maxDrawdownPct * 100.0)} |\n")
            sb.append("| Brier score vs baseline | ${String.format(Locale.US, "%.4f vs %.4f", metrics.brierScore, baseBrier)} |\n")
            if (metrics.metricsAreOptimistic) {
                sb.append("| Evaluation warning | Optimistic (threshold tuned on same data) |\n")
            }
            if (metrics.manualThreshold != null && metrics.manualTradesTaken != null) {
                sb.append("| Manual threshold (${String.format(Locale.US, "%.0f%%", metrics.manualThreshold * 100.0)}) | ${metrics.manualTradesTaken} trades, ${String.format(Locale.US, "%.2f%%", (metrics.manualWinRate ?: 0.0) * 100.0)} win, ${String.format(Locale.US, "%+.3f%%", (metrics.manualExpectancyPct ?: 0.0) * 100.0)} exp |\n")
            }
            sb.append('\n')

            if (metrics.calibrationBuckets.isNotEmpty()) {
                sb.append("**Calibration buckets**:\n\n")
                sb.append("| Bucket | Samples | Predicted Avg | Actual Win Rate |\n| --- | --- | --- | --- |\n")
                for (b in metrics.calibrationBuckets) {
                    sb.append("| ${(b.minProb * 100).toInt()}-${(b.maxProb * 100).toInt()}% | ${b.sampleCount} | ${String.format(Locale.US, "%.1f%%", b.predictedAvg * 100.0)} | ${String.format(Locale.US, "%.1f%%", b.actualWinRate * 100.0)} |\n")
                }
                sb.append('\n')
            }
        }

        sb.append("#### (f) Candidate vs active comparison\n\n")
        if (data == null) {
            sb.append("Limited data: hold-out comparison not captured for this legacy run.\n\n")
        } else {
            sb.append("- **Decision**: ${if (data.promoted) "Promoted" else "Kept"} — ${data.promotionReason}\n")
            data.candidateHoldoutMetrics?.let { c ->
                sb.append("- **Candidate hold-out**: ${c.tradesTaken} trades, win ${String.format(Locale.US, "%.2f%%", c.winRate * 100.0)}, net expectancy ${String.format(Locale.US, "%+.3f%%", c.netExpectancyPct * 100.0)} (baseline ${String.format(Locale.US, "%+.3f%%", c.baselineExpectancyPct * 100.0)})\n")
            }
            data.activeHoldoutMetrics?.let { a ->
                sb.append("- **Previous active hold-out**: ${a.tradesTaken} trades, win ${String.format(Locale.US, "%.2f%%", a.winRate * 100.0)}, net expectancy ${String.format(Locale.US, "%+.3f%%", a.netExpectancyPct * 100.0)}\n")
            }
            sb.append('\n')
        }

        sb.append("#### (g) Per-asset models & range selection\n\n")
        if (!includePerAssetAndFactors) {
            sb.append("Omitted for size in combined export (see comparison table above or inspect latest 5 runs).\n\n")
        } else if (data == null) {
            sb.append("Limited data: per-asset table not available for this legacy run.\n\n")
        } else {
            if (data.pooledPresetSummaries.isNotEmpty()) {
                sb.append("**Pooled preset comparison** (pooled-best: ${data.pooledBestPresetId}):\n\n")
                sb.append("| Preset | Window/Gap | Threshold | Trades | Win Rate | Expectancy | LCB Expectancy | Brier |\n| --- | --- | --- | --- | --- | --- | --- | --- |\n")
                for (p in data.pooledPresetSummaries) {
                    sb.append("| ${p.presetId} (${p.label}) | ${p.windowBars}/${p.minGapBars} | ${String.format(Locale.US, "%.0f%%", p.threshold * 100.0)} | ${p.trades} | ${String.format(Locale.US, "%.1f%%", p.winRate * 100.0)} | ${String.format(Locale.US, "%+.3f%%", p.expectancyPct * 100.0)} | ${String.format(Locale.US, "%+.3f%%", p.lcbExpectancyPct * 100.0)} | ${String.format(Locale.US, "%.4f", p.brierScore)} |\n")
                }
                sb.append('\n')
            }
            if (data.perAssetRows.isEmpty()) {
                sb.append("No per-asset models met the sample threshold.\n\n")
            } else {
                sb.append("| Symbol | Range Preset | Samples | Threshold | Win Rate | Expectancy | Profit Factor | Status |\n| --- | --- | --- | --- | --- | --- | --- | --- |\n")
                for (row in data.perAssetRows.take(30)) {
                    sb.append("| ${row.symbol} | ${row.presetId} | ${row.samples} | ${String.format(Locale.US, "%.0f%%", row.threshold * 100.0)} | ${String.format(Locale.US, "%.1f%%", row.winRate * 100.0)} | ${String.format(Locale.US, "%+.3f%%", row.netExpectancyPct * 100.0)} | ${String.format(Locale.US, "%.2f", row.profitFactor)} | ${row.updatedOrKept} |\n")
                }
                sb.append('\n')
            }
        }

        sb.append("#### (h) Learned factors\n\n")
        if (!includePerAssetAndFactors) {
            sb.append("Omitted for size in combined export (included for newest 5 runs).\n\n")
        } else if (data == null || (data.topPositiveFactors.isEmpty() && data.topNegativeFactors.isEmpty())) {
            sb.append("No learned factor details available for this run.\n\n")
        } else {
            if (data.topPositiveFactors.isNotEmpty()) {
                sb.append("**Top positive factors**:\n")
                for (f in data.topPositiveFactors.take(5)) {
                    sb.append("- ${f.title} (+${String.format(Locale.US, "%.3f", f.strength)}): ${f.sentence}\n")
                }
            }
            if (data.topNegativeFactors.isNotEmpty()) {
                sb.append("**Top negative factors**:\n")
                for (f in data.topNegativeFactors.take(5)) {
                    sb.append("- ${f.title} (-${String.format(Locale.US, "%.3f", f.strength)}): ${f.sentence}\n")
                }
            }
            sb.append('\n')
        }

        sb.append("#### (i) Live outcomes since last run\n\n")
        if (data == null) {
            sb.append("Limited data: live outcome delta not captured.\n\n")
        } else {
            val lo = data.liveOutcomes
            val liveWinStr = lo.winRate?.let { String.format(Locale.US, "%.1f%%", it * 100.0) } ?: "N/A"
            val shadowWinStr = lo.shadowWinRate?.let { String.format(Locale.US, "%.1f%%", it * 100.0) } ?: "N/A"
            sb.append("- **Accepted alerts**: ${lo.acceptedAlerts} (TP ${lo.resolvedTp}, SL ${lo.resolvedSl}, Opposite ${lo.resolvedOpposite}, Manual ${lo.resolvedManual}) | **Win rate**: $liveWinStr\n")
            sb.append("- **Shadow signals**: ${lo.shadowCount} | **Shadow win rate**: $shadowWinStr\n\n")
        }
    }

    private fun appendGlossary(sb: StringBuilder) {
        sb.append("## (j) Glossary\n\n")
        sb.append("- **Expectancy**: Average net return per trade (after estimated round-trip fees).\n")
        sb.append("- **Profit factor**: Total gross profits divided by total gross losses (above 1.00 means net positive before unmodeled slippage).\n")
        sb.append("- **Brier score**: Mean squared error of predicted win probabilities vs binary outcomes (lower is better; compare against constant base-rate baseline p*(1-p)).\n")
        sb.append("- **Break-even win rate**: Minimum win rate required to cover average net losses including round-trip fees.\n")
        sb.append("- **Confidence threshold**: Minimum predicted probability P(win) required for an alert to be accepted instead of logged as shadow.\n")
        sb.append("- **Shadow trade**: Signal below the active threshold that was filtered out of live alerts but tracked on candles to measure unbiased counterfactual performance.\n")
        sb.append("- **Triple-barrier label**: Trade outcome determined by whichever barrier triggers first: take-profit (win), stop-loss (loss), or horizon timeout (sign of net return after fees).\n")
        sb.append("- **Out-of-sample / walk-forward**: Chronological validation where models are trained strictly on earlier candles (with a horizon purge gap) and scored on unseen later setups.\n")
    }

    private fun sameSettings(a: TrainingReportData, b: TrainingReportData): Boolean =
        a.exchange == b.exchange &&
            a.marketType == b.marketType &&
            abs(a.capitalUsd - b.capitalUsd) < 1e-9 &&
            abs(a.maxLossUsd - b.maxLossUsd) < 1e-9 &&
            abs(a.takeProfitUsd - b.takeProfitUsd) < 1e-9 &&
            abs(a.roundTripFeeRate - b.roundTripFeeRate) < 1e-9 &&
            a.labelHorizonBars == b.labelHorizonBars &&
            a.thresholdMode == b.thresholdMode &&
            abs(a.manualThreshold - b.manualThreshold) < 1e-9 &&
            a.minSamplesForPerAssetModel == b.minSamplesForPerAssetModel &&
            a.retentionDays == b.retentionDays

    private fun sameDataset(a: TrainingReportData, b: TrainingReportData): Boolean =
        a.totalSetups == b.totalSetups &&
            a.symbolCount == b.symbolCount &&
            a.dataWindowStartMs == b.dataWindowStartMs &&
            a.dataWindowEndMs == b.dataWindowEndMs &&
            a.symbols == b.symbols

    private fun diffSettingsAndDataset(prev: TrainingReportData, curr: TrainingReportData): List<String> {
        val diffs = ArrayList<String>()
        if (abs(prev.capitalUsd - curr.capitalUsd) > 1e-6) {
            diffs.add(String.format(Locale.US, "capital \$%.2f -> \$%.2f", prev.capitalUsd, curr.capitalUsd))
        }
        if (abs(prev.maxLossUsd - curr.maxLossUsd) > 1e-6) {
            diffs.add(String.format(Locale.US, "maxLoss \$%.2f -> \$%.2f", prev.maxLossUsd, curr.maxLossUsd))
        }
        if (abs(prev.takeProfitUsd - curr.takeProfitUsd) > 1e-6) {
            diffs.add(String.format(Locale.US, "takeProfit \$%.2f -> \$%.2f", prev.takeProfitUsd, curr.takeProfitUsd))
        }
        if (abs(prev.roundTripFeeRate - curr.roundTripFeeRate) > 1e-7) {
            diffs.add(String.format(Locale.US, "fee %.3f%% -> %.3f%%", prev.roundTripFeeRate * 100.0, curr.roundTripFeeRate * 100.0))
        }
        if (prev.thresholdMode != curr.thresholdMode || abs(prev.manualThreshold - curr.manualThreshold) > 1e-6) {
            diffs.add("threshold ${prev.thresholdMode} -> ${curr.thresholdMode}")
        }
        if (prev.labelHorizonBars != curr.labelHorizonBars) {
            diffs.add("horizon ${prev.labelHorizonBars} -> ${curr.labelHorizonBars}")
        }
        if (prev.retentionDays != curr.retentionDays) {
            diffs.add("retention ${prev.retentionDays}d -> ${curr.retentionDays}d")
        }
        if (prev.symbolCount != curr.symbolCount) {
            diffs.add("symbols ${prev.symbolCount} -> ${curr.symbolCount}")
        }
        if (prev.totalSetups != curr.totalSetups) {
            diffs.add("setups ${prev.totalSetups} -> ${curr.totalSetups}")
        }
        return diffs
    }

    private fun formatTime(ms: Long): String = utcDateTime.format(Instant.ofEpochMilli(ms))
}
