package com.lrmlc.tradingalerts.ml

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.lrmlc.tradingalerts.R
import com.lrmlc.tradingalerts.TradingAlertsApp
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.service.NotificationHelper
import java.util.concurrent.TimeUnit

class TrainingWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val container = (applicationContext as TradingAlertsApp).container
        container.notificationHelper.ensureChannels()
        setForeground(createForegroundInfo("Training LRMLC models..."))

        val explicitJobId = inputData.getString(KEY_JOB_ID)
        val scheduledType = inputData.getString(KEY_SCHEDULED_TYPE)
        val settings = container.settingsRepository.getSettings()

        val targetJobId = if (explicitJobId != null) {
            explicitJobId
        } else if (scheduledType != null) {
            val type = runCatching { TrainingJobType.valueOf(scheduledType) }.getOrDefault(TrainingJobType.DAILY)
            container.trainingOrchestrator.enqueueJob(type, settings.exchange, settings.marketType).jobId
        } else {
            null
        }

        val ok = container.trainingOrchestrator.runNextOrSpecificJob(targetJobId)
        // Do not retry forever: a perpetually backed-off run would block later work
        return if (ok || runAttemptCount >= 2) Result.success() else Result.retry()
    }

    private fun createForegroundInfo(text: String): ForegroundInfo {
        val notif = NotificationCompat.Builder(applicationContext, NotificationHelper.CHANNEL_OUTCOMES)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Trading Alerts (LRMLC)")
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(1002, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(1002, notif)
        }
    }

    companion object {
        const val KEY_JOB_ID = "job_id"
        const val KEY_SCHEDULED_TYPE = "scheduled_type"

        // userInitiated = true replaces any stuck/backed-off run so a Train tap always starts;
        // app-start resume keeps an already running job.
        fun enqueueOneTime(context: Context, jobId: String, userInitiated: Boolean = false) {
            val req = OneTimeWorkRequestBuilder<TrainingWorker>()
                .setInputData(workDataOf(KEY_JOB_ID to jobId))
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                "lrmlc_training_active",
                if (userInitiated) ExistingWorkPolicy.REPLACE else ExistingWorkPolicy.KEEP,
                req
            )
        }

        fun schedulePeriodicCadences(context: Context) {
            val wm = WorkManager.getInstance(context)

            val daily = PeriodicWorkRequestBuilder<TrainingWorker>(24, TimeUnit.HOURS)
                .setInputData(workDataOf(KEY_SCHEDULED_TYPE to TrainingJobType.DAILY.name))
                .build()
            wm.enqueueUniquePeriodicWork("lrmlc_daily_train", ExistingPeriodicWorkPolicy.KEEP, daily)

            val threeDay = PeriodicWorkRequestBuilder<TrainingWorker>(3, TimeUnit.DAYS)
                .setInputData(workDataOf(KEY_SCHEDULED_TYPE to TrainingJobType.THREE_DAY.name))
                .build()
            wm.enqueueUniquePeriodicWork("lrmlc_3day_train", ExistingPeriodicWorkPolicy.KEEP, threeDay)

            val weekly = PeriodicWorkRequestBuilder<TrainingWorker>(7, TimeUnit.DAYS)
                .setInputData(workDataOf(KEY_SCHEDULED_TYPE to TrainingJobType.WEEKLY.name))
                .build()
            wm.enqueueUniquePeriodicWork("lrmlc_weekly_train", ExistingPeriodicWorkPolicy.KEEP, weekly)
        }
    }
}
