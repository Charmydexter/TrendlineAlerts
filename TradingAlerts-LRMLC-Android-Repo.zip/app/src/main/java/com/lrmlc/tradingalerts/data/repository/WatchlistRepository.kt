package com.lrmlc.tradingalerts.data.repository

import com.lrmlc.tradingalerts.data.local.RecycleBinDao
import com.lrmlc.tradingalerts.data.local.RecycleBinEntity
import com.lrmlc.tradingalerts.data.local.SignalCandidateDao
import com.lrmlc.tradingalerts.data.local.SyncProgressDao
import com.lrmlc.tradingalerts.data.local.WatchlistDao
import com.lrmlc.tradingalerts.data.local.WatchlistEntity
import com.lrmlc.tradingalerts.data.model.DefaultWatchlist
import com.lrmlc.tradingalerts.data.model.ExchangeId
import com.lrmlc.tradingalerts.data.model.InstrumentInfo
import com.lrmlc.tradingalerts.data.model.MarketType
import com.lrmlc.tradingalerts.data.model.ensureUsdtSymbol
import com.lrmlc.tradingalerts.data.model.stripUsdtSuffix
import kotlinx.coroutines.flow.Flow

data class DefaultWatchlistResolution(
    val resolvedSymbols: List<String>,
    val unavailableNotes: List<String>
)

object DefaultWatchlistResolver {
    fun resolve(
        exchange: ExchangeId,
        marketType: MarketType,
        availableInstruments: List<InstrumentInfo>,
        desiredBases: List<String> = DefaultWatchlist.DEFAULT_BASES
    ): DefaultWatchlistResolution {
        val availableSet = availableInstruments.map { it.symbol.uppercase() }.toHashSet()
        val resolved = ArrayList<String>(desiredBases.size)
        val notes = ArrayList<String>()

        for (base in desiredBases.take(DefaultWatchlist.MAX_WATCHLIST_SIZE)) {
            val symbol = base.ensureUsdtSymbol()
            if (availableSet.contains(symbol)) {
                resolved.add(symbol)
            } else {
                val baseLabel = base.stripUsdtSuffix()
                notes.add("$baseLabel is not available on ${exchange.displayName} ${marketType.displayName} — slot left free to add another asset.")
            }
        }
        return DefaultWatchlistResolution(resolved, notes)
    }
}

sealed class WatchlistMutationResult {
    data object Success : WatchlistMutationResult()
    data class Error(val message: String) : WatchlistMutationResult()
}

class WatchlistRepository(
    private val watchlistDao: WatchlistDao,
    private val recycleBinDao: RecycleBinDao,
    private val candleStore: CandleStoreRepository,
    private val signalDao: SignalCandidateDao,
    private val syncProgressDao: SyncProgressDao
) {
    fun observeWatchlist(exchange: ExchangeId, marketType: MarketType): Flow<List<WatchlistEntity>> =
        watchlistDao.observeWatchlist(exchange.name, marketType.name)

    fun observeRecycleBin(exchange: ExchangeId, marketType: MarketType): Flow<List<RecycleBinEntity>> =
        recycleBinDao.observeBin(exchange.name, marketType.name)

    suspend fun getWatchlist(exchange: ExchangeId, marketType: MarketType): List<WatchlistEntity> =
        watchlistDao.getWatchlist(exchange.name, marketType.name)

    suspend fun initializeDefaultsIfEmpty(
        exchange: ExchangeId,
        marketType: MarketType,
        availableInstruments: List<InstrumentInfo>
    ): DefaultWatchlistResolution {
        val current = watchlistDao.getWatchlist(exchange.name, marketType.name)
        if (current.isNotEmpty()) {
            return DefaultWatchlistResolution(current.map { it.symbol }, emptyList())
        }
        val resolution = DefaultWatchlistResolver.resolve(exchange, marketType, availableInstruments)
        val now = System.currentTimeMillis()
        val entities = resolution.resolvedSymbols.mapIndexed { idx, sym ->
            WatchlistEntity(
                exchange = exchange.name,
                marketType = marketType.name,
                symbol = sym,
                displayOrder = idx,
                addedAtMs = now
            )
        }
        if (entities.isNotEmpty()) {
            watchlistDao.upsertAll(entities)
        }
        return resolution
    }

    suspend fun saveResolvedList(
        exchange: ExchangeId,
        marketType: MarketType,
        symbols: List<String>
    ) {
        val existing = watchlistDao.getWatchlist(exchange.name, marketType.name)
            .associateBy { it.symbol }
        val trimmed = symbols.map { it.ensureUsdtSymbol() }.distinct().take(DefaultWatchlist.MAX_WATCHLIST_SIZE)
        val now = System.currentTimeMillis()

        // Remove symbols no longer in trimmed
        for (old in existing.values) {
            if (!trimmed.contains(old.symbol)) {
                removeAsset(exchange, marketType, old.symbol)
            }
        }
        trimmed.forEachIndexed { idx, sym ->
            val prev = existing[sym]
            recycleBinDao.delete(exchange.name, marketType.name, sym)
            watchlistDao.upsert(
                prev?.copy(displayOrder = idx) ?: WatchlistEntity(
                    exchange = exchange.name,
                    marketType = marketType.name,
                    symbol = sym,
                    displayOrder = idx,
                    addedAtMs = now
                )
            )
        }
    }

    suspend fun addAsset(
        exchange: ExchangeId,
        marketType: MarketType,
        rawSymbol: String
    ): WatchlistMutationResult {
        val symbol = rawSymbol.ensureUsdtSymbol()
        val current = watchlistDao.getWatchlist(exchange.name, marketType.name)
        if (current.any { it.symbol == symbol }) {
            return WatchlistMutationResult.Error("${symbol.stripUsdtSuffix()} is already in the watchlist.")
        }
        if (current.size >= DefaultWatchlist.MAX_WATCHLIST_SIZE) {
            return WatchlistMutationResult.Error("Watchlist limit of ${DefaultWatchlist.MAX_WATCHLIST_SIZE} assets reached. Remove one first.")
        }
        // Remove from recycle bin if present (preserving its stored candles)
        recycleBinDao.delete(exchange.name, marketType.name, symbol)
        val nextOrder = (current.maxOfOrNull { it.displayOrder } ?: -1) + 1
        watchlistDao.upsert(
            WatchlistEntity(
                exchange = exchange.name,
                marketType = marketType.name,
                symbol = symbol,
                displayOrder = nextOrder,
                addedAtMs = System.currentTimeMillis()
            )
        )
        return WatchlistMutationResult.Success
    }

    suspend fun removeAsset(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String
    ) {
        val upper = symbol.ensureUsdtSymbol()
        watchlistDao.delete(exchange.name, marketType.name, upper)
        val now = System.currentTimeMillis()
        recycleBinDao.upsert(
            RecycleBinEntity(
                exchange = exchange.name,
                marketType = marketType.name,
                symbol = upper,
                removedAtMs = now
            )
        )
        enforceBinCapacity(exchange, marketType)
    }

    suspend fun restoreFromBin(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String
    ): WatchlistMutationResult {
        return addAsset(exchange, marketType, symbol)
    }

    suspend fun permanentlyDeleteFromBin(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String
    ) {
        val upper = symbol.ensureUsdtSymbol()
        recycleBinDao.delete(exchange.name, marketType.name, upper)
        candleStore.deleteAssetCandles(exchange, marketType, upper)
        signalDao.deleteForSymbol(exchange.name, marketType.name, upper)
        syncProgressDao.deleteForSymbol(exchange.name, marketType.name, upper)
    }

    private suspend fun enforceBinCapacity(exchange: ExchangeId, marketType: MarketType) {
        val bin = recycleBinDao.getBinOldestFirst(exchange.name, marketType.name)
        if (bin.size > DefaultWatchlist.MAX_RECYCLE_BIN_SIZE) {
            val overflow = bin.size - DefaultWatchlist.MAX_RECYCLE_BIN_SIZE
            for (i in 0 until overflow) {
                val oldest = bin[i]
                recycleBinDao.delete(exchange.name, marketType.name, oldest.symbol)
                candleStore.deleteAssetCandles(exchange, marketType, oldest.symbol)
                signalDao.deleteForSymbol(exchange.name, marketType.name, oldest.symbol)
                syncProgressDao.deleteForSymbol(exchange.name, marketType.name, oldest.symbol)
            }
        }
    }

    suspend fun setInPosition(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        inPosition: Boolean
    ) {
        watchlistDao.setInPosition(
            exchange = exchange.name,
            marketType = marketType.name,
            symbol = symbol.ensureUsdtSymbol(),
            inPosition = inPosition,
            updatedAtMs = System.currentTimeMillis()
        )
    }

    suspend fun setMuted(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        muted: Boolean
    ) {
        watchlistDao.setMuted(exchange.name, marketType.name, symbol.ensureUsdtSymbol(), muted)
    }

    suspend fun updateMarketSnapshot(
        exchange: ExchangeId,
        marketType: MarketType,
        symbol: String,
        lastPrice: Double?,
        change24hPct: Double?,
        lastCandleReceivedMs: Long?,
        activeDirection: String? = null,
        activeConfidence: Double? = null,
        updateActiveFields: Boolean = false
    ) {
        val existing = watchlistDao.getAsset(exchange.name, marketType.name, symbol) ?: return
        watchlistDao.upsert(
            existing.copy(
                lastPrice = lastPrice ?: existing.lastPrice,
                change24hPct = change24hPct ?: existing.change24hPct,
                lastCandleReceivedMs = lastCandleReceivedMs ?: existing.lastCandleReceivedMs,
                activeDirection = if (updateActiveFields) activeDirection else existing.activeDirection,
                activeConfidence = if (updateActiveFields) activeConfidence else existing.activeConfidence
            )
        )
    }
}
