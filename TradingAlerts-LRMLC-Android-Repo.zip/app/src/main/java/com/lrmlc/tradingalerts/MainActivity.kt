package com.lrmlc.tradingalerts

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.lrmlc.tradingalerts.service.NotificationHelper
import com.lrmlc.tradingalerts.ui.MainViewModel
import com.lrmlc.tradingalerts.ui.alerts.AlertsScreen
import com.lrmlc.tradingalerts.ui.chart.AssetChartScreen
import com.lrmlc.tradingalerts.ui.components.CompactBottomBar
import com.lrmlc.tradingalerts.ui.home.HomeScreen
import com.lrmlc.tradingalerts.ui.insights.InsightsScreen
import com.lrmlc.tradingalerts.ui.onboarding.OnboardingScreen
import com.lrmlc.tradingalerts.ui.settings.SettingsScreen
import com.lrmlc.tradingalerts.ui.theme.LrmlcTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        val app = application as TradingAlertsApp
        MainViewModel.Factory(app.container, applicationContext)
    }

    private var pendingDeepLink by mutableStateOf<Pair<String, String?>?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        captureDeepLink(intent)

        setContent {
            val settings by viewModel.settings.collectAsState()
            val settingsLoaded by viewModel.settingsLoaded.collectAsState()
            val watchlist by viewModel.watchlist.collectAsState()
            val recycleBin by viewModel.recycleBin.collectAsState()
            val activeModels by viewModel.activeModels.collectAsState()
            val recentSignals by viewModel.recentSignals.collectAsState()
            val activeTradeBySymbol by viewModel.activeTradeBySymbol.collectAsState()
            val lastAlertBySymbol by viewModel.lastAlertBySymbol.collectAsState()
            val exitCellRules by viewModel.exitCellRules.collectAsState()
            val assetPresetSelections by viewModel.assetPresetSelections.collectAsState()
            val hasUnreadAlerts by viewModel.hasUnreadAlerts.collectAsState()
            val needsRetrain by viewModel.needsRetrain.collectAsState()
            val trainingLogs by viewModel.trainingLogs.collectAsState()
            val downloadProgress by viewModel.downloadProgress.collectAsState()
            val trainingStatus by viewModel.trainingStatus.collectAsState()
            val serviceRunning by viewModel.serviceRunning.collectAsState()
            val formingCandles by viewModel.formingCandles.collectAsState()
            val connectionReport by viewModel.connectionReport.collectAsState()
            val masterStatus by viewModel.masterStatus.collectAsState()
            val connectionTesting by viewModel.connectionTesting.collectAsState()
            val availableInstruments by viewModel.availableInstruments.collectAsState()
            val defaultResolution by viewModel.defaultResolution.collectAsState()
            val storageSummary by viewModel.storageSummary.collectAsState()
            val bannerMessage by viewModel.uiBannerMessage.collectAsState()
            val isRefreshing by viewModel.isRefreshing.collectAsState()
            val chartState by viewModel.chartState.collectAsState()
            val importPreview by viewModel.importPreview.collectAsState()

            LrmlcTheme(darkTheme = settings.darkTheme, accentColor = settings.accentColor) {
                if (!settingsLoaded) {
                    // Blank themed surface while settings load (prevents the onboarding flash)
                    androidx.compose.foundation.layout.Box(
                        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
                    )
                } else if (!settings.onboardingCompleted) {
                    OnboardingScreen(
                        importPreview = importPreview,
                        onInspectImportUri = { viewModel.inspectImportUri(it) },
                        onConfirmImport = { viewModel.confirmImport() },
                        onDismissImportPreview = { viewModel.dismissImportPreview() },
                        settings = settings,
                        connectionReport = connectionReport,
                        isTestingConnection = connectionTesting,
                        defaultResolution = defaultResolution,
                        watchlistSymbols = watchlist.map { it.symbol },
                        downloadProgress = downloadProgress,
                        trainingStatus = trainingStatus,
                        onSelectExchange = { ex -> viewModel.updateSettings { it.copy(exchange = ex) } },
                        onSelectMarketType = { mt -> viewModel.updateSettings { it.copy(marketType = mt) } },
                        onRunConnectionTest = { viewModel.runConnectionTest() },
                        onLoadDefaults = { viewModel.loadInstrumentsAndResolveDefaults() },
                        onRemoveWatchlistSymbol = { sym -> viewModel.removeAsset(sym) },
                        onStartHistoryDownload = { viewModel.startInitialHistoryAndTraining() },
                        onPauseDownload = { viewModel.pauseHistoryDownload() },
                        onResumeDownload = { viewModel.resumeHistoryDownload() },
                        onCompleteOnboarding = { bg -> viewModel.completeOnboarding(bg) }
                    )
                } else {
                    val navController = rememberNavController()
                    val backStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = backStackEntry?.destination?.route

                    LaunchedEffect(pendingDeepLink) {
                        val link = pendingDeepLink
                        if (link != null && link.first.isNotBlank()) {
                            pendingDeepLink = null
                            val (sym, sigId) = link
                            viewModel.openChart(sym, sigId)
                            val route = if (!sigId.isNullOrBlank()) "chart/$sym?signalId=$sigId" else "chart/$sym"
                            navController.navigate(route) {
                                launchSingleTop = true
                            }
                        }
                    }

                    LaunchedEffect(currentRoute) {
                        if (currentRoute == "alerts") {
                            viewModel.markAlertsSeen()
                        }
                    }

                    val showBottomBar = currentRoute in setOf("home", "alerts", "insights", "settings")

                    Scaffold(
                        bottomBar = {
                            if (showBottomBar) {
                                CompactBottomBar(
                                    currentRoute = currentRoute,
                                    hasUnreadAlerts = hasUnreadAlerts,
                                    onNavigate = { route ->
                                        if (route != currentRoute) {
                                            navController.navigate(route) {
                                                popUpTo("home") { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    ) { scaffoldPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = "home",
                            modifier = Modifier.padding(scaffoldPadding),
                            enterTransition = { fadeIn(animationSpec = tween(180)) },
                            exitTransition = { fadeOut(animationSpec = tween(150)) }
                        ) {
                            composable("home") {
                                HomeScreen(
                                    settings = settings,
                                    watchlist = watchlist,
                                    formingCandles = formingCandles,
                                    activeModels = activeModels,
                                    activeTradeBySymbol = activeTradeBySymbol,
                                    lastAlertBySymbol = lastAlertBySymbol,
                                    recentSignals = recentSignals,
                                    downloadProgress = downloadProgress,
                                    trainingStatus = trainingStatus,
                                    serviceRunning = serviceRunning,
                                    isRefreshing = isRefreshing,
                                    availableInstruments = availableInstruments,
                                    bannerMessage = bannerMessage,
                                    onRefresh = { viewModel.refreshWatchlist() },
                                    onOpenChart = { sym ->
                                        viewModel.openChart(sym)
                                        navController.navigate("chart/$sym")
                                    },
                                    onToggleInPosition = { sym, inPos -> viewModel.setInPosition(sym, inPos) },
                                    onOpenAddSearch = { viewModel.fetchInstrumentsForSearch() },
                                    onAddAsset = { sym -> viewModel.addAsset(sym) },
                                    onDismissBanner = { viewModel.clearBannerMessage() }
                                )
                            }

                            composable("alerts") {
                                AlertsScreen(
                                    settings = settings,
                                    recentSignals = recentSignals,
                                    onOpenAlert = { sym, sigId ->
                                        viewModel.openChart(sym, sigId)
                                        navController.navigate("chart/$sym?signalId=$sigId") {
                                            launchSingleTop = true
                                        }
                                    }
                                )
                            }

                            composable(
                                route = "chart/{symbol}?signalId={signalId}",
                                arguments = listOf(
                                    navArgument("symbol") { type = NavType.StringType },
                                    navArgument("signalId") {
                                        type = NavType.StringType
                                        nullable = true
                                        defaultValue = null
                                    }
                                )
                            ) { entry ->
                                val sym = entry.arguments?.getString("symbol").orEmpty()
                                val item = watchlist.firstOrNull { it.symbol == sym }
                                AssetChartScreen(
                                    chartState = chartState,
                                    watchlistItem = item,
                                    formingCandle = formingCandles[sym],
                                    settings = settings,
                                    onBack = { navController.popBackStack() },
                                    onToggleInPosition = { inPos -> viewModel.setInPosition(sym, inPos) },
                                    onToggleMute = { muted -> viewModel.setMuted(sym, muted) },
                                    onUpdateManualSlTp = { sigId, sl, tp -> viewModel.updateManualSlTp(sigId, sl, tp) },
                                    onResetDefaultSlTp = { sigId -> viewModel.resetSlTpToDefault(sigId) }
                                )
                            }

                            composable("insights") {
                                InsightsScreen(
                                    settings = settings,
                                    activeModels = activeModels,
                                    recentSignals = recentSignals,
                                    trainingLogs = trainingLogs,
                                    exitCellRules = exitCellRules,
                                    assetPresetSelections = assetPresetSelections,
                                    needsRetrain = needsRetrain,
                                    trainingStatus = trainingStatus,
                                    onBuildSingleReport = { id -> viewModel.buildTrainingReport(id) },
                                    onBuildRangeReport = { hrs -> viewModel.buildRangeReport(hrs) },
                                    onTrainNow = { viewModel.triggerTraining() }
                                )
                            }

                            composable("settings") {
                                SettingsScreen(
                                    settings = settings,
                                    connectionReport = connectionReport,
                                    isTestingConnection = connectionTesting,
                                    trainingStatus = trainingStatus,
                                    watchlist = watchlist,
                                    recycleBin = recycleBin,
                                    storageSummary = storageSummary,
                                    importPreview = importPreview,
                                    exitCellRules = exitCellRules,
                                    onUpdateSettings = { viewModel.updateSettings(it) },
                                    masterStatus = masterStatus,
                                    onChangeMasterAsset = { viewModel.changeMasterAsset(it) },
                                    onRunConnectionTest = { viewModel.runConnectionTest() },
                                    onTrainNow = { viewModel.triggerTraining() },
                                    onPauseTraining = { viewModel.pauseTraining() },
                                    onResumeTraining = { viewModel.resumeTraining() },
                                    onRemoveWatchlistAsset = { sym -> viewModel.removeAsset(sym) },
                                    onRestoreBinAsset = { sym -> viewModel.restoreFromBin(sym) },
                                    onDeleteBinAsset = { sym -> viewModel.permanentlyDeleteFromBin(sym) },
                                    onRefreshStorage = { viewModel.refreshStorageSummary() },
                                    onClearAssetStorage = { sym -> viewModel.clearAssetStorage(sym) },
                                    onExportBackup = { uri, inc -> viewModel.exportBackup(uri, inc) },
                                    onInspectImportUri = { uri -> viewModel.inspectImportUri(uri) },
                                    onConfirmImport = { viewModel.confirmImport() },
                                    onDismissImportPreview = { viewModel.dismissImportPreview() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureDeepLink(intent)
    }

    private fun captureDeepLink(intent: Intent?) {
        val sym = intent?.getStringExtra(NotificationHelper.EXTRA_OPEN_SYMBOL)
        if (!sym.isNullOrBlank()) {
            val sigId = intent.getStringExtra(NotificationHelper.EXTRA_OPEN_SIGNAL_ID)
            pendingDeepLink = sym to sigId
        }
    }
}
