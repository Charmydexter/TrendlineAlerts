package com.lrmlc.tradingalerts

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.lrmlc.tradingalerts.service.NotificationHelper
import com.lrmlc.tradingalerts.ui.MainViewModel
import com.lrmlc.tradingalerts.ui.chart.AssetChartScreen
import com.lrmlc.tradingalerts.ui.home.HomeScreen
import com.lrmlc.tradingalerts.ui.insights.InsightsScreen
import com.lrmlc.tradingalerts.ui.onboarding.OnboardingScreen
import com.lrmlc.tradingalerts.ui.settings.SettingsScreen
import com.lrmlc.tradingalerts.ui.theme.LrmlcTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        val app = application as TradingAlertsApp
        MainViewModel.Factory(app.container, applicationContext)
    }

    private var pendingDeepLinkSymbol by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingDeepLinkSymbol = intent?.getStringExtra(NotificationHelper.EXTRA_OPEN_SYMBOL)

        setContent {
            val settings by viewModel.settings.collectAsState()
            val watchlist by viewModel.watchlist.collectAsState()
            val recycleBin by viewModel.recycleBin.collectAsState()
            val activeModels by viewModel.activeModels.collectAsState()
            val recentSignals by viewModel.recentSignals.collectAsState()
            val trainingLogs by viewModel.trainingLogs.collectAsState()
            val downloadProgress by viewModel.downloadProgress.collectAsState()
            val trainingStatus by viewModel.trainingStatus.collectAsState()
            val serviceRunning by viewModel.serviceRunning.collectAsState()
            val formingCandles by viewModel.formingCandles.collectAsState()
            val connectionReport by viewModel.connectionReport.collectAsState()
            val connectionTesting by viewModel.connectionTesting.collectAsState()
            val availableInstruments by viewModel.availableInstruments.collectAsState()
            val defaultResolution by viewModel.defaultResolution.collectAsState()
            val storageSummary by viewModel.storageSummary.collectAsState()
            val bannerMessage by viewModel.uiBannerMessage.collectAsState()
            val isRefreshing by viewModel.isRefreshing.collectAsState()
            val chartState by viewModel.chartState.collectAsState()
            val importPreview by viewModel.importPreview.collectAsState()

            LrmlcTheme(darkTheme = settings.darkTheme) {
                if (!settings.onboardingCompleted) {
                    OnboardingScreen(
                        settings = settings,
                        connectionReport = connectionReport,
                        isTestingConnection = connectionTesting,
                        defaultResolution = defaultResolution,
                        watchlistSymbols = watchlist.map { it.symbol },
                        downloadProgress = downloadProgress,
                        trainingStatus = trainingStatus,
                        onSelectExchange = { ex -> viewModel.updateSettings { it.copy(exchange = ex) } },
                        onSelectMarketType = { mt -> viewModel.updateSettings { it.copy(marketType = mt) } },
                        onRunConnectionTest = { viewModel.runConnectionTest() },
                        onLoadDefaults = { viewModel.loadInstrumentsAndResolveDefaults() },
                        onRemoveWatchlistSymbol = { sym -> viewModel.removeAsset(sym) },
                        onStartHistoryDownload = { viewModel.startInitialHistoryAndTraining() },
                        onPauseDownload = { viewModel.pauseHistoryDownload() },
                        onResumeDownload = { viewModel.resumeHistoryDownload() },
                        onCompleteOnboarding = { bg -> viewModel.completeOnboarding(bg) }
                    )
                } else {
                    val navController = rememberNavController()
                    val backStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = backStackEntry?.destination?.route

                    LaunchedEffect(pendingDeepLinkSymbol) {
                        val target = pendingDeepLinkSymbol
                        if (!target.isNullOrBlank()) {
                            pendingDeepLinkSymbol = null
                            viewModel.openChart(target)
                            navController.navigate("chart/$target") {
                                launchSingleTop = true
                            }
                        }
                    }

                    val showBottomBar = currentRoute in setOf("home", "insights", "settings")

                    Scaffold(
                        bottomBar = {
                            if (showBottomBar) {
                                NavigationBar {
                                    NavigationBarItem(
                                        selected = currentRoute == "home",
                                        onClick = { navController.navigate("home") { launchSingleTop = true } },
                                        icon = { Icon(Icons.Default.Home, contentDescription = "Watchlist") },
                                        label = { Text("Watchlist") }
                                    )
                                    NavigationBarItem(
                                        selected = currentRoute == "insights",
                                        onClick = { navController.navigate("insights") { launchSingleTop = true } },
                                        icon = { Icon(Icons.Default.Analytics, contentDescription = "Insights") },
                                        label = { Text("Insights") }
                                    )
                                    NavigationBarItem(
                                        selected = currentRoute == "settings",
                                        onClick = { navController.navigate("settings") { launchSingleTop = true } },
                                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                        label = { Text("Settings") }
                                    )
                                }
                            }
                        }
                    ) { scaffoldPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = "home",
                            modifier = Modifier.padding(scaffoldPadding)
                        ) {
                            composable("home") {
                                HomeScreen(
                                    settings = settings,
                                    watchlist = watchlist,
                                    formingCandles = formingCandles,
                                    activeModels = activeModels,
                                    downloadProgress = downloadProgress,
                                    trainingStatus = trainingStatus,
                                    serviceRunning = serviceRunning,
                                    isRefreshing = isRefreshing,
                                    availableInstruments = availableInstruments,
                                    bannerMessage = bannerMessage,
                                    onRefresh = { viewModel.refreshWatchlist() },
                                    onOpenChart = { sym ->
                                        viewModel.openChart(sym)
                                        navController.navigate("chart/$sym")
                                    },
                                    onToggleInPosition = { sym, inPos -> viewModel.setInPosition(sym, inPos) },
                                    onOpenAddSearch = { viewModel.fetchInstrumentsForSearch() },
                                    onAddAsset = { sym -> viewModel.addAsset(sym) },
                                    onDismissBanner = { viewModel.clearBannerMessage() }
                                )
                            }

                            composable(
                                route = "chart/{symbol}",
                                arguments = listOf(navArgument("symbol") { type = NavType.StringType })
                            ) { entry ->
                                val sym = entry.arguments?.getString("symbol").orEmpty()
                                val item = watchlist.firstOrNull { it.symbol == sym }
                                AssetChartScreen(
                                    chartState = chartState,
                                    watchlistItem = item,
                                    formingCandle = formingCandles[sym],
                                    settings = settings,
                                    onBack = { navController.popBackStack() },
                                    onToggleInPosition = { inPos -> viewModel.setInPosition(sym, inPos) },
                                    onToggleMute = { muted -> viewModel.setMuted(sym, muted) },
                                    onUpdateManualSlTp = { sigId, sl, tp -> viewModel.updateManualSlTp(sigId, sl, tp) },
                                    onResetDefaultSlTp = { sigId -> viewModel.resetSlTpToDefault(sigId) }
                                )
                            }

                            composable("insights") {
                                InsightsScreen(
                                    settings = settings,
                                    activeModels = activeModels,
                                    recentSignals = recentSignals,
                                    trainingLogs = trainingLogs
                                )
                            }

                            composable("settings") {
                                SettingsScreen(
                                    settings = settings,
                                    connectionReport = connectionReport,
                                    isTestingConnection = connectionTesting,
                                    trainingStatus = trainingStatus,
                                    watchlist = watchlist,
                                    recycleBin = recycleBin,
                                    storageSummary = storageSummary,
                                    importPreview = importPreview,
                                    onUpdateSettings = { viewModel.updateSettings(it) },
                                    onRunConnectionTest = { viewModel.runConnectionTest() },
                                    onTrainNow = { viewModel.triggerTraining() },
                                    onPauseTraining = { viewModel.pauseTraining() },
                                    onResumeTraining = { viewModel.resumeTraining() },
                                    onRemoveWatchlistAsset = { sym -> viewModel.removeAsset(sym) },
                                    onRestoreBinAsset = { sym -> viewModel.restoreFromBin(sym) },
                                    onDeleteBinAsset = { sym -> viewModel.permanentlyDeleteFromBin(sym) },
                                    onRefreshStorage = { viewModel.refreshStorageSummary() },
                                    onClearAssetStorage = { sym -> viewModel.clearAssetStorage(sym) },
                                    onExportBackup = { uri, inc -> viewModel.exportBackup(uri, inc) },
                                    onInspectImportUri = { uri -> viewModel.inspectImportUri(uri) },
                                    onConfirmImport = { viewModel.confirmImport() },
                                    onDismissImportPreview = { viewModel.dismissImportPreview() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingDeepLinkSymbol = intent.getStringExtra(NotificationHelper.EXTRA_OPEN_SYMBOL)
    }
}
