-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keep class com.lrmlc.tradingalerts.data.remote.** { *; }
-keep class com.lrmlc.tradingalerts.ml.** { *; }
-keep class com.lrmlc.tradingalerts.backup.** { *; }

# kotlinx.serialization
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault
-keepclassmembers class * {
    @kotlinx.serialization.Serializable <fields>;
}
-keepclassmembers class * {
    @kotlinx.serialization.SerialName <fields>;
}
-dontwarn kotlinx.serialization.**
