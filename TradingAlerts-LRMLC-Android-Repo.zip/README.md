# Trading Alerts (LRMLC)

**Trading Alerts (LRMLC)** (*Logistic Regression Machine Learning and Confluence*) is a native Android Kotlin application for **1-minute cryptocurrency scalping** alerts. It monitors a 20-asset watchlist using public, read-only Bybit or Binance market data, evaluates an exact bar-by-bar port of the Triple Confluence Pine Script ruleset, and filters/manages setups with an **on-device logistic regression model** trained exclusively on raw OHLCV and structural confluence geometry.

> **Disclaimer:** Informational alerts and statistical modeling only. Never asks for API keys, never places orders, and collects zero telemetry.

---

## Architecture & Modules (`com.lrmlc.tradingalerts`)

- **`data`**:
  - `ExchangeAdapter` (`BybitAdapter`, `BinanceAdapter`) normalizing public Spot & USDT Linear Perpetual 1-minute klines, instrument lists, 24h tickers, and WebSocket kline streams.
  - `RestRateLimiterQueue`: sequential single-request REST queue (>= 350 ms spacing, honors `Retry-After`, `X-Bapi-Limit-*`, `X-MBX-USED-WEIGHT-*`, pauses whole queue on 429/418/403 with exponential backoff + jitter).
  - `WebSocketFeedClient`: single multi-symbol WebSocket connection inside the foreground service with exponential backoff + jitter and exchange-specific ping rules.
  - `DayChunkCodec` & `CandleStoreRepository`: compact UTC-day binary blobs in Room (up to 1440 bars/day/blob) with `GapDetector` and configurable 42–90 day retention.
  - `WatchlistRepository`: 20-asset hard limit, default 20-asset resolver against live exchange instruments, and 10-slot recycle bin preserving candles until evicted.
- **`engine`**:
  - `ConfluenceEngine`: faithful bar-by-bar Kotlin port of the attached Pine Script v6 (`winLen = 240`, `minGap = 30`, `capital = $20`, `maxLoss = $0.50`, `takeProfit = $0.50`, confirmed-peak resistance/support persistence, OHLC4 SMA basis, dollar risk filter, and arming/disarming gate).
- **`ml`**:
  - `FeatureBuilder` & `FeatureSpec`: 71 features derived purely from raw OHLCV and engine structure (line geometry, structure distances, gate history, volume-since-birth dynamics, price behavior, cyclical UTC context).
  - `TripleBarrierLabeler`: forward walk over horizon N (default 60 bars) with conservative same-bar SL-first priority, fee-adjusted timeout labeling, and MAE/MFE tracking.
  - `LogisticRegressionTrainer`: pure Kotlin L2-regularized logistic regression with Adam optimizer, standardization, class balancing, overlap sample weighting, hierarchical per-asset regularization toward global weights, and batch-level checkpoints.
  - `WalkForwardValidator`: purged & embargoed walk-forward cross-validation, net-expectancy threshold optimization (never below break-even), calibration reliability buckets, and out-of-sample promotion rule.
  - `TrainingOrchestrator` & `TrainingWorker`: persistent resumable Room job queue executed by WorkManager on `Dispatchers.Default` (initial 4-week fit + daily, 3-day, weekly schedules).
  - `ExitWarningModel`: second logistic regression predicting bar-by-bar `P(reversal)` during open positions.
  - `ModelExplainer`: translates weights, top-3 per-signal drivers, calibration buckets, and MAE/MFE stats into plain English.
- **`trade`**:
  - `SlTpManager`: Auto-SL (80th percentile winning MAE clamped within max-loss limit and structural side) and Auto-TP (median winning MFE >= minimum TP), with manual override support.
  - `TradeLifecycleManager` & `ExitWarningEvaluator`: shadow-trade tracking (preventing selection bias), active trade lifecycle, and re-arming exit warnings.
- **`service`**:
  - `MonitoringForegroundService` (`specialUse` foreground service type), `BootReceiver`, `NotificationHelper`, and `PersistentNotificationFormatter` (newest positioned alert at top with TP/SL, older open positions comma-separated without `USDT`).
- **`backup`**:
  - `BackupManager`: Android Storage Access Framework (SAF) export/import to versioned gzipped JSON with schema validation, import preview, and safe transactional merge.
- **`ui`**:
  - Jetpack Compose Material 3 UI (`#212121` charcoal dark theme default + light theme), custom Compose Canvas Heikin Ashi / Candlestick chart with pinch-zoom, pan, crosshair, extended trendlines, basis, SL/TP lines, and signal markers.

---

## How the On-Device ML Model Works (Plain Language)

1. **Confluence Generates Candidates:** On every closed 1-minute bar, the rule-based engine checks whether price broke cleanly above/below the falling resistance, rising support, and 4-hour rolling average while passing the dollar-risk filter and arming gate.
2. **Shadow Trades Prevent Blind Spots:** Every candidate—even ones the model rejects—is tracked forward for up to 60 minutes to see whether Take Profit or Stop Loss hit first. This prevents selection bias.
3. **Resumable Learning:** A pure-Kotlin logistic regression learns which structural and volume-since-birth patterns separate winners from losers, validated strictly on purged future walk-forward splits (never random splits).
4. **Adaptive Protection:** A second logistic regression monitors active trades bar-by-bar for reversal risk, while winning trade excursions (MAE/MFE) fine-tune SL and TP within your dollar-risk limit.

---

## Building the APK Locally

### Prerequisites
- **JDK 17**
- **Android SDK** with **Platform 35** and **Build-Tools 35.0.0**
- **Gradle 8.9** (or the included `./gradlew` wrapper)

### Commands
```bash
# 1. Run Android Lint
./gradlew lintDebug

# 2. Run all unit & integration tests
./gradlew testDebugUnitTest

# 3. Build the Debug APK
./gradlew assembleDebug
```
The debug APK is written to:
`app/build/outputs/apk/debug/app-debug.apk`
