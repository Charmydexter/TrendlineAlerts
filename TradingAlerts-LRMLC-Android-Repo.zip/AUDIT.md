# Security, Correctness & Architecture Audit — Trading Alerts (LRMLC)

## 1. Security Audit
- **Zero Secrets / Zero API Keys:** Verified across all modules (`data`, `engine`, `ml`, `trade`, `service`, `backup`, `ui`) that no exchange API keys, private tokens, or credentials exist anywhere in code, resources, or `BuildConfig`. Only public, read-only market data endpoints are called.
- **Input Validation & Malformed Payload Resilience:**
  - `BybitAdapter` and `BinanceAdapter` validate JSON trees safely using `kotlinx.serialization.json` with `contentOrNull` / `longOrNull` / `doubleOrNull` and `isFinite()` guards before constructing `Candle` instances. Malformed REST or WebSocket frames return empty lists or typed `ExchangeApiException` instead of throwing uncaught exceptions.
  - `BackupManager.parseAndValidate` checks the `"LRMLC_BACKUP"` magic header, enforces schema version bounds (`1..CURRENT_SCHEMA_VERSION`), bounds GZIP decompression to 128 MB to prevent zip-bomb memory exhaustion, and validates Base64 candle chunk payloads before touching Room.
- **Exported Components & Manifest Hardening:**
  - `android:allowBackup="false"` and `data_extraction_rules.xml` prevent unintended OS cloud backups of local trading databases.
  - `MonitoringForegroundService` is `android:exported="false"` and uses `foregroundServiceType="specialUse"` with the required `PROPERTY_SPECIAL_USE_FGS_SUBTYPE` manifest property.
  - `androidx.work.impl.foreground.SystemForegroundService` merges `foregroundServiceType="dataSync"` alongside explicit `FOREGROUND_SERVICE_DATA_SYNC` manifest permission (Android 14+ runtime safety verified by Android Lint).
  - `BootReceiver` is `android:exported="true"` solely for `BOOT_COMPLETED` / `MY_PACKAGE_REPLACED` and explicitly checks `intent?.action` before starting monitoring (and only if the user enabled both `keepMonitoringInBackground` and `startOnBoot`).
  - PendingIntents use `PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE`.
- **Dependency Review:** Uses official Google/JetBrains/Square artifacts via Gradle Version Catalog (`libs.versions.toml`): AndroidX Core/Lifecycle/Compose BOM/Room/DataStore/WorkManager, OkHttp 4.12.0, Kotlinx Serialization 1.7.3, Coroutines 1.9.0. Zero third-party ML or charting WebView dependencies.

## 2. Confluence Engine Correctness Audit (vs. Pine Script v6)
Verified line-by-line against `triple_confluence_signals_7eafed7b.txt`:
- **Rolling Window & Confirmed Peaks/Troughs:**
  - `hi1` iterates `i = 0 until winLen` (`0` = current bar) with strict `>` (`h > h1`), preserving the most recent bar on equal highs.
  - `hi2` iterates `i = 1..(hi1 - minGap)` (only if `hi1 - minGap >= 1`), excluding bar `0` and requiring `high[i] > high[i - 1]` (confirmed peak) and `high[i] > h2`.
  - Support mirrors with `<`. Because `hi1` keeps the most recent max, `hi2 < hi1` always has strictly lower high (`rY2 < rY1`), ensuring resistance always slopes downward and support always slopes upward.
  - Line persistence: when `hi2 < 0` or `li2 < 0`, the previous anchor pair and `birthBar` remain unchanged.
- **Basis & Signal Gate:**
  - `basis` computes the exact `winLen`-bar SMA of `(O+H+L+C)/4`.
  - `slDist = maxLossUsd * close / capitalUsd`, `tpDist = takeProfitUsd * close / capitalUsd`.
  - `longOk = (close - slDist) < loLine`, `shortOk = (close + slDist) > hiLine`.
  - `longFire = rawLong && longArmed && longOk`, `shortFire = rawShort && shortArmed && shortOk` evaluated strictly on closed 1-minute bars.
  - Gate state transitions match Pine Script lines 118–125: firing disarms that side; raw opposite condition re-arms even if blocked by the risk filter; risk-blocked signals never disarm their own side.

## 3. Performance, Memory & Battery Audit
- **Off-Main-Thread Execution:** All Room I/O, DayChunk binary encoding/decoding, SAF backup streams, `HistorySyncManager` sync/gap-fill loops, `ConnectionTester` diagnostics, and `RestRateLimiterQueue.get()` synchronous OkHttp calls execute strictly on `Dispatchers.IO` (preventing `NetworkOnMainThreadException` when initiated from `viewModelScope`); Confluence evaluation, 71-feature extraction, and Logistic Regression training run on `Dispatchers.Default` or WorkManager background workers.
- **Compact Storage:** `DayChunkCodec` packs 1-minute candles into 42-byte records inside UTC-day blobs (~60 KB/day/asset instead of ~1,440 Room rows/day), keeping SQLite indices tiny and gap detection fast via `getDayCounts`.
- **Single WebSocket & Closed-Bar Processing:** One OkHttp WebSocket subscription handles all 20 watchlist symbols. Heavy signal/ML evaluation only runs when `isClosed` (`confirm` / `x`) is true. Forming candle updates only update the lightweight `LiveFormingCandleHub` flow for an open chart.

## 4. Data Integrity & Resumable Checkpointing Audit
- **Atomic Model Swaps:** `MlModelDao.atomicSwapActive` runs inside a Room `@Transaction`, deactivating the previous key and inserting the newly validated model only after `WalkForwardValidator.shouldPromote` approves it.
- **Resumable Sync & Training:**
  - `HistorySyncManager` persists `SyncProgressEntity` after every 1000-candle page.
  - `TrainingOrchestrator` persists `TrainingJobEntity` with epoch, batch index, PRNG seed, shuffled permutation order, weights, and Adam `m`/`v`/`step` moments.
- **Finding Fixed During Audit:** In `TrainingOrchestrator.runNextOrSpecificJob`, `existingIds` was initially built from `allHistoricalCandidates` instead of `allExistingInDb`, which would have skipped persisting initial historical shadow signals into Room. Fixed to query `allExistingInDb` before filtering `newLoggedEntities`.
- **Safe Import:** `BackupManager.applyImport` runs inside `db.withTransaction` and validates headers, schema version, decompressed size, and Base64 chunks before mutating any state.

## 5. Rate-Limit Safety Audit
- `RestRateLimiterQueue` serializes all REST calls through a single `Mutex` with >= 350 ms inter-request spacing.
- Inspects `Retry-After`, `X-Bapi-Limit-Status`, `X-Bapi-Limit-Reset-Timestamp`, and `X-MBX-USED-WEIGHT-1M`.
- Pauses the entire queue with exponential backoff + jitter on HTTP 429, 418, and 403, and fails fast without retry loops on HTTP 451 region blocks or HTTP 400/404 invalid symbols.
