# Changelog

## [1.0.0] - 2026-11-26
### Added
- Initial production release of **Trading Alerts (LRMLC)** (`com.lrmlc.tradingalerts`).
- Bybit v5 and Binance Spot/Perpetual public REST & WebSocket adapters with sequential rate-limited queue and 4-step connection tester.
- Compact UTC-day binary candle chunk storage in Room, automatic gap detection, 42–90 day retention, 20-asset watchlist, and 10-slot recycle bin.
- Deterministic Kotlin port of the Triple Confluence Pine Script v6 ruleset.
- On-device pure-Kotlin L2 logistic regression with 71 OHLCV/structural/volume-since-birth features, triple-barrier labeling, purged walk-forward validation, shadow trade tracking, hierarchical per-asset models, exit-reversal model, and checkpointed resumable WorkManager training.
- Learned Auto-SL / Auto-TP management, `specialUse` foreground monitoring service, persistent active-position notification, high-importance signal & exit alerts, and deep-linked custom Compose Canvas Heikin Ashi / candlestick charts.
- SAF versioned gzipped backup export/import with schema validation and preview.
- Comprehensive unit and end-to-end integration test suite plus GitHub Actions CI workflow.
