## Unreleased - Fix: backup export with 1m candles
- Export now streams candles one day-chunk at a time (no more whole-store-in-memory), fixing the 0-byte file when "Include stored 1m candles" was on. Same file format, existing imports still work.
- The switch is saved in settings (`backupIncludeCandles`), is ON by default, and no longer resets when leaving the page.
- A failed export shows the error and removes the empty file it created.

## Unreleased - Job 3: marker when a trade is likely to run far past its TP
- Training replays TP-reaching trades past TP until price returns to entry, the stop is touched, or twice the normal trade length passes; records the peak (in TP distances), candles to peak and where it ended. "Ran far" = peak >= 1.5 x TP distance. The main alert model still counts a TP touch as a win.
- Job 2 beyond-TP situations now fill with data (exit labels use the replay end).
- New run-on model (key RUNON_<exchange>_<market>) on the Job 2 moment features + alert confidence, TP distance, reward-to-risk, momentum, volume trend. Per situation (20), shown only if right >= 65%, >= 10 pts above that situation's normal rate, >= 30 unseen test cases; otherwise nothing.
- Live: chance computed at each closed candle; marker on above the situation's level, kept until 5 points below it; chance and marker saved with the trade (DB migration 4->5, included in backups).
- UI: blast emoji (plus sign if the phone cannot draw it) next to TP on Home and chart, tick when reached; trade card line "Model expects a run past TP (N% sure, reliable at this stage)"; Settings switch "Notify: possible run past TP" (off by default); Insights "Run-on markers: N shown, M% went at least half a TP further" + 5x4 grid.

## Unreleased - Job 4: more to learn from (keep only what helps)
- New feature groups: market context (Master asset, BTC default; neutral for the Master itself), volatility mood, bigger-picture view (5m/15m candles, RSI), and optional futures (funding, open-interest change, perp only).
- Each group is proven per range setting on unseen data (cautious lower-bound expectancy, must gain >= 0.03 pts/trade) and dropped otherwise; enabled groups are stored with the model and shown in Insights and the training report.
- Recency weighting (half-life 14/7/28 days or none, scored on unseen data; 14 days when nothing can be scored), time-limited search over overfitting strength and passes with fallback to current settings.
- Per-period (3 test periods) results; Insights flags "unstable" when positive in fewer than two.
- Real closed trades are extra examples at double weight (count reported). Setups over more than 2 missing candles in a row are skipped (count reported).
- Settings: "Market context (Master asset)" box (one Master). Backend keeps up to 5 master datasets; a replaced Master is phased out over 14 days, oldest days first; if full and the new Master is not stored, the longest-retired slot is deleted. Master history is downloaded quietly even when not on the watchlist.

## Unreleased - Job 2: exit warnings that learn when to warn
- 20 situations (5 age ranges x 4 positions incl. beyond TP); progress counts past TP, capped at 3.
- New exit feature layout (25 features); old exit models/rules/state wiped by DB migration 3->4. No exit warnings until the first training run finishes ("Exit warnings: learning").
- Per-situation levels 55-90%, unseen-trade test, 30-warning minimum; beyond-TP label rule; every candle replayed to learn "N candles in a row" (1-3).
- No fixed warning cap/wait: re-warn only after the condition is gone N candles or in a different proven situation.
- Notification text with age, return and position; Insights 5x4 grid; report line; Settings "Learned: ..." line. Backups keep only complete 20-situation rule sets.

## Unreleased - Job 1: trades stay open at TP/SL
- Settings: new "Trade handling" (Auto-close on TP: off by default, Auto-close on SL: on by default).
- Trades touching TP/SL with auto-close off stay ACTIVE, marked "TP reached"/"SL reached"; run beyond TP is tracked (maxBeyondTpPct). One "still open" notification per touch.
- Shadow trades still end at TP/SL. Opposite signal still closes older trade.
- Manual close now stores exit price, time, net result and win/loss label.
- UI: tick after TP on Home and chart label, chart card line, "Active - TP reached" in Alerts. Backup carries the new fields. DB migration 2->3.

# Changelog

## [1.0.0] - 2026-11-26
### Added
- Initial production release of **Trading Alerts (LRMLC)** (`com.lrmlc.tradingalerts`).
- Bybit v5 and Binance Spot/Perpetual public REST & WebSocket adapters with sequential rate-limited queue and 4-step connection tester.
- Compact UTC-day binary candle chunk storage in Room, automatic gap detection, 42–90 day retention, 20-asset watchlist, and 10-slot recycle bin.
- Deterministic Kotlin port of the Triple Confluence Pine Script v6 ruleset.
- On-device pure-Kotlin L2 logistic regression with 71 OHLCV/structural/volume-since-birth features, triple-barrier labeling, purged walk-forward validation, shadow trade tracking, hierarchical per-asset models, exit-reversal model, and checkpointed resumable WorkManager training.
- Learned Auto-SL / Auto-TP management, `specialUse` foreground monitoring service, persistent active-position notification, high-importance signal & exit alerts, and deep-linked custom Compose Canvas Heikin Ashi / candlestick charts.
- SAF versioned gzipped backup export/import with schema validation and preview.
- Comprehensive unit and end-to-end integration test suite plus GitHub Actions CI workflow.

### Fixed
- Enforced `Dispatchers.IO` inside `RestRateLimiterQueue`, `ConnectionTester`, `HistorySyncManager`, and `MainViewModel` REST/backup paths to eliminate `NetworkOnMainThreadException` during exchange connection tests and market syncs on Android devices.
- Increased mobile OkHttp and WebSocket test timeouts for slower 3G networks and surfaced exception class names when error messages are empty.
