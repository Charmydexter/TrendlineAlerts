package com.trendlinealerts.core.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/** Long (supports) or Short (resistances) tracker for GENERAL assets. */
@Serializable
data class SideTracker(
    /** pivotKey of every line that already fired since the last reset. */
    val firedKeys: Set<String> = emptySet(),
    /** The line that fired last (kept even if that line is later replaced). */
    val lastFired: LineRef? = null,
    /** True once a bar closed with its whole body beyond lastFired without touching the next line. */
    val armed: Boolean = false
)

/** Everything the signal logic must remember for one symbol. Persisted between runs. */
@Serializable
data class SymbolSignalState(
    val symbol: String,
    val mode: AssetMode = AssetMode.GENERAL,
    /** Open time of the last 1m bar that was processed. */
    val lastProcessedOpenMs: Long = 0L,
    /** pivotKey of the line currently in each slot ("" = no line). Used for the swap gap. */
    val slotKeys: Map<String, String> = emptyMap(),
    val longTracker: SideTracker = SideTracker(),
    val shortTracker: SideTracker = SideTracker(),
    /** Positioned assets: side of the last cross alert (only the opposite side re-arms). */
    val lastCrossSide: TrendlineSide? = null,
    val lastEntryDirection: EntryDirection? = null,
    val r1Key: String? = null,
    val s1Key: String? = null
)

object SignalStateCodec {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun encode(state: SymbolSignalState): String = json.encodeToString(SymbolSignalState.serializer(), state)

    fun decode(raw: String?, symbol: String): SymbolSignalState {
        if (raw.isNullOrBlank()) return SymbolSignalState(symbol)
        return runCatching { json.decodeFromString(SymbolSignalState.serializer(), raw) }
            .getOrElse { SymbolSignalState(symbol) }
    }
}
