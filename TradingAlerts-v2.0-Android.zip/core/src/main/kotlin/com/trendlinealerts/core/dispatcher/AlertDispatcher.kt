package com.trendlinealerts.core.dispatcher

import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide

data class DispatcherPersistedState(
    val lastAlertSymbol: String? = null,
    val lastAlertTimeMs: Long = 0L,
    val lastAlertSide: TrendlineSide? = null
)

data class DispatchResult(
    val emittedCross: TrendlineCandidate?,
    val updatedState: DispatcherPersistedState
)

class AlertDispatcher(
    initialState: DispatcherPersistedState = DispatcherPersistedState()
) {
    companion object {
        const val GLOBAL_COOLDOWN_MS = 60_000L
    }

    var state: DispatcherPersistedState = initialState
        private set

    fun updateState(newState: DispatcherPersistedState) {
        state = newState
    }

    /**
     * Rule A: At least 60 seconds must elapse since the last cross alert.
     * Rule B:
     *   - When generalMonitoringOn == true: locked symbol cannot alert again until another symbol alerts.
     *   - When generalMonitoringOn == false (Priority Override mode):
     *       different symbols reset each other, AND the same symbol can reset itself when the
     *       opposite trendline side alerts (SUPPORT <-> RESISTANCE).
     */
    fun processCycle(
        candidates: List<TrendlineCandidate>,
        generalMonitoringOn: Boolean,
        nowMs: Long
    ): DispatchResult {
        if (candidates.isEmpty()) {
            return DispatchResult(emittedCross = null, updatedState = state)
        }

        if (state.lastAlertTimeMs > 0L && (nowMs - state.lastAlertTimeMs) < GLOBAL_COOLDOWN_MS) {
            return DispatchResult(emittedCross = null, updatedState = state)
        }

        val eligible = candidates.firstOrNull { candidate ->
            val sameSymbol = candidate.symbol == state.lastAlertSymbol
            if (!sameSymbol) {
                true
            } else if (!generalMonitoringOn) {
                state.lastAlertSide == null || candidate.side != state.lastAlertSide
            } else {
                false
            }
        }

        if (eligible == null) {
            return DispatchResult(emittedCross = null, updatedState = state)
        }

        val updated = DispatcherPersistedState(
            lastAlertSymbol = eligible.symbol,
            lastAlertTimeMs = nowMs,
            lastAlertSide = eligible.side
        )
        state = updated
        return DispatchResult(emittedCross = eligible, updatedState = updated)
    }
}
