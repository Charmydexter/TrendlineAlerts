package com.trendlinealerts.core.engine

import com.trendlinealerts.core.model.ActiveTrendline
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.PivotPoint
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.TrendlineSide

/**
 * Ordered pivot list for ONE side (exact port of the Pine `pivotStack`).
 * dir = +1.0 resistance (each newer pivot high must be LOWER), -1.0 support (each newer pivot low must be HIGHER).
 * A pivot that breaks that order is held as PENDING (never part of the list) until:
 *   - a more extreme pivot replaces it, or
 *   - a pivot comes back inside, which promotes it (popping the older pivots it outranks).
 */
class PivotStack(private val dir: Double) {
    companion object {
        const val MAX_SIZE = 50
    }

    private val list = ArrayList<PivotPoint>()
    var pending: PivotPoint? = null
        private set

    val size: Int get() = list.size

    /** Newest first. */
    fun newest(n: Int): List<PivotPoint> = list.asReversed().take(n)

    fun onPivot(pivot: PivotPoint) {
        val pend = pending
        if (pend != null) {
            if (dir * pivot.price >= dir * pend.price) {
                // more extreme than the pending pivot: replaces it
                pending = pivot
            } else {
                // came back inside: the pending pivot becomes valid and takes its spot
                while (list.isNotEmpty() && dir * list.last().price <= dir * pend.price) {
                    list.removeAt(list.lastIndex)
                }
                list.add(pend)
                list.add(pivot)
                pending = null
            }
        } else if (list.isEmpty() || dir * pivot.price < dir * list.last().price) {
            list.add(pivot)
        } else {
            pending = pivot
        }
        while (list.size > MAX_SIZE) list.removeAt(0)
    }
}

data class EngineResult(
    val lines: Map<SlotId, ActiveTrendline>,
    /** Newest first, up to 4. */
    val resistancePivots: List<PivotPoint>,
    val supportPivots: List<PivotPoint>,
    val pendingResistance: PivotPoint?,
    val pendingSupport: PivotPoint?,
    val resistanceCount: Int,
    val supportCount: Int,
    val closedBarCount: Int
)

class TrendlineEngine {

    /**
     * Builds R1..R3 / S1..S3 from CLOSED HTF candles (oldest first). Never pass a forming candle.
     *
     * Pine reference (candle[j] is the "current" bar of the step and is itself ignored):
     *   highPivot = h[j-5] < h[j-4] < h[j-3] > h[j-2] > h[j-1]   (pivot bar = j-3)
     *   lowPivot  = l[j-5] > l[j-4] > l[j-3] < l[j-2] < l[j-1]
     * The output is the stack state after the last closed candle (Pine: values shifted by one bar).
     */
    fun build(closed: List<Candle>, tfMs: Long): EngineResult {
        val res = PivotStack(1.0)
        val sup = PivotStack(-1.0)

        for (j in 5 until closed.size) {
            val p = j - 3
            val c5 = closed[j - 5]; val c4 = closed[j - 4]; val c3 = closed[p]
            val c2 = closed[j - 2]; val c1 = closed[j - 1]

            val highPivot = c5.high < c4.high && c4.high < c3.high && c3.high > c2.high && c2.high > c1.high
            val lowPivot = c5.low > c4.low && c4.low > c3.low && c3.low < c2.low && c2.low < c1.low

            if (highPivot) res.onPivot(PivotPoint(p, c3.openTimeMs, c3.high))
            if (lowPivot) sup.onPivot(PivotPoint(p, c3.openTimeMs, c3.low))
        }

        val r = res.newest(4)
        val s = sup.newest(4)
        val lines = linkedMapOf<SlotId, ActiveTrendline>()
        val rSlots = listOf(SlotId.R1, SlotId.R2, SlotId.R3)
        val sSlots = listOf(SlotId.S1, SlotId.S2, SlotId.S3)
        for ((i, slot) in rSlots.withIndex()) makeLine(slot, TrendlineSide.RESISTANCE, r.getOrNull(i), r.getOrNull(i + 1), tfMs)?.let { lines[slot] = it }
        for ((i, slot) in sSlots.withIndex()) makeLine(slot, TrendlineSide.SUPPORT, s.getOrNull(i), s.getOrNull(i + 1), tfMs)?.let { lines[slot] = it }

        return EngineResult(
            lines = lines,
            resistancePivots = r,
            supportPivots = s,
            pendingResistance = res.pending,
            pendingSupport = sup.pending,
            resistanceCount = res.size,
            supportCount = sup.size,
            closedBarCount = closed.size
        )
    }

    private fun makeLine(
        slot: SlotId,
        side: TrendlineSide,
        newer: PivotPoint?,
        older: PivotPoint?,
        tfMs: Long
    ): ActiveTrendline? {
        if (newer == null || older == null) return null
        if (newer.openTimeMs == older.openTimeMs) return null
        val bars = (newer.openTimeMs - older.openTimeMs).toDouble() / tfMs.toDouble()
        val slope = (newer.price - older.price) / bars
        return ActiveTrendline(slot, side, older, newer, slope, tfMs)
    }
}

/**
 * Gives the trendlines as they were known at any moment: only HTF candles that were fully closed
 * by then are used (a 1m bar opening at time T sees HTF candles with openTime + tf <= T).
 * The last result is cached, so a normal minute does not rebuild anything.
 */
/** Source of the trendlines known at a given moment (the HTF book in the app, a fixed set in tests). */
interface LineProvider {
    fun resultAsOf(timeMs: Long): EngineResult
}

class HtfLineBook(
    private val engine: TrendlineEngine,
    private val htf: List<Candle>,
    private val tfMs: Long
) : LineProvider {
    private var cachedCount = -1
    private var cached: EngineResult? = null

    fun closedCountAsOf(timeMs: Long): Int {
        val limit = timeMs - tfMs
        var lo = 0
        var hi = htf.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (htf[mid].openTimeMs <= limit) lo = mid + 1 else hi = mid
        }
        return lo
    }

    override fun resultAsOf(timeMs: Long): EngineResult {
        val k = closedCountAsOf(timeMs)
        val c = cached
        if (c != null && k == cachedCount) return c
        val r = engine.build(htf.subList(0, k), tfMs)
        cachedCount = k
        cached = r
        return r
    }
}
