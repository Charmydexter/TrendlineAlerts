package com.trendlinealerts.core.engine

import com.trendlinealerts.core.model.ActiveTrendline
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.DebugLineInfo
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.PivotPoint
import com.trendlinealerts.core.model.RelativeSide
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.SymbolDebugSnapshot
import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide

data class SlotRuntimeState(
    var prevSide: RelativeSide? = null,
    var awaitingRejection: Boolean = false,
    var prevAnchorKey: String? = null
)

data class SymbolEngineState(
    val symbol: String,
    var initialized: Boolean = false,
    var lastCrossSide: TrendlineSide? = null,
    var lastEntryDirection: EntryDirection? = null,
    val slotStates: MutableMap<SlotId, SlotRuntimeState> = SlotId.entries
        .associateWith { SlotRuntimeState() }
        .toMutableMap()
)

data class EngineBuildResult(
    val activeLines: Map<SlotId, ActiveTrendline>,
    val currentBarIndex: Double,
    val resistancePivotCount: Int,
    val supportPivotCount: Int,
    val newLineEvents: List<TrendlineCandidate>,
    val debugSnapshot: SymbolDebugSnapshot
)

class TrendlineEngine {

    companion object {
        private const val MAX_STACK_SIZE = 50
    }

    /**
     * Builds active R1..R3 and S1..S3 trendlines from closed HTF candles + forming HTF candle.
     * Pivot rule (strict 5-bar Pine port):
     *   For each closed bar index j >= 5, evaluate p = j - 3 (ignores j):
     *   - High pivot if H[p] > H[j-5] && H[p] > H[j-4] && H[p] > H[j-2] && H[p] > H[j-1]
     *   - Low pivot  if L[p] < L[j-5] && L[p] < L[j-4] && L[p] < L[j-2] && L[p] < L[j-1]
     * Resistance stack keeps strictly descending highs (popping lower/equal newer pivots? No:
     * keeping monotonic sequence where new lower high appends and pops older highs below it, or
     * standard downward-sloping line stack capped at 50).
     */
    fun buildActiveLines(
        symbol: String,
        closedHtfCandles: List<Candle>,
        formingCandle: Candle?,
        state: SymbolEngineState,
        nowMs: Long
    ): EngineBuildResult {
        val highPivots = mutableListOf<PivotPoint>()
        val lowPivots = mutableListOf<PivotPoint>()

        for (j in 5 until closedHtfCandles.size) {
            val p = j - 3
            val center = closedHtfCandles[p]

            val isPivotHigh = center.high > closedHtfCandles[j - 5].high &&
                center.high > closedHtfCandles[j - 4].high &&
                center.high > closedHtfCandles[j - 2].high &&
                center.high > closedHtfCandles[j - 1].high

            if (isPivotHigh) {
                val pivot = PivotPoint(
                    barIndex = p,
                    openTimeMs = center.openTimeMs,
                    price = center.high
                )
                while (highPivots.isNotEmpty() && highPivots.last().price <= pivot.price) {
                    highPivots.removeAt(highPivots.lastIndex)
                }
                highPivots.add(pivot)
                if (highPivots.size > MAX_STACK_SIZE) {
                    highPivots.removeAt(0)
                }
            }

            val isPivotLow = center.low < closedHtfCandles[j - 5].low &&
                center.low < closedHtfCandles[j - 4].low &&
                center.low < closedHtfCandles[j - 2].low &&
                center.low < closedHtfCandles[j - 1].low

            if (isPivotLow) {
                val pivot = PivotPoint(
                    barIndex = p,
                    openTimeMs = center.openTimeMs,
                    price = center.low
                )
                while (lowPivots.isNotEmpty() && lowPivots.last().price >= pivot.price) {
                    lowPivots.removeAt(lowPivots.lastIndex)
                }
                lowPivots.add(pivot)
                if (lowPivots.size > MAX_STACK_SIZE) {
                    lowPivots.removeAt(0)
                }
            }
        }

        val currentBarIndex = if (formingCandle != null) {
            closedHtfCandles.size.toDouble()
        } else {
            (closedHtfCandles.size - 1).coerceAtLeast(0).toDouble()
        }

        val activeLines = linkedMapOf<SlotId, ActiveTrendline>()

        val resSlots = listOf(SlotId.R1, SlotId.R2, SlotId.R3)
        for ((idx, slot) in resSlots.withIndex()) {
            val p2Idx = highPivots.size - 1 - idx
            val p1Idx = p2Idx - 1
            if (p1Idx >= 0 && p2Idx >= 1) {
                val p1 = highPivots[p1Idx]
                val p2 = highPivots[p2Idx]
                val barDelta = (p2.barIndex - p1.barIndex).coerceAtLeast(1)
                val slope = (p2.price - p1.price) / barDelta.toDouble()
                activeLines[slot] = ActiveTrendline(
                    slotId = slot,
                    side = TrendlineSide.RESISTANCE,
                    p1 = p1,
                    p2 = p2,
                    slopePerBar = slope
                )
            }
        }

        val supSlots = listOf(SlotId.S1, SlotId.S2, SlotId.S3)
        for ((idx, slot) in supSlots.withIndex()) {
            val p2Idx = lowPivots.size - 1 - idx
            val p1Idx = p2Idx - 1
            if (p1Idx >= 0 && p2Idx >= 1) {
                val p1 = lowPivots[p1Idx]
                val p2 = lowPivots[p2Idx]
                val barDelta = (p2.barIndex - p1.barIndex).coerceAtLeast(1)
                val slope = (p2.price - p1.price) / barDelta.toDouble()
                activeLines[slot] = ActiveTrendline(
                    slotId = slot,
                    side = TrendlineSide.SUPPORT,
                    p1 = p1,
                    p2 = p2,
                    slopePerBar = slope
                )
            }
        }

        val newLineEvents = mutableListOf<TrendlineCandidate>()
        val latestPrice = formingCandle?.close ?: closedHtfCandles.lastOrNull()?.close ?: 0.0

        listOf(SlotId.R1, SlotId.S1).forEach { primarySlot ->
            val line = activeLines[primarySlot]
            val slotState = state.slotStates.getValue(primarySlot)
            val newKey = line?.anchorKey
            if (line != null && newKey != slotState.prevAnchorKey) {
                if (state.initialized && slotState.prevAnchorKey != null) {
                    val eventType = if (primarySlot == SlotId.R1) {
                        EventType.NEW_RESISTANCE
                    } else {
                        EventType.NEW_SUPPORT
                    }
                    newLineEvents.add(
                        TrendlineCandidate(
                            symbol = symbol,
                            slotId = primarySlot,
                            side = line.side,
                            eventType = eventType,
                            price = latestPrice,
                            lineValue = line.valueAt(currentBarIndex),
                            timestampMs = nowMs
                        )
                    )
                }
                slotState.prevAnchorKey = newKey
                slotState.awaitingRejection = false
            }
        }

        val debugLines = activeLines.values.map { line ->
            DebugLineInfo(
                slotId = line.slotId,
                currentValue = line.valueAt(currentBarIndex),
                p1TimeMs = line.p1.openTimeMs,
                p1Price = line.p1.price,
                p2TimeMs = line.p2.openTimeMs,
                p2Price = line.p2.price
            )
        }

        val debugSnapshot = SymbolDebugSnapshot(
            symbol = symbol,
            updatedAtMs = nowMs,
            lastPrice = latestPrice,
            htfBarCount = closedHtfCandles.size,
            activeLines = debugLines,
            resistancePivotCount = highPivots.size,
            supportPivotCount = lowPivots.size,
            lastCrossSide = state.lastCrossSide,
            lastEntryDirection = state.lastEntryDirection
        )

        return EngineBuildResult(
            activeLines = activeLines,
            currentBarIndex = currentBarIndex,
            resistancePivotCount = highPivots.size,
            supportPivotCount = lowPivots.size,
            newLineEvents = newLineEvents,
            debugSnapshot = debugSnapshot
        )
    }
}
