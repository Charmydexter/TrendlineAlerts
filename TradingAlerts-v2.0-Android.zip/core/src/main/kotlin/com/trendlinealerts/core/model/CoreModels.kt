package com.trendlinealerts.core.model

import kotlinx.serialization.Serializable

@Serializable
data class Candle(
    val openTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0,
    val isClosed: Boolean = true
)

@Serializable
enum class Timeframe(
    val label: String,
    val minutes: Int,
    val binanceInterval: String,
    val bybitInterval: String,
    val okxBar: String
) {
    M3("3m", 3, "3m", "3", "3m"),
    M5("5m", 5, "5m", "5", "5m"),
    M15("15m", 15, "15m", "15", "15m"),
    M30("30m", 30, "30m", "30", "30m"),
    H1("1h", 60, "1h", "60", "1H"),
    H4("4h", 240, "4h", "240", "4H")
}

@Serializable
enum class SlotId(val side: TrendlineSide) {
    R1(TrendlineSide.RESISTANCE),
    R2(TrendlineSide.RESISTANCE),
    R3(TrendlineSide.RESISTANCE),
    S1(TrendlineSide.SUPPORT),
    S2(TrendlineSide.SUPPORT),
    S3(TrendlineSide.SUPPORT)
}

@Serializable
enum class TrendlineSide {
    RESISTANCE,
    SUPPORT
}

@Serializable
enum class EventType {
    CROSS_RESISTANCE,
    CROSS_SUPPORT,
    LONG_ENTRY,
    SHORT_ENTRY,
    NEW_RESISTANCE,
    NEW_SUPPORT
}

@Serializable
enum class EntryDirection {
    LONG,
    SHORT
}

@Serializable
enum class RelativeSide {
    ABOVE,
    BELOW,
    ON_LINE
}

@Serializable
data class AlertSettings(
    val timeframe: Timeframe = Timeframe.M3,
    val proximityPct: Double = 0.25,
    val enabledSlots: Set<SlotId> = SlotId.entries.toSet()
)

@Serializable
data class PivotPoint(
    val barIndex: Int,
    val openTimeMs: Long,
    val price: Double
)

@Serializable
data class ActiveTrendline(
    val slotId: SlotId,
    val side: TrendlineSide,
    val p1: PivotPoint,
    val p2: PivotPoint,
    val slopePerBar: Double
) {
    val anchorKey: String
        get() = "${p1.openTimeMs}-${p2.openTimeMs}"

    fun valueAt(barIndex: Double): Double {
        return p2.price + slopePerBar * (barIndex - p2.barIndex.toDouble())
    }
}

@Serializable
data class NearestLineInfo(
    val slotId: SlotId,
    val side: TrendlineSide,
    val lineValue: Double,
    val distancePct: Double
)

@Serializable
data class TrendlineCandidate(
    val symbol: String,
    val slotId: SlotId,
    val side: TrendlineSide,
    val eventType: EventType,
    val price: Double,
    val lineValue: Double,
    val timestampMs: Long
)

@Serializable
data class DebugLineInfo(
    val slotId: SlotId,
    val currentValue: Double,
    val p1TimeMs: Long,
    val p1Price: Double,
    val p2TimeMs: Long,
    val p2Price: Double
)

@Serializable
data class SymbolDebugSnapshot(
    val symbol: String,
    val updatedAtMs: Long,
    val lastPrice: Double,
    val htfBarCount: Int,
    val activeLines: List<DebugLineInfo>,
    val resistancePivotCount: Int,
    val supportPivotCount: Int,
    val lastCrossSide: TrendlineSide? = null,
    val lastEntryDirection: EntryDirection? = null
)

data class SymbolEvaluationResult(
    val symbol: String,
    val lastPrice: Double,
    val crossCandidate: TrendlineCandidate?,
    val specialEvents: List<TrendlineCandidate>,
    val nearestSupport: NearestLineInfo?,
    val nearestResistance: NearestLineInfo?,
    val nearestOverall: NearestLineInfo?,
    val lastCrossSide: TrendlineSide?,
    val lastEntryDirection: EntryDirection?,
    val debugSnapshot: SymbolDebugSnapshot
)
