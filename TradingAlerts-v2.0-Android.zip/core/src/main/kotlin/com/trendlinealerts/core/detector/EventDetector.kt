package com.trendlinealerts.core.detector

import com.trendlinealerts.core.engine.EngineBuildResult
import com.trendlinealerts.core.engine.SymbolEngineState
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.NearestLineInfo
import com.trendlinealerts.core.model.RelativeSide
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.SymbolEvaluationResult
import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide
import kotlin.math.abs

class EventDetector {

    fun evaluate(
        symbol: String,
        latestCandle: Candle,
        lastPrice: Double,
        engineResult: EngineBuildResult,
        state: SymbolEngineState,
        settings: AlertSettings,
        isPriorityOverride: Boolean,
        nowMs: Long
    ): SymbolEvaluationResult {
        val crossCandidates = mutableListOf<TrendlineCandidate>()
        val specialEvents = mutableListOf<TrendlineCandidate>()

        if (isPriorityOverride) {
            specialEvents.addAll(engineResult.newLineEvents)
        }

        var nearestSupport: NearestLineInfo? = null
        var nearestResistance: NearestLineInfo? = null
        var nearestOverall: NearestLineInfo? = null

        val barIndex = engineResult.currentBarIndex

        for (slot in SlotId.entries) {
            val line = engineResult.activeLines[slot] ?: continue
            val lineValue = line.valueAt(barIndex)
            if (lineValue <= 0.0) continue

            val slotState = state.slotStates.getValue(slot)
            val currentSide = when {
                lastPrice > lineValue -> RelativeSide.ABOVE
                lastPrice < lineValue -> RelativeSide.BELOW
                else -> RelativeSide.ON_LINE
            }

            if (settings.enabledSlots.contains(slot)) {
                val signedPct = ((lastPrice - lineValue) / lineValue) * 100.0
                val info = NearestLineInfo(
                    slotId = slot,
                    side = line.side,
                    lineValue = lineValue,
                    distancePct = signedPct
                )

                if (nearestOverall == null || abs(signedPct) < abs(nearestOverall.distancePct)) {
                    nearestOverall = info
                }

                if (line.side == TrendlineSide.SUPPORT) {
                    if (nearestSupport == null || abs(signedPct) < abs(nearestSupport.distancePct)) {
                        nearestSupport = info
                    }
                } else {
                    if (nearestResistance == null || abs(signedPct) < abs(nearestResistance.distancePct)) {
                        nearestResistance = info
                    }
                }

                if (state.initialized) {
                    val prevSide = slotState.prevSide
                    if (line.side == TrendlineSide.RESISTANCE) {
                        if (prevSide == RelativeSide.BELOW && latestCandle.high >= lineValue) {
                            crossCandidates.add(
                                TrendlineCandidate(
                                    symbol = symbol,
                                    slotId = slot,
                                    side = TrendlineSide.RESISTANCE,
                                    eventType = EventType.CROSS_RESISTANCE,
                                    price = lastPrice,
                                    lineValue = lineValue,
                                    timestampMs = nowMs
                                )
                            )
                            slotState.awaitingRejection = true
                            state.lastCrossSide = TrendlineSide.RESISTANCE
                        } else if (isPriorityOverride && slotState.awaitingRejection && latestCandle.close < lineValue) {
                            if (state.lastEntryDirection != EntryDirection.SHORT) {
                                specialEvents.add(
                                    TrendlineCandidate(
                                        symbol = symbol,
                                        slotId = slot,
                                        side = TrendlineSide.RESISTANCE,
                                        eventType = EventType.SHORT_ENTRY,
                                        price = latestCandle.close,
                                        lineValue = lineValue,
                                        timestampMs = nowMs
                                    )
                                )
                                state.lastEntryDirection = EntryDirection.SHORT
                            }
                            slotState.awaitingRejection = false
                        }
                    } else {
                        if (prevSide == RelativeSide.ABOVE && latestCandle.low <= lineValue) {
                            crossCandidates.add(
                                TrendlineCandidate(
                                    symbol = symbol,
                                    slotId = slot,
                                    side = TrendlineSide.SUPPORT,
                                    eventType = EventType.CROSS_SUPPORT,
                                    price = lastPrice,
                                    lineValue = lineValue,
                                    timestampMs = nowMs
                                )
                            )
                            slotState.awaitingRejection = true
                            state.lastCrossSide = TrendlineSide.SUPPORT
                        } else if (isPriorityOverride && slotState.awaitingRejection && latestCandle.close > lineValue) {
                            if (state.lastEntryDirection != EntryDirection.LONG) {
                                specialEvents.add(
                                    TrendlineCandidate(
                                        symbol = symbol,
                                        slotId = slot,
                                        side = TrendlineSide.SUPPORT,
                                        eventType = EventType.LONG_ENTRY,
                                        price = latestCandle.close,
                                        lineValue = lineValue,
                                        timestampMs = nowMs
                                    )
                                )
                                state.lastEntryDirection = EntryDirection.LONG
                            }
                            slotState.awaitingRejection = false
                        }
                    }
                }
            }

            if (currentSide != RelativeSide.ON_LINE) {
                slotState.prevSide = currentSide
            } else if (slotState.prevSide == null) {
                slotState.prevSide = RelativeSide.ON_LINE
            }
        }

        state.initialized = true

        val bestCross = crossCandidates.minByOrNull { it.slotId.ordinal }

        return SymbolEvaluationResult(
            symbol = symbol,
            lastPrice = lastPrice,
            crossCandidate = bestCross,
            specialEvents = specialEvents,
            nearestSupport = nearestSupport,
            nearestResistance = nearestResistance,
            nearestOverall = nearestOverall,
            lastCrossSide = state.lastCrossSide,
            lastEntryDirection = state.lastEntryDirection,
            debugSnapshot = engineResult.debugSnapshot.copy(
                lastCrossSide = state.lastCrossSide,
                lastEntryDirection = state.lastEntryDirection
            )
        )
    }
}
