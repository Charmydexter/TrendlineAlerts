package com.trendlinealerts.core.detector

import com.trendlinealerts.core.engine.EngineResult
import com.trendlinealerts.core.engine.HtfLineBook
import com.trendlinealerts.core.engine.LineProvider
import com.trendlinealerts.core.engine.TrendlineEngine
import com.trendlinealerts.core.model.ActiveTrendline
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.NearestLineInfo
import com.trendlinealerts.core.model.SideTracker
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SignalResult(
    val state: SymbolSignalState,
    val events: List<TrendlineCandidate>,
    /** Trendlines as of `nowMs` (for display / debug). */
    val current: EngineResult?,
    val nearestOverall: NearestLineInfo?,
    val nearestSupport: NearestLineInfo?,
    val nearestResistance: NearestLineInfo?
)

/**
 * Runs closed 1m bars, in order, through the signal rules.
 *
 * GENERAL assets  -> LONG / SHORT entries (early heads-up, two extreme lines).
 * POSITIONED assets -> CROSS alerts (+ NEW R1/S1 line alerts); no long / short.
 *
 * A bar "touches" a line when its range reaches the line while the line was on the approach side
 * of the bar's open (support below the open, resistance above it). Pierce and touch are the same.
 * Each bar is processed exactly once; replaying missed minutes uses the same code, with
 * `missed = true` on events older than [LIVE_WINDOW_MS].
 */
class SignalProcessor(private val engine: TrendlineEngine = TrendlineEngine()) {

    companion object {
        const val BAR_MS = 60_000L
        const val LIVE_WINDOW_MS = 150_000L
    }

    fun process(
        symbol: String,
        previous: SymbolSignalState,
        mode: AssetMode,
        htfClosed: List<Candle>,
        timeframe: Timeframe,
        bars1m: List<Candle>,
        lastPrice: Double,
        settings: AlertSettings,
        nowMs: Long,
        lineProvider: LineProvider? = null
    ): SignalResult {
        var st = if (previous.mode != mode) {
            SymbolSignalState(symbol = symbol, mode = mode, lastProcessedOpenMs = previous.lastProcessedOpenMs)
        } else previous

        val tfMs = timeframe.ms
        val book: LineProvider = lineProvider ?: HtfLineBook(engine, htfClosed, tfMs)
        val events = mutableListOf<TrendlineCandidate>()

        val ordered = bars1m.filter { it.isClosed && it.openTimeMs > st.lastProcessedOpenMs }.sortedBy { it.openTimeMs }
        for (bar in ordered) {
            val t = bar.openTimeMs + BAR_MS
            val missed = t < nowMs - LIVE_WINDOW_MS
            val res = book.resultAsOf(bar.openTimeMs)

            // Swap gap (Pine: one bar without a value when a slot's line is replaced).
            val skipped = HashSet<SlotId>()
            val newKeys = HashMap<String, String>()
            for (slot in SlotId.entries) {
                val key = res.lines[slot]?.pivotKey ?: ""
                if (st.slotKeys[slot.name] != key) skipped.add(slot)
                newKeys[slot.name] = key
            }
            st = st.copy(slotKeys = newKeys)

            val lines = res.lines.values.filter { it.slotId in settings.enabledSlots && it.slotId !in skipped }

            when (mode) {
                AssetMode.GENERAL -> st = stepGeneral(symbol, st, bar, t, lines, nowMs, missed, events)
                AssetMode.POSITIONED -> st = stepPositioned(symbol, st, bar, t, lines, res, nowMs, missed, events)
            }
            st = st.copy(lastProcessedOpenMs = bar.openTimeMs)
        }

        val current = if (lineProvider != null || htfClosed.isNotEmpty()) book.resultAsOf(nowMs) else null
        var nearest: NearestLineInfo? = null
        var nearestS: NearestLineInfo? = null
        var nearestR: NearestLineInfo? = null
        current?.lines?.values?.filter { it.slotId in settings.enabledSlots }?.forEach { line ->
            val v = line.valueAt(nowMs)
            if (v <= 0.0) return@forEach
            val info = NearestLineInfo(line.slotId, line.side, v, (lastPrice - v) / v * 100.0)
            if (nearest == null || abs(info.distancePct) < abs(nearest!!.distancePct)) nearest = info
            if (line.side == TrendlineSide.SUPPORT) {
                if (nearestS == null || abs(info.distancePct) < abs(nearestS!!.distancePct)) nearestS = info
            } else {
                if (nearestR == null || abs(info.distancePct) < abs(nearestR!!.distancePct)) nearestR = info
            }
        }

        return SignalResult(st, events, current, nearest, nearestS, nearestR)
    }

    // ───────────────────────────── GENERAL: long / short ─────────────────────────────

    private fun stepGeneral(
        symbol: String,
        st0: SymbolSignalState,
        bar: Candle,
        t: Long,
        lines: List<ActiveTrendline>,
        nowMs: Long,
        missed: Boolean,
        out: MutableList<TrendlineCandidate>
    ): SymbolSignalState {
        var st = st0
        val supports = lines.filter { it.side == TrendlineSide.SUPPORT }
        val resistances = lines.filter { it.side == TrendlineSide.RESISTANCE }

        val longFire = fireCandidate(bar, t, supports, true, st.longTracker)
        val shortFire = fireCandidate(bar, t, resistances, false, st.shortTracker)

        // One signal per bar: if both sides fire, the line closer to the bar's open wins.
        val chosen: Pair<ActiveTrendline, Boolean>? = when {
            longFire != null && shortFire != null ->
                if (abs(bar.open - longFire.valueAt(t)) <= abs(bar.open - shortFire.valueAt(t))) longFire to true else shortFire to false
            longFire != null -> longFire to true
            shortFire != null -> shortFire to false
            else -> null
        }

        if (chosen != null) {
            val (line, isLong) = chosen
            val fired = SideTracker(
                firedKeys = (if (isLong) st.longTracker else st.shortTracker).firedKeys + line.pivotKey,
                lastFired = line.ref(),
                armed = false
            )
            st = if (isLong) {
                st.copy(longTracker = fired, shortTracker = SideTracker(), lastEntryDirection = EntryDirection.LONG)
            } else {
                st.copy(shortTracker = fired, longTracker = SideTracker(), lastEntryDirection = EntryDirection.SHORT)
            }
            out.add(
                TrendlineCandidate(
                    symbol = symbol,
                    slotId = line.slotId,
                    side = line.side,
                    eventType = if (isLong) EventType.LONG_ENTRY else EventType.SHORT_ENTRY,
                    price = bar.close,
                    lineValue = line.valueAt(t),
                    timestampMs = nowMs,
                    eventTimeMs = t,
                    missed = missed
                )
            )
        } else {
            st = st.copy(
                longTracker = updateArming(bar, t, supports, true, st.longTracker),
                shortTracker = updateArming(bar, t, resistances, false, st.shortTracker)
            )
        }
        return st
    }

    private fun extremeTwo(lines: List<ActiveTrendline>, t: Long, isSupport: Boolean): List<ActiveTrendline> =
        if (isSupport) lines.sortedBy { it.valueAt(t) }.take(2)
        else lines.sortedByDescending { it.valueAt(t) }.take(2)

    private fun onApproachSide(value: Double, bar: Candle, isSupport: Boolean) =
        if (isSupport) value < bar.open else value > bar.open

    private fun touched(value: Double, bar: Candle, isSupport: Boolean) =
        if (isSupport) bar.low <= value else bar.high >= value

    /** Returns the line that fires on this bar for one side, or null. */
    private fun fireCandidate(
        bar: Candle,
        t: Long,
        sideLines: List<ActiveTrendline>,
        isSupport: Boolean,
        tr: SideTracker
    ): ActiveTrendline? {
        val two = extremeTwo(sideLines, t, isSupport)
        val lastValue = tr.lastFired?.valueAt(t)
        val eligible = two.filter { line ->
            val v = line.valueAt(t)
            if (line.pivotKey in tr.firedKeys) return@filter false
            if (!onApproachSide(v, bar, isSupport)) return@filter false
            if (!touched(v, bar, isSupport)) return@filter false
            if (lastValue == null) return@filter true
            // A line further along the move than the last fired line needs the arming bar first.
            val furtherAlong = if (isSupport) v < lastValue else v > lastValue
            !furtherAlong || tr.armed
        }
        if (eligible.isEmpty()) return null
        // Price approaches from the open: the line nearest to the open is reached first.
        return if (isSupport) eligible.maxByOrNull { it.valueAt(t) } else eligible.minByOrNull { it.valueAt(t) }
    }

    /**
     * Arms the next line once a bar closes with its WHOLE body beyond the last fired line
     * and that same bar does not touch the next line.
     */
    private fun updateArming(
        bar: Candle,
        t: Long,
        sideLines: List<ActiveTrendline>,
        isSupport: Boolean,
        tr: SideTracker
    ): SideTracker {
        val last = tr.lastFired ?: return tr
        if (tr.armed) return tr
        val f = last.valueAt(t)
        val bodyBeyond = if (isSupport) max(bar.open, bar.close) < f else min(bar.open, bar.close) > f
        if (!bodyBeyond) return tr
        val nextTargets = extremeTwo(sideLines, t, isSupport).filter { line ->
            val v = line.valueAt(t)
            line.pivotKey !in tr.firedKeys && (if (isSupport) v < f else v > f)
        }
        val touchesNext = nextTargets.any { touched(it.valueAt(t), bar, isSupport) }
        return if (touchesNext) tr else tr.copy(armed = true)
    }

    // ───────────────────────────── POSITIONED: cross alerts ─────────────────────────────

    private fun stepPositioned(
        symbol: String,
        st0: SymbolSignalState,
        bar: Candle,
        t: Long,
        lines: List<ActiveTrendline>,
        res: EngineResult,
        nowMs: Long,
        missed: Boolean,
        out: MutableList<TrendlineCandidate>
    ): SymbolSignalState {
        var st = st0

        // New R1 / S1 line (live only; skipped on the first bar and on replayed minutes).
        val r1Key = res.lines[SlotId.R1]?.pivotKey
        val s1Key = res.lines[SlotId.S1]?.pivotKey
        if (!missed) {
            if (st.r1Key != null && r1Key != null && r1Key != st.r1Key) {
                out.add(newLineEvent(symbol, res.lines.getValue(SlotId.R1), EventType.NEW_RESISTANCE, bar, t, nowMs))
            }
            if (st.s1Key != null && s1Key != null && s1Key != st.s1Key) {
                out.add(newLineEvent(symbol, res.lines.getValue(SlotId.S1), EventType.NEW_SUPPORT, bar, t, nowMs))
            }
        }
        st = st.copy(r1Key = r1Key ?: st.r1Key, s1Key = s1Key ?: st.s1Key)

        // Supports must be below the open, resistances above it. Highest support / lowest resistance is reached first.
        val s = if (st.lastCrossSide == TrendlineSide.SUPPORT) null else lines
            .filter { it.side == TrendlineSide.SUPPORT && onApproachSide(it.valueAt(t), bar, true) && touched(it.valueAt(t), bar, true) }
            .maxByOrNull { it.valueAt(t) }
        val r = if (st.lastCrossSide == TrendlineSide.RESISTANCE) null else lines
            .filter { it.side == TrendlineSide.RESISTANCE && onApproachSide(it.valueAt(t), bar, false) && touched(it.valueAt(t), bar, false) }
            .minByOrNull { it.valueAt(t) }

        val chosen = when {
            s != null && r != null -> if (abs(bar.open - s.valueAt(t)) <= abs(bar.open - r.valueAt(t))) s else r
            else -> s ?: r
        }
        if (chosen != null) {
            val isSupport = chosen.side == TrendlineSide.SUPPORT
            st = st.copy(lastCrossSide = chosen.side)
            out.add(
                TrendlineCandidate(
                    symbol = symbol,
                    slotId = chosen.slotId,
                    side = chosen.side,
                    eventType = if (isSupport) EventType.CROSS_SUPPORT else EventType.CROSS_RESISTANCE,
                    price = bar.close,
                    lineValue = chosen.valueAt(t),
                    timestampMs = nowMs,
                    eventTimeMs = t,
                    missed = missed
                )
            )
        }
        return st
    }

    private fun newLineEvent(
        symbol: String,
        line: ActiveTrendline,
        type: EventType,
        bar: Candle,
        t: Long,
        nowMs: Long
    ) = TrendlineCandidate(symbol, line.slotId, line.side, type, bar.close, line.valueAt(t), nowMs, t, false)
}
