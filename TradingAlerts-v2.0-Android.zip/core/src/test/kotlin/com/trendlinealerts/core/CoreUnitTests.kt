package com.trendlinealerts.core

import com.trendlinealerts.core.detector.EventDetector
import com.trendlinealerts.core.dispatcher.AlertDispatcher
import com.trendlinealerts.core.dispatcher.DispatcherPersistedState
import com.trendlinealerts.core.engine.SymbolEngineState
import com.trendlinealerts.core.engine.TrendlineEngine
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EntryDirection
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreUnitTests {

    private fun candle(
        idx: Int,
        open: Double,
        high: Double,
        low: Double,
        close: Double
    ): Candle {
        return Candle(
            openTimeMs = idx * 180_000L,
            open = open,
            high = high,
            low = low,
            close = close,
            isClosed = true
        )
    }

    @Test
    fun pivotDetectionAndDescendingResistanceStackBuildsR1() {
        val engine = TrendlineEngine()
        val state = SymbolEngineState("SUIUSDT")

        // Create two descending 5-bar high pivots at index 2 (high=110) and index 8 (high=104)
        val candles = listOf(
            candle(0, 99.0, 100.0, 98.0, 99.0),
            candle(1, 99.0, 101.0, 98.0, 100.0),
            candle(2, 100.0, 110.0, 99.0, 105.0), // p1 high = 110
            candle(3, 104.0, 105.0, 99.0, 100.0),
            candle(4, 100.0, 102.0, 97.0, 98.0),
            candle(5, 98.0, 99.0, 96.0, 97.0),
            candle(6, 97.0, 99.0, 95.0, 98.0),
            candle(7, 98.0, 100.0, 96.0, 99.0),
            candle(8, 99.0, 104.0, 97.0, 101.0), // p2 high = 104
            candle(9, 101.0, 102.0, 97.0, 98.0),
            candle(10, 98.0, 100.0, 96.0, 97.0),
            candle(11, 97.0, 98.0, 95.0, 96.0)
        )

        val result = engine.buildActiveLines(
            symbol = "SUIUSDT",
            closedHtfCandles = candles,
            formingCandle = null,
            state = state,
            nowMs = 1_000_000L
        )

        val r1 = result.activeLines[SlotId.R1]
        assertNotNull(r1)
        assertEquals(2, r1!!.p1.barIndex)
        assertEquals(8, r1.p2.barIndex)
        assertEquals(-1.0, r1.slopePerBar, 1e-6)
        // At bar index 11: 104 + (-1)*(11-8) = 101.0
        assertEquals(101.0, r1.valueAt(result.currentBarIndex), 1e-6)
    }

    @Test
    fun preRejectionCrossAndAlternatingShortLongRejectionEntries() {
        val engine = TrendlineEngine()
        val detector = EventDetector()
        val state = SymbolEngineState("SUIUSDT")
        val settings = AlertSettings()

        val candles = listOf(
            candle(0, 99.0, 100.0, 98.0, 99.0),
            candle(1, 99.0, 101.0, 98.0, 100.0),
            candle(2, 100.0, 110.0, 99.0, 105.0),
            candle(3, 104.0, 105.0, 99.0, 100.0),
            candle(4, 100.0, 102.0, 97.0, 98.0),
            candle(5, 98.0, 99.0, 96.0, 97.0),
            candle(6, 97.0, 99.0, 95.0, 98.0),
            candle(7, 98.0, 100.0, 96.0, 99.0),
            candle(8, 99.0, 104.0, 97.0, 101.0),
            candle(9, 101.0, 102.0, 97.0, 98.0),
            candle(10, 98.0, 100.0, 96.0, 97.0),
            candle(11, 97.0, 98.0, 95.0, 96.0)
        )

        val buildResult = engine.buildActiveLines("SUIUSDT", candles, null, state, 1_000L)
        // Bar index 11 => R1 lineValue = 101.0. Initialize below R1 at 96.0.
        val initEval = detector.evaluate(
            symbol = "SUIUSDT",
            latestCandle = candle(11, 97.0, 98.0, 95.0, 96.0),
            lastPrice = 96.0,
            engineResult = buildResult,
            state = state,
            settings = settings,
            isPriorityOverride = true,
            nowMs = 1_000L
        )
        assertNull(initEval.crossCandidate)

        // Touch R1 exactly (high == 101.0, close == 101.0) => CROSS_RESISTANCE fires immediately
        val touchEval = detector.evaluate(
            symbol = "SUIUSDT",
            latestCandle = candle(11, 96.0, 101.0, 96.0, 101.0),
            lastPrice = 101.0,
            engineResult = buildResult,
            state = state,
            settings = settings,
            isPriorityOverride = true,
            nowMs = 2_000L
        )
        assertEquals(EventType.CROSS_RESISTANCE, touchEval.crossCandidate?.eventType)

        // Next tick closes back below R1 (99.5 < 101.0) => SHORT_ENTRY fires for priority override
        val rejectEval = detector.evaluate(
            symbol = "SUIUSDT",
            latestCandle = candle(11, 96.0, 101.0, 96.0, 99.5),
            lastPrice = 99.5,
            engineResult = buildResult,
            state = state,
            settings = settings,
            isPriorityOverride = true,
            nowMs = 3_000L
        )
        assertTrue(rejectEval.specialEvents.any { it.eventType == EventType.SHORT_ENTRY })
        assertEquals(EntryDirection.SHORT, state.lastEntryDirection)

        // Re-touch and re-reject R1 without an intervening LONG_ENTRY must NOT re-fire SHORT_ENTRY
        detector.evaluate(
            symbol = "SUIUSDT",
            latestCandle = candle(11, 99.5, 101.5, 99.0, 101.2),
            lastPrice = 101.2,
            engineResult = buildResult,
            state = state,
            settings = settings,
            isPriorityOverride = true,
            nowMs = 4_000L
        )
        val secondRejectEval = detector.evaluate(
            symbol = "SUIUSDT",
            latestCandle = candle(11, 99.5, 101.5, 99.0, 99.0),
            lastPrice = 99.0,
            engineResult = buildResult,
            state = state,
            settings = settings,
            isPriorityOverride = true,
            nowMs = 5_000L
        )
        assertTrue(secondRejectEval.specialEvents.none { it.eventType == EventType.SHORT_ENTRY })
    }

    @Test
    fun dispatcherGeneralOffAllowsOppositeSideSelfResetAfterCooldown() {
        val dispatcher = AlertDispatcher(
            DispatcherPersistedState(
                lastAlertSymbol = "SUIUSDT",
                lastAlertTimeMs = 100_000L,
                lastAlertSide = TrendlineSide.SUPPORT
            )
        )

        val sameSide = TrendlineCandidate(
            symbol = "SUIUSDT",
            slotId = SlotId.S1,
            side = TrendlineSide.SUPPORT,
            eventType = EventType.CROSS_SUPPORT,
            price = 1.0,
            lineValue = 1.0,
            timestampMs = 170_000L
        )
        val oppositeSide = TrendlineCandidate(
            symbol = "SUIUSDT",
            slotId = SlotId.R1,
            side = TrendlineSide.RESISTANCE,
            eventType = EventType.CROSS_RESISTANCE,
            price = 1.1,
            lineValue = 1.1,
            timestampMs = 170_000L
        )

        // General monitoring ON blocks same symbol even on opposite side
        val blockedGeneralOn = dispatcher.processCycle(
            candidates = listOf(oppositeSide),
            generalMonitoringOn = true,
            nowMs = 170_000L
        )
        assertNull(blockedGeneralOn.emittedCross)

        // General monitoring OFF blocks same side on same symbol
        val blockedSameSide = dispatcher.processCycle(
            candidates = listOf(sameSide),
            generalMonitoringOn = false,
            nowMs = 170_000L
        )
        assertNull(blockedSameSide.emittedCross)

        // General monitoring OFF allows opposite side on same symbol after 60s cooldown
        val allowedOpposite = dispatcher.processCycle(
            candidates = listOf(oppositeSide),
            generalMonitoringOn = false,
            nowMs = 170_000L
        )
        assertNotNull(allowedOpposite.emittedCross)
        assertEquals(TrendlineSide.RESISTANCE, allowedOpposite.updatedState.lastAlertSide)
    }
}
