package com.trendlinealerts.core

import com.trendlinealerts.core.detector.SignalProcessor
import com.trendlinealerts.core.detector.SignalResult
import com.trendlinealerts.core.dispatcher.AlertDispatcher
import com.trendlinealerts.core.engine.EngineResult
import com.trendlinealerts.core.engine.HtfLineBook
import com.trendlinealerts.core.engine.LineProvider
import com.trendlinealerts.core.engine.PivotStack
import com.trendlinealerts.core.engine.TrendlineEngine
import com.trendlinealerts.core.model.ActiveTrendline
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.AssetMode
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.PivotPoint
import com.trendlinealerts.core.model.SignalStateCodec
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.SymbolSignalState
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreUnitTests {

    private val T0 = 6_000_000L
    private val TF = 180_000L
    private val BAR = 60_000L

    // ───────────────────────── helpers ─────────────────────────

    private fun piv(price: Double, idx: Int = 0, t: Long = 0L) = PivotPoint(idx, t, price)

    private fun htf(i: Int, high: Double) =
        Candle(T0 + i * TF, high - 1.0, high, high - 5.0, high - 1.0)

    private fun bar(i: Int, o: Double, h: Double, l: Double, c: Double) =
        Candle(T0 + i * BAR, o, h, l, c)

    /** A horizontal line. `id` makes its pivot pair (its identity) unique. */
    private fun flat(slot: SlotId, price: Double, id: Int) = ActiveTrendline(
        slotId = slot,
        side = slot.side,
        older = PivotPoint(0, id * 1000L, price),
        newer = PivotPoint(1, id * 1000L + TF, price),
        slopePerBar = 0.0,
        tfMs = TF
    )

    private fun provider(vararg lines: ActiveTrendline) = object : LineProvider {
        override fun resultAsOf(timeMs: Long) = EngineResult(
            lines = lines.associateBy { it.slotId },
            resistancePivots = emptyList(),
            supportPivots = emptyList(),
            pendingResistance = null,
            pendingSupport = null,
            resistanceCount = 0,
            supportCount = 0,
            closedBarCount = 0
        )
    }

    private val proc = SignalProcessor()

    /** nowMs = T0 keeps every event "live" (never flagged missed). */
    private fun run(
        mode: AssetMode,
        p: LineProvider,
        bars: List<Candle>,
        prev: SymbolSignalState = SymbolSignalState("TEST"),
        now: Long = T0
    ): SignalResult = proc.process(
        symbol = "TEST",
        previous = prev,
        mode = mode,
        htfClosed = emptyList(),
        timeframe = Timeframe.M3,
        bars1m = bars,
        lastPrice = bars.last().close,
        settings = AlertSettings(),
        nowMs = now,
        lineProvider = p
    )

    private fun types(r: SignalResult) = r.events.map { it.eventType to it.slotId }

    // ───────────────────────── pivot stack ─────────────────────────

    @Test
    fun resistanceStackKeepsDescendingOrder() {
        val s = PivotStack(1.0)
        listOf(100.0, 90.0, 80.0).forEach { s.onPivot(piv(it)) }
        assertEquals(listOf(80.0, 90.0, 100.0), s.newest(3).map { it.price })
        assertNull(s.pending)
    }

    @Test
    fun higherHighBecomesPendingThenPromotedWhenPivotComesBackInside() {
        val s = PivotStack(1.0)
        s.onPivot(piv(100.0))
        s.onPivot(piv(110.0))
        assertEquals(110.0, s.pending!!.price, 0.0)
        assertEquals(listOf(100.0), s.newest(4).map { it.price })

        s.onPivot(piv(105.0)) // came back inside: 110 is valid, pops the 100 it outranks
        assertNull(s.pending)
        assertEquals(listOf(105.0, 110.0), s.newest(4).map { it.price })
    }

    @Test
    fun moreExtremePivotReplacesPending() {
        val s = PivotStack(1.0)
        listOf(100.0, 110.0, 120.0).forEach { s.onPivot(piv(it)) }
        assertEquals(120.0, s.pending!!.price, 0.0)
        assertEquals(listOf(100.0), s.newest(4).map { it.price })
    }

    @Test
    fun supportStackMirrorsResistance() {
        val s = PivotStack(-1.0)
        listOf(100.0, 90.0, 95.0).forEach { s.onPivot(piv(it)) } // lower low pending, then promoted
        assertEquals(listOf(95.0, 90.0), s.newest(4).map { it.price })
    }

    @Test
    fun stackIsCappedAtFifty() {
        val s = PivotStack(1.0)
        for (i in 0 until 60) s.onPivot(piv(1000.0 - i, i, i.toLong()))
        assertEquals(50, s.size)
    }

    // ───────────────────────── engine ─────────────────────────

    @Test
    fun strictPivotChainBuildsLineWithBarSlope() {
        val highs = listOf(10, 20, 30, 20, 10, 10, 12, 20, 25, 20, 12, 10).map { it.toDouble() }
        val candles = highs.mapIndexed { i, h -> htf(i, h) }
        val r = TrendlineEngine().build(candles, TF)

        val r1 = r.lines[SlotId.R1]
        assertNotNull(r1)
        assertEquals(-5.0 / 6.0, r1!!.slopePerBar, 1e-9)
        // 3 bars after the newer pivot (index 8): 25 + 3 * (-5/6) = 22.5
        assertEquals(22.5, r1.valueAt(candles[11].openTimeMs), 1e-9)
        assertNull(r.lines[SlotId.R2])
        assertTrue(r.lines.keys.none { it.side == TrendlineSide.SUPPORT })
    }

    @Test
    fun equalHighsDoNotFormAPivot() {
        // 20 == 20 breaks the strict chain: no pivot, no line
        val highs = listOf(10, 20, 20, 20, 10, 10, 12, 20, 25, 20, 12, 10).map { it.toDouble() }
        val r = TrendlineEngine().build(highs.mapIndexed { i, h -> htf(i, h) }, TF)
        assertEquals(1, r.resistanceCount)
        assertTrue(r.lines.isEmpty())
    }

    @Test
    fun lineBookOnlyUsesFullyClosedHtfBars() {
        val candles = (0 until 12).map { htf(it, 10.0 + it) }
        val book = HtfLineBook(TrendlineEngine(), candles, TF)
        assertEquals(5, book.closedCountAsOf(T0 + 5 * TF))
        assertEquals(5, book.closedCountAsOf(T0 + 5 * TF + TF - 1))
        assertEquals(6, book.closedCountAsOf(T0 + 6 * TF))
    }

    // ───────────────────────── GENERAL: long / short ─────────────────────────

    private val s1 get() = flat(SlotId.S1, 100.0, 1)
    private val s2 get() = flat(SlotId.S2, 98.0, 2)
    private val r1 get() = flat(SlotId.R1, 110.0, 3)
    private val r2 get() = flat(SlotId.R2, 112.0, 4)

    @Test
    fun firstBarAfterStartIsWarmUpAndNeverAlerts() {
        // the line just appeared for this symbol, so it is skipped on the first bar (swap gap)
        val r = run(AssetMode.GENERAL, provider(s1), listOf(bar(0, 105.0, 105.0, 99.0, 101.0)))
        assertTrue(r.events.isEmpty())
    }

    @Test
    fun longFiresOnFirstTouchThenSecondLineOnlyAfterArmingBar() {
        val bars = listOf(
            bar(0, 105.0, 106.0, 104.0, 105.0),
            bar(1, 105.0, 105.0, 99.5, 101.0),   // touches S1 -> LONG S1
            bar(2, 99.5, 99.8, 98.5, 99.0),      // whole body below S1, does not touch S2 -> arms
            bar(3, 99.0, 99.1, 97.8, 98.2),      // touches S2 -> LONG S2
            bar(4, 98.2, 101.0, 98.1, 100.5),
            bar(5, 100.5, 100.6, 97.9, 99.0)     // both fired: locked, nothing
        )
        val r = run(AssetMode.GENERAL, provider(s1, s2), bars)
        assertEquals(
            listOf(EventType.LONG_ENTRY to SlotId.S1, EventType.LONG_ENTRY to SlotId.S2),
            types(r)
        )
    }

    @Test
    fun armingBarThatTouchesTheNextLineDoesNotArm() {
        val bars = listOf(
            bar(0, 105.0, 106.0, 104.0, 105.0),
            bar(1, 105.0, 105.0, 99.5, 101.0),   // LONG S1
            bar(2, 99.5, 99.8, 97.9, 98.4),      // body below S1 but touches S2 -> no arm, no fire
            bar(3, 98.4, 98.5, 97.8, 98.1)       // touches S2 again, still not armed
        )
        val r = run(AssetMode.GENERAL, provider(s1, s2), bars)
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S1), types(r))
        assertFalse(r.state.longTracker.armed)
    }

    @Test
    fun barThroughBothLinesFiresOnlyTheFirstLine() {
        val bars = listOf(
            bar(0, 105.0, 106.0, 104.0, 105.0),
            bar(1, 105.0, 105.0, 97.5, 97.8),
            bar(2, 97.8, 99.0, 97.7, 98.5)       // S2 is no longer below the open
        )
        val r = run(AssetMode.GENERAL, provider(s1, s2), bars)
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S1), types(r))
    }

    @Test
    fun supportAbovePriceCannotFireLong() {
        val bars = listOf(
            bar(0, 99.0, 99.5, 98.5, 99.0),
            bar(1, 99.0, 100.5, 98.6, 100.2)     // line 100 is above the open: not a support for this bar
        )
        val r = run(AssetMode.GENERAL, provider(s1), bars)
        assertTrue(r.events.isEmpty())
    }

    @Test
    fun oppositeSignalResetsAndLongCanFireAgain() {
        val p = provider(s1, s2, r1, r2)
        val first = run(
            AssetMode.GENERAL, p,
            listOf(bar(0, 105.0, 106.0, 104.0, 105.0), bar(1, 105.0, 105.0, 99.5, 101.0), bar(2, 101.0, 101.2, 98.0, 99.0))
        )
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S1), types(first))

        val second = run(
            AssetMode.GENERAL, p,
            listOf(bar(3, 99.0, 111.0, 98.9, 109.0), bar(4, 109.0, 109.5, 99.9, 102.0)),
            prev = first.state
        )
        assertEquals(
            listOf(EventType.SHORT_ENTRY to SlotId.R1, EventType.LONG_ENTRY to SlotId.S1),
            types(second)
        )
    }

    @Test
    fun singleLineIsOnlyResetByTheOppositeSignal() {
        val bars = listOf(
            bar(0, 105.0, 106.0, 104.0, 105.0),
            bar(1, 105.0, 105.0, 99.5, 101.0),
            bar(2, 101.0, 102.0, 99.4, 101.0),
            bar(3, 101.0, 102.0, 99.0, 101.0)
        )
        val r = run(AssetMode.GENERAL, provider(s1), bars)
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S1), types(r))
    }

    @Test
    fun newLowerSupportCanFireAfterBothLinesFired() {
        val firstBars = listOf(
            bar(0, 105.0, 106.0, 104.0, 105.0),
            bar(1, 105.0, 105.0, 99.5, 101.0),
            bar(2, 99.5, 99.8, 98.5, 99.0),
            bar(3, 99.0, 99.1, 97.8, 98.2)
        )
        val first = run(AssetMode.GENERAL, provider(s1, s2), firstBars)
        assertEquals(2, first.events.size)

        val s3 = flat(SlotId.S3, 95.0, 5)
        val second = run(
            AssetMode.GENERAL, provider(s1, s2, s3),
            listOf(
                bar(4, 98.2, 98.4, 97.5, 97.9),  // S3 appears: swap gap bar
                bar(5, 97.9, 98.0, 97.0, 97.2),  // whole body below the last fired line, away from 95: arms
                bar(6, 97.2, 97.3, 94.8, 95.5)   // touches the new lower support -> LONG S3
            ),
            prev = first.state
        )
        assertEquals(listOf(EventType.LONG_ENTRY to SlotId.S3), types(second))
    }

    @Test
    fun shortMirrorsLong() {
        val bars = listOf(
            bar(0, 105.0, 106.0, 104.0, 105.0),
            bar(1, 105.0, 110.5, 104.0, 109.0),  // touches R1 (110) -> SHORT R1
            bar(2, 110.5, 111.0, 110.2, 110.8),  // whole body above R1, no touch of R2 (112) -> arms
            bar(3, 110.8, 112.3, 110.6, 111.5)   // touches R2 -> SHORT R2
        )
        val r = run(AssetMode.GENERAL, provider(r1, r2), bars)
        assertEquals(
            listOf(EventType.SHORT_ENTRY to SlotId.R1, EventType.SHORT_ENTRY to SlotId.R2),
            types(r)
        )
    }

    @Test
    fun onlyTheTwoLowestSupportsAreUsed() {
        val s3 = flat(SlotId.S3, 90.0, 5)
        // lowest two are 90 and 98; the line at 100 is NOT valid for long
        val bars = listOf(
            bar(0, 105.0, 106.0, 104.0, 105.0),
            bar(1, 105.0, 105.0, 99.5, 101.0)
        )
        val r = run(AssetMode.GENERAL, provider(s1, s2, s3), bars)
        assertTrue(r.events.isEmpty())
    }

    // ───────────────────────── POSITIONED: cross alerts ─────────────────────────

    @Test
    fun positionedCrossesAlternateAndLowerSupportDoesNotRefire() {
        val p = provider(s1, s2, r1)
        val bars = listOf(
            bar(0, 105.0, 106.0, 104.0, 105.0),
            bar(1, 105.0, 105.0, 99.5, 101.0),   // CROSS_SUPPORT S1
            bar(2, 101.0, 101.0, 97.5, 98.0),    // lower support crossed: nothing
            bar(3, 98.0, 111.0, 97.9, 109.0),    // CROSS_RESISTANCE R1 (re-arms support)
            bar(4, 109.0, 109.5, 97.5, 99.0)     // CROSS_SUPPORT again
        )
        val r = run(AssetMode.POSITIONED, p, bars)
        assertEquals(
            listOf(
                EventType.CROSS_SUPPORT to SlotId.S1,
                EventType.CROSS_RESISTANCE to SlotId.R1,
                EventType.CROSS_SUPPORT to SlotId.S1
            ),
            types(r)
        )
    }

    @Test
    fun positionedNeverProducesLongOrShort() {
        val r = run(
            AssetMode.POSITIONED, provider(s1, s2),
            listOf(bar(0, 105.0, 106.0, 104.0, 105.0), bar(1, 105.0, 105.0, 99.5, 101.0))
        )
        assertTrue(r.events.none { it.eventType == EventType.LONG_ENTRY || it.eventType == EventType.SHORT_ENTRY })
    }

    @Test
    fun positionedSupportAbovePriceIsNotACross() {
        val r = run(
            AssetMode.POSITIONED, provider(s1),
            listOf(bar(0, 99.0, 99.5, 98.5, 99.0), bar(1, 99.0, 100.5, 98.6, 100.2))
        )
        assertTrue(r.events.isEmpty())
    }

    @Test
    fun oldEventsAreFlaggedMissed() {
        val bars = listOf(bar(0, 105.0, 106.0, 104.0, 105.0), bar(1, 105.0, 105.0, 99.5, 101.0))
        val r = run(AssetMode.POSITIONED, provider(s1), bars, now = T0 + 3_600_000L)
        assertEquals(1, r.events.size)
        assertTrue(r.events[0].missed)
    }

    @Test
    fun eachBarIsProcessedOnlyOnce() {
        val bars = listOf(bar(0, 105.0, 106.0, 104.0, 105.0), bar(1, 105.0, 105.0, 99.5, 101.0))
        val first = run(AssetMode.POSITIONED, provider(s1), bars)
        val again = run(AssetMode.POSITIONED, provider(s1), bars, prev = first.state)
        assertTrue(again.events.isEmpty())
    }

    @Test
    fun stateSurvivesJsonRoundTrip() {
        val r = run(
            AssetMode.GENERAL, provider(s1, s2),
            listOf(bar(0, 105.0, 106.0, 104.0, 105.0), bar(1, 105.0, 105.0, 99.5, 101.0))
        )
        val back = SignalStateCodec.decode(SignalStateCodec.encode(r.state), "TEST")
        assertEquals(r.state, back)
        assertEquals(SymbolSignalState("X"), SignalStateCodec.decode("not json", "X"))
    }

    // ───────────────────────── dispatcher ─────────────────────────

    private fun cand(
        symbol: String,
        type: EventType,
        missed: Boolean = false,
        eventTime: Long = 1_000L
    ) = TrendlineCandidate(
        symbol = symbol,
        slotId = SlotId.S1,
        side = TrendlineSide.SUPPORT,
        eventType = type,
        price = 1.0,
        lineValue = 1.0,
        timestampMs = 5_000L,
        eventTimeMs = eventTime,
        missed = missed
    )

    @Test
    fun generalLongShortAreClusteredAndPositionedAreSeparate() {
        val plan = AlertDispatcher.plan(
            listOf(
                cand("AAA", EventType.LONG_ENTRY),
                cand("BBB", EventType.SHORT_ENTRY),
                cand("POS", EventType.CROSS_SUPPORT)
            ),
            positionedSymbols = setOf("POS"),
            generalMonitoringOn = true
        )
        assertEquals(listOf("AAA", "BBB"), plan.cluster.map { it.symbol })
        assertEquals(listOf("POS"), plan.individual.map { it.symbol })
        assertTrue(plan.missed.isEmpty())
    }

    @Test
    fun clusterKeepsOneRowPerAsset() {
        val plan = AlertDispatcher.plan(
            listOf(
                cand("AAA", EventType.LONG_ENTRY, eventTime = 1_000L),
                cand("AAA", EventType.SHORT_ENTRY, eventTime = 2_000L)
            ),
            emptySet(), true
        )
        assertEquals(1, plan.cluster.size)
        assertEquals(EventType.SHORT_ENTRY, plan.cluster[0].eventType)
    }

    @Test
    fun missedEventsPositionedNotifyGeneralOnlyLog() {
        val plan = AlertDispatcher.plan(
            listOf(
                cand("POS", EventType.CROSS_SUPPORT, missed = true, eventTime = 1L),
                cand("POS", EventType.CROSS_RESISTANCE, missed = true, eventTime = 2L),
                cand("GEN", EventType.LONG_ENTRY, missed = true)
            ),
            setOf("POS"), true
        )
        assertEquals(listOf("POS"), plan.missed.keys.toList())
        assertEquals(2, plan.missed.getValue("POS").size)
        assertEquals(listOf("GEN"), plan.logOnly.map { it.symbol })
        assertTrue(plan.cluster.isEmpty() && plan.individual.isEmpty())
    }

    @Test
    fun monitoringOffSilencesGeneralButNotPositioned() {
        val plan = AlertDispatcher.plan(
            listOf(cand("GEN", EventType.LONG_ENTRY), cand("POS", EventType.CROSS_RESISTANCE)),
            setOf("POS"), generalMonitoringOn = false
        )
        assertTrue(plan.cluster.isEmpty())
        assertEquals(listOf("POS"), plan.individual.map { it.symbol })
    }
}
