# Keep Kotlinx Serialization & Retrofit models
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.SerializationKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.trendlinealerts.**$$serializer { *; }
-keepclassmembers class com.trendlinealerts.** { *** Companion; }
