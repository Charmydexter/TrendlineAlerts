package com.trendlinealerts.app.di

import android.content.Context
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import com.trendlinealerts.app.data.cache.HtfCandleCache
import com.trendlinealerts.app.data.local.AppDatabase
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.remote.BinanceFuturesApi
import com.trendlinealerts.app.data.remote.BinanceSpotApi
import com.trendlinealerts.app.data.remote.BybitApi
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.OkxApi
import com.trendlinealerts.app.data.repository.AlertLogRepository
import com.trendlinealerts.app.data.repository.DebugSnapshotRepository
import com.trendlinealerts.app.data.repository.MonitorStateRepository
import com.trendlinealerts.app.data.repository.WatchlistRepository
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import retrofit2.Retrofit

private class DohFallbackDns(
    private val json: Json
) : Dns {

    private val bootstrapClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val cache = ConcurrentHashMap<String, Pair<Long, List<InetAddress>>>()

    override fun lookup(hostname: String): List<InetAddress> {
        val now = System.currentTimeMillis()
        val cached = cache[hostname]
        if (cached != null && (now - cached.first) < 300_000L) {
            return cached.second
        }

        val systemAddrs = runCatching { Dns.SYSTEM.lookup(hostname) }
            .getOrNull()
            ?.filter { addr ->
                val ip = addr.hostAddress.orEmpty()
                ip != "0.0.0.0" && ip != "::" && !ip.startsWith("127.")
            }
            .orEmpty()

        if (systemAddrs.isNotEmpty()) {
            cache[hostname] = now to systemAddrs
            return systemAddrs
        }

        val dohAddrs = queryDoh("https://1.1.1.1/dns-query?name=$hostname&type=A")
            .ifEmpty { queryDoh("https://8.8.8.8/resolve?name=$hostname&type=A") }

        if (dohAddrs.isNotEmpty()) {
            cache[hostname] = now to dohAddrs
            return dohAddrs
        }

        return Dns.SYSTEM.lookup(hostname)
    }

    private fun queryDoh(url: String): List<InetAddress> {
        return runCatching {
            val req = Request.Builder()
                .url(url)
                .header("Accept", "application/dns-json")
                .build()
            bootstrapClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val body = resp.body?.string().orEmpty()
                if (body.isBlank()) return emptyList()
                val root = json.parseToJsonElement(body).jsonObject
                val answers = root["Answer"]?.jsonArray ?: return emptyList()
                answers.mapNotNull { elem ->
                    val obj = elem.jsonObject
                    val type = obj["type"]?.jsonPrimitive?.content?.toIntOrNull()
                    val data = obj["data"]?.jsonPrimitive?.content
                    if (type == 1 && !data.isNullOrBlank()) {
                        runCatching { InetAddress.getByName(data) }.getOrNull()
                    } else {
                        null
                    }
                }
            }
        }.getOrDefault(emptyList())
    }
}

class AppContainer(context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    private val okHttpClient = OkHttpClient.Builder()
        .dns(DohFallbackDns(json))
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                )
                .build()
            chain.proceed(req)
        }
        .build()

    private val contentType = "application/json".toMediaType()

    private fun buildRetrofit(baseUrl: String): Retrofit {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()
    }

    private val bybitApi: BybitApi = buildRetrofit("https://api.bybit.com/").create(BybitApi::class.java)
    private val binanceFuturesApi: BinanceFuturesApi = buildRetrofit("https://fapi.binance.com/").create(BinanceFuturesApi::class.java)
    private val binanceSpotApi: BinanceSpotApi = buildRetrofit("https://api.binance.com/").create(BinanceSpotApi::class.java)
    private val okxApi: OkxApi = buildRetrofit("https://www.okx.com/").create(OkxApi::class.java)

    val database: AppDatabase = AppDatabase.create(context)
    val settingsDataStore = SettingsDataStore(context)

    val marketDataCoordinator = MarketDataCoordinator(
        bybitApi = bybitApi,
        binanceFuturesApi = binanceFuturesApi,
        binanceSpotApi = binanceSpotApi,
        okxApi = okxApi
    )

    val htfCandleCache = HtfCandleCache(
        dao = database.htfCandleDao(),
        coordinator = marketDataCoordinator
    )

    val watchlistRepository = WatchlistRepository(
        dao = database.watchlistDao(),
        coordinator = marketDataCoordinator
    )

    val alertLogRepository = AlertLogRepository(database.alertLogDao())
    val monitorStateRepository = MonitorStateRepository()
    val debugSnapshotRepository = DebugSnapshotRepository()
}
