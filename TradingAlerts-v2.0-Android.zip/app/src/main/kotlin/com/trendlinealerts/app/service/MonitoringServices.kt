package com.trendlinealerts.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.IBinder
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.trendlinealerts.app.R
import com.trendlinealerts.app.TrendlineAlertsApp
import com.trendlinealerts.app.data.local.AlertLogEntity
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.data.remote.SymbolNotListedException
import com.trendlinealerts.app.data.repository.SignalDotColor
import com.trendlinealerts.app.data.repository.SymbolMonitorRow
import com.trendlinealerts.app.ui.MainActivity
import com.trendlinealerts.core.detector.EventDetector
import com.trendlinealerts.core.dispatcher.AlertDispatcher
import com.trendlinealerts.core.engine.SymbolEngineState
import com.trendlinealerts.core.engine.TrendlineEngine
import com.trendlinealerts.core.model.EventType
import com.trendlinealerts.core.model.NearestLineInfo
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.TrendlineCandidate
import com.trendlinealerts.core.model.TrendlineSide
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

class NotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_MONITORING = "monitoring_status"
        const val CHANNEL_ALERTS = "trendline_alerts_high"
        const val FOREGROUND_NOTIFICATION_ID = 1001

        private const val GOOGLE_RED_INT = 0xFFEA4335.toInt()
        private const val GOOGLE_GREEN_INT = 0xFF34A853.toInt()
    }

    private val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannels() {
        val statusChannel = NotificationChannel(
            CHANNEL_MONITORING,
            "Monitoring Status",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Persistent foreground notification while monitoring trendlines"
            setShowBadge(false)
        }

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val audioAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val alertChannel = NotificationChannel(
            CHANNEL_ALERTS,
            "Trading Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "High-priority alerts for trendline crosses, entries, and new S/R lines"
            enableVibration(true)
            enableLights(true)
            setSound(soundUri, audioAttrs)
        }

        manager.createNotificationChannel(statusChannel)
        manager.createNotificationChannel(alertChannel)
    }

    fun buildForegroundNotification(text: String): Notification {
        ensureChannels()
        val intent = Intent(context, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(context, CHANNEL_MONITORING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Trading Alerts Active")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pending)
            .build()
    }

    fun sendAlertNotification(candidate: TrendlineCandidate) {
        ensureChannels()
        val (headline, accent) = when (candidate.eventType) {
            EventType.CROSS_RESISTANCE -> "▲${candidate.slotId.name}" to GOOGLE_RED_INT
            EventType.CROSS_SUPPORT -> "▼${candidate.slotId.name}" to GOOGLE_GREEN_INT
            EventType.LONG_ENTRY -> "Long Entry" to GOOGLE_GREEN_INT
            EventType.SHORT_ENTRY -> "Short Entry" to GOOGLE_RED_INT
            EventType.NEW_RESISTANCE -> "New ▲${candidate.slotId.name}" to GOOGLE_RED_INT
            EventType.NEW_SUPPORT -> "New ▼${candidate.slotId.name}" to GOOGLE_GREEN_INT
        }

        val fullTitle = "$headline · ${candidate.symbol}"
        val styledTitle = SpannableString(fullTitle).apply {
            setSpan(
                ForegroundColorSpan(accent),
                0,
                headline.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        val body = String.format(
            Locale.US,
            "Price %.5f | Line %.5f",
            candidate.price,
            candidate.lineValue
        )

        val intent = Intent(context, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            context,
            candidate.symbol.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(accent)
            .setContentTitle(styledTitle)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()

        val id = (System.currentTimeMillis() and 0x7FFFFFFF).toInt()
        manager.notify(id, notification)
    }

    fun sendTestNotification() {
        sendAlertNotification(
            TrendlineCandidate(
                symbol = "SUIUSDT",
                slotId = SlotId.S1,
                side = TrendlineSide.SUPPORT,
                eventType = EventType.CROSS_SUPPORT,
                price = 0.6516,
                lineValue = 0.6512,
                timestampMs = System.currentTimeMillis()
            )
        )
    }
}

private sealed interface PollItemResult {
    data class Success(
        val row: SymbolMonitorRow,
        val crossCandidate: TrendlineCandidate?,
        val specialEvents: List<TrendlineCandidate>
    ) : PollItemResult

    data class Failure(val error: Exception) : PollItemResult
    data object Skipped : PollItemResult
}

class MonitoringForegroundService : Service() {

    companion object {
        const val ACTION_START_GENERAL = "com.trendlinealerts.action.START_GENERAL"
        const val ACTION_STOP_GENERAL = "com.trendlinealerts.action.STOP_GENERAL"
        const val ACTION_SYNC = "com.trendlinealerts.action.SYNC"

        fun startGeneral(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_START_GENERAL
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stopGeneral(context: Context) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_STOP_GENERAL
            }
            runCatching { context.startService(intent) }
        }

        fun syncPriorityService(context: Context, shouldBeRunning: Boolean) {
            val intent = Intent(context, MonitoringForegroundService::class.java).apply {
                action = ACTION_SYNC
            }
            if (shouldBeRunning) {
                ContextCompat.startForegroundService(context, intent)
            } else {
                runCatching { context.startService(intent) }
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollLoopJob: Job? = null

    private val engine = TrendlineEngine()
    private val detector = EventDetector()
    private val dispatcher = AlertDispatcher()
    private val engineStates = ConcurrentHashMap<String, SymbolEngineState>()

    private var consecutiveGlobalFailures = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as TrendlineAlertsApp
        val container = app.container
        val helper = NotificationHelper(this)

        startForeground(
            NotificationHelper.FOREGROUND_NOTIFICATION_ID,
            helper.buildForegroundNotification("Initializing market feed...")
        )

        serviceScope.launch {
            container.watchlistRepository.ensureDefaultWatchlistSeeded()

            when (intent?.action) {
                ACTION_START_GENERAL -> {
                    container.settingsDataStore.setMonitoringEnabled(true)
                    container.monitorStateRepository.updateStatus { it.copy(lastPollError = null) }
                }
                ACTION_STOP_GENERAL -> {
                    container.settingsDataStore.setMonitoringEnabled(false)
                }
            }

            val snapshot = container.settingsDataStore.getSnapshot()
            dispatcher.updateState(snapshot.dispatcherState)
            val hasPriority = container.watchlistRepository.hasAnyPriorityOverride()
            val shouldRun = snapshot.monitoringEnabled || hasPriority

            container.monitorStateRepository.setPriorityServiceActive(hasPriority)

            if (!shouldRun) {
                pollLoopJob?.cancel()
                pollLoopJob = null
                container.monitorStateRepository.updateStatus {
                    it.copy(nextCheckAtMs = 0L, lastPollError = null)
                }
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return@launch
            }

            if (pollLoopJob?.isActive != true) {
                pollLoopJob = launch { runPollingLoop() }
            }
        }

        return START_STICKY
    }

    private suspend fun runPollingLoop() {
        val app = application as TrendlineAlertsApp
        val container = app.container
        val helper = NotificationHelper(this)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        while (serviceScope.isActive) {
            val snapshot = container.settingsDataStore.getSnapshot()
            val entities = container.watchlistRepository.getAllEntities()
            val hasPriority = entities.any { it.isPriorityOverride }
            container.monitorStateRepository.setPriorityServiceActive(hasPriority)

            val generalOn = snapshot.monitoringEnabled
            if (!generalOn && !hasPriority) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return
            }

            val activeEntities = if (generalOn) {
                entities
            } else {
                entities.filter { it.isPriorityOverride }
            }

            val statusLabel = if (generalOn) {
                "Monitoring ${activeEntities.size} assets (${snapshot.alertSettings.timeframe.label})"
            } else {
                "Priority Override: ${activeEntities.size} asset(s)"
            }
            manager.notify(
                NotificationHelper.FOREGROUND_NOTIFICATION_ID,
                helper.buildForegroundNotification(statusLabel)
            )

            val cycleStartMs = System.currentTimeMillis()
            val crossCandidates = mutableListOf<TrendlineCandidate>()
            val specialEvents = mutableListOf<TrendlineCandidate>()
            val existingRows = container.monitorStateRepository.symbolRows.value.associateBy { it.symbol }
            val rowBySymbol = ConcurrentHashMap<String, SymbolMonitorRow>()
            var anySymbolSucceeded = false
            var cycleLastError: String? = null

            for (chunk in activeEntities.chunked(3)) {
                val results: List<PollItemResult> = coroutineScope {
                    chunk.map { entity ->
                        async<PollItemResult> {
                            try {
                                val oneMinCandles = container.marketDataCoordinator.fetch1mCandles(
                                    symbol = entity.symbol,
                                    source = snapshot.dataSource,
                                    marketType = snapshot.marketType,
                                    limit = 10
                                )
                                val latest1m = oneMinCandles.lastOrNull() ?: return@async PollItemResult.Skipped
                                val htfSet = container.htfCandleCache.getCandlesForEvaluation(
                                    symbol = entity.symbol,
                                    timeframe = snapshot.alertSettings.timeframe,
                                    source = snapshot.dataSource,
                                    marketType = snapshot.marketType
                                )
                                if (htfSet.closedCandles.size < 10) return@async PollItemResult.Skipped

                                val engineState = engineStates.getOrPut(entity.symbol) {
                                    SymbolEngineState(entity.symbol)
                                }

                                val engineResult = engine.buildActiveLines(
                                    symbol = entity.symbol,
                                    closedHtfCandles = htfSet.closedCandles,
                                    formingCandle = htfSet.formingCandle ?: latest1m,
                                    state = engineState,
                                    nowMs = cycleStartMs
                                )

                                val eval = detector.evaluate(
                                    symbol = entity.symbol,
                                    latestCandle = latest1m,
                                    lastPrice = latest1m.close,
                                    engineResult = engineResult,
                                    state = engineState,
                                    settings = snapshot.alertSettings,
                                    isPriorityOverride = entity.isPriorityOverride,
                                    nowMs = cycleStartMs
                                )

                                container.debugSnapshotRepository.putSnapshot(eval.debugSnapshot)

                                val dotColor = computeDotColor(
                                    lastCrossSide = eval.lastCrossSide,
                                    nearestSupport = eval.nearestSupport,
                                    nearestResistance = eval.nearestResistance,
                                    proximityPct = snapshot.alertSettings.proximityPct
                                )

                                val nearest = eval.nearestOverall
                                val row = SymbolMonitorRow(
                                    symbol = entity.symbol,
                                    lastPrice = eval.lastPrice,
                                    dotColor = dotColor,
                                    nearestSlot = nearest?.slotId,
                                    nearestSide = nearest?.side,
                                    nearestDistancePct = nearest?.distancePct,
                                    isPriorityOverride = entity.isPriorityOverride,
                                    lastAlertedAtMs = entity.lastAlertedAtMs
                                )
                                PollItemResult.Success(
                                    row = row,
                                    crossCandidate = eval.crossCandidate,
                                    specialEvents = if (entity.isPriorityOverride) eval.specialEvents else emptyList()
                                )
                            } catch (ce: CancellationException) {
                                throw ce
                            } catch (_: SymbolNotListedException) {
                                PollItemResult.Skipped
                            } catch (err: Exception) {
                                PollItemResult.Failure(err)
                            }
                        }
                    }.awaitAll()
                }

                for (res in results) {
                    when (res) {
                        is PollItemResult.Success -> {
                            anySymbolSucceeded = true
                            rowBySymbol[res.row.symbol] = res.row
                            res.crossCandidate?.let { crossCandidates.add(it) }
                            specialEvents.addAll(res.specialEvents)
                        }
                        is PollItemResult.Failure -> {
                            cycleLastError = "${res.error::class.java.simpleName}: ${res.error.message}"
                        }
                        PollItemResult.Skipped -> Unit
                    }
                }

                // Stream partial updates immediately so prices or errors appear after the first chunk
                val partialRows = entities.map { entity ->
                    rowBySymbol[entity.symbol]
                        ?: existingRows[entity.symbol]?.copy(
                            isPriorityOverride = entity.isPriorityOverride,
                            lastAlertedAtMs = entity.lastAlertedAtMs
                        )
                        ?: SymbolMonitorRow(
                            symbol = entity.symbol,
                            lastPrice = null,
                            dotColor = SignalDotColor.GREY,
                            isPriorityOverride = entity.isPriorityOverride,
                            lastAlertedAtMs = entity.lastAlertedAtMs
                        )
                }
                container.monitorStateRepository.updateSymbolRows(partialRows)

                if (anySymbolSucceeded) {
                    container.monitorStateRepository.updateStatus {
                        it.copy(lastPollError = null)
                    }
                } else if (cycleLastError != null) {
                    container.monitorStateRepository.updateStatus {
                        it.copy(lastPollError = cycleLastError)
                    }
                }
            }

            if (anySymbolSucceeded) {
                consecutiveGlobalFailures = 0
                container.monitorStateRepository.updateStatus {
                    it.copy(lastPollError = null)
                }
            } else if (activeEntities.isNotEmpty()) {
                consecutiveGlobalFailures++
                container.monitorStateRepository.updateStatus {
                    it.copy(lastPollError = cycleLastError ?: "No market data returned")
                }

                if (consecutiveGlobalFailures >= 3) {
                    val nextSource = nextSourceAfter(snapshot.dataSource)
                    container.settingsDataStore.setDataSource(nextSource)
                    consecutiveGlobalFailures = 0
                    val msg = "${formatSourceTitle(snapshot.dataSource, snapshot.marketType)} failed repeatedly — switched to ${formatSourceTitle(nextSource, snapshot.marketType)}."
                    container.monitorStateRepository.updateStatus {
                        it.copy(failoverMessage = msg)
                    }
                }
            }

            val mergedRows = entities.map { entity ->
                rowBySymbol[entity.symbol] ?: SymbolMonitorRow(
                    symbol = entity.symbol,
                    lastPrice = null,
                    dotColor = SignalDotColor.GREY,
                    isPriorityOverride = entity.isPriorityOverride,
                    lastAlertedAtMs = entity.lastAlertedAtMs
                )
            }
            container.monitorStateRepository.updateSymbolRows(mergedRows)

            for (event in specialEvents) {
                helper.sendAlertNotification(event)
                container.watchlistRepository.markAlerted(event.symbol, event.timestampMs)
                container.alertLogRepository.insert(
                    AlertLogEntity(
                        symbol = event.symbol,
                        eventType = event.eventType.name,
                        slotId = event.slotId.name,
                        price = event.price,
                        lineValue = event.lineValue,
                        message = "${event.eventType.name} on ${event.slotId.name}",
                        timestampMs = event.timestampMs
                    )
                )
            }

            val dispatchResult = dispatcher.processCycle(
                candidates = crossCandidates,
                generalMonitoringOn = generalOn,
                nowMs = System.currentTimeMillis()
            )

            dispatchResult.emittedCross?.let { emitted ->
                helper.sendAlertNotification(emitted)
                container.settingsDataStore.saveDispatcherState(dispatchResult.updatedState)
                container.watchlistRepository.markAlerted(emitted.symbol, emitted.timestampMs)
                container.alertLogRepository.insert(
                    AlertLogEntity(
                        symbol = emitted.symbol,
                        eventType = emitted.eventType.name,
                        slotId = emitted.slotId.name,
                        price = emitted.price,
                        lineValue = emitted.lineValue,
                        message = "${emitted.eventType.name} on ${emitted.slotId.name}",
                        timestampMs = emitted.timestampMs
                    )
                )
            }

            val disp = dispatcher.state
            val nowMs = System.currentTimeMillis()
            val nextBoundaryMs = ((nowMs / 60_000L) + 1L) * 60_000L + 2_000L
            container.monitorStateRepository.updateStatus {
                it.copy(
                    lastAlertSymbol = disp.lastAlertSymbol,
                    lastAlertTimeMs = disp.lastAlertTimeMs,
                    nextCheckAtMs = nextBoundaryMs
                )
            }

            val waitMs = (nextBoundaryMs - nowMs).coerceIn(5_000L, 62_000L)
            withTimeoutOrNull(waitMs) {
                container.settingsDataStore.settingsFlow.first {
                    it.dataSource != snapshot.dataSource ||
                        it.marketType != snapshot.marketType ||
                        it.alertSettings.timeframe != snapshot.alertSettings.timeframe
                }
            }
        }
    }

    private fun computeDotColor(
        lastCrossSide: TrendlineSide?,
        nearestSupport: NearestLineInfo?,
        nearestResistance: NearestLineInfo?,
        proximityPct: Double
    ): SignalDotColor {
        val entryWindow = (proximityPct * 3.0).coerceAtLeast(0.1)
        return when (lastCrossSide) {
            TrendlineSide.SUPPORT -> {
                val dist = nearestSupport?.distancePct
                if (dist != null && dist >= 0.0 && dist <= entryWindow) {
                    SignalDotColor.GREEN
                } else {
                    SignalDotColor.GREY
                }
            }
            TrendlineSide.RESISTANCE -> {
                val dist = nearestResistance?.distancePct
                if (dist != null && dist <= 0.0 && dist >= -entryWindow) {
                    SignalDotColor.RED
                } else {
                    SignalDotColor.GREY
                }
            }
            null -> SignalDotColor.GREY
        }
    }

    private fun nextSourceAfter(current: DataSourceType): DataSourceType {
        return when (current) {
            DataSourceType.BYBIT -> DataSourceType.BINANCE
            DataSourceType.BINANCE -> DataSourceType.OKX
            DataSourceType.OKX -> DataSourceType.BYBIT
        }
    }

    private fun formatSourceTitle(source: DataSourceType, marketType: MarketType): String {
        return when (source) {
            DataSourceType.BYBIT -> if (marketType == MarketType.PERP) "Bybit Linear Perps" else "Bybit Spot"
            DataSourceType.BINANCE -> if (marketType == MarketType.PERP) "Binance USDT-M Futures" else "Binance Spot"
            DataSourceType.OKX -> if (marketType == MarketType.PERP) "OKX Perps" else "OKX Spot"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val app = context.applicationContext as? TrendlineAlertsApp ?: return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = app.container.settingsDataStore.getSnapshot()
                val hasPriority = app.container.watchlistRepository.hasAnyPriorityOverride()
                if (settings.monitoringEnabled || hasPriority) {
                    MonitoringForegroundService.syncPriorityService(context, true)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
