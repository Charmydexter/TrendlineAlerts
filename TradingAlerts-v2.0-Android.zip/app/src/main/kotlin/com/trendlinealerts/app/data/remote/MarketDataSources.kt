package com.trendlinealerts.app.data.remote

import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.Timeframe
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import retrofit2.HttpException
import retrofit2.http.GET
import retrofit2.http.Query

enum class DataSourceType {
    BYBIT,
    BINANCE,
    OKX
}

enum class MarketType {
    PERP,
    SPOT
}

class SymbolNotListedException(message: String) : Exception(message)

@Serializable
data class BybitResponse(
    @SerialName("retCode") val retCode: Int = -1,
    @SerialName("retMsg") val retMsg: String = "",
    @SerialName("result") val result: BybitResult? = null
)

@Serializable
data class BybitResult(
    @SerialName("list") val list: List<List<String>> = emptyList()
)

@Serializable
data class OkxResponse(
    @SerialName("code") val code: String = "-1",
    @SerialName("msg") val msg: String = "",
    @SerialName("data") val data: List<List<String>> = emptyList()
)

interface BybitApi {
    @GET("v5/market/kline")
    suspend fun getKlines(
        @Query("category") category: String,
        @Query("symbol") symbol: String,
        @Query("interval") interval: String,
        @Query("limit") limit: Int = 200,
        @Query("end") end: Long? = null
    ): BybitResponse
}

interface BinanceFuturesApi {
    @GET("fapi/v1/klines")
    suspend fun getKlines(
        @Query("symbol") symbol: String,
        @Query("interval") interval: String,
        @Query("limit") limit: Int = 200,
        @Query("endTime") endTime: Long? = null
    ): List<List<JsonPrimitive>>
}

interface BinanceSpotApi {
    @GET("api/v3/klines")
    suspend fun getKlines(
        @Query("symbol") symbol: String,
        @Query("interval") interval: String,
        @Query("limit") limit: Int = 200,
        @Query("endTime") endTime: Long? = null
    ): List<List<JsonPrimitive>>
}

interface OkxApi {
    @GET("api/v5/market/candles")
    suspend fun getCandles(
        @Query("instId") instId: String,
        @Query("bar") bar: String,
        @Query("limit") limit: Int = 100,
        @Query("after") after: String? = null
    ): OkxResponse
}

class MarketDataCoordinator(
    private val bybitApi: BybitApi,
    private val binanceFuturesApi: BinanceFuturesApi,
    private val binanceSpotApi: BinanceSpotApi,
    private val okxApi: OkxApi
) {
    companion object {
        /** Max candles one request can return per source. */
        fun pageSize(source: DataSourceType): Int = when (source) {
            DataSourceType.BYBIT -> 1000
            DataSourceType.BINANCE -> 1000
            DataSourceType.OKX -> 100
        }
    }

    /**
     * One page, oldest first. endTimeMs = newest open time wanted (null = latest).
     * The still-forming candle (isClosed = false) is included when it is in range.
     */
    suspend fun fetchCandles(
        symbol: String,
        intervalLabel: String,
        intervalMs: Long,
        source: DataSourceType,
        marketType: MarketType,
        limit: Int,
        endTimeMs: Long? = null
    ): List<Candle> {
        val rawCandles = when (source) {
            DataSourceType.BYBIT -> fetchBybit(symbol, intervalLabel, intervalMs, marketType, limit, endTimeMs)
            DataSourceType.BINANCE -> fetchBinance(symbol, intervalLabel, intervalMs, marketType, limit, endTimeMs)
            DataSourceType.OKX -> fetchOkx(symbol, intervalLabel, intervalMs, marketType, limit, endTimeMs)
        }
        return rawCandles.sortedBy { it.openTimeMs }
    }

    /** Newest `totalBars` candles, fetched page by page (newest to oldest). */
    suspend fun fetchHistory(
        symbol: String,
        intervalLabel: String,
        intervalMs: Long,
        source: DataSourceType,
        marketType: MarketType,
        totalBars: Int
    ): List<Candle> {
        val size = pageSize(source)
        val all = java.util.TreeMap<Long, Candle>()
        var end: Long? = null
        var first = true
        while (all.size < totalBars) {
            if (!first) kotlinx.coroutines.delay(120L) // gentle on rate limits when paging
            val want = minOf(size, totalBars - all.size)
            val page = try {
                fetchCandles(symbol, intervalLabel, intervalMs, source, marketType, want, end)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (first) throw e
                break
            }
            first = false
            if (page.isEmpty()) break
            page.forEach { all[it.openTimeMs] = it }
            if (page.size < want) break
            end = page.first().openTimeMs - 1
        }
        return all.values.toList().takeLast(totalBars)
    }

    suspend fun fetch1mCandles(
        symbol: String,
        source: DataSourceType,
        marketType: MarketType,
        limit: Int = 2
    ): List<Candle> {
        val intervalLabel = when (source) {
            DataSourceType.BYBIT -> "1"
            DataSourceType.BINANCE -> "1m"
            DataSourceType.OKX -> "1m"
        }
        return fetchHistory(symbol, intervalLabel, 60_000L, source, marketType, limit)
    }

    suspend fun fetchHtfCandles(
        symbol: String,
        timeframe: Timeframe,
        source: DataSourceType,
        marketType: MarketType,
        limit: Int = 200
    ): List<Candle> {
        val intervalLabel = when (source) {
            DataSourceType.BYBIT -> timeframe.bybitInterval
            DataSourceType.BINANCE -> timeframe.binanceInterval
            DataSourceType.OKX -> timeframe.okxBar
        }
        return fetchHistory(symbol, intervalLabel, timeframe.minutes * 60_000L, source, marketType, limit)
    }

    private suspend fun fetchBybit(
        symbol: String,
        interval: String,
        intervalMs: Long,
        marketType: MarketType,
        limit: Int,
        endTimeMs: Long?
    ): List<Candle> {
        val category = if (marketType == MarketType.PERP) "linear" else "spot"
        val resp = bybitApi.getKlines(
            category = category,
            symbol = symbol,
            interval = interval,
            limit = limit.coerceAtMost(1000),
            end = endTimeMs
        )
        if (resp.retCode == 10001) {
            throw SymbolNotListedException("Symbol $symbol not listed on Bybit ($category): ${resp.retMsg}")
        }
        if (resp.retCode != 0) {
            throw IllegalStateException("Bybit error ${resp.retCode}: ${resp.retMsg}")
        }
        val list = resp.result?.list.orEmpty()
        if (list.isEmpty()) {
            throw SymbolNotListedException("No Bybit ($category) candles for $symbol")
        }
        val nowMs = System.currentTimeMillis()
        return list.mapNotNull { row ->
            if (row.size < 6) return@mapNotNull null
            val openMs = row[0].toLongOrNull() ?: return@mapNotNull null
            Candle(
                openTimeMs = openMs,
                open = row[1].toDoubleOrNull() ?: return@mapNotNull null,
                high = row[2].toDoubleOrNull() ?: return@mapNotNull null,
                low = row[3].toDoubleOrNull() ?: return@mapNotNull null,
                close = row[4].toDoubleOrNull() ?: return@mapNotNull null,
                volume = row[5].toDoubleOrNull() ?: 0.0,
                isClosed = (openMs + intervalMs) <= nowMs
            )
        }
    }

    private suspend fun fetchBinance(
        symbol: String,
        interval: String,
        intervalMs: Long,
        marketType: MarketType,
        limit: Int,
        endTimeMs: Long?
    ): List<Candle> {
        val rows = try {
            if (marketType == MarketType.PERP) {
                binanceFuturesApi.getKlines(symbol = symbol, interval = interval, limit = limit.coerceAtMost(1000), endTime = endTimeMs)
            } else {
                binanceSpotApi.getKlines(symbol = symbol, interval = interval, limit = limit.coerceAtMost(1000), endTime = endTimeMs)
            }
        } catch (e: HttpException) {
            if (e.code() == 400) {
                throw SymbolNotListedException("Symbol $symbol not listed on Binance ($marketType)")
            }
            throw e
        }

        val nowMs = System.currentTimeMillis()
        return rows.mapNotNull { row ->
            if (row.size < 6) return@mapNotNull null
            val openMs = row[0].content.toLongOrNull() ?: return@mapNotNull null
            Candle(
                openTimeMs = openMs,
                open = row[1].content.toDoubleOrNull() ?: return@mapNotNull null,
                high = row[2].content.toDoubleOrNull() ?: return@mapNotNull null,
                low = row[3].content.toDoubleOrNull() ?: return@mapNotNull null,
                close = row[4].content.toDoubleOrNull() ?: return@mapNotNull null,
                volume = row[5].content.toDoubleOrNull() ?: 0.0,
                isClosed = (openMs + intervalMs) <= nowMs
            )
        }
    }

    private suspend fun fetchOkx(
        symbol: String,
        bar: String,
        intervalMs: Long,
        marketType: MarketType,
        limit: Int,
        endTimeMs: Long?
    ): List<Candle> {
        val instId = toOkxInstId(symbol, marketType)
        val resp = okxApi.getCandles(
            instId = instId,
            bar = bar,
            limit = limit.coerceAtMost(100),
            after = endTimeMs?.let { (it + 1).toString() }
        )
        if (resp.code == "51001") {
            throw SymbolNotListedException("Instrument $instId not listed on OKX")
        }
        if (resp.code != "0") {
            throw IllegalStateException("OKX error ${resp.code}: ${resp.msg}")
        }
        if (resp.data.isEmpty()) {
            throw SymbolNotListedException("No OKX candles for $instId")
        }
        val nowMs = System.currentTimeMillis()
        return resp.data.mapNotNull { row ->
            if (row.size < 6) return@mapNotNull null
            val openMs = row[0].toLongOrNull() ?: return@mapNotNull null
            val confirmFlag = row.getOrNull(8)
            val isClosed = if (confirmFlag != null) confirmFlag == "1" else (openMs + intervalMs) <= nowMs
            Candle(
                openTimeMs = openMs,
                open = row[1].toDoubleOrNull() ?: return@mapNotNull null,
                high = row[2].toDoubleOrNull() ?: return@mapNotNull null,
                low = row[3].toDoubleOrNull() ?: return@mapNotNull null,
                close = row[4].toDoubleOrNull() ?: return@mapNotNull null,
                volume = row[5].toDoubleOrNull() ?: 0.0,
                isClosed = isClosed
            )
        }
    }

    private fun toOkxInstId(symbol: String, marketType: MarketType): String {
        val upper = symbol.uppercase()
        val base = if (upper.endsWith("USDT")) upper.removeSuffix("USDT") else upper
        return if (marketType == MarketType.PERP) "$base-USDT-SWAP" else "$base-USDT"
    }
}
