package com.trendlinealerts.app.data.repository

import com.trendlinealerts.app.data.local.AlertLogDao
import com.trendlinealerts.app.data.local.AlertLogEntity
import com.trendlinealerts.app.data.local.WatchlistDao
import com.trendlinealerts.app.data.local.WatchlistEntity
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.SymbolDebugSnapshot
import com.trendlinealerts.core.model.TrendlineSide
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SignalDotColor {
    GREEN,
    RED,
    GREY
}

data class SymbolMonitorRow(
    val symbol: String,
    val lastPrice: Double? = null,
    val dotColor: SignalDotColor = SignalDotColor.GREY,
    val nearestSlot: SlotId? = null,
    val nearestSide: TrendlineSide? = null,
    val nearestDistancePct: Double? = null,
    val isPriorityOverride: Boolean = false,
    val lastAlertedAtMs: Long = 0L
)

data class MonitorStatusSnapshot(
    val lastAlertSymbol: String? = null,
    val lastAlertTimeMs: Long = 0L,
    val nextCheckAtMs: Long = 0L,
    val failoverMessage: String? = null,
    val lastPollError: String? = null
)

class WatchlistRepository(
    private val dao: WatchlistDao,
    private val coordinator: MarketDataCoordinator
) {
    companion object {
        val DEFAULT_20_SYMBOLS = listOf(
            "GRAMUSDT",
            "HYPEUSDT",
            "XLMUSDT",
            "XRPUSDT",
            "SOLUSDT",
            "ZECUSDT",
            "SUIUSDT",
            "SEIUSDT",
            "HBARUSDT",
            "1INCHUSDT",
            "APTUSDT",
            "CAKEUSDT",
            "ATOMUSDT",
            "FILUSDT",
            "INJUSDT",
            "NEARUSDT",
            "IOTAUSDT",
            "POLUSDT",
            "SANDUSDT",
            "WLDUSDT"
        )
    }

    val entitiesFlow: Flow<List<WatchlistEntity>> = dao.observeAll()

    suspend fun ensureDefaultWatchlistSeeded() {
        if (dao.count() == 0) {
            seedDefault20()
        }
    }

    suspend fun seedDefault20() {
        val now = System.currentTimeMillis()
        val entities = DEFAULT_20_SYMBOLS.mapIndexed { idx, sym ->
            WatchlistEntity(
                symbol = sym,
                sortOrder = idx,
                addedAtMs = now + idx,
                isPriorityOverride = false,
                lastAlertedAtMs = 0L
            )
        }
        dao.insertAll(entities)
    }

    suspend fun resetToDefault20() {
        dao.deleteAll()
        seedDefault20()
    }

    suspend fun getAllEntities(): List<WatchlistEntity> = dao.getAll()

    suspend fun addSymbol(rawInput: String, marketType: MarketType): String {
        val cleaned = rawInput.trim().uppercase().replace("/", "").replace("-", "")
        require(cleaned.isNotBlank()) { "Enter a valid ticker symbol" }
        val normalized = if (cleaned.endsWith("USDT")) cleaned else "${cleaned}USDT"

        // Validate against Bybit first, then Binance/OKX so valid coins across exchanges can be added
        var validated = false
        var lastError: Throwable? = null
        for (source in listOf(DataSourceType.BYBIT, DataSourceType.BINANCE, DataSourceType.OKX)) {
            val result = runCatching {
                coordinator.fetch1mCandles(
                    symbol = normalized,
                    source = source,
                    marketType = marketType,
                    limit = 5
                )
            }
            if (result.isSuccess && result.getOrNull()?.isNotEmpty() == true) {
                validated = true
                break
            } else {
                lastError = result.exceptionOrNull()
            }
        }
        if (!validated) {
            throw IllegalArgumentException(
                "Could not verify $normalized (${lastError?.message ?: "symbol unavailable"})"
            )
        }

        val currentCount = dao.count()
        dao.upsert(
            WatchlistEntity(
                symbol = normalized,
                sortOrder = currentCount,
                addedAtMs = System.currentTimeMillis(),
                isPriorityOverride = false,
                lastAlertedAtMs = 0L
            )
        )
        return normalized
    }

    suspend fun removeSymbol(symbol: String) {
        dao.deleteBySymbol(symbol)
    }

    suspend fun setPriorityOverride(symbol: String, enabled: Boolean) {
        dao.setPriorityOverride(symbol, enabled)
    }

    suspend fun hasAnyPriorityOverride(): Boolean {
        return dao.countPriorityOverrides() > 0
    }

    suspend fun markAlerted(symbol: String, timestampMs: Long) {
        dao.updateLastAlertedAt(symbol, timestampMs)
    }
}

class AlertLogRepository(
    private val dao: AlertLogDao
) {
    val logsFlow: Flow<List<AlertLogEntity>> = dao.observeRecent()

    suspend fun insert(entity: AlertLogEntity) {
        dao.insert(entity)
    }

    suspend fun clearAll() {
        dao.clearAll()
    }
}

class MonitorStateRepository {
    private val _symbolRows = MutableStateFlow<List<SymbolMonitorRow>>(emptyList())
    val symbolRows: StateFlow<List<SymbolMonitorRow>> = _symbolRows.asStateFlow()

    private val _statusFlow = MutableStateFlow(MonitorStatusSnapshot())
    val statusFlow: StateFlow<MonitorStatusSnapshot> = _statusFlow.asStateFlow()

    private val _isPriorityServiceActive = MutableStateFlow(false)
    val isPriorityServiceActive: StateFlow<Boolean> = _isPriorityServiceActive.asStateFlow()

    fun updateSymbolRows(rows: List<SymbolMonitorRow>) {
        _symbolRows.value = rows
    }

    fun updateStatus(transform: (MonitorStatusSnapshot) -> MonitorStatusSnapshot) {
        _statusFlow.value = transform(_statusFlow.value)
    }

    fun setPriorityServiceActive(active: Boolean) {
        _isPriorityServiceActive.value = active
    }
}

class DebugSnapshotRepository {
    private val _snapshots = MutableStateFlow<Map<String, SymbolDebugSnapshot>>(emptyMap())
    val snapshots: StateFlow<Map<String, SymbolDebugSnapshot>> = _snapshots.asStateFlow()

    fun putSnapshot(snapshot: SymbolDebugSnapshot) {
        _snapshots.value = _snapshots.value + (snapshot.symbol to snapshot)
    }
}
