package com.trendlinealerts.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.core.dispatcher.DispatcherPersistedState
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.TrendlineSide
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

@Entity(tableName = "watchlist")
data class WatchlistEntity(
    @PrimaryKey val symbol: String,
    val sortOrder: Int,
    val addedAtMs: Long,
    val isPriorityOverride: Boolean = false,
    val lastAlertedAtMs: Long = 0L,
    val lastCrossSide: String? = null,
    val lastEntryDirection: String? = null
)

@Entity(tableName = "alert_logs")
data class AlertLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val symbol: String,
    val eventType: String,
    val slotId: String,
    val price: Double,
    val lineValue: Double,
    val message: String,
    val timestampMs: Long
)

@Entity(
    tableName = "htf_candles",
    primaryKeys = ["symbol", "timeframe", "source", "marketType", "openTimeMs"]
)
data class HtfCandleEntity(
    val symbol: String,
    val timeframe: String,
    val source: String,
    val marketType: String,
    val openTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM watchlist ORDER BY lastAlertedAtMs DESC, sortOrder ASC, addedAtMs ASC")
    fun observeAll(): Flow<List<WatchlistEntity>>

    @Query("SELECT * FROM watchlist ORDER BY lastAlertedAtMs DESC, sortOrder ASC, addedAtMs ASC")
    suspend fun getAll(): List<WatchlistEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<WatchlistEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: WatchlistEntity)

    @Query("DELETE FROM watchlist WHERE symbol = :symbol")
    suspend fun deleteBySymbol(symbol: String)

    @Query("DELETE FROM watchlist")
    suspend fun deleteAll()

    @Query("UPDATE watchlist SET isPriorityOverride = :enabled WHERE symbol = :symbol")
    suspend fun setPriorityOverride(symbol: String, enabled: Boolean)

    @Query("SELECT COUNT(*) FROM watchlist WHERE isPriorityOverride = 1")
    suspend fun countPriorityOverrides(): Int

    @Query("UPDATE watchlist SET lastAlertedAtMs = :timestampMs WHERE symbol = :symbol")
    suspend fun updateLastAlertedAt(symbol: String, timestampMs: Long)

    @Query("SELECT COUNT(*) FROM watchlist")
    suspend fun count(): Int
}

@Dao
interface AlertLogDao {
    @Query("SELECT * FROM alert_logs ORDER BY timestampMs DESC LIMIT 200")
    fun observeRecent(): Flow<List<AlertLogEntity>>

    @Insert
    suspend fun insert(entity: AlertLogEntity)

    @Query("DELETE FROM alert_logs")
    suspend fun clearAll()
}

@Dao
interface HtfCandleDao {
    @Query(
        "SELECT * FROM htf_candles WHERE symbol = :symbol AND timeframe = :timeframe AND source = :source AND marketType = :marketType ORDER BY openTimeMs ASC"
    )
    suspend fun getCandles(
        symbol: String,
        timeframe: String,
        source: String,
        marketType: String
    ): List<HtfCandleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<HtfCandleEntity>)

    @Query(
        "DELETE FROM htf_candles WHERE symbol = :symbol AND timeframe = :timeframe AND source = :source AND marketType = :marketType AND openTimeMs < :minKeepTimeMs"
    )
    suspend fun trimOlderThan(
        symbol: String,
        timeframe: String,
        source: String,
        marketType: String,
        minKeepTimeMs: Long
    )
}

@Database(
    entities = [WatchlistEntity::class, AlertLogEntity::class, HtfCandleEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchlistDao(): WatchlistDao
    abstract fun alertLogDao(): AlertLogDao
    abstract fun htfCandleDao(): HtfCandleDao

    companion object {
        fun create(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "trading_alerts.db"
            )
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}

data class AppSettingsSnapshot(
    val monitoringEnabled: Boolean = false,
    val dataSource: DataSourceType = DataSourceType.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val alertSettings: AlertSettings = AlertSettings(),
    val dispatcherState: DispatcherPersistedState = DispatcherPersistedState()
)

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "trading_alerts_prefs")

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val MONITORING_ENABLED = booleanPreferencesKey("monitoring_enabled")
        val DATA_SOURCE = stringPreferencesKey("data_source")
        val MARKET_TYPE = stringPreferencesKey("market_type")
        val TIMEFRAME = stringPreferencesKey("timeframe")
        val PROXIMITY_PCT = doublePreferencesKey("proximity_pct")
        val ENABLED_SLOTS = stringSetPreferencesKey("enabled_slots")
        val LAST_ALERT_SYMBOL = stringPreferencesKey("last_alert_symbol")
        val LAST_ALERT_TIME_MS = longPreferencesKey("last_alert_time_ms")
        val LAST_ALERT_SIDE = stringPreferencesKey("last_alert_side")
    }

    val settingsFlow: Flow<AppSettingsSnapshot> = context.dataStore.data.map { prefs ->
        val source = prefs[Keys.DATA_SOURCE]
            ?.let { runCatching { DataSourceType.valueOf(it) }.getOrNull() }
            ?: DataSourceType.BYBIT

        val marketType = prefs[Keys.MARKET_TYPE]
            ?.let { runCatching { MarketType.valueOf(it) }.getOrNull() }
            ?: MarketType.PERP

        val timeframe = prefs[Keys.TIMEFRAME]
            ?.let { runCatching { Timeframe.valueOf(it) }.getOrNull() }
            ?: Timeframe.M3

        val proximity = prefs[Keys.PROXIMITY_PCT] ?: 0.25

        val enabledSlots = prefs[Keys.ENABLED_SLOTS]
            ?.mapNotNull { runCatching { SlotId.valueOf(it) }.getOrNull() }
            ?.toSet()
            ?.takeIf { it.isNotEmpty() }
            ?: SlotId.entries.toSet()

        val lastAlertSide = prefs[Keys.LAST_ALERT_SIDE]
            ?.let { runCatching { TrendlineSide.valueOf(it) }.getOrNull() }

        AppSettingsSnapshot(
            monitoringEnabled = prefs[Keys.MONITORING_ENABLED] ?: false,
            dataSource = source,
            marketType = marketType,
            alertSettings = AlertSettings(
                timeframe = timeframe,
                proximityPct = proximity,
                enabledSlots = enabledSlots
            ),
            dispatcherState = DispatcherPersistedState(
                lastAlertSymbol = prefs[Keys.LAST_ALERT_SYMBOL],
                lastAlertTimeMs = prefs[Keys.LAST_ALERT_TIME_MS] ?: 0L,
                lastAlertSide = lastAlertSide
            )
        )
    }

    suspend fun getSnapshot(): AppSettingsSnapshot = settingsFlow.first()

    suspend fun setMonitoringEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.MONITORING_ENABLED] = enabled }
    }

    suspend fun setDataSource(source: DataSourceType) {
        context.dataStore.edit { it[Keys.DATA_SOURCE] = source.name }
    }

    suspend fun setMarketType(marketType: MarketType) {
        context.dataStore.edit { it[Keys.MARKET_TYPE] = marketType.name }
    }

    suspend fun setTimeframe(timeframe: Timeframe) {
        context.dataStore.edit { it[Keys.TIMEFRAME] = timeframe.name }
    }

    suspend fun setProximityPct(pct: Double) {
        context.dataStore.edit { it[Keys.PROXIMITY_PCT] = pct }
    }

    suspend fun setEnabledSlots(slots: Set<SlotId>) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ENABLED_SLOTS] = slots.map { it.name }.toSet()
        }
    }

    suspend fun saveDispatcherState(state: DispatcherPersistedState) {
        val symbol = state.lastAlertSymbol
        val timeMs = state.lastAlertTimeMs
        val sideName = state.lastAlertSide?.name
        context.dataStore.edit { prefs ->
            if (symbol != null) {
                prefs[Keys.LAST_ALERT_SYMBOL] = symbol
            } else {
                prefs.remove(Keys.LAST_ALERT_SYMBOL)
            }
            prefs[Keys.LAST_ALERT_TIME_MS] = timeMs
            if (sideName != null) {
                prefs[Keys.LAST_ALERT_SIDE] = sideName
            } else {
                prefs.remove(Keys.LAST_ALERT_SIDE)
            }
        }
    }
}
