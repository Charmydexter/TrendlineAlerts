package com.trendlinealerts.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.Timeframe
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

@Entity(tableName = "watchlist")
data class WatchlistEntity(
    @PrimaryKey val symbol: String,
    val sortOrder: Int,
    val addedAtMs: Long,
    val isPriorityOverride: Boolean = false,
    val lastAlertedAtMs: Long = 0L,
    val lastCrossSide: String? = null,
    val lastEntryDirection: String? = null
)

@Entity(tableName = "alert_logs")
data class AlertLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val symbol: String,
    val eventType: String,
    val slotId: String,
    val price: Double,
    val lineValue: Double,
    val message: String,
    val timestampMs: Long
)

@Entity(
    tableName = "htf_candles",
    primaryKeys = ["symbol", "timeframe", "source", "marketType", "openTimeMs"]
)
data class HtfCandleEntity(
    val symbol: String,
    val timeframe: String,
    val source: String,
    val marketType: String,
    val openTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

/** Per-symbol signal memory (JSON of SymbolSignalState). Lets the app resume exactly where it stopped. */
@Entity(tableName = "symbol_state")
data class SymbolStateEntity(
    @PrimaryKey val symbol: String,
    val json: String
)

@Dao
interface SymbolStateDao {
    @Query("SELECT json FROM symbol_state WHERE symbol = :symbol")
    suspend fun get(symbol: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entity: SymbolStateEntity)

    @Query("DELETE FROM symbol_state WHERE symbol = :symbol")
    suspend fun delete(symbol: String)

    @Query("DELETE FROM symbol_state WHERE symbol NOT IN (:keep)")
    suspend fun deleteNotIn(keep: List<String>)

    @Query("DELETE FROM symbol_state")
    suspend fun clear()
}

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM watchlist ORDER BY lastAlertedAtMs DESC, sortOrder ASC, addedAtMs ASC")
    fun observeAll(): Flow<List<WatchlistEntity>>

    @Query("SELECT * FROM watchlist ORDER BY lastAlertedAtMs DESC, sortOrder ASC, addedAtMs ASC")
    suspend fun getAll(): List<WatchlistEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<WatchlistEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: WatchlistEntity)

    @Query("DELETE FROM watchlist WHERE symbol = :symbol")
    suspend fun deleteBySymbol(symbol: String)

    @Query("DELETE FROM watchlist")
    suspend fun deleteAll()

    @Query("UPDATE watchlist SET isPriorityOverride = :enabled WHERE symbol = :symbol")
    suspend fun setPriorityOverride(symbol: String, enabled: Boolean)

    @Query("SELECT COUNT(*) FROM watchlist WHERE isPriorityOverride = 1")
    suspend fun countPriorityOverrides(): Int

    @Query("UPDATE watchlist SET lastAlertedAtMs = :timestampMs WHERE symbol = :symbol")
    suspend fun updateLastAlertedAt(symbol: String, timestampMs: Long)

    @Query("SELECT COUNT(*) FROM watchlist")
    suspend fun count(): Int
}

@Dao
interface AlertLogDao {
    @Query("SELECT * FROM alert_logs ORDER BY timestampMs DESC LIMIT 500")
    fun observeRecent(): Flow<List<AlertLogEntity>>

    @Insert
    suspend fun insert(entity: AlertLogEntity)

    @Query("DELETE FROM alert_logs")
    suspend fun clearAll()

    /** Keeps only the newest `keep` rows so the table can never grow without limit. */
    @Query("DELETE FROM alert_logs WHERE id NOT IN (SELECT id FROM alert_logs ORDER BY timestampMs DESC, id DESC LIMIT :keep)")
    suspend fun trimTo(keep: Int)
}

@Dao
interface HtfCandleDao {
    @Query(
        "SELECT * FROM htf_candles WHERE symbol = :symbol AND timeframe = :timeframe AND source = :source AND marketType = :marketType ORDER BY openTimeMs ASC"
    )
    suspend fun getCandles(
        symbol: String,
        timeframe: String,
        source: String,
        marketType: String
    ): List<HtfCandleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<HtfCandleEntity>)

    @Query(
        "DELETE FROM htf_candles WHERE symbol = :symbol AND timeframe = :timeframe AND source = :source AND marketType = :marketType AND openTimeMs < :minKeepTimeMs"
    )
    suspend fun trimOlderThan(
        symbol: String,
        timeframe: String,
        source: String,
        marketType: String,
        minKeepTimeMs: Long
    )

    @Query("DELETE FROM htf_candles WHERE timeframe != :timeframe")
    suspend fun deleteOtherTimeframes(timeframe: String)

    @Query("DELETE FROM htf_candles WHERE symbol NOT IN (:keep)")
    suspend fun deleteSymbolsNotIn(keep: List<String>)
}

@Database(
    entities = [WatchlistEntity::class, AlertLogEntity::class, HtfCandleEntity::class, SymbolStateEntity::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchlistDao(): WatchlistDao
    abstract fun alertLogDao(): AlertLogDao
    abstract fun htfCandleDao(): HtfCandleDao
    abstract fun symbolStateDao(): SymbolStateDao

    companion object {
        /** Adds the per-symbol signal memory table without touching the watchlist or history. */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `symbol_state` (`symbol` TEXT NOT NULL, `json` TEXT NOT NULL, PRIMARY KEY(`symbol`))"
                )
            }
        }

        fun create(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "trading_alerts.db"
            )
                .addMigrations(MIGRATION_2_3)
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}

data class AppSettingsSnapshot(
    val monitoringEnabled: Boolean = false,
    val dataSource: DataSourceType = DataSourceType.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val alertSettings: AlertSettings = AlertSettings()
)

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "trading_alerts_prefs")

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val MONITORING_ENABLED = booleanPreferencesKey("monitoring_enabled")
        val DATA_SOURCE = stringPreferencesKey("data_source")
        val MARKET_TYPE = stringPreferencesKey("market_type")
        val TIMEFRAME = stringPreferencesKey("timeframe")
        val PROXIMITY_PCT = doublePreferencesKey("proximity_pct")
        val ENABLED_SLOTS = stringSetPreferencesKey("enabled_slots")
    }

    val settingsFlow: Flow<AppSettingsSnapshot> = context.dataStore.data.map { prefs ->
        val source = prefs[Keys.DATA_SOURCE]
            ?.let { runCatching { DataSourceType.valueOf(it) }.getOrNull() }
            ?: DataSourceType.BYBIT

        val marketType = prefs[Keys.MARKET_TYPE]
            ?.let { runCatching { MarketType.valueOf(it) }.getOrNull() }
            ?: MarketType.PERP

        val timeframe = prefs[Keys.TIMEFRAME]
            ?.let { runCatching { Timeframe.valueOf(it) }.getOrNull() }
            ?: Timeframe.M3

        val proximity = prefs[Keys.PROXIMITY_PCT] ?: 0.25

        val enabledSlots = prefs[Keys.ENABLED_SLOTS]
            ?.mapNotNull { runCatching { SlotId.valueOf(it) }.getOrNull() }
            ?.toSet()
            ?.takeIf { it.isNotEmpty() }
            ?: SlotId.entries.toSet()

        AppSettingsSnapshot(
            monitoringEnabled = prefs[Keys.MONITORING_ENABLED] ?: false,
            dataSource = source,
            marketType = marketType,
            alertSettings = AlertSettings(
                timeframe = timeframe,
                proximityPct = proximity,
                enabledSlots = enabledSlots
            )
        )
    }

    suspend fun getSnapshot(): AppSettingsSnapshot = settingsFlow.first()

    suspend fun setMonitoringEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.MONITORING_ENABLED] = enabled }
    }

    suspend fun setDataSource(source: DataSourceType) {
        context.dataStore.edit { it[Keys.DATA_SOURCE] = source.name }
    }

    suspend fun setMarketType(marketType: MarketType) {
        context.dataStore.edit { it[Keys.MARKET_TYPE] = marketType.name }
    }

    suspend fun setTimeframe(timeframe: Timeframe) {
        context.dataStore.edit { it[Keys.TIMEFRAME] = timeframe.name }
    }

    suspend fun setProximityPct(pct: Double) {
        context.dataStore.edit { it[Keys.PROXIMITY_PCT] = pct }
    }

    suspend fun setEnabledSlots(slots: Set<SlotId>) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ENABLED_SLOTS] = slots.map { it.name }.toSet()
        }
    }
}
