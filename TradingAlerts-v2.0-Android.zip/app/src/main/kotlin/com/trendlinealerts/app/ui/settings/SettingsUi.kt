package com.trendlinealerts.app.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.SurfaceVariantDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.core.model.AlertSettings
import com.trendlinealerts.core.model.SlotId
import com.trendlinealerts.core.model.Timeframe
import java.util.Locale
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val dataSource: DataSourceType = DataSourceType.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val alertSettings: AlertSettings = AlertSettings()
)

class SettingsViewModel(
    private val settingsDataStore: SettingsDataStore
) : ViewModel() {

    val uiState: StateFlow<SettingsUiState> = settingsDataStore.settingsFlow
        .map { snapshot ->
            SettingsUiState(
                dataSource = snapshot.dataSource,
                marketType = snapshot.marketType,
                alertSettings = snapshot.alertSettings
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = SettingsUiState()
        )

    fun setDataSource(source: DataSourceType) {
        viewModelScope.launch {
            settingsDataStore.setDataSource(source)
        }
    }

    fun setMarketType(marketType: MarketType) {
        viewModelScope.launch {
            settingsDataStore.setMarketType(marketType)
        }
    }

    fun setTimeframe(timeframe: Timeframe) {
        viewModelScope.launch {
            settingsDataStore.setTimeframe(timeframe)
        }
    }

    fun setProximityPct(pct: Double) {
        viewModelScope.launch {
            settingsDataStore.setProximityPct(pct)
        }
    }

    fun toggleSlot(slot: SlotId) {
        viewModelScope.launch {
            val current = settingsDataStore.getSnapshot().alertSettings.enabledSlots
            val updated = if (current.contains(slot)) current - slot else current + slot
            settingsDataStore.setEnabledSlots(updated)
        }
    }

    class Factory(
        private val settingsDataStore: SettingsDataStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(settingsDataStore) as T
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onSendTestNotification: () -> Unit,
    onOpenBatteryOptimization: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var tfMenuExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Settings",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            SettingsCard(title = "Market Data Source") {
                DataSourceType.entries.forEach { source ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setDataSource(source) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = state.dataSource == source,
                            onClick = { viewModel.setDataSource(source) },
                            colors = RadioButtonDefaults.colors(selectedColor = PrimaryBlue)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (source) {
                                DataSourceType.BYBIT -> "Bybit (Default)"
                                DataSourceType.BINANCE -> "Binance"
                                DataSourceType.OKX -> "OKX"
                            },
                            color = TextPrimary,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        item {
            SettingsCard(title = "Market Type (Perp / Spot)") {
                MarketType.entries.forEach { market ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setMarketType(market) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = state.marketType == market,
                            onClick = { viewModel.setMarketType(market) },
                            colors = RadioButtonDefaults.colors(selectedColor = PrimaryBlue)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (market) {
                                MarketType.PERP -> "Perpetual Futures (Perp)"
                                MarketType.SPOT -> "Spot"
                            },
                            color = TextPrimary,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        item {
            SettingsCard(title = "Higher Timeframe (HTF)") {
                Box {
                    OutlinedButton(
                        onClick = { tfMenuExpanded = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "Selected HTF: ${state.alertSettings.timeframe.label}",
                            color = TextPrimary,
                            fontSize = 15.sp
                        )
                    }
                    DropdownMenu(
                        expanded = tfMenuExpanded,
                        onDismissRequest = { tfMenuExpanded = false },
                        modifier = Modifier.background(SurfaceVariantDark)
                    ) {
                        Timeframe.entries.forEach { tf ->
                            DropdownMenuItem(
                                text = { Text(tf.label, color = TextPrimary) },
                                onClick = {
                                    tfMenuExpanded = false
                                    viewModel.setTimeframe(tf)
                                }
                            )
                        }
                    }
                }
            }
        }

        item {
            SettingsCard(title = "Entry Dot Proximity") {
                val pct = state.alertSettings.proximityPct
                Text(
                    text = String.format(
                        Locale.US,
                        "Base threshold: %.2f%% (Green/Red entry zone within %.2f%%)",
                        pct,
                        pct * 3.0
                    ),
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Slider(
                    value = pct.toFloat().coerceIn(0.05f, 2.0f),
                    onValueChange = { viewModel.setProximityPct(it.toDouble()) },
                    valueRange = 0.05f..2.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = PrimaryBlue,
                        activeTrackColor = PrimaryBlue,
                        inactiveTrackColor = OutlineDark
                    )
                )
            }
        }

        item {
            SettingsCard(title = "Enabled Trendline Slots") {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SlotId.entries.forEach { slot ->
                        val selected = state.alertSettings.enabledSlots.contains(slot)
                        val isResistance = slot.name.startsWith("R")
                        val accentColor = if (isResistance) GoogleRed else GoogleGreen

                        FilterChip(
                            selected = selected,
                            onClick = { viewModel.toggleSlot(slot) },
                            label = {
                                Text(
                                    text = if (isResistance) "▲${slot.name}" else "▼${slot.name}",
                                    color = if (selected) Color.White else TextSecondary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor.copy(alpha = 0.85f),
                                containerColor = SurfaceVariantDark
                            )
                        )
                    }
                }
            }
        }

        item {
            SettingsCard(title = "Diagnostics & Background Reliability") {
                Button(
                    onClick = onSendTestNotification,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Icon(imageVector = Icons.Filled.NotificationsActive, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Send Test Notification")
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = onOpenBatteryOptimization,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.BatteryChargingFull,
                        contentDescription = null,
                        tint = GoogleGreen
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Battery Optimization Setup", color = TextPrimary)
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun BatteryOptimizationScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val isIgnoring = isIgnoringBatteryOptimizations(context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }
            Text(
                text = "Battery Optimization",
                color = TextPrimary,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (isIgnoring) {
                        "Status: Unrestricted (Battery optimization disabled)"
                    } else {
                        "Status: Optimized (Android may pause background alerts)"
                    },
                    color = if (isIgnoring) GoogleGreen else GoogleRed,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Allow unrestricted background battery usage so general monitoring and Priority Override alerts keep running reliably when the screen is off.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Button(
                    onClick = { openBatterySettings(context) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Open Battery Settings")
                }
            }
        }
    }
}

private fun isIgnoringBatteryOptimizations(context: Context): Boolean {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}

private fun openBatterySettings(context: Context) {
    val requestIntent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
        data = Uri.parse("package:${context.packageName}")
    }
    runCatching {
        context.startActivity(requestIntent)
    }.onFailure {
        val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        runCatching { context.startActivity(fallback) }
    }
}
