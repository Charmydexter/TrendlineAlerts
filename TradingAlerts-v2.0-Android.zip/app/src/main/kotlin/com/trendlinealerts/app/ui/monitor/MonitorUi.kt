package com.trendlinealerts.app.ui.monitor

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.trendlinealerts.app.data.local.SettingsDataStore
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.app.data.repository.MonitorStateRepository
import com.trendlinealerts.app.data.repository.SignalDotColor
import com.trendlinealerts.app.data.repository.SymbolMonitorRow
import com.trendlinealerts.app.data.repository.WatchlistRepository
import com.trendlinealerts.app.ui.theme.BgDark
import com.trendlinealerts.app.ui.theme.GoogleGreen
import com.trendlinealerts.app.ui.theme.GoogleRed
import com.trendlinealerts.app.ui.theme.OutlineDark
import com.trendlinealerts.app.ui.theme.PrimaryBlue
import com.trendlinealerts.app.ui.theme.SignalGreen
import com.trendlinealerts.app.ui.theme.SignalGrey
import com.trendlinealerts.app.ui.theme.SignalRed
import com.trendlinealerts.app.ui.theme.SurfaceDark
import com.trendlinealerts.app.ui.theme.TextPrimary
import com.trendlinealerts.app.ui.theme.TextSecondary
import com.trendlinealerts.app.ui.theme.WarningAmber
import com.trendlinealerts.core.model.Timeframe
import com.trendlinealerts.core.model.TrendlineSide
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class MonitorUiState(
    val isGeneralMonitoring: Boolean = false,
    val isServiceActive: Boolean = false,
    val isPriorityActive: Boolean = false,
    val dataSource: DataSourceType = DataSourceType.BYBIT,
    val marketType: MarketType = MarketType.PERP,
    val timeframe: Timeframe = Timeframe.M3,
    val lastAlertSymbol: String? = null,
    val lastAlertTimeMs: Long = 0L,
    val nextCheckAtMs: Long = 0L,
    val failoverMessage: String? = null,
    val lastPollError: String? = null,
    val rows: List<SymbolMonitorRow> = emptyList()
)

class MonitorViewModel(
    settingsDataStore: SettingsDataStore,
    watchlistRepository: WatchlistRepository,
    monitorStateRepository: MonitorStateRepository
) : ViewModel() {

    val uiState: StateFlow<MonitorUiState> = combine(
        settingsDataStore.settingsFlow,
        watchlistRepository.entitiesFlow,
        monitorStateRepository.symbolRows,
        monitorStateRepository.statusFlow,
        monitorStateRepository.isPriorityServiceActive
    ) { settings, entities, liveRows, status, priorityServiceActive ->
        val liveBySymbol = liveRows.associateBy { it.symbol }
        val mergedRows = entities.map { entity ->
            val live = liveBySymbol[entity.symbol]
            live?.copy(
                isPriorityOverride = entity.isPriorityOverride,
                lastAlertedAtMs = entity.lastAlertedAtMs
            ) ?: SymbolMonitorRow(
                symbol = entity.symbol,
                lastPrice = null,
                dotColor = SignalDotColor.GREY,
                nearestSlot = null,
                nearestSide = null,
                nearestDistancePct = null,
                isPriorityOverride = entity.isPriorityOverride,
                lastAlertedAtMs = entity.lastAlertedAtMs
            )
        }

        val hasPriority = entities.any { it.isPriorityOverride }
        MonitorUiState(
            isGeneralMonitoring = settings.monitoringEnabled,
            isServiceActive = settings.monitoringEnabled || priorityServiceActive,
            isPriorityActive = hasPriority,
            dataSource = settings.dataSource,
            marketType = settings.marketType,
            timeframe = settings.alertSettings.timeframe,
            lastAlertSymbol = status.lastAlertSymbol,
            lastAlertTimeMs = status.lastAlertTimeMs,
            nextCheckAtMs = status.nextCheckAtMs,
            failoverMessage = status.failoverMessage,
            lastPollError = status.lastPollError,
            rows = mergedRows
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = MonitorUiState()
    )

    class Factory(
        private val settingsDataStore: SettingsDataStore,
        private val watchlistRepository: WatchlistRepository,
        private val monitorStateRepository: MonitorStateRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MonitorViewModel(
                settingsDataStore = settingsDataStore,
                watchlistRepository = watchlistRepository,
                monitorStateRepository = monitorStateRepository
            ) as T
        }
    }
}

@Composable
fun MonitorScreen(
    viewModel: MonitorViewModel,
    onToggleGeneralMonitoring: (Boolean) -> Unit,
    onTogglePriorityOverride: (String, Boolean) -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(1_000L)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "monitoring_button") {
            Button(
                onClick = { onToggleGeneralMonitoring(!state.isGeneralMonitoring) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (state.isGeneralMonitoring) GoogleRed else PrimaryBlue,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = if (state.isGeneralMonitoring) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (state.isGeneralMonitoring) "STOP MONITORING" else "START MONITORING",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.6.sp
                )
            }
        }

        if (!state.isGeneralMonitoring && state.isPriorityActive) {
            item(key = "priority_banner") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Text(
                        text = "General monitoring is OFF — Priority override assets remain active.",
                        color = GoogleGreen,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
            }
        }

        if (!state.failoverMessage.isNullOrBlank()) {
            item(key = "failover_banner") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B210B))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null,
                            tint = WarningAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = state.failoverMessage.orEmpty(),
                            color = Color(0xFFFDE68A),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        if (!state.lastPollError.isNullOrBlank()) {
            item(key = "poll_error") {
                Text(
                    text = "Last poll error: ${state.lastPollError}",
                    color = GoogleRed,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item(key = "status_card") {
            StatusCard(state = state, nowMs = nowMs)
        }

        item(key = "table_header") {
            Column(modifier = Modifier.fillMaxWidth()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SYMBOL / OVERRIDE",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "PRICE / NEAREST LINE",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.8.sp
                    )
                }
                HorizontalDivider(color = OutlineDark, thickness = 1.dp)
            }
        }

        items(items = state.rows, key = { it.symbol }) { row ->
            SymbolRowItem(
                row = row,
                onTogglePriorityOverride = { enabled ->
                    onTogglePriorityOverride(row.symbol, enabled)
                }
            )
            HorizontalDivider(color = OutlineDark.copy(alpha = 0.6f), thickness = 1.dp)
        }
    }
}

@Composable
private fun StatusCard(
    state: MonitorUiState,
    nowMs: Long
) {
    val cooldownRemainingSec = if (state.lastAlertTimeMs > 0L) {
        ((60_000L - (nowMs - state.lastAlertTimeMs)).coerceAtLeast(0L) / 1_000L)
    } else {
        0L
    }
    val nextCheckRemainingSec = if (state.nextCheckAtMs > nowMs) {
        ((state.nextCheckAtMs - nowMs) / 1_000L)
    } else {
        0L
    }

    val lastAlertText = when {
        state.lastAlertSymbol.isNullOrBlank() -> "None"
        state.isGeneralMonitoring -> "${state.lastAlertSymbol} (locked until another asset alerts)"
        else -> "${state.lastAlertSymbol} (override mode)"
    }
    val nextAllowedText = if (cooldownRemainingSec <= 0L) {
        "00:00 (Ready)"
    } else {
        formatMmSs(cooldownRemainingSec)
    }
    val nextCheckText = if (!state.isServiceActive) {
        "Paused"
    } else {
        formatMmSs(nextCheckRemainingSec)
    }
    val sourceLabel = formatSourceLabel(state.dataSource, state.marketType)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusLine(label = "Last alert", value = lastAlertText)
            StatusLine(label = "Next alert allowed in", value = nextAllowedText)
            StatusLine(label = "Next check in", value = nextCheckText)
            StatusLine(label = "Data source", value = sourceLabel)
            StatusLine(label = "HTF", value = state.timeframe.label)
        }
    }
}

@Composable
private fun StatusLine(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 13.sp,
            modifier = Modifier.weight(0.45f)
        )
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(0.55f)
        )
    }
}

@Composable
private fun SymbolRowItem(
    row: SymbolMonitorRow,
    onTogglePriorityOverride: (Boolean) -> Unit
) {
    val dotColor = when (row.dotColor) {
        SignalDotColor.GREEN -> SignalGreen
        SignalDotColor.RED -> SignalRed
        SignalDotColor.GREY -> SignalGrey
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp, horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(dotColor)
        )

        Spacer(modifier = Modifier.width(8.dp))

        Switch(
            checked = row.isPriorityOverride,
            onCheckedChange = onTogglePriorityOverride,
            modifier = Modifier.scale(0.75f),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = GoogleGreen,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = OutlineDark
            )
        )

        Spacer(modifier = Modifier.width(6.dp))

        Text(
            text = row.symbol,
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )

        Column(
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = row.lastPrice?.let { formatPrice(it) } ?: "--",
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            val slot = row.nearestSlot
            val side = row.nearestSide
            val distPct = row.nearestDistancePct
            if (slot != null && side != null && distPct != null) {
                val isResistance = side == TrendlineSide.RESISTANCE
                val icon = if (isResistance) "🔺" else "🔻"
                val lineColor = if (isResistance) GoogleRed else GoogleGreen
                val sign = if (distPct >= 0.0) "+" else ""
                val formattedPct = String.format(Locale.US, "%s%.2f%%", sign, distPct)

                Text(
                    text = "$icon${slot.name} $formattedPct",
                    color = lineColor,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            } else {
                Text(
                    text = "--",
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            }
        }
    }
}

private fun formatSourceLabel(
    source: DataSourceType,
    marketType: MarketType
): String {
    return when (source) {
        DataSourceType.BYBIT -> if (marketType == MarketType.PERP) "Bybit Linear Perps" else "Bybit Spot"
        DataSourceType.BINANCE -> if (marketType == MarketType.PERP) "Binance USDT-M Futures" else "Binance Spot"
        DataSourceType.OKX -> if (marketType == MarketType.PERP) "OKX Perps" else "OKX Spot"
    }
}

private fun formatMmSs(totalSeconds: Long): String {
    val safe = totalSeconds.coerceAtLeast(0L)
    val mins = safe / 60L
    val secs = safe % 60L
    return String.format(Locale.US, "%02d:%02d", mins, secs)
}

private fun formatPrice(price: Double): String {
    return when {
        price >= 1_000.0 -> String.format(Locale.US, "%.2f", price)
        price >= 1.0 -> String.format(Locale.US, "%.4f", price)
        price >= 0.01 -> String.format(Locale.US, "%.5f", price)
        else -> String.format(Locale.US, "%.6f", price)
    }
}
