package com.trendlinealerts.app.data.cache

import com.trendlinealerts.app.data.local.HtfCandleDao
import com.trendlinealerts.app.data.local.HtfCandleEntity
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.Timeframe

data class HtfCandleSet(
    val closedCandles: List<Candle>,
    val formingCandle: Candle?
)

class HtfCandleCache(
    private val dao: HtfCandleDao,
    private val coordinator: MarketDataCoordinator
) {
    companion object {
        private const val MAX_CLOSED_HISTORY = 250
    }

    suspend fun getCandlesForEvaluation(
        symbol: String,
        timeframe: Timeframe,
        source: DataSourceType,
        marketType: MarketType
    ): HtfCandleSet {
        val cached = dao.getCandles(
            symbol = symbol,
            timeframe = timeframe.name,
            source = source.name,
            marketType = marketType.name
        ).map {
            Candle(
                openTimeMs = it.openTimeMs,
                open = it.open,
                high = it.high,
                low = it.low,
                close = it.close,
                volume = it.volume,
                isClosed = true
            )
        }

        val lastCachedTimeMs = cached.lastOrNull()?.openTimeMs ?: 0L
        val tfMs = timeframe.minutes * 60_000L
        val nowMs = System.currentTimeMillis()
        val currentBucketStartMs = (nowMs / tfMs) * tfMs

        val needsFullBackfill = cached.size < 150
        val fetchLimit = if (needsFullBackfill) {
            200
        } else {
            val missingBars = (((currentBucketStartMs - lastCachedTimeMs) / tfMs).toInt() + 4)
                .coerceIn(5, 200)
            missingBars
        }

        val fresh = coordinator.fetchHtfCandles(
            symbol = symbol,
            timeframe = timeframe,
            source = source,
            marketType = marketType,
            limit = fetchLimit
        )

        val closedFresh = fresh.filter { it.isClosed }
        val formingFresh = fresh.lastOrNull { !it.isClosed }

        if (closedFresh.isNotEmpty()) {
            val entities = closedFresh.map {
                HtfCandleEntity(
                    symbol = symbol,
                    timeframe = timeframe.name,
                    source = source.name,
                    marketType = marketType.name,
                    openTimeMs = it.openTimeMs,
                    open = it.open,
                    high = it.high,
                    low = it.low,
                    close = it.close,
                    volume = it.volume
                )
            }
            dao.upsertAll(entities)

            val minKeepTimeMs = (closedFresh.last().openTimeMs - (MAX_CLOSED_HISTORY * tfMs))
                .coerceAtLeast(0L)
            dao.trimOlderThan(
                symbol = symbol,
                timeframe = timeframe.name,
                source = source.name,
                marketType = marketType.name,
                minKeepTimeMs = minKeepTimeMs
            )
        }

        val mergedMap = linkedMapOf<Long, Candle>()
        cached.forEach { mergedMap[it.openTimeMs] = it }
        closedFresh.forEach { mergedMap[it.openTimeMs] = it }

        val mergedClosed = mergedMap.values
            .sortedBy { it.openTimeMs }
            .takeLast(MAX_CLOSED_HISTORY)

        return HtfCandleSet(
            closedCandles = mergedClosed,
            formingCandle = formingFresh
        )
    }
}
