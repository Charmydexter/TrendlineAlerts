package com.trendlinealerts.app.data.cache

import com.trendlinealerts.app.data.local.HtfCandleDao
import com.trendlinealerts.app.data.local.HtfCandleEntity
import com.trendlinealerts.app.data.remote.DataSourceType
import com.trendlinealerts.app.data.remote.MarketDataCoordinator
import com.trendlinealerts.app.data.remote.MarketType
import com.trendlinealerts.core.model.Candle
import com.trendlinealerts.core.model.Timeframe
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Closed higher-timeframe candles per (symbol, timeframe, source, market).
 *  - kept in memory and in Room (survives restarts and offline periods);
 *  - the network is only used when a new HTF candle has closed since the last stored one,
 *    or when the stored history is too short (first run, new source, long offline gap);
 *  - the still-forming candle is never returned, so lines cannot repaint.
 */
class HtfCandleCache(
    private val dao: HtfCandleDao,
    private val coordinator: MarketDataCoordinator
) {
    companion object {
        /** Closed bars kept per series. The pivot stack is path dependent, so more history = closer to TradingView. */
        const val TARGET_BARS = 1000
        private const val MIN_BARS_OK = 900
    }

    private val memory = ConcurrentHashMap<String, List<Candle>>()
    private val locks = ConcurrentHashMap<String, Mutex>()

    private fun key(symbol: String, tf: Timeframe, source: DataSourceType, market: MarketType) =
        "$symbol|${tf.name}|${source.name}|${market.name}"

    suspend fun getClosedCandles(
        symbol: String,
        timeframe: Timeframe,
        source: DataSourceType,
        marketType: MarketType,
        nowMs: Long = System.currentTimeMillis()
    ): List<Candle> {
        val k = key(symbol, timeframe, source, marketType)
        val mutex = locks.getOrPut(k) { Mutex() }
        return mutex.withLock {
            val tfMs = timeframe.ms
            var cached = memory[k] ?: dao.getCandles(symbol, timeframe.name, source.name, marketType.name)
                .map { it.toCandle() }
            val expectedLastClosedOpen = (nowMs / tfMs) * tfMs - tfMs
            val lastCached = cached.lastOrNull()?.openTimeMs ?: 0L

            val barsToFetch = when {
                cached.size < MIN_BARS_OK -> TARGET_BARS                       // first run / new source / too short
                lastCached < expectedLastClosedOpen -> {
                    val missing = ((expectedLastClosedOpen - lastCached) / tfMs).toInt()
                    (missing + 2).coerceAtMost(TARGET_BARS)                      // +2: re-read the last bars, they may have been unfinished
                }
                else -> 0
            }

            if (barsToFetch > 0) {
                val fresh = coordinator.fetchHtfCandles(symbol, timeframe, source, marketType, barsToFetch)
                val closedFresh = fresh.filter { it.openTimeMs + tfMs <= nowMs }
                if (closedFresh.isNotEmpty()) {
                    dao.upsertAll(closedFresh.map { it.toEntity(symbol, timeframe, source, marketType) })
                    val merged = java.util.TreeMap<Long, Candle>()
                    cached.forEach { merged[it.openTimeMs] = it }
                    closedFresh.forEach { merged[it.openTimeMs] = it }
                    cached = merged.values.toList().takeLast(TARGET_BARS)
                    dao.trimOlderThan(
                        symbol = symbol,
                        timeframe = timeframe.name,
                        source = source.name,
                        marketType = marketType.name,
                        minKeepTimeMs = cached.first().openTimeMs
                    )
                }
            }
            memory[k] = cached
            cached
        }
    }

    /** Drops stored history that can never be used again (other timeframes, removed symbols). */
    suspend fun prune(keepSymbols: Collection<String>, timeframe: Timeframe) {
        if (keepSymbols.isEmpty()) return
        dao.deleteOtherTimeframes(timeframe.name)
        dao.deleteSymbolsNotIn(keepSymbols.toList())
        memory.keys.filter { it.split("|").getOrNull(1) != timeframe.name || it.substringBefore("|") !in keepSymbols }
            .forEach { memory.remove(it) }
    }

    private fun HtfCandleEntity.toCandle() = Candle(openTimeMs, open, high, low, close, volume, true)

    private fun Candle.toEntity(symbol: String, tf: Timeframe, source: DataSourceType, market: MarketType) =
        HtfCandleEntity(symbol, tf.name, source.name, market.name, openTimeMs, open, high, low, close, volume)
}
