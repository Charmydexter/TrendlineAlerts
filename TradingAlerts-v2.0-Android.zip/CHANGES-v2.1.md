# TradingAlerts v2.1: what changed

Engine (core): exact Pine port. Strict 5-bar pivot chain, pending-pivot stack, R1-R3 / S1-S3 from the 4 newest pivots,
bar-based slope (elapsed time / HTF length), swap = one skipped bar, lines never killed, closed HTF bars only.

Signals (per closed 1m bar, each bar processed once)
- General assets: LONG / SHORT using the two lowest supports / two highest resistances, arming-bar rule, only the
  opposite signal (or a new lower support / higher resistance) resets.
- Positioned assets: crosses only (support cross <-> resistance cross re-arm each other), plus New R1 / S1 alerts.
- Touch = bar range reaches the line while the line was on the approach side of the bar open.

Delivery: general long/short clustered in ONE expandable notification per minute; positioned alerts separate;
missed-while-offline catch-up (one MISSED notification per positioned asset, log-only for general assets);
Stop / Start button on the persistent notification (plus a small "Monitoring is OFF - Start" notification).

Data: 2 candles per symbol per minute, HTF only when a new HTF bar closes, 5000 HTF bars stored (paged backfill, closer to TradingView's deep history),
per-symbol signal state persisted, old rows cleaned automatically, user-selectable default source that is
re-probed every minute while on a fallback and restored as soon as it answers.

Not verified in the build sandbox: compilation (no Gradle / Kotlin there). The logic scenarios in the unit tests
were cross-checked with a Python mirror. Your GitHub Actions run (:core:test then assembleDebug) is the real check.
